'use strict';
// ============================================================================
// v1.85.6 — Stability fixes (comprehensive inspection pass)
//
// Scope: provably behavior-preserving fast paths for idempotent "ensure"
// initializers that were being re-executed tens of thousands of times per
// game day, plus day-1 duplicate modal queue suppression.
// No RNG is consumed, skipped, or reordered by this layer. No simulation
// values, thresholds, or game rules are changed. Save format is untouched.
// ============================================================================
(function() {
    // --------------------------------------------------------------------
    // 1) ensureV1327State — profiled at ~12k calls/day during simulation.
    //    The body only fills default fields on game.signatureDevelopment
    //    .hulls[hid] for each V1326_SIGNATURE_SPECS key (spreading existing
    //    values last), so once every hull entry is structurally complete the
    //    call is a no-op. ensureV1326SignatureState (called first by the
    //    original) is also idempotent; its only mutating act is deleting
    //    impossible `installed` entries, so the fast path stays exact by
    //    verifying none exist.
    // --------------------------------------------------------------------
    function v1327Ready() {
        try {
            const se = game?.signatureEquipment;
            if (!se || !se.owned || !se.installed) return false;
            for (const [hid, mid] of Object.entries(se.installed)) {
                if (!HULLS[hid] || !SHIP_MODULES[mid]?.signature || SHIP_MODULES[mid].signatureHull !== hid) return false;
            }
            const hulls = game?.signatureDevelopment?.hulls;
            if (!hulls) return false;
            for (const hid of Object.keys(V1326_SIGNATURE_SPECS)) {
                const h = hulls[hid];
                if (!h) return false;
                if (!Number.isFinite(h.xp) || !Number.isFinite(h.battles) || !Number.isFinite(h.victories) || !Number.isFinite(h.losses) || !Number.isFinite(h.captureRolls)) return false;
                const l = h.lessons;
                if (!l || !Number.isFinite(l.assault) || !Number.isFinite(l.defense) || !Number.isFinite(l.maneuver) || !Number.isFinite(l.command)) return false;
            }
            return true;
        } catch (_) {
            return false;
        }
    }
    if (typeof ensureV1327State === 'function') {
        const base = ensureV1327State;
        ensureV1327State = function() {
            if (v1327Ready()) return;
            return base.apply(this, arguments);
        };
    }

    // --------------------------------------------------------------------
    // 2) ensureV133State — ~12k calls/day. The body re-merges default force
    //    definitions over existing state (existing values win) and clones
    //    task forces per call. Once every defined force exists with all of
    //    its defined task forces present, the call is a no-op.
    // --------------------------------------------------------------------
    function v133Ready() {
        try {
            const pf = game?.gm?.parallelForces;
            if (!pf) return false;
            if (!Number.isFinite(game.gm.lastV133Day)) return false;
            for (const [id, d] of Object.entries(V133_PARALLEL_FORCE_DEFS)) {
                const f = pf[id];
                if (!f || typeof f.name !== 'string' || !Array.isArray(f.taskForces) || !Array.isArray(f.history)) return false;
                for (const t of d.taskForces) {
                    const ft = f.taskForces.find(x => x && x.id === t.id);
                    if (!ft || typeof ft.name !== 'string' || !Number.isFinite(ft.power)) return false;
                }
            }
            return true;
        } catch (_) {
            return false;
        }
    }
    if (typeof ensureV133State === 'function') {
        const base = ensureV133State;
        ensureV133State = function() {
            if (v133Ready()) return;
            return base.apply(this, arguments);
        };
    }

    // --------------------------------------------------------------------
    // 3) v163State — ~43k calls/day (via v163ActivePolicy and friends), each
    //    re-running the reinsurer default merge and v163EnsureTreaty for
    //    every insurer (~173k treaty calls/day). All of that work is
    //    idempotent default-filling: existing entries are spread last and
    //    always win. Once every reinsurer and treaty exists, the merge is a
    //    no-op. The cheap container guards and lastDay default are kept by
    //    requiring them in the predicate.
    // --------------------------------------------------------------------
    function v163Ready() {
        try {
            const x = game?.gm?.insuranceReinsurance;
            if (!x) return false;
            if (!x.policies || !x.claims || !Array.isArray(x.claimOrder) || !x.reinsurers || !x.treaties || !Array.isArray(x.history) || !x.processed || !x.metrics) return false;
            if (!Number.isFinite(x.lastDay) || !x.nextClaim) return false;
            for (const id of Object.keys(V163_REINSURERS)) {
                const r = x.reinsurers[id];
                if (!r || typeof r.name !== 'string' || !Array.isArray(r.appetite) || !Number.isFinite(r.capital) || !Number.isFinite(r.lastReview) || !r.underwriting) return false;
            }
            for (const id of Object.keys(V19_INSURERS || {})) {
                const t = x.treaties[`treaty:${id}`];
                if (!t || !t.status || !Number.isFinite(t.quota) || !Number.isFinite(t.nextPremium)) return false;
            }
            return true;
        } catch (_) {
            return false;
        }
    }
    if (typeof v163State === 'function') {
        const base = v163State;
        v163State = function() {
            if (v163Ready()) return game.gm.insuranceReinsurance;
            return base.apply(this, arguments);
        };
    }

    // --------------------------------------------------------------------
    // 4) Day-1 duplicate major-event modals. Every faction fires its own
    //    election event at game start with a per-faction dedup key, so the
    //    same-titled modal ("総選挙" x5 etc.) had to be dismissed repeatedly.
    //    Events are still recorded to game.gm.majorEvents and the news log
    //    exactly as before; only the on-screen modal queue is collapsed by
    //    title so each distinct title appears once per batch.
    // --------------------------------------------------------------------
    if (typeof v138MajorEvent === 'function') {
        const base = v138MajorEvent;
        v138MajorEvent = function() {
            const out = base.apply(this, arguments);
            try {
                const q = window.__v138MajorQueue;
                if (Array.isArray(q) && q.length > 1) {
                    const root = document.getElementById('v138MajorEventRoot');
                    const shownTitle = root?.classList?.contains('show') ? document.getElementById('v138MajorTitle')?.textContent : null;
                    const seen = new Set(shownTitle ? [shownTitle] : []);
                    window.__v138MajorQueue = q.filter(e => {
                        const k = e?.title;
                        if (!k) return false;
                        if (seen.has(k)) return false;
                        seen.add(k);
                        return true;
                    });
                }
            } catch (_) {}
            return out;
        };
    }

    if (typeof window !== 'undefined') window.StarFrontierStabilityFixes = {
        build: '1.85.6',
        checks: {
            v1327Ready,
            v133Ready,
            v163Ready
        }
    };
})();
