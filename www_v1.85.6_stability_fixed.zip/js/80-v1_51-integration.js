'use strict';
// ===== v1.51.0: integration stability / long-run diagnostics =====
const V151_BUILD='1.51.0';

// v1.45 wrapper shipped with a legacy symbol typo: gmAdvance calls processV145Daily(),
// while the implementation is named v145ProcessDaily(). Keep the public call stable.
function processV145Daily(){return v145ProcessDaily()}

// The historical build has a long chain of ensureVxxState() calls. Later systems call
// their own ensure functions every day, and each ensure recursively normalizes older
// systems again. During one logical init/render/day-advance pass, run each ensure at
// most once. Outside those passes (direct user actions) ensures still run normally.
let v151EnsureEpoch=0;
let v151EnsureDepth=0;
function v151WithEnsureEpoch(fn){
  const outer=v151EnsureDepth===0;
  if(outer)v151EnsureEpoch++;
  v151EnsureDepth++;
  try{return fn()}
  finally{v151EnsureDepth--;}
}
function v151MemoEnsure(fn){
  let busy=false,lastEpoch=-1,lastResult;
  return function(...args){
    if(v151EnsureDepth>0&&lastEpoch===v151EnsureEpoch)return lastResult;
    if(busy)return lastResult;
    if(v151EnsureDepth>0)lastEpoch=v151EnsureEpoch;
    busy=true;
    try{return lastResult=fn.apply(this,args)}
    catch(err){if(v151EnsureDepth>0)lastEpoch=-1;throw err}
    finally{busy=false}
  };
}
// Core and late-version state normalizers used repeatedly by the simulation.
ensureV14State=v151MemoEnsure(ensureV14State);
ensureV15State=v151MemoEnsure(ensureV15State);
ensureV16State=v151MemoEnsure(ensureV16State);
ensureV17State=v151MemoEnsure(ensureV17State);
ensureV18State=v151MemoEnsure(ensureV18State);
ensureV19State=v151MemoEnsure(ensureV19State);
ensureV110State=v151MemoEnsure(ensureV110State);
ensureV111State=v151MemoEnsure(ensureV111State);
ensureV112State=v151MemoEnsure(ensureV112State);
ensureV113State=v151MemoEnsure(ensureV113State);
ensureV1131State=v151MemoEnsure(ensureV1131State);
ensureV114State=v151MemoEnsure(ensureV114State);
ensureV115State=v151MemoEnsure(ensureV115State);
ensureV116State=v151MemoEnsure(ensureV116State);
ensureV117State=v151MemoEnsure(ensureV117State);
ensureV118State=v151MemoEnsure(ensureV118State);
ensureV119State=v151MemoEnsure(ensureV119State);
ensureV120State=v151MemoEnsure(ensureV120State);
ensureV1201State=v151MemoEnsure(ensureV1201State);
ensureV121State=v151MemoEnsure(ensureV121State);
ensureV122State=v151MemoEnsure(ensureV122State);
ensureV123State=v151MemoEnsure(ensureV123State);
ensureV124State=v151MemoEnsure(ensureV124State);
ensureV125State=v151MemoEnsure(ensureV125State);
ensureV126State=v151MemoEnsure(ensureV126State);
ensureV127State=v151MemoEnsure(ensureV127State);
ensureV128State=v151MemoEnsure(ensureV128State);
ensureV1281State=v151MemoEnsure(ensureV1281State);
ensureV1283State=v151MemoEnsure(ensureV1283State);
ensureV129State=v151MemoEnsure(ensureV129State);
ensureV1291State=v151MemoEnsure(ensureV1291State);
ensureV1295State=v151MemoEnsure(ensureV1295State);
ensureV130State=v151MemoEnsure(ensureV130State);
ensureV131State=v151MemoEnsure(ensureV131State);
ensureV132State=v151MemoEnsure(ensureV132State);
ensureV1326SignatureState=v151MemoEnsure(ensureV1326SignatureState);
ensureV1327State=v151MemoEnsure(ensureV1327State);
ensureV133State=v151MemoEnsure(ensureV133State);
ensureV134State=v151MemoEnsure(ensureV134State);
ensureV135State=v151MemoEnsure(ensureV135State);
ensureV136State=v151MemoEnsure(ensureV136State);
ensureV137State=v151MemoEnsure(ensureV137State);
v138EnsureState=v151MemoEnsure(v138EnsureState);
ensureV139State=v151MemoEnsure(ensureV139State);
ensureV140State=v151MemoEnsure(ensureV140State);
ensureV141State=v151MemoEnsure(ensureV141State);
ensureV142State=v151MemoEnsure(ensureV142State);
v143EnsureState=v151MemoEnsure(v143EnsureState);
ensureV144State=v151MemoEnsure(ensureV144State);
ensureV145State=v151MemoEnsure(ensureV145State);
ensureV146State=v151MemoEnsure(ensureV146State);
ensureV147State=v151MemoEnsure(ensureV147State);
ensureV148State=v151MemoEnsure(ensureV148State);
ensureV149State=v151MemoEnsure(ensureV149State);

// v1.47-v1.49 extended the v1.45 MOE rebuild function and call ensureV147/148/149
// from inside the rebuild chain. Those ensure functions recurse through ensureV145State(),
// which itself rebuilds MOE agents. Guard re-entry so startup and periodic rebuilds terminate.
let v151MoeRebuildBusy=false;
const v151MoeRebuildBase=v145RebuildMoeAgents;
v145RebuildMoeAgents=function(){
  if(v151MoeRebuildBusy)return;
  v151MoeRebuildBusy=true;
  try{return v151MoeRebuildBase()}
  finally{v151MoeRebuildBusy=false}
};

function v151CountActive(obj,pred=null){
  const rows=Object.values(obj||{});
  return pred?rows.filter(pred).length:rows.length;
}
function v151Metrics(){
  if(!game)return null;
  const gm=game.gm||{};
  const religions=gm.v147?.religions||{};
  const intl=gm.v148?.organizations||{};
  const legs=gm.v149?.legislatures||{};
  const merc=gm.irregular?.mercGroups||{};
  const pirates=gm.irregular?.pirateBands||{};
  return {
    day:game.day,
    factions:v151CountActive(gm.factions),
    dynamicStates:v151CountActive(gm.breakawayStates,s=>s?.status!=='dissolved'),
    parallelForces:v151CountActive(gm.parallelForces,o=>o?.status!=='disbanded'),
    religions:v151CountActive(religions,r=>r?.status!=='dissolved'),
    armedReligions:v151CountActive(religions,r=>!!r?.armedWingId&&r?.status!=='dissolved'),
    internationalOrgs:v151CountActive(intl,o=>o?.status==='active'),
    intlProposals:(gm.v148?.proposals||[]).filter(p=>p?.status==='negotiating').length,
    legislatures:v151CountActive(legs),
    parties:Object.values(legs).reduce((n,l)=>n+Object.values(l?.parties||{}).filter(p=>p?.status==='active').length,0),
    actors:v151CountActive(gm.v144?.actors),
    mercGroups:v151CountActive(merc,g=>g?.status!=='dissolved'),
    pirateBands:v151CountActive(pirates,g=>g?.status!=='dissolved'),
    // Avoid calling v127AllEnterprises() here: its historical ensure chain mutates game.version.
    enterprises:Object.keys(gm.enterpriseEconomy?.enterprises||{}).length,
    mediaEvents:(gm.media?.events||[]).length,
    mediaArticles:(gm.media?.articles||[]).length,
    mediaStatements:(gm.media?.statements||[]).length,
    gmNews:(gm.news||[]).length,
    majorEvents:(gm.majorEvents||[]).length,
    moeAgents:Object.keys(gm.v145?.moe?.agents||{}).length,
    moeEvents:(gm.v145?.moe?.events||[]).length,
    courtCases:(gm.v147?.courtCases||[]).filter(c=>c?.status==='pending').length,
    adminCases:(gm.v147?.adminCases||[]).filter(c=>c?.status==='pending').length
  };
}
function v151Validate(){
  const issues=[];
  if(!game||!game.gm){issues.push('game/gm missing');return issues}
  const finite=(v)=>Number.isFinite(Number(v));
  for(const [fid,f] of Object.entries(game.gm.factions||{})){
    if(!finite(f?.treasury))issues.push(`faction ${fid}: treasury not finite`);
    if(finite(f?.stability)&&(f.stability<0||f.stability>100))issues.push(`faction ${fid}: stability out of range ${f.stability}`);
    if(finite(f?.fleet)&&(f.fleet<0||f.fleet>5000))issues.push(`faction ${fid}: fleet suspicious ${f.fleet}`);
  }
  for(const [id,o] of Object.entries(game.gm.parallelForces||{})){
    if(!finite(o?.treasury))issues.push(`parallel ${id}: treasury not finite`);
    if(finite(o?.readiness)&&(o.readiness<0||o.readiness>100))issues.push(`parallel ${id}: readiness out of range ${o.readiness}`);
  }
  for(const [id,r] of Object.entries(game.gm.v147?.religions||{})){
    if(!finite(r?.followers))issues.push(`religion ${id}: followers not finite`);
    if(finite(r?.violence)&&(r.violence<0||r.violence>100))issues.push(`religion ${id}: violence out of range ${r.violence}`);
  }
  for(const [id,o] of Object.entries(game.gm.v148?.organizations||{})){
    if(!Array.isArray(o?.members))issues.push(`international ${id}: members missing`);
    if(!finite(o?.budget))issues.push(`international ${id}: budget not finite`);
  }
  for(const [fid,l] of Object.entries(game.gm.v149?.legislatures||{})){
    const allocated=Object.values(l?.parties||{}).filter(p=>p?.status==='active').reduce((n,p)=>n+(Number(p.seats)||0),0);
    if(allocated!==Number(l?.seats||0))issues.push(`legislature ${fid}: seat mismatch ${allocated}/${l?.seats}`);
    const members=Object.keys(l?.members||{}).length;
    if(members!==Number(l?.seats||0))issues.push(`legislature ${fid}: member mismatch ${members}/${l?.seats}`);
  }
  return issues.slice(0,100);
}


function v151CompactState(force=false){
  if(!game?.gm)return;
  game.v151=game.v151||{snapshots:[],issues:[],lastAuditDay:game.day,lastCompactDay:game.day};
  if(!force&&game.day-(game.v151.lastCompactDay||0)<10)return;
  game.v151.lastCompactDay=game.day;
  const gm=game.gm;

  // High-frequency banking reviews are diagnostics, not durable world state.
  if(Array.isArray(gm.banking?.history)&&gm.banking.history.length>240)gm.banking.history=gm.banking.history.slice(0,240);

  // Keep every live corporate loan plus a bounded audit trail of closed loans.
  const eco=gm.enterpriseEconomy;
  if(Array.isArray(eco?.corporateLoans)){
    const active=eco.corporateLoans.filter(l=>l?.active);
    const closed=eco.corporateLoans.filter(l=>!l?.active).sort((a,b)=>(b?.started||0)-(a?.started||0)).slice(0,120);
    eco.corporateLoans=[...active,...closed];
    const loanIds=new Set(eco.corporateLoans.map(l=>l?.id).filter(Boolean));
    for(const e of Object.values(eco.enterprises||{})){
      if(Array.isArray(e?.loans))e.loans=e.loans.filter(id=>loanIds.has(id)).slice(-32);
      if(Array.isArray(e?.capitalProjects)){
        const live=e.capitalProjects.filter(p=>['building','awaiting_payment'].includes(p?.status));
        const old=e.capitalProjects.filter(p=>!['building','awaiting_payment'].includes(p?.status)).sort((a,b)=>(b?.readyDay||b?.started||0)-(a?.readyDay||a?.started||0)).slice(0,16);
        e.capitalProjects=[...old.reverse(),...live];
      }
      if(Array.isArray(e?.products)&&e.products.length>16)e.products=e.products.slice(0,16);
      if(Array.isArray(e?.history)&&e.history.length>32)e.history=e.history.slice(0,32);
    }
  }

  // Completed military convoys are historical records; only live convoys affect routing.
  for(const ms of Object.values(gm.v129?.militarySupply?.states||{})){
    if(!Array.isArray(ms?.convoys))continue;
    const live=ms.convoys.filter(c=>c?.status==='enroute');
    const old=ms.convoys.filter(c=>c?.status!=='enroute').sort((a,b)=>(b?.started||0)-(a?.started||0)).slice(0,30);
    ms.convoys=[...old.reverse(),...live];
  }

  // v1.30 kept orphaned completed contracts after contractOrder rolled over.
  const law=gm.v130;
  if(law?.contracts&&Array.isArray(law.contractOrder)){
    v130TrimContractOrder(law);
    const keep=new Set(law.contractOrder);
    for(const [id,c] of Object.entries(law.contracts)){
      if(!keep.has(id))delete law.contracts[id];
    }
    if(Array.isArray(law.history)&&law.history.length>100)law.history=law.history.slice(0,100);
  }

  // Media deduplication only needs a recent window. Cold issues are safe to retire.
  const media=gm.media;
  if(media){
    const minSeenDay=Math.max(0,game.day-21);
    for(const k of Object.keys(media.seen||{})){
      const d=Number.parseInt(String(k).split(':',1)[0],10);
      if(Number.isFinite(d)&&d<minSeenDay)delete media.seen[k];
    }
    const liveIssueKeys=new Set((media.events||[]).map(e=>e?.issueKey).filter(Boolean));
    for(const [k,issue] of Object.entries(media.issueInterest||{})){
      if(liveIssueKeys.has(k))continue;
      if((issue?.heat||0)>2)continue;
      if(game.day-(issue?.lastDay||0)<60)continue;
      delete media.issueInterest[k];
      for(const row of Object.values(media.factionInterest||{}))if(row)delete row[k];
    }
  }

  // Personal NPC histories are flavor/audit data and do not drive career state.
  for(const a of Object.values(gm.v144?.actors||{}))if(Array.isArray(a?.history)&&a.history.length>40)a.history=a.history.slice(0,40);

  // Major-event dedup only needs to prevent near-term repeats. Keeping every key forever
  // caused a steady save-growth leak in long simulations.
  if(gm.majorEventSeen&&typeof gm.majorEventSeen==='object'){
    const cutoff=Math.max(0,game.day-120);
    for(const [k,d] of Object.entries(gm.majorEventSeen))if(Number.isFinite(Number(d))&&Number(d)<cutoff)delete gm.majorEventSeen[k];
  }

  // v1.7 government/corporate procurement contracts only affect simulation while active.
  // Preserve all live records plus a small recent audit trail for UI/news context.
  if(Array.isArray(gm.corporateContracts)){
    const active=gm.corporateContracts.filter(x=>x?.active);
    const closed=gm.corporateContracts.filter(x=>!x?.active).sort((a,b)=>(b?.expires||b?.started||0)-(a?.expires||a?.started||0)).slice(0,60);
    gm.corporateContracts=[...closed.reverse(),...active];
  }

  // Regional and monetary sanctions are stateful only while active; old records are audit data.
  if(Array.isArray(gm.regionalSanctions)){
    const active=gm.regionalSanctions.filter(x=>x?.status==='active');
    const closed=gm.regionalSanctions.filter(x=>x?.status!=='active').sort((a,b)=>(b?.expires||b?.started||0)-(a?.expires||a?.started||0)).slice(0,40);
    gm.regionalSanctions=[...closed.reverse(),...active];
  }
  if(Array.isArray(gm.monetary?.sanctions)){
    const active=gm.monetary.sanctions.filter(x=>x?.active&&Number(x?.until||0)>=game.day);
    const closed=gm.monetary.sanctions.filter(x=>!active.includes(x)).sort((a,b)=>(b?.until||b?.started||0)-(a?.until||a?.started||0)).slice(0,40);
    gm.monetary.sanctions=[...closed.reverse(),...active];
  }
  if(Array.isArray(gm.monetary?.bonds)){
    const held=game.finance?.bonds?.holdings||{};
    const live=gm.monetary.bonds.filter(b=>b?.active||Number(held[b?.id]||0)>0||Number(b?.playerFace||0)>0);
    const old=gm.monetary.bonds.filter(b=>!live.includes(b)).sort((a,b)=>(b?.maturity||b?.issued||0)-(a?.maturity||a?.issued||0)).slice(0,28);
    gm.monetary.bonds=[...old.reverse(),...live];
  }

  // Technology-market ledgers contain many completed records that no longer drive AI.
  // Keep all live/review/suspended relations and a bounded recent terminal history.
  const tt=gm.techTrade;
  if(tt){
    if(Array.isArray(tt.licenses)){
      const live=new Set(['active','review','suspended','draft']);
      const a=tt.licenses.filter(x=>live.has(x?.status));
      const z=tt.licenses.filter(x=>!live.has(x?.status)).sort((x,y)=>(y?.created||y?.started||0)-(x?.created||x?.started||0)).slice(0,60);
      tt.licenses=[...z.reverse(),...a];
    }
    if(Array.isArray(tt.jointDevelopments)){
      const live=new Set(['development','review','suspended','draft']);
      const a=tt.jointDevelopments.filter(x=>live.has(x?.status));
      const z=tt.jointDevelopments.filter(x=>!live.has(x?.status)).sort((x,y)=>(y?.created||y?.started||0)-(x?.created||x?.started||0)).slice(0,40);
      tt.jointDevelopments=[...z.reverse(),...a];
    }
    if(Array.isArray(tt.reviews)){
      const a=tt.reviews.filter(x=>x?.status==='pending');
      const z=tt.reviews.filter(x=>x?.status!=='pending').sort((x,y)=>(y?.started||0)-(x?.started||0)).slice(0,40);
      tt.reviews=[...z.reverse(),...a];
    }
    if(Array.isArray(tt.incidents)&&tt.incidents.length>30)tt.incidents=tt.incidents.slice(0,30);
    if(Array.isArray(tt.acquisitions)&&tt.acquisitions.length>20)tt.acquisitions=tt.acquisitions.slice(0,20);

    // patentOrder is already the canonical recent index. Also retain any patent required by
    // a live licence. Expired orphan patent objects otherwise accumulated indefinitely.
    const keepPatents=new Set((tt.patentOrder||[]).filter(Boolean));
    for(const [id,p] of Object.entries(tt.patents||{}))if(p?.status==='active')keepPatents.add(id);
    for(const x of tt.licenses||[])if(['active','review','suspended','draft'].includes(x?.status)&&x?.patentId)keepPatents.add(x.patentId);
    for(const id of Object.keys(tt.patents||{}))if(!keepPatents.has(id))delete tt.patents[id];
    tt.patentOrder=(tt.patentOrder||[]).filter(id=>!!tt.patents[id]).slice(0,260);
    const validPatents=new Set(Object.keys(tt.patents||{}));
    for(const e of Object.values(gm.enterpriseEconomy?.enterprises||{})){
      if(Array.isArray(e?.patents))e.patents=e.patents.filter(id=>validPatents.has(id));
      if(Array.isArray(e?.licensedPatents))e.licensedPatents=e.licensedPatents.filter(id=>validPatents.has(id));
      if(Array.isArray(e?.groupTechAccess))e.groupTechAccess=e.groupTechAccess.filter(id=>validPatents.has(id));
    }
  }

  // Contract-law registry: keep a smaller recent window, but never evict a live contract or
  // anything linked to an open dispute. v130ScanBreaches iterates contractOrder, so those IDs
  // must also remain in the order list.
  if(law?.contracts&&Array.isArray(law.contractOrder)){
    v130TrimContractOrder(law);
    const keep=new Set(law.contractOrder);
    for(const id of Object.keys(law.contracts))if(!keep.has(id))delete law.contracts[id];
    if(Array.isArray(law.disputes)){
      const open=law.disputes.filter(d=>['pending','negotiating','open'].includes(d?.status));
      const done=law.disputes.filter(d=>!['pending','negotiating','open'].includes(d?.status)).slice(0,60);
      law.disputes=[...open,...done].slice(0,100);
    }
  }
}

function v151TrimIntegrationLogs(){
  if(!game?.gm)return;
  if(Array.isArray(game.gm.news)&&game.gm.news.length>160)game.gm.news=game.gm.news.slice(0,160);
  if(Array.isArray(game.gm.majorEvents)&&game.gm.majorEvents.length>80)game.gm.majorEvents=game.gm.majorEvents.slice(0,80);
  if(Array.isArray(game.gm.media?.events)&&game.gm.media.events.length>120)game.gm.media.events=game.gm.media.events.slice(0,120);
  if(Array.isArray(game.gm.media?.articles)&&game.gm.media.articles.length>140)game.gm.media.articles=game.gm.media.articles.slice(0,140);
  if(Array.isArray(game.gm.media?.statements)&&game.gm.media.statements.length>140)game.gm.media.statements=game.gm.media.statements.slice(0,140);
}

// Browser localStorage cannot safely hold the primary save plus three multi-megabyte copies.
// Keep the primary save authoritative; scale browser backup count with save size and always
// prefer the Android native backup when the host bridge is available. v1.53 will move the
// primary save itself to native file storage.
function v151BrowserBackupSlots(rawLength){
  if(rawLength<=850000)return 3;
  if(rawLength<=1400000)return 2;
  if(rawLength<=2100000)return 1;
  return 0;
}
function v151ClearBrowserBackups(from=0){
  for(let i=Math.max(0,from);i<SF_BACKUP_KEYS.length;i++){try{localStorage.removeItem(SF_BACKUP_KEYS[i])}catch(_){}}
}
sfWriteBackupStatus=function(){
  const el=document.getElementById('sfBackupStatus');if(!el)return;
  const m=sfReadBackupMeta(),native=!!(window.AndroidNative&&typeof AndroidNative.getNativeBackup==='function');
  const mode=m.mode==='native_only'?'大容量セーブ：端末/手動バックアップ推奨':m.slots?`Webバックアップ ${m.slots}世代`:'Webバックアップ';
  el.textContent=m.day?`直近バックアップ：Day ${m.day} / ${new Date(m.time||Date.now()).toLocaleString()} / ${native?'Android端末バックアップ有効':mode}`:`バックアップ未作成 / ${native?'Android端末バックアップ有効':mode}`;
};
sfRotateBackup=function(raw,force=false){
  let obj;try{obj=JSON.parse(raw)}catch(_){return false}
  if(!sfValidSaveObject(obj))return false;
  const m=sfReadBackupMeta();
  if(!force&&m.day===obj.day&&Date.now()-(m.time||0)<120000)return false;
  let nativeOk=false;
  try{if(window.AndroidNative&&typeof AndroidNative.persistBackup==='function'){AndroidNative.persistBackup(raw);nativeOk=true}}catch(_){}
  let slots=v151BrowserBackupSlots(raw.length),webOk=false;
  try{
    // Free oversized stale generations before writing the next backup.
    v151ClearBrowserBackups(slots);
    if(slots>0){
      for(let i=slots-1;i>0;i--){const prev=localStorage.getItem(SF_BACKUP_KEYS[i-1]);if(prev)localStorage.setItem(SF_BACKUP_KEYS[i],prev);else localStorage.removeItem(SF_BACKUP_KEYS[i])}
      localStorage.setItem(SF_BACKUP_KEYS[0],raw);webOk=true;
    }else v151ClearBrowserBackups(0);
  }catch(_){
    // Quota pressure: sacrifice browser generations instead of risking the primary save.
    v151ClearBrowserBackups(0);slots=0;webOk=false;
  }
  try{localStorage.setItem(SF_BACKUP_META,JSON.stringify({day:obj.day,time:Date.now(),slots,mode:slots?'web':'native_only',chars:raw.length,native:nativeOk}))}catch(_){}
  sfWriteBackupStatus();
  return webOk||nativeOk;
};
const v151GmAdvanceBase=gmAdvance;
gmAdvance=function(){
  v151WithEnsureEpoch(()=>v151GmAdvanceBase());
  game.version=V151_BUILD;
  v151TrimIntegrationLogs();
  v151CompactState(false);
  game.v151=game.v151||{snapshots:[],issues:[],lastAuditDay:0,lastCompactDay:game.day};
  if(game.day-game.v151.lastAuditDay>=25){
    game.v151.lastAuditDay=game.day;
    const issues=v151Validate();
    game.v151.snapshots.unshift(v151Metrics());
    game.v151.snapshots=game.v151.snapshots.slice(0,24);
    if(issues.length){game.v151.issues.unshift({day:game.day,issues});game.v151.issues=game.v151.issues.slice(0,12)}
  }
};

const v151InitBase=initV10;
initV10=function(){
  v151WithEnsureEpoch(()=>v151InitBase());
  game.v151=game.v151||{snapshots:[],issues:[],lastAuditDay:game.day,lastCompactDay:game.day};
  game.version=V151_BUILD;
};


const v151LoadBase=load;
load=function(){
  const out=v151LoadBase();
  if(game){
    game.version=V151_BUILD;
    game.v151=game.v151||{snapshots:[],issues:[],lastAuditDay:game.day,lastCompactDay:game.day};
    v151CompactState(true);
  }
  return out;
};

const v151SaveBase=save;
save=function(){
  v151CompactState(true);
  if(game)game.version=V151_BUILD;
  let raw;try{raw=JSON.stringify(game)}catch(e){if(game?.v151)game.v151.lastSaveError=`serialize:${e?.message||e}`;return false}
  try{
    localStorage.setItem(SAVE_KEY,raw);
    if(game?.v151){game.v151.lastSaveError=null;game.v151.lastSaveChars=raw.length;game.v151.lastSaveDay=game.day}
  }catch(e){
    if(game?.v151)game.v151.lastSaveError=`primary:${e?.name||'Error'}:${e?.message||e}`;
    try{if(typeof toast==='function')toast('セーブ領域が不足しています。JSON書き出しを推奨します')}catch(_){}
    return false;
  }
  sfRotateBackup(raw,false);
  return true;
};

const v151RenderBase=render;
render=function(){
  v151WithEnsureEpoch(()=>v151RenderBase());
  if(game)game.version=V151_BUILD;
  const badge=document.querySelector('header .title .badge');if(badge)badge.textContent='v1.51.0';
  const sub=document.querySelector('header .sub');if(sub)sub.textContent='結合試験・長期安定性・MOE再帰修正・統合監査';
  document.title='STAR FRONTIER v1.51.0 — Integration Stability';
};

if(typeof window!=='undefined')window.StarFrontierIntegration={metrics:v151Metrics,validate:v151Validate,compact:()=>v151CompactState(true),rebuildMOE:()=>v145RebuildMoeAgents()};
