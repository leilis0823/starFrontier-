'use strict';
// ============================================================================
// v1.85.2 — Architecture Performance Update
// UI-only navigation scheduler + dynamic ship UI import + idle save flushing.
// Simulation order / global RNG order are deliberately left untouched.
// ============================================================================
(function(){
 const BUILD='1.85.6';
 const VALID_TABS=new Set(['home','galaxy','mine','market','ship']);
 let generation=0,shipUiPromise=null,deferredSaveTimer=0;
 const stats={routes:0,galaxyRoutes:0,repeatedRoutes:0,lazyShipLoads:0,lazyShipLoadMs:0,deferredSaves:0,lastRouteMs:0};
 const now=()=>{try{return performance.now()}catch(_){return Date.now()}};
 const raf=fn=>typeof requestAnimationFrame==='function'?requestAnimationFrame(fn):setTimeout(fn,16);
 const idle=(fn,timeout=1600)=>typeof requestIdleCallback==='function'?requestIdleCallback(fn,{timeout}):setTimeout(fn,60);
 function visible(id){const el=document.getElementById(id);return !!el&&!el.classList.contains('hidden')}
 function routeLoading(on){try{document.documentElement.classList.toggle('sf-route-loading',!!on)}catch(_){}}
 function showTabShell(id){
  document.querySelectorAll('.tab').forEach(e=>e.classList.add('hidden'));
  document.getElementById(id)?.classList.remove('hidden');
  document.querySelectorAll('.nav button').forEach(e=>e.classList.remove('active'));
  document.getElementById('nav-'+id)?.classList.add('active');
 }
 function showGalaxyShell(id){
  document.querySelectorAll('.gal-sub').forEach(e=>e.classList.add('hidden'));
  document.getElementById('gal-'+id)?.classList.remove('hidden');
  document.querySelectorAll('.segment button').forEach(e=>e.classList.remove('active'));
  document.getElementById('seg-'+id)?.classList.add('active');
 }
 function afterPaint(fn){raf(()=>raf(fn))}
 function scheduleDeferredSave(){
  if(typeof window==='undefined'||!window.__SF_UI_NAV_SAVE_PENDING__)return;
  window.__SF_UI_NAV_SAVE_PENDING__=false;
  clearTimeout(deferredSaveTimer);
  deferredSaveTimer=setTimeout(()=>{deferredSaveTimer=0;try{save?.();stats.deferredSaves++}catch(_){}},750);
 }
 function flushDeferredSave(){
  if(deferredSaveTimer){clearTimeout(deferredSaveTimer);deferredSaveTimer=0;try{save?.();stats.deferredSaves++}catch(_){}}
  else if(typeof window!=='undefined'&&window.__SF_UI_NAV_SAVE_PENDING__){window.__SF_UI_NAV_SAVE_PENDING__=false;try{save?.();stats.deferredSaves++}catch(_){}}
 }
 function runNavigationRender(fn){
  if(typeof window==='undefined')return fn();
  window.__SF_UI_NAV_RENDER__=(Number(window.__SF_UI_NAV_RENDER__)||0)+1;
  try{return fn()}finally{window.__SF_UI_NAV_RENDER__=Math.max(0,(Number(window.__SF_UI_NAV_RENDER__)||1)-1);scheduleDeferredSave()}
 }
 function loadShipUi(){
  if(typeof window!=='undefined'&&window.StarFrontierShipIcons)return Promise.resolve(true);
  if(shipUiPromise)return shipUiPromise;
  const t0=now();stats.lazyShipLoads++;
  shipUiPromise=import('./127-v1_82-ship-icons-registry.js').then(()=>{
   stats.lazyShipLoadMs=now()-t0;
   try{document.documentElement.dataset.sfShipUiLoaded='1'}catch(_){}
   return true;
  }).catch(err=>{
   shipUiPromise=null;
   console.warn('[STAR FRONTIER] ship UI lazy import failed',err);
   return false;
  });
  return shipUiPromise;
 }
 function hydrateShipUi(){
  idle(()=>loadShipUi().then(ok=>{
   if(!ok||!visible('ship'))return;
   idle(()=>{try{sfRenderCurrentShipArt?.()}catch(_){}try{StarFrontierShipRegistry?.rerender?.()}catch(_){}},900);
  }),1200);
 }
 function openTab(id){
  id=String(id||'');if(!VALID_TABS.has(id)){try{return showTab(id)}catch(_){return}}
  if(visible(id))stats.repeatedRoutes++;
  const token=++generation,t0=now();stats.routes++;showTabShell(id);routeLoading(true);
  afterPaint(()=>{
   if(token!==generation)return;
   try{runNavigationRender(()=>showTab(id))}finally{stats.lastRouteMs=now()-t0;routeLoading(false);if(id==='ship')hydrateShipUi()}
  });
 }
 function openGalaxy(id){
  id=String(id||'map');
  if(!visible('galaxy')){openTab('galaxy');afterPaint(()=>openGalaxy(id));return}
  if(visible('gal-'+id))stats.repeatedRoutes++;
  const token=++generation,t0=now();stats.galaxyRoutes++;showGalaxyShell(id);routeLoading(true);
  afterPaint(()=>{
   if(token!==generation)return;
   try{runNavigationRender(()=>showGalaxy(id))}finally{stats.lastRouteMs=now()-t0;routeLoading(false)}
  });
 }
 // Capture only direct user navigation. Internal game calls keep original,
 // synchronous showTab/showGalaxy semantics and therefore simulation ordering.
 document.addEventListener?.('click',ev=>{
  const btn=ev.target?.closest?.('button');if(!btn)return;
  if(btn.parentElement?.classList?.contains('nav')&&/^nav-/.test(btn.id||'')){
   ev.preventDefault();ev.stopImmediatePropagation();openTab(btn.id.slice(4));return;
  }
  if(btn.closest?.('#galaxy')&&/^seg-/.test(btn.id||'')){
   ev.preventDefault();ev.stopImmediatePropagation();openGalaxy(btn.id.slice(4));
  }
 },true);
 document.addEventListener?.('visibilitychange',()=>{if(document.hidden)flushDeferredSave()});
 window.addEventListener?.('pagehide',flushDeferredSave);
 // Ship visuals/registry stay unloaded until the Ship scene is actually opened.
 // This keeps both startup parse work and non-Ship memory use off the critical path.
 window.StarFrontierNavigator={build:BUILD,openTab,openGalaxy,loadShipUi,flushSave:flushDeferredSave,stats:()=>({...stats}),_test:{showTabShell,showGalaxyShell,runNavigationRender}};
})();
