'use strict';
// ===== v1.54.1: hybrid-intervention-aware media + international-organization AI overview =====
// Adds semantic understanding of v1.54 public events to the v1.43 media layer and
// explains dynamically created international organizations without changing save IDs.

const V1541_BUILD='1.55.0';
const V1541_SPECIAL_CATEGORIES=Object.freeze(['covert','hybrid','annexation','sphere']);

Object.assign(V143_CATEGORY,{
  covert:{name:'秘密工作・暗殺',icon:'🕶'},
  hybrid:{name:'非正規・ハイブリッド介入',icon:'◩'},
  annexation:{name:'編入・主権移管',icon:'⚑'},
  sphere:{name:'勢力圏・従属関係',icon:'◎'}
});
Object.assign(V143_ACTION_LABEL,{
  investigation:'国際帰属調査・情報検証',
  counter_hybrid:'防諜・国境警戒協力',
  nonrecognition:'不承認・主権支持'
});

for(const [fid,cats] of Object.entries({
  nyxdom:['covert','hybrid','annexation'],
  orpheus:['covert','hybrid','annexation','sphere'],
  concord:['hybrid','annexation','sphere'],
  imperium:['hybrid','annexation','sphere'],
  league:['sphere','annexation']
})){
  const o=V143_MEDIA_OUTLETS[fid];
  if(o)for(const c of cats)if(!o.focus.includes(c))o.focus.push(c);
}

function v1541SpecialCategory(text){
  const s=String(text||'');
  if(/暗殺|暗殺未遂|秘密工作|工作露見|秘密活動|国家関与|帰属確定|帰属調査|実行主体/.test(s))return'covert';
  if(/所属不明部隊|識別標識を持たない|非正規介入|代理勢力|代理武装|ハイブリッド介入|秘密支援/.test(s))return'hybrid';
  if(/編入要請|編入成立|主権移管|編入・主権移管|編入を見送り/.test(s))return'annexation';
  if(/勢力圏形成|勢力圏離脱|保護国|傀儡国家|安全保障従属国|友好・勢力圏国家|政策依存/.test(s))return'sphere';
  return null;
}
function v1541EvidenceState(text){
  const s=String(text||'');
  if(/関与確定|帰属確定|関与を立証|後援国.*判明|国家関与.*確認/.test(s))return'confirmed';
  if(/露見|発覚|検知|阻止/.test(s))return'exposed';
  if(/所属不明|識別標識を持たない|実行主体.*特定|可能性を捜査|関係を否定/.test(s))return'uncertain';
  return'unknown';
}

const v1541ClassifyBase=v143Classify;
v143Classify=function(text,forcedCategory=null,forcedSeverity=null){
  const special=v1541SpecialCategory(text);
  if(special&&(!forcedCategory||['politics','collapse','military','general'].includes(forcedCategory))){
    const base=v1541ClassifyBase(text,special,forcedSeverity);
    let importance=base.importance;
    if(special==='covert'&&/暗殺|暗殺未遂|工作露見/.test(String(text)))importance=Math.max(importance,/暗殺された|国家秘密工作の露見/.test(String(text))?88:76);
    if(special==='hybrid')importance=Math.max(importance,72);
    if(special==='annexation')importance=Math.max(importance,/編入成立|主権移管/.test(String(text))?92:76);
    if(special==='sphere')importance=Math.max(importance,62);
    return{category:special,importance};
  }
  return v1541ClassifyBase(text,forcedCategory,forcedSeverity);
};

const v1541InterestBase=v143InterestScore;
v143InterestScore=function(fid,e){
  let n=v1541InterestBase(fid,e);
  const g=game.gm.governments?.[fid];
  if(e.category==='covert')n+=(g?.internalSecurity||50)*.10+(game.gm.factions?.[fid]?.intel||45)*.08;
  if(e.category==='hybrid')n+=(g?.dimensions?.military||50)*.08+(g?.dimensions?.local||50)*.04;
  if(e.category==='annexation')n+=(100-(g?.dimensions?.local||50))*.07+(g?.foreignPosture||50)*.06;
  if(e.category==='sphere')n+=(g?.foreignPosture||50)*.07+(g?.dimensions?.corporate||50)*.03;
  return clamp(n,4,100);
};

const v1541StanceBase=v143Stance;
v143Stance=function(fid,e){
  if(!V1541_SPECIAL_CATEGORIES.includes(e.category))return v1541StanceBase(fid,e);
  const gov=game.gm.governments?.[fid],actors=e.actors||[],ev=v1541EvidenceState(e.text);
  if(actors.includes(fid)){
    if(e.category==='covert')return{code:ev==='confirmed'?'accountability':'investigate',label:ev==='confirmed'?'関与説明・危機管理':'捜査・帰属確認',toward:fid};
    if(e.category==='hybrid')return{code:'sovereignty',label:'主権防衛・越境介入警戒',toward:fid};
    if(e.category==='annexation')return{code:'involved',label:'当事国・主権判断',toward:fid};
    return{code:'involved',label:'当事国・関係維持',toward:fid};
  }
  if(fid==='orpheus'&&(e.category==='covert'||e.category==='hybrid'))return{code:'investigate',label:'独立検証・帰属調査',toward:null};
  if(fid==='concord'&&e.category==='hybrid')return{code:'condemn',label:'非正規介入抑制・住民保護',toward:null};
  if(e.category==='annexation'){
    if(fid==='orpheus')return{code:'nonrecognition',label:'手続・住民意思の検証',toward:null};
    if(['absolute_monarchy','military_junta','revolutionary_state'].includes(gov?.regimeId))return{code:'sovereignty',label:'領土保全・編入警戒',toward:e.actors?.[0]||null};
  }
  if(e.category==='sphere'){
    if((gov?.foreignPosture||50)<42)return{code:'neutral',label:'中立・勢力圏化を警戒',toward:null};
    if((gov?.dimensions?.military||50)>68)return{code:'sovereignty',label:'安全保障均衡を重視',toward:null};
  }
  const base=v1541StanceBase(fid,e);
  if(e.category==='covert'&&base.code==='neutral')return{code:'investigate',label:'帰属確認・情勢注視',toward:null};
  return base;
};

const v1541GovQuoteBase=v143GovQuote;
v143GovQuote=function(fid,e,stance){
  if(!V1541_SPECIAL_CATEGORIES.includes(e.category))return v1541GovQuoteBase(fid,e,stance);
  const subject=v143IssueLabel(e),ev=v1541EvidenceState(e.text),f=FACTIONS[fid]?.short||fid;
  if(e.category==='covert'){
    if(stance.code==='investigate')return `${subject}について、断定を避けつつ証拠の保全と実行主体の帰属確認を進める。${ev==='uncertain'?'未確認情報と確認済み事実を区別する。':''}`;
    if(stance.code==='accountability')return `${f}政府は国家関与を示す証拠を重大視し、指揮系統・権限行使・再発防止について説明責任を果たす必要がある。`;
    if(stance.code==='condemn'||stance.code==='sovereignty')return `政治目的の秘密工作や要人への暴力による現状変更は受け入れられない。独立した帰属調査を支持する。`;
  }
  if(e.category==='hybrid'){
    if(stance.code==='sovereignty')return `所属を隠した武装介入や代理勢力を通じた既成事実化を警戒する。国境・航路の監視と証拠収集を強化する。`;
    if(stance.code==='condemn')return `非正規部隊を利用した曖昧な軍事介入は住民保護と停戦を困難にする。即時の透明化と緊張緩和を求める。`;
    if(stance.code==='investigate')return `部隊の装備・指揮関係・補給経路に関する公開情報を照合し、国家帰属を慎重に検証する。`;
  }
  if(e.category==='annexation'){
    if(stance.code==='nonrecognition')return `主権移管の正当性は、武力的圧力の有無、住民意思、旧母国との手続を含めて検証されなければならない。`;
    if(stance.code==='sovereignty')return `一方的な編入や外部圧力による領土変更は地域秩序を不安定化させる。領土保全を重視する。`;
    return `編入・主権移管は当事国間の合意、住民意思、国際的承認の三点を満たす必要がある。`;
  }
  if(e.category==='sphere')return `安全保障協力と従属化は区別されるべきだ。軍事アクセス、財政依存、外交裁量の変化を継続的に評価する。`;
  return v1541GovQuoteBase(fid,e,stance);
};

const v1541PortfolioBase=v143PortfolioRole;
v143PortfolioRole=function(category){
  if(category==='covert')return'interior';
  if(category==='hybrid')return'defense';
  if(category==='annexation'||category==='sphere')return'foreign';
  return v1541PortfolioBase(category);
};

const v1541HeadlineBase=v143Headline;
v143Headline=function(outletFid,e,stance){
  if(!V1541_SPECIAL_CATEGORIES.includes(e.category))return v1541HeadlineBase(outletFid,e,stance);
  const o=v143MediaOutlet(outletFid),label=v143IssueLabel(e),ev=v1541EvidenceState(e.text),own=e.actors?.includes(outletFid),short=FACTIONS[outletFid]?.short||outletFid;
  if(e.category==='covert'){
    if(o.stateBias>75&&own)return `${short}当局、秘密工作疑惑への捜査・公式見解を発表`;
    if(o.freedom>85)return `${ev==='confirmed'?'国家関与の証拠を検証':'秘密工作疑惑、帰属は未確定'} — ${label}`;
    if(o.sensational>60)return `影の介入か：${label}`;
    return `秘密工作・暗殺を巡り帰属調査 — ${label}`;
  }
  if(e.category==='hybrid'){
    if(o.stateBias>75&&own)return `${short}、所属不明部隊への警戒と主権防衛を強調`;
    if(o.freedom>85)return `所属不明部隊の後援関係を検証 — ${label}`;
    if(o.sensational>60)return `「誰の軍か」曖昧な介入が拡大 — ${label}`;
    return `非正規介入の疑い、各国が監視強化 — ${label}`;
  }
  if(e.category==='annexation')return o.freedom>80?`編入・主権移管の正当性を検証 — ${label}`:`主権移管を巡り各国が対応協議 — ${label}`;
  return o.freedom>80?`勢力圏化の実態を分析 — ${label}`:`安全保障・通商関係が再編 — ${label}`;
};

const v1541ArticleSummaryBase=v143ArticleSummary;
v143ArticleSummary=function(outletFid,e,stance){
  if(!V1541_SPECIAL_CATEGORIES.includes(e.category))return v1541ArticleSummaryBase(outletFid,e,stance);
  const o=v143MediaOutlet(outletFid),raw=e.text.replace(/^【[^】]+】/,'').slice(0,132),ev=v1541EvidenceState(e.text);
  let method='公式発表と現地情報を併記し';
  if(o.stateBias>75)method='政府・安全保障当局の発表を中心に';
  else if(o.freedom>85)method='複数の独立情報源と公開証拠を照合し';
  else if(o.sensational>60)method='現地証言と速報情報を優先して';
  let caveat='';
  if(e.category==='covert'||e.category==='hybrid')caveat=ev==='confirmed'?' 国家帰属を示す証拠が公表されており、反証も含めて検証中。':ev==='uncertain'?' 実行主体の帰属は未確定で、確認済み事実と当事者の主張を区別している。':' 国家関与は確認されておらず、推測を事実として扱わない。';
  if(e.category==='annexation')caveat=' 編入の法的手続、住民意思、外部圧力の有無を主要争点として扱う。';
  if(e.category==='sphere')caveat=' 軍事アクセス、財政支援、外交裁量の変化から実質的な依存度を評価する。';
  return `${method}、${raw}${e.text.length>132?'…':''}${caveat} 世論関心 ${Math.round(v143InterestScore(outletFid,e))}/100。`;
};

const v1541CoverageBase=v143GenerateCoverage;
v143GenerateCoverage=function(e){
  if(!V1541_SPECIAL_CATEGORIES.includes(e.category))return v1541CoverageBase(e);
  const m=v143EnsureState(),set=new Set();
  for(const a of e.actors||[])if(V143_MEDIA_OUTLETS[a])set.add(a);
  set.add('orpheus');
  if(e.category==='covert'||e.category==='hybrid')set.add('nyxdom');
  if(e.category==='hybrid'||e.category==='annexation')set.add('concord');
  if(e.category==='sphere')set.add('league');
  if(set.size<3)set.add('helios');
  for(const fid of [...set].slice(0,e.importance>=82?5:4)){
    const stance=v143Stance(fid,e),o=v143MediaOutlet(fid);
    m.articles.unshift({id:`art-${game.day}-${Math.floor(rng()*1e8)}`,day:game.day,eventId:e.id,outletFaction:fid,outlet:o.name,kind:o.kind,headline:v143Headline(fid,e,stance),summary:v143ArticleSummary(fid,e,stance),stance:stance.label,interest:Math.round(v143InterestScore(fid,e)),freedom:o.freedom});
  }
  m.articles=m.articles.slice(0,140);
};

const v1541StatementsBase=v143GenerateStatements;
v143GenerateStatements=function(e){
  const before=v143EnsureState().statements.length;
  v1541StatementsBase(e);
  if(!V1541_SPECIAL_CATEGORIES.includes(e.category)||e.importance<68)return;
  const ids=v143FactionIds().sort((a,b)=>v143InterestScore(b,e)-v143InterestScore(a,e)).slice(0,2);
  for(const fid of ids){
    if(e.category==='covert'){
      const stance=v143Stance(fid,e);
      v143AddStatement(fid,e,`${FACTIONS[fid]?.short||fid}防諜当局`,'情報・治安機関','公開情報・通信記録・指揮関係を照合し、帰属を断定する前に証拠強度を評価する。',stance,false);
    }else if(e.category==='hybrid'){
      const sf=game.gm.securityForces?.[fid];
      if(sf){const stance=v143Stance(fid,e);v143AddStatement(fid,e,`${FACTIONS[fid]?.short||fid}国境・航路警備部門`,'国境警備','識別不能部隊への誤認拡大を避けつつ、越境移動・補給・航路安全の監視を強化する。',stance,false)}
    }
  }
  if(v143EnsureState().statements.length-before>10)v143EnsureState().statements=v143EnsureState().statements.slice(0,140);
};

const v1541ApplyActionBase=v143ApplyAction;
v143ApplyAction=function(fid,e,stance){
  if(!V1541_SPECIAL_CATEGORIES.includes(e.category))return v1541ApplyActionBase(fid,e,stance);
  if(e.importance<72||e.actors.includes(fid))return;
  const fs=game.gm.factions?.[fid];if(!fs||fs.treasury<700)return;
  const r=rng(),target=v143ActionTarget(e,stance);
  if((e.category==='covert'||e.category==='hybrid')&&r<.50){
    const cost=Math.min(320,Math.max(120,(fs.treasury||0)*.002));fs.treasury-=cost;
    if(e.system){const owner=v135OwnerForSystem(e.system);if(owner&&typeof v154RaiseSecurityAlert==='function')v154RaiseSecurityAlert(owner,1.2,'外国政府との情報共有・公開帰属調査')}
    return v143RecordAction(fid,e,'investigation',target,cost,'公開証拠・通信情報・現地報告を共有し、国家帰属の共同検証を開始した。');
  }
  if(e.category==='hybrid'&&r<.72){fs.treasury-=180;fs.fleet=clamp((fs.fleet||50)+.35,0,100);return v143RecordAction(fid,e,'counter_hybrid',null,180,'国境・主要航路の監視、識別手続、早期警戒の情報共有を強化した。')}
  if(e.category==='annexation'&&(stance.code==='sovereignty'||stance.code==='nonrecognition'||stance.code==='condemn')&&r<.65){fs.treasury-=120;if(target)changePairTension(fid,target,1);return v143RecordAction(fid,e,'nonrecognition',target,120,'主権移管の承認を保留し、住民意思と手続の検証を外交ルートで要求した。')}
  return v1541ApplyActionBase(fid,e,stance);
};

function v1541RebuildIssueIndex(){
  const m=v143EnsureState();
  m.issueInterest={};
  m.factionInterest={};for(const fid of v143FactionIds())m.factionInterest[fid]={};
  const ordered=[...(m.events||[])].sort((a,b)=>(a.day||0)-(b.day||0));
  for(const e of ordered){
    const cls=v143Classify(e.text,null,e.importance>=88?'critical':e.importance>=74?'major':null);
    if(v1541SpecialCategory(e.text)){e.category=cls.category;e.importance=Math.max(e.importance||0,cls.importance)}
    e.issueKey=v143EventKey(e.category,e.actors||[],e.system||null);e.label=v143IssueLabel(e);
    const issue=m.issueInterest[e.issueKey]||{key:e.issueKey,label:e.label,category:e.category,heat:0,lastDay:e.day,eventId:e.id};
    issue.label=e.label;issue.category=e.category;issue.heat=clamp(Math.max(issue.heat||0,(e.importance||44)*.72)+(e.historical?0:(e.importance||44)*.12),0,100);issue.lastDay=e.day;issue.eventId=e.id;m.issueInterest[e.issueKey]=issue;
    for(const fid of v143FactionIds())m.factionInterest[fid][e.issueKey]=Math.round(v143InterestScore(fid,e));
  }
  for(const a of m.articles||[]){const e=m.events.find(x=>x.id===a.eventId);if(e&&V1541_SPECIAL_CATEGORIES.includes(e.category)){const st=v143Stance(a.outletFaction,e);a.headline=v143Headline(a.outletFaction,e,st);a.summary=v143ArticleSummary(a.outletFaction,e,st);a.stance=st.label;a.interest=Math.round(v143InterestScore(a.outletFaction,e))}}
}
function v1541EnsureMediaMigration(){
  const m=v143EnsureState();if(m.v1541Migrated)return;
  m.v1541Migrated=true;v1541RebuildIssueIndex();
}

const V1541_ORG_ROLE=Object.freeze({
  collective_security:'加盟国への侵攻・越境危機を抑止し、共同警戒・停戦監視・制裁協調を行う安全保障枠組み。',
  military_alliance:'加盟国が共通脅威に対して共同防衛と軍事支援を行う相互防衛体制。',
  free_trade:'関税、港湾、物流規制を調整し、加盟国間の通商障壁と供給網寸断を減らす経済圏。',
  mediation:'戦争・内戦・独立危機の当事者を仲介し、停戦交渉や監視体制を制度化する機構。',
  humanitarian:'難民、戦災、人口流出、生活危機に対して加盟国の資金と物資を共同投入する支援機構。',
  development_bank:'債務危機、地方財政、戦後復興へ融資・信用保証を提供する多国間金融機関。',
  research:'共同研究、技術標準、危険研究の監督と研究資源の共有を行う科学協力機構。',
  anti_piracy:'海賊、密輸、航路襲撃に対して共同哨戒、船団護衛、航路情報共有を行う治安協力組織。',
  anomaly_watch:'星海生体艦、エイドロン、古代構造体など国家単独では扱いにくい異常存在を共同監視する機構。',
  religious_forum:'越境宗教、宗教迫害、聖地・共同体紛争を仲裁し、信仰共同体の権利と治安の両立を図る会議体。'
});
function v1541OrgActionText(type){
  const map={collective_security:'共同監視・制裁・安全保障協議',military_alliance:'共同即応・軍事支援',free_trade:'通商救済・規制調整',mediation:'停戦仲介・和平調整',humanitarian:'人道支援',development_bank:'復興・開発融資',research:'共同研究・調査任務',anti_piracy:'共同航路哨戒',anomaly_watch:'共同研究・監視',religious_forum:'国際調査・仲裁'};
  return map[type]||'多国間協議・共同措置';
}
function v1541OrgDemandReason(type){
  let signal=0;try{signal=v148Signals?.()?.[type]||0}catch(_){}
  const level=signal>=75?'非常に高い':signal>=55?'高い':signal>=35?'中程度':'低い';
  const kw=(V148_ORG_TYPES[type]?.keywords||[]).slice(0,4).join('・');
  return `現在の設立需要は${level}（${Math.round(signal)}/100）。AIは${kw||'関連情勢'}の発生状況を評価して必要性を判断する。`;
}
function v1541InternationalOverview(entity){
  const type=typeof entity==='string'?entity:entity?.type,def=V148_ORG_TYPES[type];if(!def)return'組織目的の情報がありません。';
  const role=V1541_ORG_ROLE[type]||def.desc||`${def.name}として多国間協力を行う。`;
  const action=v1541OrgActionText(type);
  if(!entity||typeof entity==='string')return `${role} 主な共同措置：${action}。 ${v1541OrgDemandReason(type)}`;
  const vote=typeof v1521InternationalVotingLabel==='function'?v1521InternationalVotingLabel(entity.voting):entity.voting;
  const sponsor=entity.sponsor?FACTIONS[entity.sponsor]?.short||entity.sponsor:null;
  const recent=Array.isArray(entity.resolutions)&&entity.resolutions.length?entity.resolutions[0]:null;
  const recentText=recent?` 最新決議：${typeof v1521InternationalActionLabel==='function'?v1521InternationalActionLabel(recent.action):recent.action}（${recent.status==='passed'?'可決':'否決'}）。`:'';
  return `${role} 主な共同措置：${action}。${sponsor?` 提唱・中核国：${sponsor}。`:''}${vote?` 議決方式：${vote}。`:''}${recentText}`;
}

const v1541RenderIntlBase=renderV148International;
renderV148International=function(){
  ensureV148State();
  const sig=v148Signals(),orgs=Object.values(game.gm.v148.organizations||{}).filter(o=>o.status==='active'),props=(game.gm.v148.proposals||[]).filter(p=>p.status==='negotiating');
  const voteLabel=v=>typeof v1521InternationalVotingLabel==='function'?v1521InternationalVotingLabel(v):v;
  return `<div class="panel"><div class="section-title"><h2>◎ 国際組織・多国間政治</h2><span class="pill">DYNAMIC INSTITUTIONS / AI概要</span></div><p class="desc">国際組織は固定配置ではありません。国家AIが戦争、海賊、債務危機、異常存在、宗教紛争などを評価して創設します。各カードには「何のための組織か」と現在のAI評価を表示します。</p><div class="station-stock"><div>活動組織<b>${orgs.length}</b></div><div>創設交渉<b>${props.length}</b></div><div>成立累計<b>${game.gm.v148.stats.formed}</b></div><div>決議累計<b>${game.gm.v148.stats.resolutions}</b></div></div>${props.map(p=>`<div class="order-card hot"><b>創設会議：${escapeHtml(p.name)}</b><p><b>概要：</b>${escapeHtml(v1541InternationalOverview(p.type))}</p><div class="lore-meta">種別 ${escapeHtml(V148_ORG_TYPES[p.type]?.name||p.type)} / 提唱 ${escapeHtml(FACTIONS[p.sponsor]?.short||p.sponsor)} / 加盟予定 ${p.members.length} / オブザーバー ${p.observers.length} / ${escapeHtml(voteLabel(p.voting))} / Day ${p.resolveDay}に憲章採択</div></div>`).join('')}${orgs.map(o=>`<div class="station-card"><div class="station-head"><b>${escapeHtml(o.name)}</b><span class="pill">${escapeHtml(o.typeName)}</span></div><p class="desc"><b>AI概要：</b>${escapeHtml(v1541InternationalOverview(o))}</p><div class="lore-meta">加盟 ${o.members.length} / オブザーバー ${o.observers.length} / 本部 ${escapeHtml(SYSTEMS[o.hq]?.name||o.hq)} / ${escapeHtml(voteLabel(o.voting))}</div><div class="station-stock"><div>予算<b>${Math.round(o.budget).toLocaleString()} Cr</b></div><div>結束<b>${Math.round(o.cohesion)}</b></div><div>正統性<b>${Math.round(o.legitimacy)}</b></div><div>決議<b>${o.resolutions.length}</b></div></div><div class="hint">加盟：${o.members.map(fid=>escapeHtml(FACTIONS[fid]?.short||fid)).join(' / ')}</div><details><summary class="hint">設立需要・AI判断を見る</summary><p class="smallnote">${escapeHtml(v1541OrgDemandReason(o.type))}</p></details></div>`).join('')}${!orgs.length&&!props.length?'<div class="hint">現在、制度化された多国間組織はありません。下の需要シグナルが閾値を超えると国家AIが創設を提案します。</div>':''}<details><summary class="hint">現在の国際組織需要シグナル</summary>${Object.entries(sig).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="kv"><span>${escapeHtml(V148_ORG_TYPES[k]?.name||k)}<br><small>${escapeHtml(V1541_ORG_ROLE[k]||V148_ORG_TYPES[k]?.desc||'')}</small></span><b>${Math.round(v)}</b></div>`).join('')}</details></div>`;
};

if(typeof window!=='undefined'){
  window.StarFrontierInternationalAI=window.StarFrontierInternationalAI||{};
  window.StarFrontierInternationalAI.describe=function(idOrOrg){
    if(typeof idOrOrg==='string'&&V148_ORG_TYPES[idOrOrg])return v1541InternationalOverview(idOrOrg);
    if(typeof idOrOrg==='string')return v1541InternationalOverview(game.gm.v148?.organizations?.[idOrOrg]);
    return v1541InternationalOverview(idOrOrg);
  };
  window.StarFrontierInternationalAI.describeType=type=>v1541InternationalOverview(type);
  window.StarFrontierInternationalAI.typeRoles=V1541_ORG_ROLE;
}

function v1541SetVersion(){
  if(typeof game==='undefined'||!game)return;
  game.version=V1541_BUILD;
  if(typeof document!=='undefined'){
    const badge=document.querySelector('header .title .badge');if(badge)badge.textContent='v1.55.0';
    const sub=document.querySelector('header .sub');if(sub)sub.textContent='ハイブリッド介入メディアAI・国際組織AI概要・Adaptive UI';
    document.title='STAR FRONTIER v1.55.0 — Adaptive UI';
  }
}

const v1541InitBase=initV10;
initV10=function(){const out=v1541InitBase();v1541EnsureMediaMigration();v1541SetVersion();return out};
const v1541LoadBase=load;
load=function(){const out=v1541LoadBase();v1541EnsureMediaMigration();v1541SetVersion();return out};
const v1541SaveBase=save;
save=function(){v1541SetVersion();return v1541SaveBase()};
const v1541GmAdvanceBase=gmAdvance;
gmAdvance=function(){const out=v1541GmAdvanceBase();v1541EnsureMediaMigration();v1541SetVersion();return out};
const v1541RenderBase=render;
render=function(){const out=v1541RenderBase();v1541EnsureMediaMigration();v1541SetVersion();return out};

if(typeof window!=='undefined')window.StarFrontierV1541={
  build:V1541_BUILD,
  classify:v1541SpecialCategory,
  describeInternational:v1541InternationalOverview,
  migrateMedia:v1541RebuildIssueIndex
};
