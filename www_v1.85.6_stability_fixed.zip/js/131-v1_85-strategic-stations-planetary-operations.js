'use strict';
// ============================================================================
// STAR FRONTIER v1.85.0 — Strategic Stations & Planetary Operations
// - Expanded orbital station roles / modules
// - 12 strategic station-ship classes
// - 6 dual-environment surface/space hull families
// - Planetary facilities, pirate landing raids, orbital/atmosphere/surface defense
//
// RNG SAFETY: this layer never calls the global rng(). Procedural content uses
// an independent deterministic FNV-1a hash and therefore does not advance
// marketSeed or alter the established simulation RNG order.
// ============================================================================
(function(){
 const V185_BUILD='1.85.0';
 const V185_FEATURE='Strategic Stations & Planetary Operations';
 const V185_STATE_VERSION=1;
 const V185_MAX_STRATEGIC_ASSETS=4;
 const V185_NEWS_LIMIT=36;

 const V185_STATION_MODULES={
  navalBase:{name:'艦隊軍港',icon:'⚔',credits:24500,req:{iron:30,titanium:22,crystal:4},desc:'駐留艦隊の整備・再武装と軌道防衛を担う軍港。惑星作戦艦の運用母港にもなる。',daily:70,defense:18},
  miningHub:{name:'採鉱管制ステーション',icon:'⛏',credits:15800,req:{iron:24,titanium:12,crystal:2},desc:'周辺鉱区、採掘船、原鉱集積を統括する資源拠点。惑星鉱山とも物流接続する。',daily:145,defense:3},
  research:{name:'深宇宙研究ステーション',icon:'🔬',credits:26800,req:{iron:20,titanium:20,crystal:8},desc:'未知遺物・航法・生体艦・先端材料を解析する大型研究施設。',daily:65,defense:4},
  sensorArray:{name:'長距離情報監視アレイ',icon:'📡',credits:21400,req:{iron:18,titanium:16,crystal:7},desc:'海賊、艦隊、未知信号を早期探知する超長距離センサー・電子情報拠点。',daily:40,defense:10},
  medical:{name:'医療・救難ステーション',icon:'✚',credits:22600,req:{iron:18,titanium:14,crystal:6},desc:'救難、難民収容、戦傷治療、損傷艦の緊急受入れを担う人道拠点。',daily:55,defense:5},
  fuelDepot:{name:'燃料精製・補給基地',icon:'⛽',credits:18800,req:{iron:22,titanium:14,crystal:2},desc:'艦隊用燃料の精製・備蓄・補給を行い、遠征作戦と星系物流を支える。',daily:135,defense:5},
  habitat:{name:'植民居住環',icon:'🏙',credits:29600,req:{iron:36,titanium:20,crystal:5},desc:'居住区・商業区・労働人口を抱える大型軌道都市。地域経済と人口基盤を形成する。',daily:185,defense:6},
  blackMarket:{name:'非公式交易区画',icon:'☠',credits:13200,req:{iron:14,titanium:8,crystal:2},desc:'登録外取引、盗品仲介、非正規船主が集まる危険な自由区画。収益性は高いが治安上の弱点になる。',daily:215,defense:-5}
 };

 const V185_STATION_ARCHETYPES={
  trade:{name:'交易ハブ',icon:'◫',match:m=>m.includes('trade')&&m.includes('habitat')},
  grand_yard:{name:'大型造船コンプレックス',icon:'⚓',match:m=>m.includes('shipyard')&&m.includes('navalBase')},
  naval:{name:'艦隊軍港',icon:'⚔',match:m=>m.includes('navalBase')},
  fortress:{name:'星系要塞',icon:'⌾',match:m=>m.includes('defense')&&(m.includes('sensorArray')||m.includes('navalBase'))},
  refinery:{name:'精錬コンプレックス',icon:'⚗',match:m=>m.includes('refinery')&&m.includes('miningHub')},
  mining:{name:'採鉱ステーション',icon:'⛏',match:m=>m.includes('miningHub')},
  research:{name:'研究ステーション',icon:'🔬',match:m=>m.includes('research')},
  intel:{name:'情報監視ステーション',icon:'📡',match:m=>m.includes('sensorArray')},
  medical:{name:'医療・救難ステーション',icon:'✚',match:m=>m.includes('medical')},
  fuel:{name:'燃料精製基地',icon:'⛽',match:m=>m.includes('fuelDepot')},
  habitat:{name:'植民居住ステーション',icon:'🏙',match:m=>m.includes('habitat')},
  black:{name:'ブラックマーケット港',icon:'☠',match:m=>m.includes('blackMarket')}
 };

 const V185_STRATEGIC_SHIPS={
  bastille_sr:{name:'BASTILLE-SR〈バスティーユ戦略型〉',icon:'▣',role:'移動要塞艦',cost:360000,days:18,req:{iron:115,titanium:92,crystal:18},power:155,orbit:42,atmo:0,surface:0,bonus:'展開宙域のステーション防衛を大幅強化',desc:'既存BASTILLE思想を戦略拠点化した移動要塞。巨大砲台・修理ドック・備蓄庫を一体化する。'},
  citadel:{name:'CITADEL〈シタデル〉',icon:'⬢',role:'防衛ステーション艦',cost:318000,days:16,req:{iron:104,titanium:88,crystal:22},power:142,orbit:54,atmo:4,surface:0,bonus:'軌道防衛・迎撃',desc:'多層シールドと迎撃砲を中心にした純防衛型。要衝へ展開すると侵攻艦隊の突破を困難にする。'},
  arsenal:{name:'ARSENAL〈アーセナル〉',icon:'⌬',role:'移動兵器工廠',cost:294000,days:15,req:{iron:92,titanium:86,crystal:18},power:118,orbit:24,atmo:5,surface:0,bonus:'弾薬・装備補給',desc:'ミサイル、迎撃弾、交換兵装を前線で生産する兵器工廠艦。艦隊の継戦能力を支える。'},
  foundry:{name:'FOUNDRY〈ファウンドリ〉',icon:'⚒',role:'移動造船工廠',cost:342000,days:19,req:{iron:126,titanium:96,crystal:20},power:105,orbit:18,atmo:0,surface:0,bonus:'前線造船・修理',desc:'小型・中型艦の船体ブロックを現地生産できる移動造船所。生存するほど戦争の補充力へ効く。'},
  atlas:{name:'ATLAS〈アトラス〉',icon:'▤',role:'重輸送ステーション艦',cost:246000,days:13,req:{iron:86,titanium:58,crystal:10},power:82,orbit:14,atmo:8,surface:0,bonus:'星系物流・補給',desc:'艦隊数個群を支える巨大貨物・燃料・生活物資区画を持つ戦略輸送拠点。'},
  hospitaller:{name:'HOSPITALLER〈ホスピタラー〉',icon:'✚',role:'医療・救難母艦',cost:258000,days:14,req:{iron:72,titanium:62,crystal:18},power:76,orbit:12,atmo:16,surface:5,bonus:'救難・災害復旧',desc:'病院、避難区画、曳航艇、降下救難艇を備えた人道戦略艦。戦争と災害の被害を吸収する。'},
  observer:{name:'OBSERVER〈オブザーバー〉',icon:'◉',role:'情報戦ステーション艦',cost:278000,days:15,req:{iron:66,titanium:70,crystal:28},power:91,orbit:22,atmo:10,surface:0,bonus:'海賊・艦隊早期探知',desc:'巨大センサー面と電子戦ノードを展開し、星系全域の航跡・通信・降下作戦を監視する。'},
  sovereign:{name:'SOVEREIGN〈ソヴリン〉',icon:'♜',role:'艦隊司令要塞',cost:396000,days:21,req:{iron:118,titanium:112,crystal:30},power:172,orbit:38,atmo:8,surface:0,bonus:'艦隊戦力・指揮',desc:'戦域司令部、作戦演算、通信中継を一隻へ集約した国家級指揮要塞。'},
  devourer:{name:'DEVOURER〈デヴァウラー〉',icon:'⛏',role:'資源採取要塞',cost:272000,days:15,req:{iron:94,titanium:64,crystal:12},power:88,orbit:16,atmo:6,surface:10,bonus:'採掘・サルベージ',desc:'小惑星・廃船・鉱石を船体内部へ取り込み連続処理する巨大資源拠点。'},
  gatekeeper:{name:'GATEKEEPER〈ゲートキーパー〉',icon:'⛉',role:'航路封鎖艦',cost:326000,days:17,req:{iron:98,titanium:92,crystal:24},power:148,orbit:46,atmo:6,surface:0,bonus:'航路防衛・関税支配',desc:'星系進入口へ展開し、通航識別・臨検・長距離火力で航路そのものを支配する。'},
  leviathan_dock:{name:'LEVIATHAN DOCK〈リヴァイアサン・ドック〉',icon:'🜚',role:'生体艦支援施設艦',cost:302000,days:18,req:{iron:68,titanium:62,crystal:36},power:94,orbit:18,atmo:12,surface:4,bonus:'生体艦研究・保護',desc:'星海生体艦の治療・観察・共生研究を目的とする特殊ドック。通常の乾ドックとは構造が異なる。'},
  axiom_node:{name:'AXIOM NODE〈アクシオム・ノード〉',icon:'⬡',role:'機械文明移動ノード',cost:420000,days:22,req:{iron:82,titanium:96,crystal:44},power:188,orbit:48,atmo:18,surface:8,bonus:'機械文明解析・電子戦',desc:'アクシオム技術を限定的に模倣した可変戦略ノード。通常の艦・ステーション分類から逸脱する。'}
 };

 const V185_SURFACE_HULLS={
  strider_ax:{name:'STRIDER-AX〈ストライダー〉',class:'corvette',cost:48500,baseCargo:48,baseFuel:210,mining:-1,engine:.21,military:1,surfaceCapable:true,atmospheric:true,surfaceRole:'哨戒・施設防衛',surfacePower:44,atmoPower:51,marketHull:true,desc:'軌道哨戒と惑星低空作戦を両立する小型航宙コルベット。反重力補助と可変推力ノズルで未整備地への垂直着陸が可能。'},
  lander_lc:{name:'LANDER-LC〈ランダー〉',class:'freighter',cost:56200,baseCargo:142,baseFuel:252,mining:-2,engine:.08,surfaceCapable:true,atmospheric:true,surfaceRole:'兵員・物資降下',surfacePower:34,atmoPower:40,marketHull:true,desc:'海兵隊、ドローン、救難班、補給物資を軌道から直接地表へ運ぶ強襲・救難兼用輸送艦。'},
  hammerhead_ag:{name:'HAMMERHEAD-AG〈ハンマーヘッド〉',class:'frigate',cost:92800,baseCargo:66,baseFuel:228,mining:-3,engine:.05,military:2,surfaceCapable:true,atmospheric:true,surfaceRole:'重地上攻撃',surfacePower:82,atmoPower:67,marketHull:true,desc:'大気圏内で速度と燃費を犠牲にし、施設制圧用の重火力を地表へ持ち込む強襲フリゲート。大型のため降下地点を選ぶ。'},
  warden_at:{name:'WARDEN-AT〈ウォーデン・アトモス〉',class:'frigate',cost:88600,baseCargo:58,baseFuel:236,mining:-3,engine:.07,military:2,surfaceCapable:true,atmospheric:true,surfaceRole:'地上防空・基地防衛',surfacePower:76,atmoPower:78,marketHull:true,desc:'平時は施設周辺へ着陸し、対艦ミサイル・迎撃ドローン・防壁を展開する防衛艦。必要時は軌道戦へ復帰する。'},
  ranger_px:{name:'RANGER-PX〈レンジャー〉',class:'prospect',cost:41200,baseCargo:88,baseFuel:268,mining:2,engine:.16,surfaceCapable:true,atmospheric:true,surfaceRole:'探査・開拓・救難',surfacePower:28,atmoPower:36,marketHull:true,desc:'未開惑星、衛星、辺境拠点への降下を想定した探査・開拓艇。地質調査、遺跡調査、救難、植民支援を一隻で行う。'},
  marauder_rx:{name:'MARAUDER-RX〈マローダー〉',class:'corvette',cost:61800,baseCargo:78,baseFuel:224,mining:-2,engine:.24,surfaceCapable:true,atmospheric:true,surfaceRole:'襲撃・略奪降下',surfacePower:61,atmoPower:58,marketHull:false,irregular:true,desc:'民間輸送艇を海賊が改造した地表襲撃艦。軌道襲撃から降下、倉庫・鉱山・燃料基地の略奪、離脱までを短時間で行う。'}
 };

 const V185_SITE_TYPES={
  mine:{name:'惑星採鉱基地',icon:'⛏',cost:14800,req:{iron:18,titanium:8,crystal:1},defense:16,value:72,desc:'地表鉱床を継続採掘する鉱業拠点。襲撃されると原鉱供給へ影響する。'},
  fuel:{name:'地表燃料精製所',icon:'⛽',cost:17200,req:{iron:20,titanium:10,crystal:1},defense:14,value:78,desc:'揮発物・反応材を処理して航宙燃料を供給する施設。'},
  research:{name:'惑星研究前哨基地',icon:'🔬',cost:21800,req:{iron:15,titanium:12,crystal:5},defense:12,value:84,desc:'生態・地質・遺物・大気圏研究を行う地表研究所。'},
  logistics:{name:'地上物流デポ',icon:'▤',cost:13600,req:{iron:16,titanium:8,crystal:0},defense:13,value:68,desc:'倉庫、荷役、地上輸送網を束ねる物流施設。海賊にとって高価値な略奪対象。'},
  settlement:{name:'植民居住区',icon:'🏘',cost:24800,req:{iron:28,titanium:12,crystal:3},defense:10,value:90,desc:'民間人口と労働力を抱える恒久居住区。攻撃時は人道・政治コストが非常に大きい。'},
  garrison:{name:'惑星防衛駐屯地',icon:'⛨',cost:19600,req:{iron:22,titanium:16,crystal:2},defense:42,value:55,desc:'地表防空、対艦ミサイル、迎撃ドローンを運用する防衛拠点。周辺施設も防護する。'}
 };

 const V185_NPC_STRATEGIC_SEEDS=[
  ['league','aurora','gatekeeper'],['league','orion','atlas'],['helios','forge','foundry'],['helios','bastion','citadel'],
  ['nyxdom','nyx','devourer'],['concord','elysia','hospitaller'],['concord','halcyon','leviathan_dock'],
  ['imperium','drakon','sovereign'],['orpheus','umbra','observer'],['orpheus','umbra','axiom_node'],
  ['volgar','kronos','bastille_sr'],['volgar','kronos','arsenal']
 ];

 function v185Clamp(n,a=0,b=100){return Math.max(a,Math.min(b,Number(n)||0))}
 function v185Hash(text){let h=2166136261>>>0;for(const ch of String(text||'')){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0}return h>>>0}
 function v185Unit(text){return v185Hash(text)/4294967295}
 function v185Id(prefix,key){return `${prefix}-${v185Hash(key).toString(36)}`}
 function v185Round100(n){return Math.max(0,Math.round((Number(n)||0)/100)*100)}
 function v185News(text){try{game.gm=game.gm||{};game.gm.news=Array.isArray(game.gm.news)?game.gm.news:[];game.gm.news.unshift(`Day ${game.day}: ${text}`);game.gm.news=game.gm.news.slice(0,V185_NEWS_LIMIT)}catch(_){}}
 function v185SystemName(sid){return SYSTEMS?.[sid]?.name||sid||'不明星系'}
 function v185FactionName(fid){return fid==='player'?(game.playerFaction?.name||'プレイヤー勢力'):(FACTIONS?.[fid]?.short||fid||'不明勢力')}
 function v185MaterialText(req){try{return typeof materialText==='function'?materialText(req):Object.entries(req||{}).map(([k,n])=>`${k}${n}`).join(' / ')}catch(_){return''}}
 function v185StationClass(st){const mods=st?.modules||[];for(const a of Object.values(V185_STATION_ARCHETYPES))if(a.match(mods))return a;return{name:'汎用軌道ステーション',icon:'◉'}}
 function v185SurfaceHull(id){const h=typeof getHull==='function'?getHull(id):HULLS?.[id];return !!h?.surfaceCapable}
 function v185SurfacePower(id){const h=typeof getHull==='function'?getHull(id):HULLS?.[id];return Number(h?.surfacePower)||0}
 function v185AtmoPower(id){const h=typeof getHull==='function'?getHull(id):HULLS?.[id];return Number(h?.atmoPower)||0}

 // Mutable existing registries: extend without replacing old definitions.
 Object.assign(STATION_MODULES,V185_STATION_MODULES);
 Object.assign(HULLS,V185_SURFACE_HULLS);

 function v185State(){
  game.planetaryOps=game.planetaryOps&&typeof game.planetaryOps==='object'?game.planetaryOps:{};const p=game.planetaryOps;p.version=V185_STATE_VERSION;
  p.sites=p.sites&&typeof p.sites==='object'?p.sites:{};p.raids=Array.isArray(p.raids)?p.raids:[];p.history=Array.isArray(p.history)?p.history:[];
  p.assignments=p.assignments&&typeof p.assignments==='object'?p.assignments:{};p.lastDailyDay=Number.isFinite(Number(p.lastDailyDay))?Number(p.lastDailyDay):game.day-1;
  p.metrics={raids:0,repelled:0,successfulRaids:0,facilitiesLost:0,playerIntercepts:0,sitesBuilt:0,...(p.metrics||{})};
  game.strategicStations=game.strategicStations&&typeof game.strategicStations==='object'?game.strategicStations:{};const s=game.strategicStations;s.version=V185_STATE_VERSION;
  s.assets=Array.isArray(s.assets)?s.assets:[];s.queue=Array.isArray(s.queue)?s.queue:[];s.history=Array.isArray(s.history)?s.history:[];s.npcAssets=Array.isArray(s.npcAssets)?s.npcAssets:[];
  s.metrics={built:0,deployed:0,relocations:0,...(s.metrics||{})};
  v185SeedSites();v185SeedNpcStrategic();
  return{planetary:p,strategic:s};
 }

 function v185SiteName(sid,type,slot){const sys=SYSTEMS?.[sid],meta=V185_SITE_TYPES[type],prefix=sys?.name?.replace('星系','').replace('宙域','').replace('空白域','').replace('漂域','')||sid;const suffixes=['第一','中央','外縁','南部','北方','環状'];return `${prefix}${suffixes[slot%suffixes.length]}${meta.name.replace('惑星','').replace('地表','').replace('地上','')}`}
 function v185SeedSites(){
  const p=game.planetaryOps;if(!p)return;
  const types=Object.keys(V185_SITE_TYPES);
  for(const sid of Object.keys(SYSTEMS||{})){
   if(Object.values(p.sites).some(x=>x.system===sid&&x.seeded))continue;
   const sec=SYSTEMS[sid]?.security,baseCount=sec==='無法'?2:3;
   for(let slot=0;slot<baseCount;slot++){
    let type=types[v185Hash(`${sid}:site:${slot}`)%types.length];
    if(slot===0&&['nyx','cinder'].includes(sid))type='mine';
    if(slot===0&&['forge','bastion','drakon','kronos'].includes(sid))type='garrison';
    if(slot===0&&['elysia','verdant','halcyon'].includes(sid))type='research';
    if(slot===0&&['aurora','orion','umbra'].includes(sid))type='logistics';
    const id=`surface-${sid}-${slot}-${type}`;if(p.sites[id])continue;
    const owner=SYSTEMS[sid]?.faction||'unclaimed',meta=V185_SITE_TYPES[type];
    p.sites[id]={id,system:sid,type,name:v185SiteName(sid,type,slot),owner,hp:100,defense:meta.defense+Math.round(v185Unit(`${id}:def`)*10),output:Math.round(70+v185Unit(`${id}:out`)*30),status:'operating',disruptedUntil:0,seeded:true,created:1};
   }
  }
 }
 function v185SeedNpcStrategic(){const s=game.strategicStations;if(s.npcAssets.length)return;for(const [owner,system,type] of V185_NPC_STRATEGIC_SEEDS){const d=V185_STRATEGIC_SHIPS[type];if(!d)continue;s.npcAssets.push({id:`npc-${owner}-${system}-${type}`,owner,system,type,name:`${v185FactionName(owner)} ${d.name}`,hp:100,active:true,seeded:true})}}
 function v185LocalSites(sid=game.system){return Object.values(v185State().planetary.sites).filter(x=>x.system===sid&&x.status!=='destroyed')}
 function v185Site(id){return v185State().planetary.sites[id]||null}
 function v185PlayerOwnsSystemAccess(sid){return (game.stations||[]).some(st=>st.system===sid&&st.owner==='player'&&!st.destroyed)||!!game.claims?.[sid]}
 function v185BuildSite(type){const meta=V185_SITE_TYPES[type];if(!meta||!v185PlayerOwnsSystemAccess(game.system))return toast?.('地表施設を建設するには自勢力の軌道拠点または領有権が必要');if(game.credits<meta.cost||!hasMaterials?.(meta.req))return toast?.('建設資金または資材が不足');const existing=v185LocalSites().filter(x=>x.owner==='player'&&x.type===type);if(existing.length>=2)return toast?.('同型地表施設は1星系2拠点まで');game.credits-=meta.cost;spendCargo?.(meta.req);const seq=Object.keys(v185State().planetary.sites).length+1,id=`surface-player-${game.system}-${type}-${seq}`;v185State().planetary.sites[id]={id,system:game.system,type,name:`${game.playerFaction?.name||'自勢力'} ${meta.name}`,owner:'player',hp:100,defense:meta.defense+5,output:100,status:'operating',disruptedUntil:0,seeded:false,created:game.day};v185State().planetary.metrics.sitesBuilt++;v185State().planetary.history.unshift({day:game.day,type:'build',text:`${v185SystemName(game.system)}に${meta.name}を建設`});addLog?.(`${meta.name}を${v185SystemName(game.system)}地表へ建設。軌道拠点と連携を開始した。`);save?.();render?.();return id}
 function v185RepairSite(id){const site=v185Site(id);if(!site||site.owner!=='player'||site.status==='destroyed')return;const cost=v185Round100((100-site.hp)*110+600);if(game.credits<cost)return toast?.(`修復費 ${cost.toLocaleString()} Crが必要`);game.credits-=cost;site.hp=100;site.status='operating';site.disruptedUntil=0;addLog?.(`${site.name}を完全修復。`);save?.();render?.()}

 function v185StationModuleDaily(st){let n=0;for(const key of st.modules||[])n+=V185_STATION_MODULES[key]?.daily||0;return n}
 function v185StationModuleDefense(st){let n=0;for(const key of st.modules||[])n+=V185_STATION_MODULES[key]?.defense||0;return n}

 function v185StrategicOwned(){return v185State().strategic.assets.filter(a=>a.owner==='player'&&a.status!=='destroyed')}
 function v185StrategicLocal(sid=game.system,owner=null){return [...v185State().strategic.assets,...v185State().strategic.npcAssets].filter(a=>a.system===sid&&a.active!==false&&a.status!=='destroyed'&&(!owner||a.owner===owner))}
 function v185StrategicOrbitPower(sid,owner=null){return v185StrategicLocal(sid,owner).reduce((n,a)=>n+(V185_STRATEGIC_SHIPS[a.type]?.orbit||0)*(Number(a.hp??100)/100),0)}
 function v185StrategicAtmoPower(sid,owner=null){return v185StrategicLocal(sid,owner).reduce((n,a)=>n+(V185_STRATEGIC_SHIPS[a.type]?.atmo||0)*(Number(a.hp??100)/100),0)}
 function v185PlayerYardsHere(){return (game.stations||[]).filter(st=>st.system===game.system&&st.owner==='player'&&!st.destroyed&&st.modules?.includes('shipyard'))}
 function v185CanStartStrategic(type,yard){const d=V185_STRATEGIC_SHIPS[type],s=v185State().strategic;if(!d||!yard||yard.owner!=='player'||!yard.modules?.includes('shipyard'))return false;if(v185StrategicOwned().length+s.queue.filter(q=>q.status==='building').length>=V185_MAX_STRATEGIC_ASSETS)return false;if(s.assets.some(a=>a.owner==='player'&&a.type===type&&a.status!=='destroyed')||s.queue.some(q=>q.type===type&&q.status==='building'))return false;if(game.credits<d.cost)return false;return hasMaterials?.(d.req,yard.inventory||{})}
 function v185StartStrategicBuild(type,yardId){const yard=stationById?.(yardId),d=V185_STRATEGIC_SHIPS[type];if(!v185CanStartStrategic(type,yard))return toast?.('戦略艦建造条件を満たしていません');game.credits-=d.cost;for(const [k,n] of Object.entries(d.req))yard.inventory[k]-=n;const id=v185Id('ssq',`${type}:${yardId}:${game.day}`),q={id,type,yard:yardId,system:yard.system,started:game.day,readyDay:game.day+d.days,status:'building',cost:d.cost};v185State().strategic.queue.push(q);v185State().strategic.history.unshift({day:game.day,type:'order',text:`${d.name}建造開始 / Day ${q.readyDay}竣工予定`});addLog?.(`${yard.name}で戦略級${d.role} ${d.name}の建造を開始。Day ${q.readyDay}竣工予定。`);save?.();render?.();return q}
 function v185ProcessStrategicBuilds(){const s=v185State().strategic;for(const q of s.queue.filter(q=>q.status==='building'&&q.readyDay<=game.day)){const d=V185_STRATEGIC_SHIPS[q.type];q.status='completed';q.completed=game.day;const id=v185Id('ssa',`${q.id}:complete`);s.assets.push({id,type:q.type,name:d.name,owner:'player',system:q.system,hp:100,active:true,status:'active',built:game.day,nextMoveDay:game.day+4});s.metrics.built++;s.metrics.deployed++;s.history.unshift({day:game.day,type:'complete',text:`${d.name}竣工 / ${v185SystemName(q.system)}へ配備`});v185News(`【戦略級建造】${game.playerFaction?.name||'独立勢力'}が${d.name}を竣工。${v185SystemName(q.system)}へ配備した。`);addLog?.(`戦略級艦 ${d.name}が竣工。${v185SystemName(q.system)}へ展開。`)}}
 function v185RelocateStrategic(id){const a=v185State().strategic.assets.find(x=>x.id===id&&x.owner==='player'&&x.status!=='destroyed'),d=a&&V185_STRATEGIC_SHIPS[a.type];if(!a||!d)return;if(a.system===game.system)return toast?.('すでに現在星系へ展開中');if(game.day<(a.nextMoveDay||0))return toast?.(`再配置可能 Day ${a.nextMoveDay}`);const cost=v185Round100(2800+d.power*22);if(game.credits<cost)return toast?.(`再配置費 ${cost.toLocaleString()} Crが必要`);game.credits-=cost;const from=a.system;a.system=game.system;a.nextMoveDay=game.day+5;a.hp=Math.min(100,(a.hp||100)+2);v185State().strategic.metrics.relocations++;v185State().strategic.history.unshift({day:game.day,type:'relocate',text:`${d.name}: ${v185SystemName(from)} → ${v185SystemName(game.system)}`});addLog?.(`${d.name}を${v185SystemName(game.system)}へ再配置。戦略機動費 ${cost.toLocaleString()} Cr。`);save?.();render?.()}
 function v185RepairStrategic(id){const a=v185State().strategic.assets.find(x=>x.id===id&&x.owner==='player'),d=a&&V185_STRATEGIC_SHIPS[a.type];if(!a||!d)return;const cost=v185Round100((100-(a.hp||100))*250+1200);if(game.credits<cost)return toast?.(`戦略艦修復費 ${cost.toLocaleString()} Crが必要`);game.credits-=cost;a.hp=100;addLog?.(`${d.name}を戦略ドックで完全修復。`);save?.();render?.()}

 function v185AssignmentShips(){return (game.ownedHulls||[]).filter(id=>v185SurfaceHull(id)&&id!==game.hull)}
 function v185AssignSurfaceShip(id,sid=game.system){if(!game.ownedHulls?.includes(id)||!v185SurfaceHull(id))return;if(!v185PlayerOwnsSystemAccess(sid))return toast?.('自勢力拠点のある星系にのみ地上防衛任務を設定できます');v185State().planetary.assignments[id]={ship:id,system:sid,assigned:game.day};addLog?.(`${getHull(id)?.name||id}を${v185SystemName(sid)}の惑星防衛予備へ配置。`);save?.();render?.()}
 function v185UnassignSurfaceShip(id){if(v185State().planetary.assignments[id]){delete v185State().planetary.assignments[id];save?.();render?.()}}
 function v185AssignedAtmoPower(sid){let n=0;for(const [id,a] of Object.entries(v185State().planetary.assignments)){if(a.system!==sid||!game.ownedHulls?.includes(id))continue;n+=v185AtmoPower(id)}return n}
 function v185AssignedSurfacePower(sid){let n=0;for(const [id,a] of Object.entries(v185State().planetary.assignments)){if(a.system!==sid||!game.ownedHulls?.includes(id))continue;n+=v185SurfacePower(id)}return n}

 function v185SystemStationDefense(sid,owner){let n=0;for(const st of game.stations||[]){if(st.system!==sid||st.destroyed||st.owner!==owner)continue;try{n+=stationDefense(st)}catch(_){n+=34+(st.modules?.includes('defense')?34:0)}}return n}
 function v185FleetDefense(sid){let n=0;for(const f of game.fleets||[]){const st=stationById?.(f.station);if(st?.system!==sid||st.owner!=='player')continue;const fm=FLEET_MISSIONS?.[f.mission||'guard']||{power:1},fh=FLEET_HULLS?.[f.type]||{power:20};n+=(fh.power+(f.powerBonus||0))*fm.power}return n}
 function v185GarrisonSupport(sid,owner){return v185LocalSites(sid).filter(s=>s.owner===owner&&s.type==='garrison'&&s.status!=='destroyed').reduce((n,s)=>n+(s.defense||42)*.65,0)}
 function v185Defenses(sid,owner){
  const orbit=v185SystemStationDefense(sid,owner)+v185StrategicOrbitPower(sid,owner)+(owner==='player'?v185FleetDefense(sid):0);
  let atmo=v185StrategicAtmoPower(sid,owner)+v185GarrisonSupport(sid,owner)*.45;
  let surface=v185GarrisonSupport(sid,owner);
  if(owner==='player'){atmo+=v185AssignedAtmoPower(sid);surface+=v185AssignedSurfacePower(sid);if(game.system===sid&&v185SurfaceHull(game.hull)){atmo+=v185AtmoPower(game.hull)*.55;surface+=v185SurfacePower(game.hull)*.55}}
  return{orbit:Math.round(orbit),atmo:Math.round(atmo),surface:Math.round(surface)}
 }

 function v185PirateBands(){try{return Object.values(game.gm?.irregular?.pirateBands||{}).filter(b=>(b.power||0)>.8)}catch(_){return[]}}
 function v185RaidTargetCandidates(b){const systems=[b.system,...Object.keys(SYSTEMS?.[b.system]?.routes||{})];const sites=[];for(const sid of systems)for(const site of v185LocalSites(sid)){if(site.status==='destroyed')continue;if(site.owner==='unclaimed'&&site.type==='garrison')continue;sites.push(site)}return sites}
 function v185RaidTargetScore(b,site){const meta=V185_SITE_TYPES[site.type],ownerDefense=v185Defenses(site.system,site.owner),security=SYSTEMS?.[site.system]?.security,sec=security==='最高'?35:security==='高'?24:security==='軍管'?30:security==='無法'?-8:8;let score=(meta?.value||60)+(100-site.hp)*.3-(site.defense||0)*.35-ownerDefense.orbit*.10-ownerDefense.atmo*.08-sec;if(site.owner==='player')score+=8;if(site.status==='disrupted')score-=12;score+=v185Unit(`${b.id}:${site.id}:${Math.floor(game.day/3)}`)*20;return score}
 function v185CreateRaid(band,site,force=false){if(!band||!site)return null;const p=v185State().planetary,bucket=Math.floor(game.day/3),id=`raid-${band.id}-${site.id}-${bucket}`;if(p.raids.some(r=>r.id===id))return null;const pressure=Number(game.gm?.irregular?.piracyPressure?.[site.system]||0),chance=.14+Math.min(.26,(band.power||5)*.012)+pressure*.002+(SYSTEMS?.[site.system]?.security==='無法'?.14:0);if(!force&&v185Unit(`${id}:spawn`)>chance)return null;const strength=Math.round(30+(band.power||6)*5+(band.notoriety||20)*.22+v185Unit(`${id}:str`)*24),raider=strength>86?'hammerhead_ag':strength>54?'marauder_rx':'strider_ax',raid={id,bandId:band.id,bandName:band.name||band.id,system:site.system,target:site.id,owner:site.owner,created:game.day,resolveDay:game.day+1,status:'active',strength,raiderHull:raider,phase:'approach',playerIntervened:false,interceptDamage:0};p.raids.push(raid);p.metrics.raids++;p.history.unshift({day:game.day,type:'raid',text:`${raid.bandName} → ${site.name}`});v185News(`【惑星襲撃警報】${raid.bandName}が${v185SystemName(site.system)}の${site.name}へ降下戦力を向けた。推定主力 ${HULLS[raider]?.name||raider}。`);return raid}
 function v185GenerateRaids(){const p=v185State().planetary;for(const b of v185PirateBands()){const key=`${b.id}:${Math.floor(game.day/3)}`;if(p.history.some(h=>h.raidKey===key))continue;const targets=v185RaidTargetCandidates(b).sort((a,c)=>v185RaidTargetScore(b,c)-v185RaidTargetScore(b,a));const site=targets[0];p.history.unshift({day:game.day,type:'raid_check',raidKey:key,text:`${b.name||b.id} target evaluation`});if(site)v185CreateRaid(b,site,false)}p.history=p.history.slice(0,180)}
 function v185ResolveRaid(raid){if(!raid||raid.status!=='active')return raid;const site=v185Site(raid.target);if(!site||site.status==='destroyed'){raid.status='cancelled';return raid}const def=v185Defenses(raid.system,site.owner),jitter=(v185Unit(`${raid.id}:resolve`)-.5)*18;let attack=raid.strength-Math.max(0,raid.interceptDamage||0),report=[];
  const orbitalMargin=def.orbit-attack*.78+jitter;report.push(`軌道 ${Math.round(def.orbit)} vs ${Math.round(attack*.78)}`);if(orbitalMargin>=14){raid.status='repelled';raid.phase='orbit';raid.result='orbital_intercept';v185RaidRepelled(raid,site,'軌道防衛線で撃退');return raid}attack*=orbitalMargin>0?.78:1.04;
  const atmoMargin=def.atmo-attack*.64+(v185Unit(`${raid.id}:atmo`)-.5)*14;report.push(`大気圏 ${Math.round(def.atmo)} vs ${Math.round(attack*.64)}`);if(atmoMargin>=12){raid.status='repelled';raid.phase='atmosphere';raid.result='atmo_intercept';v185RaidRepelled(raid,site,'大気圏迎撃で撃退');return raid}attack*=atmoMargin>0?.76:1.02;
  const surfaceDef=(site.defense||0)+def.surface, surfaceMargin=surfaceDef-attack*.58+(v185Unit(`${raid.id}:surface`)-.5)*12;report.push(`地上 ${Math.round(surfaceDef)} vs ${Math.round(attack*.58)}`);raid.report=report;
  if(surfaceMargin>=5){raid.status='repelled';raid.phase='surface';raid.result='surface_defense';v185RaidRepelled(raid,site,'地上防衛戦で撃退');return raid}
  const damage=Math.round(v185Clamp(18+(attack-surfaceDef)*.45+v185Unit(`${raid.id}:damage`)*22,16,65));site.hp=v185Clamp(site.hp-damage,0,100);site.disruptedUntil=game.day+2+Math.floor(v185Unit(`${raid.id}:down`)*4);site.status=site.hp<=0?'destroyed':'disrupted';raid.status='success';raid.phase='surface';raid.result='facility_raided';raid.damage=damage;v185State().planetary.metrics.successfulRaids++;if(site.status==='destroyed')v185State().planetary.metrics.facilitiesLost++;
  const band=game.gm?.irregular?.pirateBands?.[raid.bandId];if(band){const loot=Math.round((V185_SITE_TYPES[site.type]?.value||60)*90*(.75+v185Unit(`${raid.id}:loot`)*.7));band.treasury=(band.treasury||0)+loot;band.notoriety=v185Clamp((band.notoriety||0)+2,0,100);band.raids=(band.raids||0)+1;band.lastTarget=site.system}
  v185News(`【地表襲撃】${raid.bandName}が${site.name}の防衛線を突破。施設損傷 ${damage}%${site.status==='destroyed'?'、施設喪失':''}。`);if(site.owner==='player')addLog?.(`海賊襲撃：${site.name}が${damage}%損傷。${site.status==='destroyed'?'施設は失われた。':`Day ${site.disruptedUntil}まで機能低下。`}`);return raid
 }
 function v185RaidRepelled(raid,site,reason){raid.report=raid.report||[];v185State().planetary.metrics.repelled++;const band=game.gm?.irregular?.pirateBands?.[raid.bandId];if(band){band.failures=(band.failures||0)+1;band.power=Math.max(1,(band.power||1)-.4-v185Unit(`${raid.id}:pirloss`)*1.1);band.heat=v185Clamp((band.heat||0)+4,0,100)}v185News(`【惑星防衛】${site.name}への${raid.bandName}襲撃を${reason}。`);if(site.owner==='player')addLog?.(`${site.name}：${reason}。`)}
 function v185PlayerInterceptRaid(id){const raid=v185State().planetary.raids.find(r=>r.id===id&&r.status==='active'),site=raid&&v185Site(raid.target);if(!raid||!site)return;if(game.system!==raid.system)return toast?.(`${v185SystemName(raid.system)}へ移動してください`);const h=typeof hull==='function'?hull():HULLS?.[game.hull],surface=!!h?.surfaceCapable,combat=(()=>{try{return combatPower()}catch(_){return COMBAT_POWER?.[h?.class]||10}})(),atmo=surface?(h.atmoPower||0):0,score=combat+atmo*.65+(surface?(h.surfacePower||0)*.25:0),target=raid.strength*.62,margin=score-target+(v185Unit(`${raid.id}:player:${game.hull}`)-.5)*14;raid.playerIntervened=true;v185State().planetary.metrics.playerIntercepts++;
  if(margin>=0){const cut=Math.round(v185Clamp(raid.strength*(.34+Math.min(.38,margin/160)),12,raid.strength*.82));raid.interceptDamage=(raid.interceptDamage||0)+cut;raid.phase=surface?'atmosphere_intercept':'orbit_intercept';addLog?.(`${surface?'大気圏追撃':'軌道迎撃'}で${raid.bandName}の降下戦力を${cut}相当削減。`);if(raid.interceptDamage>=raid.strength*.72){raid.status='repelled';raid.result='player_intercept';v185RaidRepelled(raid,site,'プレイヤー艦が降下戦力を撃破')}}else{const dmg=Math.round(v185Clamp(4+(-margin)/9+v185Unit(`${raid.id}:playerdmg`)*6,4,18));try{damageShip?.(dmg)}catch(_){}raid.interceptDamage=(raid.interceptDamage||0)+Math.round(raid.strength*.12);addLog?.(`海賊降下戦力の迎撃に失敗。船体 ${dmg}%損傷したが、敵戦力の一部を削減。`)}save?.();render?.();return raid}
 function v185ResolveDueRaids(){for(const r of v185State().planetary.raids.filter(r=>r.status==='active'&&r.resolveDay<=game.day))v185ResolveRaid(r);v185State().planetary.raids=v185State().planetary.raids.filter(r=>r.status==='active'||r.created>=game.day-18).slice(-80)}

 function v185ApplySiteEconomy(){for(const site of Object.values(v185State().planetary.sites)){if(site.status==='destroyed')continue;if(site.status==='disrupted'&&game.day>site.disruptedUntil)site.status='operating';if(site.status!=='operating')continue;const strength=(site.output||80)/100;if(site.type==='logistics'){const l=game.gm?.systemLogistics?.[site.system];if(l){l.routeHealth=v185Clamp((l.routeHealth||70)+.02*strength,0,100);l.shortage=v185Clamp((l.shortage||0)-.025*strength,0,100)}}if(site.type==='research'){const fid=site.owner!=='player'?site.owner:SYSTEMS?.[site.system]?.faction;if(fid&&game.gm?.factions?.[fid])game.gm.factions[fid].research=v185Clamp((game.gm.factions[fid].research||50)+.012*strength,0,100)}if(site.type==='fuel'){const fid=site.owner!=='player'?site.owner:SYSTEMS?.[site.system]?.faction;if(fid&&game.gm?.factions?.[fid])game.gm.factions[fid].logistics=v185Clamp((game.gm.factions[fid].logistics||50)+.01*strength,0,100)}}}
 function v185Daily(){const p=v185State().planetary;if(p.lastDailyDay===game.day)return;p.lastDailyDay=game.day;v185ProcessStrategicBuilds();v185ResolveDueRaids();v185ApplySiteEconomy();v185GenerateRaids();if(game)game.version=V185_BUILD}

 function v185SurfaceBuyable(id){const h=HULLS[id];if(!h)return false;if(id==='marauder_rx')return ['nyx','cinder','meridian'].includes(game.system)||(game.stations||[]).some(st=>st.system===game.system&&!st.destroyed&&st.modules?.includes('blackMarket'));try{return !h.military||canBuyHull?.(id)}catch(_){return !h.military}}
 function v185BuySurfaceHull(id){const h=HULLS[id];if(!h||game.ownedHulls.includes(id)||!v185SurfaceBuyable(id)||game.credits<h.cost)return toast?.('購入条件を満たしていません');if(id==='marauder_rx'){game.credits-=h.cost;game.ownedHulls.push(id);game.hullState[id]={condition:100};game.shipRecords[id]={acquired:game.day,battles:0,captures:0,defenses:0,maxDamage:0,medals:['非正規地表作戦艦登録']};addLog?.(`${h.name}を非公式市場から取得。`);save?.();render?.();return id}buyHull?.(id);return id}

 // ---- Rendering -------------------------------------------------------------
 function v185ModuleEffectsHtml(){return `<div class="v185-module-legend">${Object.entries(V185_STATION_MODULES).map(([k,m])=>`<span>${m.icon} ${escapeHtml(m.name)}</span>`).join('')}</div>`}
 function v185StrategicCard(a){const d=V185_STRATEGIC_SHIPS[a.type];if(!d)return'';const mine=a.owner==='player';return `<div class="v185-strategic-card"><div class="station-head"><div><b>${d.icon} ${escapeHtml(a.name||d.name)}</b><div class="smallnote">${escapeHtml(d.role)} / ${escapeHtml(v185FactionName(a.owner))}</div></div><span class="pill">HP ${Math.round(a.hp??100)}%</span></div><div class="statsline">軌道 ${d.orbit} / 大気圏 ${d.atmo} / 戦略戦力 ${d.power}</div><p>${escapeHtml(d.desc)}</p><div class="smallnote">展開：${escapeHtml(v185SystemName(a.system))} / ${escapeHtml(d.bonus)}</div>${mine?`<div class="actions"><button onclick="StarFrontierPlanetaryOps.relocateStrategic('${a.id}')" ${a.system===game.system||game.day<(a.nextMoveDay||0)?'disabled':''}>現在星系へ再配置</button><button class="secondary" onclick="StarFrontierPlanetaryOps.repairStrategic('${a.id}')" ${(a.hp??100)>=100?'disabled':''}>修復</button></div>`:''}</div>`}
 function v185StrategicBuildHtml(){const s=v185State().strategic,yards=v185PlayerYardsHere(),owned=v185StrategicOwned(),queue=s.queue.filter(q=>q.status==='building');return `<div class="section-title"><h3>🏰 戦略級ステーション艦</h3><span class="pill">${owned.length}/${V185_MAX_STRATEGIC_ASSETS} PLAYER STRATEGIC ASSETS</span></div><p class="desc">通常艦ではなく、宙域そのものの戦略条件を変える移動拠点。希少性維持のため自勢力は最大${V185_MAX_STRATEGIC_ASSETS}隻、同型1隻までです。</p>${queue.length?`<div class="v185-build-queue">${queue.map(q=>{const d=V185_STRATEGIC_SHIPS[q.type];return `<div class="news-item"><b>${escapeHtml(d.name)}</b> / ${escapeHtml(stationById?.(q.yard)?.name||'造船所')}<br>Day ${q.readyDay}竣工予定</div>`}).join('')}</div>`:''}<div class="v185-strategic-grid">${owned.map(v185StrategicCard).join('')||'<div class="hint">自勢力の戦略級ステーション艦はまだありません。</div>'}</div><details><summary>戦略級建造カタログ（12系列）</summary>${yards.length?`<div class="v185-strategic-grid">${Object.entries(V185_STRATEGIC_SHIPS).map(([id,d])=>{const yard=yards[0],ok=v185CanStartStrategic(id,yard);return `<div class="v185-strategic-card"><b>${d.icon} ${escapeHtml(d.name)}</b><div class="smallnote">${escapeHtml(d.role)} / 戦略戦力 ${d.power} / 建造 ${d.days}日</div><p>${escapeHtml(d.desc)}</p><div class="smallnote">${d.cost.toLocaleString()} Cr / ${escapeHtml(v185MaterialText(d.req))}</div><button class="purple" onclick="StarFrontierPlanetaryOps.buildStrategic('${id}','${yard.id}')" ${ok?'':'disabled'}>戦略級建造開始</button></div>`}).join('')}</div>`:'<div class="hint">現在星系に自勢力造船所が必要です。戦略級資材は造船所在庫から消費します。</div>'}</details>`}
 function v185SiteCard(site){const m=V185_SITE_TYPES[site.type],raid=v185State().planetary.raids.find(r=>r.status==='active'&&r.target===site.id),def=v185Defenses(site.system,site.owner);return `<div class="v185-site-card ${site.status==='disrupted'?'hot':''}"><div class="station-head"><div><b>${m.icon} ${escapeHtml(site.name)}</b><div class="smallnote">${escapeHtml(v185FactionName(site.owner))} / ${escapeHtml(v185SystemName(site.system))}</div></div><span class="pill">HP ${Math.round(site.hp)}%</span></div><p>${escapeHtml(m.desc)}</p><div class="statsline">施設防衛 ${Math.round(site.defense)} / 稼働 ${Math.round(site.output)}% / ${site.status==='operating'?'正常稼働':site.status==='disrupted'?`機能低下 Day ${site.disruptedUntil}まで`:'喪失'}</div><div class="smallnote">地域防衛：軌道 ${def.orbit} / 大気圏 ${def.atmo} / 地上 ${def.surface}</div>${raid?`<div class="v185-raid-alert">☠ ${escapeHtml(raid.bandName)} 襲撃接近 / 戦力 ${raid.strength} / Day ${raid.resolveDay}決着<br>降下主力 ${escapeHtml(HULLS[raid.raiderHull]?.name||raid.raiderHull)}${game.system===raid.system?`<button class="dangerBtn" onclick="StarFrontierPlanetaryOps.interceptRaid('${raid.id}')">迎撃する</button>`:''}</div>`:''}${site.owner==='player'&&site.hp<100?`<button class="secondary" onclick="StarFrontierPlanetaryOps.repairSite('${site.id}')">施設修復</button>`:''}</div>`}
 function v185PlanetaryHtml(){const sites=v185LocalSites(),active=v185State().planetary.raids.filter(r=>r.status==='active'&&r.system===game.system),access=v185PlayerOwnsSystemAccess(game.system);return `<div class="section-title"><h3>🌍 惑星・地表オペレーション</h3><span class="pill">ORBIT → ATMOSPHERE → SURFACE</span></div><p class="desc">軌道優勢、大気圏迎撃、地上施設防衛の3層で惑星作戦を処理します。海賊は地上対応艦を降下させ、鉱山・燃料施設・研究所・物流デポ・居住区を実際に襲撃します。</p>${active.length?`<div class="v185-alert-strip">⚠ 現在星系に進行中の惑星襲撃 ${active.length}件</div>`:''}<div class="v185-site-grid">${sites.map(v185SiteCard).join('')||'<div class="hint">登録された地表施設はありません。</div>'}</div>${access?`<details><summary>自勢力の地表施設を建設</summary><div class="v185-site-grid">${Object.entries(V185_SITE_TYPES).map(([k,m])=>{const ok=game.credits>=m.cost&&hasMaterials?.(m.req);return `<div class="v185-site-card"><b>${m.icon} ${escapeHtml(m.name)}</b><p>${escapeHtml(m.desc)}</p><div class="smallnote">${m.cost.toLocaleString()} Cr / ${escapeHtml(v185MaterialText(m.req))}</div><button class="good" onclick="StarFrontierPlanetaryOps.buildSite('${k}')" ${ok?'':'disabled'}>建設</button></div>`}).join('')}</div></details>`:''}`}
 function v185SurfaceFleetHtml(){const owned=(game.ownedHulls||[]).filter(v185SurfaceHull),assign=v185State().planetary.assignments;return `<div class="section-title"><h3>🛬 大気圏・地表対応艦</h3><span class="pill">DUAL-ENVIRONMENT VESSELS</span></div><p class="desc">巨大戦艦を無理に惑星へ降ろさず、専用設計の小・中型航宙艦が宇宙戦と地表作戦を往復します。戦艦・空母・ドレッドノートは原則として軌道上から支援します。</p><div class="v185-surface-grid">${Object.entries(V185_SURFACE_HULLS).map(([id,h])=>{const own=game.ownedHulls?.includes(id),allowed=v185SurfaceBuyable(id),assigned=assign[id];return `<div class="v185-surface-card">${typeof sfShipImageHtml==='function'?sfShipImageHtml(id,h.name,'sf-ship-thumb'):''}<div><b>${escapeHtml(h.name)}</b><span class="pill">${escapeHtml(SHIP_CLASSES[h.class]?.name||h.class)}</span><div class="statsline">大気圏 ${h.atmoPower} / 地上 ${h.surfacePower} / ${escapeHtml(h.surfaceRole)}</div><p>${escapeHtml(h.desc)}</p>${own?`<div class="smallnote">${assigned?`惑星防衛：${escapeHtml(v185SystemName(assigned.system))}`:'予備艦・未配備'}</div><div class="actions">${id!==game.hull&&!assigned&&v185PlayerOwnsSystemAccess(game.system)?`<button onclick="StarFrontierPlanetaryOps.assignSurface('${id}')">現在星系の地上防衛へ</button>`:''}${assigned?`<button class="secondary" onclick="StarFrontierPlanetaryOps.unassignSurface('${id}')">配備解除</button>`:''}</div>`:`<button onclick="StarFrontierPlanetaryOps.buySurface('${id}')" ${allowed&&game.credits>=h.cost?'':'disabled'}>${h.cost.toLocaleString()} Crで取得</button>`}</div></div>`}).join('')}</div>`}
 function v185StationOverviewHtml(){const locals=localStations?.()||[];return `<div class="section-title"><h3>🏗 ステーション用途分類</h3><span class="pill">${Object.keys(V185_STATION_ARCHETYPES).length} ROLES</span></div><p class="desc">モジュール構成に応じて、交易、造船、軍港、要塞、採鉱、研究、監視、医療、燃料、居住、非公式交易などの役割へ発展します。</p>${v185ModuleEffectsHtml()}<div class="v185-station-role-grid">${locals.map(st=>{const a=v185StationClass(st);return `<div class="news-item"><b>${a.icon} ${escapeHtml(st.name)}</b><br>${escapeHtml(a.name)} / ${escapeHtml(v185FactionName(st.owner))} / 防衛 ${Math.round(stationDefense?.(st)||0)}</div>`}).join('')||'<div class="hint">現在地に稼働ステーションなし</div>'}</div>`}
 function v185Mount(){const galaxy=document.getElementById('galaxy'),tab=document.getElementById('gal-stations');if(!galaxy||galaxy.classList?.contains('hidden')||!tab||tab.classList?.contains('hidden'))return;let wrap=document.getElementById('v185StrategicPlanetaryPanel');if(!wrap){wrap=document.createElement('div');wrap.id='v185StrategicPlanetaryPanel';wrap.innerHTML='<div id="v185StationRoles" class="panel"></div><div id="v185StrategicShips" class="panel"></div><div id="v185PlanetaryOps" class="panel"></div><div id="v185SurfaceShips" class="panel"></div>';tab.appendChild(wrap)}document.getElementById('v185StationRoles').innerHTML=v185StationOverviewHtml();document.getElementById('v185StrategicShips').innerHTML=v185StrategicBuildHtml();document.getElementById('v185PlanetaryOps').innerHTML=v185PlanetaryHtml();document.getElementById('v185SurfaceShips').innerHTML=v185SurfaceFleetHtml()}
 function v185ApplyVersionUI(){if(game)game.version=V185_BUILD;const badge=document.querySelector?.('header .title .badge')||document.querySelector?.('.version-badge');if(badge)badge.textContent='v'+V185_BUILD;const sub=document.querySelector?.('header .sub');if(sub)sub.textContent='Strategic Stations / Planetary Operations / Surface-Capable Ships / Pirate Landing Raids';if(typeof document!=='undefined')document.title='STAR FRONTIER v1.85.0 — Strategic Stations & Planetary Operations'}

 // ---- Integration wrappers -------------------------------------------------
 const v185StationDefenseBase=typeof stationDefense==='function'?stationDefense:null;if(v185StationDefenseBase)stationDefense=function(st){return v185StationDefenseBase(st)+v185StationModuleDefense(st)+Math.round(v185StrategicOrbitPower(st?.system,st?.owner)*.55)};
 const v185ProcessStationDayBase=typeof processStationDay==='function'?processStationDay:null;if(v185ProcessStationDayBase)processStationDay=function(){const before=game.credits,out=v185ProcessStationDayBase();let extra=0;for(const st of playerStations?.()||[])extra+=v185StationModuleDaily(st);for(const a of v185StrategicOwned()){const d=V185_STRATEGIC_SHIPS[a.type];if(a.type==='atlas')extra+=120;if(a.type==='devourer')extra+=95;if(a.type==='gatekeeper')extra+=80;if(a.type==='hospitaller')extra+=40;if(a.type==='observer')game.agency&&(game.agency.intel=(game.agency.intel||0)+1);if(a.type==='sovereign')game.agency&&(game.agency.intel=(game.agency.intel||0)+1);if(a.type==='leviathan_dock')game.bio&&(game.bio.affinity=(game.bio.affinity||0)+.02);if(a.type==='axiom_node')game.machineContact&&(game.machineContact.resonance=(game.machineContact.resonance||0)+.01)}if(extra>0){game.credits+=extra;addLog?.(`拡張ステーション・戦略艦収益 +${extra.toLocaleString()} Cr。`)}return out};
 const v185RenderStationEconomyBase=typeof renderStationEconomy==='function'?renderStationEconomy:null;if(v185RenderStationEconomyBase)renderStationEconomy=function(){const out=v185RenderStationEconomyBase();const el=document.getElementById('stationEconomyPanel');if(el){const extra=(playerStations?.()||[]).reduce((n,st)=>n+v185StationModuleDaily(st),0);el.insertAdjacentHTML('beforeend',`<div class="news-item"><b>v1.85 拡張施設</b><br>固定日次収益 +${extra.toLocaleString()} Cr / 戦略級ステーション艦 ${v185StrategicOwned().length}隻 / 地表施設 ${v185LocalSites().filter(x=>x.owner==='player').length}拠点</div>`)}return out};
 const v185GmAdvanceBase=typeof gmAdvance==='function'?gmAdvance:null;if(v185GmAdvanceBase)gmAdvance=function(){const out=v185GmAdvanceBase();v185Daily();if(game)game.version=V185_BUILD;return out};
 const v185InitBase=typeof initV10==='function'?initV10:null;if(v185InitBase)initV10=function(){const out=v185InitBase();v185State();if(game)game.version=V185_BUILD;return out};
 const v185RenderStationsBase=typeof renderStations==='function'?renderStations:null;if(v185RenderStationsBase)renderStations=function(){const out=v185RenderStationsBase();try{v185Mount()}catch(_){}return out};
 const v185RenderBase=typeof render==='function'?render:null;if(v185RenderBase)render=function(){const out=v185RenderBase();try{v185State();v185ApplyVersionUI();v185Mount()}catch(_){}return out};
 const v185SaveBase=typeof save==='function'?save:null;if(v185SaveBase)save=function(){const build=(typeof window!=='undefined'&&window.StarFrontierPerformanceHotfix?.build)||V185_BUILD;if(game)game.version=build;const out=v185SaveBase.apply(this,arguments);if(game)game.version=build;return out};

 window.StarFrontierPlanetaryOps={
  ensure:v185State,stationModules:V185_STATION_MODULES,stationShips:V185_STRATEGIC_SHIPS,surfaceHulls:V185_SURFACE_HULLS,siteTypes:V185_SITE_TYPES,
  sites:v185LocalSites,buildSite:v185BuildSite,repairSite:v185RepairSite,
  buildStrategic:v185StartStrategicBuild,processBuilds:v185ProcessStrategicBuilds,relocateStrategic:v185RelocateStrategic,repairStrategic:v185RepairStrategic,
  assignSurface:v185AssignSurfaceShip,unassignSurface:v185UnassignSurfaceShip,buySurface:v185BuySurfaceHull,
  createRaid:v185CreateRaid,generateRaids:v185GenerateRaids,resolveRaid:v185ResolveRaid,resolveDueRaids:v185ResolveDueRaids,interceptRaid:v185PlayerInterceptRaid,
  defenses:v185Defenses,daily:v185Daily,feature:V185_FEATURE
 };
})();
