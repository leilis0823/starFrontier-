'use strict';
// ============================================================================
// v1.85.6 — Finance Tab Restoration
// Restores the Finance/Income tab entry that became unreachable after lazy UI
// guards were introduced. The finance content remains lazy; only the lightweight
// navigation shell is guaranteed to exist before visibility guards are evaluated.
// ============================================================================
(function(){
 const BUILD='1.85.6';
 let ensured=false;

 function setVersion(){
  try{
   if(typeof game!=='undefined'&&game)game.version=BUILD;
   const badge=document.querySelector?.('header .title .badge')||document.querySelector?.('.version-badge');
   if(badge)badge.textContent='v'+BUILD;
   const sub=document.querySelector?.('header .sub');
   if(sub)sub.textContent='Finance Tab Restoration / Mining Diversity / Architecture Performance';
   if(typeof document!=='undefined')document.title='STAR FRONTIER v1.85.6 — Finance Tab Restoration';
  }catch(_){}
 }

 function ensureFinanceShell(){
  if(typeof document==='undefined')return false;
  const galaxy=document.getElementById('galaxy');
  if(!galaxy)return false;
  const segment=galaxy.querySelector?.('.segment')||document.querySelector?.('#galaxy .segment');
  if(!segment)return false;

  let button=document.getElementById('seg-finance');
  if(!button){
   button=document.createElement('button');
   button.id='seg-finance';
   button.textContent='金融・収支';
   button.setAttribute('onclick',"showGalaxy('finance')");
   const corp=document.getElementById('seg-corporations');
   const military=document.getElementById('seg-military');
   const anchor=(corp&&corp.parentElement===segment)?corp.nextSibling:((military&&military.parentElement===segment)?military:null);
   segment.insertBefore(button,anchor||null);
  }

  let pane=document.getElementById('gal-finance');
  if(!pane){
   pane=document.createElement('div');
   pane.id='gal-finance';
   pane.className='gal-sub hidden';
   pane.innerHTML='<div id="v115FinanceRoot"></div>';
   const main=document.getElementById('v155GalaxyMain');
   const panel=galaxy.querySelector?.(':scope > .panel')||galaxy.querySelector?.('.panel')||document.querySelector?.('#galaxy .panel');
   const host=main||panel;
   if(host){
    const military=document.getElementById('gal-military');
    host.insertBefore(pane,(military&&military.parentElement===host)?military:null);
   }
  }else if(!document.getElementById('v115FinanceRoot')){
   pane.insertAdjacentHTML?.('afterbegin','<div id="v115FinanceRoot"></div>');
  }

  ensured=!!document.getElementById('seg-finance')&&!!document.getElementById('gal-finance');
  try{
   // v1.55 knows finance belongs to the Economy category. Re-apply only when
   // the adaptive shell already exists; this does not render finance content.
   if(ensured&&document.getElementById('v155GalaxyShell')&&typeof v155EnsureGalaxyLayout==='function'){
    v155EnsureGalaxyLayout();
    if(typeof v155ApplyCategory==='function')v155ApplyCategory();
   }
  }catch(_){}
  return ensured;
 }

 // The static HTML now contains the shell. This fallback also makes upgrades
 // resilient if a cached/older document shell is ever loaded by a WebView.
 ensureFinanceShell();

 if(typeof initV10==='function'){
  const base=initV10;
  initV10=function(){const out=base.apply(this,arguments);ensureFinanceShell();setVersion();return out};
 }
 if(typeof load==='function'){
  const base=load;
  load=function(){const out=base.apply(this,arguments);ensureFinanceShell();setVersion();return out};
 }
 if(typeof render==='function'){
  const base=render;
  render=function(){const out=base.apply(this,arguments);if(!ensured)ensureFinanceShell();setVersion();return out};
 }

 // save() is already version-stamped by the v1.85.1 batching layer, whose
 // active build constant is updated to 1.85.6 in this release.
 setVersion();
 window.StarFrontierFinanceTabFix={build:BUILD,ensureShell:ensureFinanceShell,state:()=>({ensured:!!document.getElementById('seg-finance')&&!!document.getElementById('gal-finance')})};
})();
