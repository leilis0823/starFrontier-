# STAR FRONTIER v1.85.5 — Japanese Corporate Names Fix

## Problem

The regional fiscal UI (`地方財政・企業関係 > 企業・地方政府`) displayed enterprise storage keys such as `corp:horizon` instead of the Japanese company names already defined elsewhere in the game.

## Root cause

`v136EnterpriseRows()` used `e.key` directly for presentation. The enterprise subsystem already exposes `v127EnterpriseName(key)`, which resolves corporation, food manufacturer, support firm, player company, and subsidiary keys to their display names.

## Fix

The regional fiscal renderer now resolves each enterprise through `v127EnterpriseName(e.key)` and keeps the original key only as a fallback. No enterprise key or save data is migrated.

Verified examples:

- `corp:horizon` → ヴェイル・ホライズン物流共同体
- `corp:crownstar` → クラウンスター鉱業取引機構
- `corp:pilgrim` → ピルグリム航宙燃料共同体
- `corp:regulus` → レグルス軌道造船株式会社
- `corp:aurora_bank` → オーロラ連盟商業銀行
- `food:league:aurora_provisions` → オーロラ・プロヴィジョンズ

## Compatibility

- Save schema: unchanged
- Enterprise IDs: unchanged
- Economy/AI behavior: unchanged
- Global RNG consumption: unchanged
- v1.85.4 mining/HUD behavior: retained
- v1.85.2 performance architecture: retained

## Validation

`v1855-corporate-name-localization-smoke.cjs` initializes the real game script set, renders the Aurora regional enterprise rows, checks all six Japanese names, and rejects the six raw IDs. The complete smoke suite remains green.
