# STAR FRONTIER v1.85.6 — Finance Tab Restoration

## 症状

銀河画面から「金融・収支」タブが消え、収支明細・給与・銀行・国債などの金融UIへ通常操作で到達できなかった。

## 原因

v1.15の `ensureV115UI()` は `renderV115FinancePanel()` の内部から `seg-finance` / `gal-finance` を初回生成する設計だった。一方、v1.81.4とv1.85.1はパフォーマンス対策として `renderV115FinancePanel()` を `gal-finance` が表示中の場合にのみ実行する遅延ガードで包んだ。

その結果、

1. `gal-finance` がまだ存在しない
2. visibility guard が false
3. `renderV115FinancePanel()` が実行されない
4. `ensureV115UI()` も実行されず `gal-finance` が生成されない

という循環依存が発生した。金融データ自体は削除されていない。

## 修正

- `index.html` に「金融・収支」ボタンと空の金融paneを静的に配置する。
- pane内部は `v115FinanceRoot` だけを保持し、実コンテンツは既存のlazy rendererで初回表示時に生成する。
- v1.55 Adaptive UIの既存分類 `finance:'economy'` を利用し、「💰 経済」カテゴリ内へ表示する。
- `136-v1_85_6-finance-tab-restoration.js` は、旧HTMLキャッシュ等でshellが欠落した場合のみ安全に補完する。
- finance rendererの非表示ガードは撤去しないため、パフォーマンス改善を維持する。

## 非変更事項

- `game.finance` 保存形式
- ledger / paystubs / personalLoans / bonds / banking state
- 企業AI、国家AI、経済シミュレーション
- global RNG / marketSeed の消費順

## 検証

- `seg-finance`: 1件
- `gal-finance`: 1件
- `v115FinanceRoot`: 1件
- Adaptive UI category: `finance -> economy`
- finance content lazy guards: 維持
- Web JavaScript syntax: PASS
- index script missing refs: 0
- duplicate static HTML ids: 0
- smoke: 32 / 32 PASS
- v1.81.4 RNG preservation: PASS
- v1.85.2 navigation state equivalence: PASS
