v1.75.0 APKはこのソースZIPには同梱していません。GitHub ActionsまたはAndroid SDK環境で `assembleNubiaDebug` / `assembleUniversalDebug` を実行してください。
