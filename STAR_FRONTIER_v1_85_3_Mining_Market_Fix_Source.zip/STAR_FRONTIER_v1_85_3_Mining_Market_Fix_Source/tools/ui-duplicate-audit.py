from pathlib import Path

root = Path(__file__).resolve().parents[1]
js = root / 'www' / 'js'
core = (js / '10-v1_1-v1_17.js').read_text(encoding='utf-8')
gov = (js / '20-v1_18-v1_31.js').read_text(encoding='utf-8')

checks = {
    'v130 governance has stable DOM id': 'id="v130PlayerGovernance"' in gov,
    'v117 cleanup removes v130 governance': '#v117BusinessPanel,#v118GroupPanel,#v130PlayerGovernance' in core,
    'v19 career sibling cleaned': "document.getElementById('v19CareerExtra')?.remove()" in core,
    'v19 insurer sibling cleaned': "document.getElementById('v19InsurerExtra')?.remove()" in core,
}

insertions = []
for p in js.glob('*.js'):
    for lineno, line in enumerate(p.read_text(encoding='utf-8').splitlines(), 1):
        if "insertAdjacentHTML('afterend'" in line or 'insertAdjacentHTML("afterend"' in line:
            insertions.append((p.name, lineno))

print('persistent afterend insertions:', len(insertions), insertions)
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL'), name)
if not all(checks.values()):
    raise SystemExit(1)
if len(insertions) != 2:
    raise SystemExit('Unexpected new persistent afterend insertion; audit required')
print('UI_DUPLICATE_AUDIT_PASS')
