#!/usr/bin/env python3
"""Static package audit; does not execute Android."""
import hashlib,json,pathlib,re,sys,zipfile
root=pathlib.Path(__file__).resolve().parents[1];checks={}
checks['unchanged_v152_scripts']={p.name:p.read_bytes()==(root/'www/js'/p.name).read_bytes() for p in (root/'test-fixtures/v152/www/js').glob('*.js')}
html=(root/'www/index.html').read_text();checks['direct_html_resources']={s:(root/'www'/s).is_file() for s in re.findall(r'(?:src|href)="([^\"]+\.(?:js|css))"',html)}
checks['external_runtime_urls']=[str(p.relative_to(root)) for p in (root/'www').rglob('*') if p.suffix in ['.js','.html','.css'] and re.search(r'https?://',p.read_text())]
checks['packaged_flags']=len(list((root/'images/flags').glob('*.webp')))
if len(sys.argv)>1:
 with zipfile.ZipFile(sys.argv[1]) as z:checks['apk_runtime_bytes_match']={str(p.relative_to(root)):z.read('assets/'+str(p.relative_to(root)))==p.read_bytes() for d in ['www','images'] for p in (root/d).rglob('*') if p.is_file()}
assert all(checks['unchanged_v152_scripts'].values());assert all(checks['direct_html_resources'].values());assert not checks['external_runtime_urls'];assert checks['packaged_flags']==7;assert all(checks.get('apk_runtime_bytes_match',{}).values());print(json.dumps(checks,ensure_ascii=False,indent=2))
