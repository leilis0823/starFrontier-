v1.63 validation summary
All www JavaScript syntax checks
PASS
index references missing: 0 []
HTML duplicate ids: 0 []
external HTTP(S) runtime strings: 0 []
PASS
persistent afterend insertions: 2 [('10-v1_1-v1_17.js', 1075), ('10-v1_1-v1_17.js', 1952)]
PASS v130 governance has stable DOM id
PASS v117 cleanup removes v130 governance
PASS v19 career sibling cleaned
PASS v19 insurer sibling cleaned
UI_DUPLICATE_AUDIT_PASS
V163_INSURANCE_REINSURANCE_SMOKE_PASS {
  "reinsurers": 3,
  "policies": 2,
  "claims": 5,
  "reinsurancePaid": 8993,
  "reinsuranceDefaults": 1,
  "disputes": 1
}
