package com.starfrontier.game;
import android.app.*;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Insets;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.system.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
 private static final String ORIGIN="https://appassets.androidplatform.net";
 private static final int EXPORT=1531,IMPORT=1532;
 private WebView web;private FrameLayout root;private SaveStore store;
 private volatile boolean active=false;private boolean destroyed=false,pausedWeb=false,documentBusy=false,exitShowing=false;
 private final ExecutorService io=Executors.newSingleThreadExecutor();private AudioManager audio;private AudioFocusRequest focus;
 private final Object saveQueueLock=new Object();private String pendingSaveRaw;private boolean pendingSaveCheckpoint=false,saveDrainRunning=false;
 private volatile String lastAsyncSaveError=null;private volatile long asyncSaveWrites=0;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final BroadcastReceiver screenReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){if(Intent.ACTION_SCREEN_OFF.equals(i.getAction())){active=false;suspendWeb();}}};
 private static void validate(String raw)throws Exception{
  JSONTokener parser=new JSONTokener(raw);Object value=parser.nextValue();if(!(value instanceof JSONObject)||parser.nextClean()!=0)throw new IOException("Invalid JSON object");JSONObject o=(JSONObject)value;double day=o.optDouble("day",Double.NaN);
  if(!Double.isFinite(day)||day<1||day!=Math.floor(day)||!(o.opt("system") instanceof String)||o.optString("system").isEmpty()||!Double.isFinite(o.optDouble("credits",Double.NaN)))throw new IOException("Not a STAR FRONTIER save");
  if(o.has("gm")&&!(o.opt("gm") instanceof JSONObject))throw new IOException("Invalid gm state");
 }
 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);
  try{store=new SaveStore(new File(getFilesDir(),"saves"),MainActivity::validate,d->{java.io.FileDescriptor fd=Os.open(d.getPath(),OsConstants.O_RDONLY,0);try{Os.fsync(fd);}finally{Os.close(fd);}});}catch(Exception e){new AlertDialog.Builder(this).setMessage("保存領域を開けません。データを消さずに再起動してください。").setPositiveButton("終了",(d,w)->finish()).show();return;}
  getWindow().setStatusBarColor(Color.rgb(6,16,29));getWindow().setNavigationBarColor(Color.rgb(6,16,29));
  if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
  if(Build.VERSION.SDK_INT>=28){WindowManager.LayoutParams a=getWindow().getAttributes();a.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;getWindow().setAttributes(a);}
  root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(6,16,29));web=new WebView(this);web.setBackgroundColor(Color.rgb(6,16,29));web.setLayerType(View.LAYER_TYPE_HARDWARE,null);web.setOverScrollMode(View.OVER_SCROLL_NEVER);
  if(Build.VERSION.SDK_INT>=26)web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT,!"nubia_8elite_12gb".equals(BuildConfig.SF_PERFORMANCE_PROFILE));
  root.addView(web,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
  root.setOnApplyWindowInsetsListener((v,in)->{int left,top,right,bottom;
   if(Build.VERSION.SDK_INT>=30){Insets b=in.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());left=b.left;top=b.top;right=b.right;bottom=b.bottom;}
   else{left=in.getSystemWindowInsetLeft();top=in.getSystemWindowInsetTop();right=in.getSystemWindowInsetRight();bottom=in.getSystemWindowInsetBottom();if(Build.VERSION.SDK_INT>=28&&in.getDisplayCutout()!=null){DisplayCutout c=in.getDisplayCutout();left=Math.max(left,c.getSafeInsetLeft());top=Math.max(top,c.getSafeInsetTop());right=Math.max(right,c.getSafeInsetRight());bottom=Math.max(bottom,c.getSafeInsetBottom());}}
   v.setPadding(left,top,right,bottom);return Build.VERSION.SDK_INT>=30?WindowInsets.CONSUMED:in.consumeSystemWindowInsets();});
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setBlockNetworkLoads(true);s.setMediaPlaybackRequiresUserGesture(true);s.setSupportMultipleWindows(false);s.setCacheMode(WebSettings.LOAD_DEFAULT);s.setOffscreenPreRaster(false);
  WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);web.addJavascriptInterface(new NativeBridge(),"AndroidNative");
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}
   @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){Uri u=r.getUrl();String path=u.getPath();if(!"https".equals(u.getScheme())||!"appassets.androidplatform.net".equals(u.getHost())||u.getPort()!=-1||path==null||path.contains("..")||path.contains("\\")||!(path.startsWith("/www/")||path.startsWith("/images/")))return blocked();
    try{String ext=MimeTypeMap.getFileExtensionFromUrl(path),mime=MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);if(path.endsWith(".js"))mime="application/javascript";if(mime==null)mime="application/octet-stream";Map<String,String> h=new HashMap<>();h.put("Cache-Control","no-cache");h.put("X-Content-Type-Options","nosniff");return new WebResourceResponse(mime,"UTF-8",200,"OK",h,getAssets().open(path.substring(1)));}catch(IOException e){return blocked();}}
   @Override public void onPageFinished(WebView v,String url){applyLifecycle();root.requestApplyInsets();deliverPendingImport();}
   @Override public boolean onRenderProcessGone(WebView v,RenderProcessGoneDetail detail){active=false;root.removeView(v);v.destroy();web=null;new AlertDialog.Builder(MainActivity.this).setTitle("画面処理が停止しました").setMessage("最後の正常セーブは保持されています。アプリを再起動してください。").setCancelable(false).setPositiveButton("終了",(d,w)->finish()).show();return true;}
  });
  web.setWebChromeClient(new WebChromeClient());
  if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,this::back);
  audio=(AudioManager)getSystemService(AUDIO_SERVICE);focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()).setOnAudioFocusChangeListener(change->eval("window.StarFrontierAndroid&&StarFrontierAndroid.audioFocus("+(change==AudioManager.AUDIOFOCUS_GAIN)+")",null),handler).build();
  IntentFilter filter=new IntentFilter(Intent.ACTION_SCREEN_OFF);if(Build.VERSION.SDK_INT>=33)registerReceiver(screenReceiver,filter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(screenReceiver,filter);
  web.loadUrl(ORIGIN+"/www/index.html");
 }
 private WebResourceResponse blocked(){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
 private void eval(String js,ValueCallback<String> callback){if(web!=null&&!destroyed)web.evaluateJavascript(js,callback);}
 private void back(){eval("window.StarFrontierAndroid ? StarFrontierAndroid.back() : false",r->{if(!"true".equals(r))showExit();});}
 @Override public void onBackPressed(){back();}
 private void showExit(){if(exitShowing||isFinishing())return;exitShowing=true;new AlertDialog.Builder(this).setTitle("STAR FRONTIERを終了しますか？").setMessage("現在の進行を保存して終了します。").setNegativeButton("続ける",null).setPositiveButton("保存して終了",(d,w)->eval("window.StarFrontierAndroid&&StarFrontierAndroid.saveNow()",ok->{if("true".equals(ok))finish();else new AlertDialog.Builder(this).setMessage("保存できませんでした。空き容量やJSON書き出しを確認してください。").setPositiveButton("戻る",null).show();})).setOnDismissListener(d->exitShowing=false).show();}
 private void suspendWeb(){eval("window.StarFrontierAndroid&&StarFrontierAndroid.setActive(false)",r->{if(!active&&web!=null){web.onPause();pausedWeb=true;}});if(audio!=null)audio.abandonAudioFocusRequest(focus);}
 private void applyLifecycle(){if(web==null)return;if(active){if(pausedWeb){web.onResume();pausedWeb=false;}eval("window.StarFrontierAndroid&&StarFrontierAndroid.setActive(true)",null);}else suspendWeb();}
 @Override protected void onResume(){super.onResume();active=true;applyLifecycle();if(root!=null)root.requestApplyInsets();}
 @Override protected void onPause(){active=false;suspendWeb();super.onPause();}
 @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);if(root!=null)root.requestApplyInsets();eval("window.StarFrontierAndroid&&StarFrontierAndroid.resize()",null);}
 @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus&&root!=null)root.requestApplyInsets();}
 @Override public void onTrimMemory(int level){super.onTrimMemory(level);if(level>=TRIM_MEMORY_RUNNING_LOW)eval("window.StarFrontierAndroid&&StarFrontierAndroid.memoryPressure("+level+")",null);}
 @Override protected void onDestroy(){destroyed=true;active=false;try{unregisterReceiver(screenReceiver);}catch(Exception ignored){}if(audio!=null)audio.abandonAudioFocusRequest(focus);if(web!=null){web.removeJavascriptInterface("AndroidNative");root.removeView(web);web.destroy();web=null;}io.shutdown();super.onDestroy();}
 private String result(String value,Exception error){try{JSONObject o=new JSONObject();o.put("ok",error==null);o.put("value",value==null?JSONObject.NULL:value);if(error!=null)o.put("error",error.getMessage());return o.toString();}catch(Exception e){return "{\"ok\":false}";}}
 private void toast(String message){runOnUiThread(()->Toast.makeText(this,message,Toast.LENGTH_LONG).show());}
 private File pendingImport(){return new File(getCacheDir(),"pending-import.json");}
 private void deliverPendingImport(){if(active&&pendingImport().isFile())eval("window.StarFrontierAndroid&&StarFrontierAndroid.receiveNativeImport()",null);}
 private boolean enqueueSave(String raw,boolean checkpoint){
  if(raw==null)return false;boolean start=false;
  synchronized(saveQueueLock){pendingSaveRaw=raw;pendingSaveCheckpoint|=checkpoint;if(!saveDrainRunning){saveDrainRunning=true;start=true;}}
  if(start)io.execute(this::drainSaveQueue);return true;
 }
 private void drainSaveQueue(){
  for(;;){String raw;boolean checkpoint; synchronized(saveQueueLock){raw=pendingSaveRaw;checkpoint=pendingSaveCheckpoint;pendingSaveRaw=null;pendingSaveCheckpoint=false;if(raw==null){saveDrainRunning=false;return;}}
   try{store.save(raw,checkpoint);lastAsyncSaveError=null;asyncSaveWrites++;}
   catch(Exception e){lastAsyncSaveError=String.valueOf(e.getMessage());handler.post(()->eval("window.StarFrontierAndroid&&StarFrontierAndroid.nativeSaveError()",null));}
  }
 }
 private void clearQueuedSaves(){synchronized(saveQueueLock){pendingSaveRaw=null;pendingSaveCheckpoint=false;}}
 public final class NativeBridge {
  @JavascriptInterface public boolean isActive(){return active;}
  @JavascriptInterface public String getPerformanceProfile(){return BuildConfig.SF_PERFORMANCE_PROFILE;}
  @JavascriptInterface public String readSave(){try{return result(store.load(),null);}catch(Exception e){return result(null,e);}}
  @JavascriptInterface public String writeSave(String raw){try{clearQueuedSaves();store.save(raw,true);lastAsyncSaveError=null;return result("saved",null);}catch(Exception e){return result(null,e);}}
  @JavascriptInterface public boolean queueSave(String raw,boolean checkpoint){return enqueueSave(raw,checkpoint);}
  @JavascriptInterface public String saveStatus(){try{JSONObject o=new JSONObject();o.put("profile",BuildConfig.SF_PERFORMANCE_PROFILE);o.put("queued",saveDrainRunning);o.put("writes",asyncSaveWrites);o.put("error",lastAsyncSaveError==null?JSONObject.NULL:lastAsyncSaveError);return o.toString();}catch(Exception e){return "{}";}}
  @JavascriptInterface public String backupSave(String raw){try{store.checkpoint(raw);return result("saved",null);}catch(Exception e){return result(null,e);}}
  @JavascriptInterface public String readBackup(int slot){try{return result(store.backup(slot),null);}catch(Exception e){return result(null,e);}}
  @JavascriptInterface public int backupCount(){return store.backupCount();}
  @JavascriptInterface public int backupCountFast(){return store.backupFileCount();}
  @JavascriptInterface public String getSetting(String key){if(!key.startsWith("starFrontier")||key.length()>100)return null;return getPreferences(MODE_PRIVATE).getString(key,null);}
  @JavascriptInterface public boolean setSetting(String key,String value){if(!key.startsWith("starFrontier")||key.length()>100||value!=null&&value.length()>8192)return false;android.content.SharedPreferences.Editor e=getPreferences(MODE_PRIVATE).edit();if(value==null)e.remove(key);else e.putString(key,value);e.apply();return true;}
  @JavascriptInterface public boolean requestAudioFocus(){return active&&audio!=null&&audio.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;}
  @JavascriptInterface public void exportSave(String raw){runOnUiThread(()->{if(documentBusy){toast("ファイル操作中です");return;}documentBusy=true;io.execute(()->{try{validate(raw);byte[] bytes=raw.getBytes(StandardCharsets.UTF_8);if(bytes.length>SaveStore.MAX_BYTES)throw new IOException("Too large");try(FileOutputStream out=new FileOutputStream(new File(getCacheDir(),"export.json"))){out.write(bytes);out.getFD().sync();}runOnUiThread(()->{try{startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"STAR_FRONTIER_Day_"+new JSONObject(raw).optLong("day")+".json"),EXPORT);}catch(Exception e){documentBusy=false;toast("書き出し画面を開けません");}});}catch(Exception e){runOnUiThread(()->documentBusy=false);toast("書き出し準備に失敗しました");}});});}
  @JavascriptInterface public void importSave(){runOnUiThread(()->{if(documentBusy)return;documentBusy=true;try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),IMPORT);}catch(Exception e){documentBusy=false;toast("読み込み画面を開けません");}});}
  @JavascriptInterface public String consumeImport(){try{File f=pendingImport();String raw=new String(java.nio.file.Files.readAllBytes(f.toPath()),StandardCharsets.UTF_8);f.delete();return result(raw,null);}catch(Exception e){return result(null,e);}}
 }
 @Override protected void onActivityResult(int request,int code,Intent data){super.onActivityResult(request,code,data);if(request!=EXPORT&&request!=IMPORT)return;if(code!=RESULT_OK||data==null||data.getData()==null){documentBusy=false;return;}Uri uri=data.getData();io.execute(()->{try{
  if(request==EXPORT){try(InputStream in=new FileInputStream(new File(getCacheDir(),"export.json"));OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException("No output");byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1)out.write(b,0,n);out.flush();}toast("JSONを書き出しました");}
  else{ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("No input");byte[] b=new byte[32768];int n;while((n=in.read(b))!=-1){if(bytes.size()+n>SaveStore.MAX_BYTES)throw new IOException("32 MiB limit");bytes.write(b,0,n);}}String raw=bytes.toString("UTF-8");validate(raw);try(FileOutputStream out=new FileOutputStream(pendingImport())){out.write(bytes.toByteArray());out.getFD().sync();}runOnUiThread(this::deliverPendingImport);}
 }catch(Exception e){toast(request==EXPORT?"JSON書き出しに失敗しました。ゲーム内セーブは保持されています。":"有効なセーブを読み込めませんでした。現在のセーブは保持されています。");}finally{runOnUiThread(()->documentBusy=false);}});}
}
