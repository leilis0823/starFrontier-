package com.starfrontier.game;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

/**
 * Serialized, checksummed native save transactions.
 *
 * v1.53.1 performance changes:
 * - Cache the last validated primary JSON in memory so normal autosaves do not re-read/hash
 *   multi-megabyte files before every write.
 * - Separate a fast atomic primary update from generation checkpoints. The caller decides
 *   when a previous primary should become a generation backup.
 * - Keep the on-disk format and JSON schema unchanged from v1.53.0.
 */
public final class SaveStore {
 public static final int MAX_BYTES=32*1024*1024;
 public interface Validator {void validate(String json)throws Exception;}
 public interface DirectorySync {void sync(File dir)throws Exception;}
 public interface FaultHook {void at(String point)throws IOException;}
 private final File dir;private final Validator validator;private final DirectorySync sync;
 private FaultHook fault=point->{};private long sequence;
 private String lastRaw;private boolean mainKnownValid;
 public SaveStore(File dir,Validator validator,DirectorySync sync)throws IOException{this.dir=dir;this.validator=validator;this.sync=sync;if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Cannot create save directory");}
 public void setFaultHook(FaultHook hook){fault=hook;}
 private static String hash(byte[] data)throws Exception{StringBuilder s=new StringBuilder();for(byte b:MessageDigest.getInstance("SHA-256").digest(data))s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}
 private byte[] encode(String raw)throws Exception{byte[] data=raw.getBytes(StandardCharsets.UTF_8);if(data.length>MAX_BYTES)throw new IOException("Save exceeds 32 MiB");validator.validate(raw);ByteArrayOutputStream out=new ByteArrayOutputStream(data.length+71);out.write(("SF153\n"+hash(data)+"\n").getBytes(StandardCharsets.US_ASCII));out.write(data);return out.toByteArray();}
 private String read(File f)throws Exception{if(f.length()<71||f.length()>MAX_BYTES+71)throw new IOException("Invalid size");byte[] b=Files.readAllBytes(f.toPath());String head=new String(b,0,71,StandardCharsets.US_ASCII);if(!head.startsWith("SF153\n")||head.charAt(70)!='\n')throw new IOException("Invalid header");byte[] data=Arrays.copyOfRange(b,71,b.length);if(!hash(data).equals(head.substring(6,70)))throw new IOException("Checksum mismatch");String raw=new String(data,StandardCharsets.UTF_8);validator.validate(raw);return raw;}
 private List<File> backups(){File[] f=dir.listFiles((d,n)->n.startsWith("backup-")&&n.endsWith(".sav"));List<File> list=new ArrayList<>(Arrays.asList(f==null?new File[0]:f));list.sort((a,b)->b.getName().compareTo(a.getName()));return list;}
 public synchronized String load()throws Exception{List<File> files=new ArrayList<>();File main=new File(dir,"main.sav");files.add(main);files.addAll(backups());boolean exists=false;for(File f:files)if(f.exists()){exists=true;try{String raw=read(f);lastRaw=raw;mainKnownValid=f.equals(main);return raw;}catch(Exception ignored){}}if(exists)throw new IOException("No valid save remains; original files preserved");lastRaw=null;mainKnownValid=false;return null;}
 public synchronized String backup(int slot)throws Exception{int n=0;for(File f:backups())try{String raw=read(f);if(++n==slot)return raw;}catch(Exception ignored){}return null;}
 private void atomicWrite(File target,byte[] data)throws Exception{File tmp=new File(dir,target.getName()+".tmp");try{try(FileOutputStream out=new FileOutputStream(tmp)){out.write(data);out.getFD().sync();}fault.at("after-temp-sync");read(tmp);fault.at("after-validation");Files.move(tmp.toPath(),target.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);sync.sync(dir);}finally{Files.deleteIfExists(tmp.toPath());}}
 private void snapshot(String raw)throws Exception{byte[] b=encode(raw);List<File> prior=backups();if(!prior.isEmpty())try{if(raw.equals(read(prior.get(0))))return;}catch(Exception ignored){}long next=Math.max(System.currentTimeMillis(),sequence+1);if(!prior.isEmpty())try{next=Math.max(next,Long.parseLong(prior.get(0).getName().substring(7,26))+1);}catch(Exception ignored){}sequence=next;atomicWrite(new File(dir,String.format(Locale.ROOT,"backup-%019d.sav",next)),b);}
 private void prune(){List<File> valid=new ArrayList<>();for(File f:backups())try{read(f);valid.add(f);}catch(Exception ignored){}for(int i=5;i<valid.size();i++)valid.get(i).delete();}
 private void primeCacheIfNeeded()throws Exception{if(lastRaw!=null)return;File main=new File(dir,"main.sav");if(main.exists()||!backups().isEmpty())load();}
 /**
  * Atomically replace the primary save. If checkpointPrevious is true, the previous
  * validated primary is copied to the generation set first. Autosave normally passes
  * false; day/lifecycle/manual checkpoints pass true.
  */
 public synchronized void save(String raw,boolean checkpointPrevious)throws Exception{
  byte[] b=encode(raw);primeCacheIfNeeded();File main=new File(dir,"main.sav");String old=lastRaw;
  if(raw.equals(old)&&main.exists()&&mainKnownValid){if(checkpointPrevious&&old!=null){snapshot(old);prune();}return;}
  if(checkpointPrevious&&old!=null)snapshot(old);
  fault.at("before-main-replace");atomicWrite(main,b);lastRaw=raw;mainKnownValid=true;if(checkpointPrevious)prune();
 }
 public synchronized void checkpoint(String raw)throws Exception{snapshot(raw);prune();}
 /** UI-only count: does not read/hash multi-megabyte backup bodies. */
 public synchronized int backupFileCount(){return Math.min(5,backups().size());}
 public synchronized int backupCount(){int n=0;for(File f:backups())try{read(f);n++;}catch(Exception ignored){}return n;}
}
