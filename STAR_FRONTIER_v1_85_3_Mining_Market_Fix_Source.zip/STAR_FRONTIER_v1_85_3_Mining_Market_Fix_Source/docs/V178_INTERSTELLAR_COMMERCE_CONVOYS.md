# v1.78 Interstellar Commerce, Convoys & Trade War

## Why this update
System review showed a major disconnect: player corporate freighters (v1.21), price-arbitrage trade, pirate AI (v1.24/v1.25), escort/security, cargo insurance (v1.63), contract law (v1.30), commodity markets (v1.69), mining traffic (v1.76) and customs/crime (v1.40/v1.77) already existed, while ordinary NPC merchant shipping was still represented mainly as abstract trade value. v1.78 physicalizes that missing middle layer.

## Physical trade flow
A merchant shipment loads cargo from the origin system. Base resources use the existing `game.stocks`; fuel, food, construction materials and refined/critical elements use a distribution-stock layer whose price remains governed by v1.69 benchmarks. Ships move one route leg per game day and unload into the destination. The carrier enterprise receives freight income and the existing trade-volume ledger is updated.

## Cargo seizure
The player can board or destroy physical merchant traffic. Boarding is harder but preserves substantially more cargo. Destruction is easier but destroys more value. Strong boarding loadouts have a small chance to register the merchant hull itself as a prize ship.

## Law and provenance
Enemy belligerent merchant traffic is a lawful prize when the player's military allegiance makes it a real opposing belligerent. An active v1.24 privateering shadow contract also legalizes action against its named target. Neutral/friendly civilian attacks are piracy under v1.40. Illegally seized cargo retains provenance across base resources, elements and general commodities. Regular-market disposal can trigger customs seizure/fines; underground fencing discounts the sale price in exchange for lower enforcement exposure.

## Convoys and route adaptation
High-risk lanes generate multi-ship convoys with stronger escort values. Route finding weights piracy, crisis conditions, accumulated lane danger and wartime enemy territory instead of always using the shortest path. Repeated piracy raises local danger and suppresses future traffic; successful player escort work lowers it. This prevents a permanently weak merchant spawn from becoming an infinite optimal farm.

## NPC piracy
The existing pirate AI is wrapped, not replaced. When a physical merchant is available in or near a pirate band's operating area, pirates preferentially attack that ship. Successful raids remove actual manifest quantities, enrich the pirate band, damage the carrier, create insurance exposure and prevent some goods from reaching destination markets. If no physical target exists, legacy abstract raid logic remains available.

## Market and financial effects
Deliveries increase supply; losses increase shortage pressure in v1.69 commodity fundamentals. For the original iron/titanium/crystal market, temporary existing `gm.marketEffects` modifiers transmit large delivery/loss shocks to local prices. Shipment status is mirrored into v1.30 contracts, and insured enterprise losses can file through v1.63.

## Player alternatives
The same merchant encounter supports both outlaw and lawful play: buy manifest intelligence, attack/privateer, recover prize cargo, fence stolen goods, or escort the ship through a dangerous segment for pay.

## Follow-up opportunities
The next high-value general-system expansions are passenger liners/refugee evacuation, customs/sanctions inspection gameplay, full blockade zones and naval convoy operations, ship repair/towing/salvage contracts, and dynamic freight exchanges where corporations post transport tenders that player and NPC carriers compete for.
