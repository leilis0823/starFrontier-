# STAR FRONTIER v1.53.1 Performance Optimization

## 目的

v1.53.0 Android Application Build を基準に、ゲーム内容・v1.52 JSONセーブ互換を変更せず、Android WebViewで発生していた操作時の停止感を減らす。2つのビルドフレーバーを用意する。

- `nubia`: Nubia Fold / Snapdragon 8 Elite / RAM 12GB向け。`nubia_8elite_12gb` プロファイル。
- `universal`: 他端末向け。メモリ圧迫時の解放を強め、保存間隔も保守的にする。

両フレーバーは同じ `applicationId=com.starfrontier.game` を使うため、現在のv1.53.0をアンインストールせず上書きして内部セーブを引き継ぐ設計。2版を同時インストールする設計ではない。

## 主なボトルネックと修正

### 1. render()ごとの巨大セーブ

v1.53.0では最終`render()`のたびに`saveNow()`が動き、約数MBの状態に対して毎回:

1. 強制コンパクション
2. `JSON.stringify()`
3. JavaScriptInterfaceへ全文転送
4. 旧主セーブの読み込み・SHA-256検証
5. 世代バックアップ作成
6. 新主セーブのfsync
7. バックアップ全世代の再検証

が発生し得た。タブ移動だけでも同じ処理が走るため、CPUが高速でもI/O待ちとシリアライズ停止がUIへ現れる構造だった。

v1.53.1では:

- 純粋なタブ/銀河サブタブ移動では保存しない。
- 通常保存はデバウンスして連続操作を1回へ集約。
- Nubia: 180ms、Universal: 650ms。
- 通常保存では10日周期の既存コンパクション規則を尊重し、毎回の強制走査を廃止。
- Android側へ非同期保存キューを追加。最新状態だけを保持して古い待機保存を合流。
- ActivityのBG移行、明示終了、インポート等の重要点では同期保存を維持。

### 2. SaveStoreの多重I/O

`SaveStore`は主保存のたびに旧主保存を再読込・ハッシュし、さらに毎回世代バックアップを生成していた。v1.53.1では検証済み主JSONをプロセス内キャッシュし、通常オートセーブは原子的な主保存更新だけを行う。世代バックアップは別のチェックポイントとして作成する。

- Nubia: 原則5ゲーム日ごとにチェックポイント
- Universal: 原則7ゲーム日ごとにチェックポイント
- BG/終了/手動バックアップでは安全側の同期保存を実施
- バックアップは最大5世代のまま

JVM上の>3MiBテストデータでは、5回の連続主保存が旧実装約1153ms、新fast-path約140msだった（約8.2倍）。これはPC/JVM計測であり、Nubia実機速度を保証する数値ではない。

### 3. バックアップ表示だけで全バックアップを再ハッシュ

旧版では`sfWriteBackupStatus()`がレンダーごとに`backupCount()`を呼び、最大5個の数MBファイルを読み込み・SHA検証していた。v1.53.1は表示用にファイル数だけを返すO(1)相当の`backupCountFast()`を追加し、表示値もキャッシュする。復元時の実データ検証は従来どおり維持。

### 4. WebView描画

- Hardware Layerを明示。
- Renderer PriorityをIMPORTANTに設定。Nubia版は非表示時にも優先度を維持し、Universal版はバックグラウンド時にOSへ譲る。
- 長いカードリストへ`content-visibility:auto`を適用し、画面外カードの描画コストを削減。
- Androidのメモリ圧迫通知時、Universalは非表示の巨大リストDOMを解放。Nubiaは深刻な圧迫時だけ解放し、12GB RAMをタブ再表示速度のキャッシュとして利用。
- BGM音量スライダー操作は同期フルセーブではなくデバウンス保存へ変更。
- 小さなSharedPreferences設定は`commit()`から`apply()`へ変更。

## NPUについて

Hexagon NPUは今回使用しない。STAR FRONTIERの主要負荷はルールベースのJavaScript、DOM、JSONシリアライズ、ファイルI/Oであり、ニューラルネットワーク推論ではない。QNN/NNAPI用に状態計算を書き換えると複雑性が増す一方、主要ボトルネックを解消しない。将来ローカル推論モデルをゲームAIへ組み込む場合のみ再検討する。

## ゲーム互換性

`www/js/00-core.js`から`90-v1_52-player-routes.js`までのゲームロジックファイルはv1.53.0からバイト単位で変更していない。変更対象はAndroid統合層、保存コア、Android専用CSS、Gradleビルドフレーバー。保存JSONの`game.version`は互換性のため1.52.0を維持する。

## ビルド

Android SDK 35 / Build Tools 35.0.0 / JDK 17相当の環境で:

```bash
cd android
./gradlew assembleNubiaDebug
./gradlew assembleUniversalDebug
```

Release候補:

```bash
./gradlew assembleNubiaRelease
./gradlew assembleUniversalRelease
```

この作業環境にはAndroid SDK/Build Toolsが無いため、v1.53.1 APKそのものはここでは生成していない。ソースのJavaScript構文検査、SaveStore JVM試験、資源参照監査は実施済み。

## 実機で最初に見る数値

DevToolsまたはJS評価で`StarFrontierAndroid.diagnostics()`を確認する。`profile`, `save.lastSerializeMs`, `save.maxSerializeMs`, `save.native.writes`, `game.v150.lastRenderMs`が主要指標。
