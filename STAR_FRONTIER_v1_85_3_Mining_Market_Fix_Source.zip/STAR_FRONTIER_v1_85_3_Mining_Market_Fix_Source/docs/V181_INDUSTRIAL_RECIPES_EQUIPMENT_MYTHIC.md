# v1.81.0 — Industrial Recipes, Corporate Mass Market & Heritage Derivatives

## Purpose
v1.81 connects v1.76 raw-ore geology/mining to physical ship and equipment manufacturing, expands ordinary corporate products sold on the open market, and makes selected mythic/heritage designs available only as downgraded civilian/export derivatives. Existing special originals and signature equipment are not converted into ordinary shop stock.

## Ore-backed production
All requested raw ores are used in ship/equipment bills of materials:

- 赤鉄鉱 / hematite
- チタン鉄鉱 / ilmenite
- ボーキサイト / bauxite
- 黄銅鉱 / chalcopyrite
- ペントランド鉱 / pentlandite
- スポジュメン / spodumene
- 閃ウラン鉱 / uraninite
- モナズ石 / monazite
- 白金族鉱石 / pgm_ore
- 高品位珪酸塩鉱 / silicate
- 星晶母岩 / star_matrix

Ship recipes scale by hull class and role. Freighters use more bauxite/copper/silicate; fast hulls add lithium-bearing spodumene and PGM; mining hulls add structural and nickel-bearing ores; capital/heritage hulls increasingly require uranium, monazite, PGM and star-matrix ore. A battleship-class BOM includes all 11 raw ores.

The system stores industrial raw-material inventories by system. A purchase or corporate hull commission consumes the manufacturer's real industrial inventory. If materials are insufficient, construction is blocked. Existing v1.12 equipment makers are also material-backed: newly produced equipment stock is retained only when the manufacturer has enough ore inputs.

The player can sell v1.76 raw ore directly to the local shipbuilding/equipment industry. Payment comes from an eligible shipbuilder's existing corporate cash and then the governing state's treasury if needed; delivered ore replenishes the industrial inventory.

## Ordinary corporate market hulls
Twelve new normal mass-production hulls are added to the common major-yard catalogue. They are not special-project hulls and do not inherit military-license flags:

- SURVEYOR-R3 — Regulus survey ship
- MARINER-R6 — Regulus medium merchant
- SWIFT-LX — Horizon fast cargo ship
- BULKSTAR-LX — Horizon bulk carrier
- QUARRYMAN-NX — Nox commercial mining vessel
- PILGRIM-T4 — Pilgrim tanker/hazardous-material carrier
- RESPONDER-MR — Meridian recovery/towing workship
- MERCY-HB — Helix medical/humanitarian transport
- SPEAR-AL — Arclight civilian-security corvette
- WARDEN-BW — Bulwark convoy-protection corvette
- VECTOR-SV — Synapse high-speed escort/info courier
- FRONTIER-AH — Asterion corporate-security frigate

These ships use normal market purchase rules plus the new ore BOM requirement.

## Corporate mass-market equipment
The existing v1.12 equipment companies receive nine additional products, physically manufactured into their normal market stock:

Arclight:
- AL-18汎用コイル砲
- AL近接レーザー迎撃器
- アークライト民生射撃追尾器

Bulwark:
- BWセラメタル軽量装甲
- ブルワーク自動損傷封鎖器
- BW-G2船団防御アレイ

Synapse:
- SV民生航路予測AI
- シナプス広域商用センサーマスト
- SV適応妨害デコイ

Equipment recipes are derived from equipment slot and performance. High-output weapons, high-defense systems, high-speed systems and high-power systems require additional strategic ores.

## Mythic / heritage derivatives
Five existing archive lineages are used as licensed civilian/export derivatives rather than moving the original special hull into ordinary circulation:

- DEMETER-CV〈デメテル・プロビジョン〉 — civilian strategic supply ship
- NJORD-M〈ニョルズ・マーチャント〉 — armed long-range merchant/escort derivative
- SLEIPNIR-X〈スレイプニル・エクスプレス〉 — high-speed cargo derivative
- NIRAI-KANAI-E〈ニライカナイ・エクスペディション〉 — expedition/migration derivative
- MAMMON-R〈マモン・リクレーマー〉 — legal salvage/recovery derivative

Each derivative has restricted market systems and explicitly omits the original military command systems/signature equipment. Original DEMETER, NJORD, SLEIPNIR, NIRAI-KANAI and MAMMON acquisition rules remain untouched. Other mythic hulls, including high-end combat lineages, remain special-only.

## Compatibility
- v1.76 remains the authoritative raw-ore inventory and geology source.
- v1.12 remains the authoritative physical equipment-market production/stock system.
- existing shipyards, military licenses, corporate commissions and special-project acquisition rules remain authoritative.
- v1.80 long-horizon AI remains active; v1.81 adds manufacturing constraints rather than replacing strategy logic.
