# STAR FRONTIER v1.53.2 — 国際組織UI日本語化復元

## 目的

v1.53.1 Performance Source は v1.53.0（日本語化前）を基準にしていたため、v1.52.1 で追加済みだった国際組織の表示日本語化が欠落していた。v1.53.2では、その表示レイヤーを性能最適化版へ復元した。

## 日本語化対象

内部IDはセーブ互換のため変更せず、ユーザー表示のみ変換する。

- `military_support` / `MilitarySupport` / `Militarysupport` → `軍事支援`
- `research_mission` / `ResearchMission` → `共同研究・調査任務`
- `joint_patrol` → `共同航路哨戒`
- `trade_relief` → `通商救済措置`
- `investigation` → `国際調査団派遣`
- `mediation` → `停戦仲介・和平調整`
- `readiness` → `共同即応態勢`
- `monitor` → `共同監視`
- `sanction` → `共同制裁`
- `aid` → `人道支援`
- `loan` → `復興・開発融資`
- `consensus` → `全会一致`
- `qualified` → `特別多数決`
- `simple` → `単純多数決`

既存セーブ内のニュース・重大イベント・国際組織履歴に残った英語表示もロード時に日本語へ変換する。

## 互換性

国際組織AI内部の action / voting ID は変更しない。ゲームロジック、セーブ形式、v1.53.1のNubia/Universal性能プロファイルも変更しない。
