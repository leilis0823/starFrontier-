# 構造解析・実装変更

## 元ZIPの構造

設計文書、分割方針、v1.51統合試験・v1.52ルート試験メモを確認済み。
`www/index.html`、CSS、バージョン群別クラシックJSとbootstrapの11ファイルをdeferで順に読み、関数再定義と互換ラッパーを積み重ねる構成。Androidプロジェクトはなく、android-bridge.jsは仮置き。主セーブはlocalStorageのstarFrontierSaveV11、旧キーV10/V09を移行可能。

国旗WebP7枚はwww外のimages/flagsにあり、../imagesで参照。音声ファイルと艦艇画像は同梱されていない。BGMは端末内合成、艦艇画像は任意アセットのフォールバック構成。

**既存www/jsの11ファイルは入力とバイト一致を維持。ES Modules化、単一HTML化、AIや日次処理の全面改修は行っていない。** v1.51のensure epoch、MOE再帰防止、履歴コンパクション、v1.52ルート修正を維持する。

## 主な変更

| ファイル | 内容 |
|---|---|
| MainActivity.java | ローカルassets専用WebView、JavaScript bridge、Insets、Fold/回転、戻る、ライフサイクル、音声フォーカス、SAF |
| SaveStore.java | SHA-256付き内部ファイル、テンポラリ検証、atomic replace、正常5世代、復旧 |
| storage-adapter.js | クラシックスクリプトのlexical bindingで既存localStorage参照をネイティブへ接続 |
| android-bridge.js | 保存/ロード保護、描画内保存の集約、JSON管理、戻る履歴、時計・音声統合、診断 |
| css/android.css | 狭幅・横画面・ヘッダー折返し |
| index.html | 統合JS/CSS読込み順、CSP、アプリ名 |
| manifest/Gradle/resources | 固定ID/版/SDK、configChanges、ネット権限なし、バックアップ規則、アイコン、assets同期 |

## ネイティブ保存

`files/saves/main.sav`へSF153識別子＋SHA-256ヘッダー＋既存JSONをUTF-8で格納。JSONのエクスポート/ゲームへの返却では内部ヘッダーを除く。保存上限は32MiB、正常バックアップ5世代。設定だけはSharedPreferences。

入力検証 → 旧正常主セーブの世代保存 → テンポラリ書込み → ファイルfsync → 再読込み・SHA/JSON検証 → 同一ディレクトリatomic move → ディレクトリfsync → 古い正常世代の整理。

主セーブ破損時は新しい正常バックアップから復旧。全候補破損時は自動新規保存を止め、元ファイルを保全する。全世代破損後のアプリ内修復UIは未実装で、ファイルの調査・復旧が必要。

インポートはステージング状態で既存ロード/正規化と整合性検査を行い、成功後に保存する。失敗時は元のゲーム状態を戻し、復旧描画による自動保存を抑止。normalize例外を拾って旧ローダーによる黙ったnewGameへの移行を検出する。

描画チェーン内の複数save呼出しは、最外側の正常な描画完了時の1回へ集約。明示saveは同期で結果を返す。ネイティブI/OはJavaScript interfaceのスレッドで直列化される。Android主保存にlocalStorageは使用しない。通常Webブラウザは従来の保存方式であり、Androidの永続性保証をブラウザに拡張したとはしない。

## Fold・回転・戻る・ライフサイクル

ActivityのconfigChangesでorientation/screenSize/smallestScreenSize/density等を処理し、onConfigurationChangedでWebView再生成やloadUrlを実行しない。root paddingへsystem bars/cutout/IMEのInsetsを適用し、WebViewを安全領域内に配置。CSS既存Safe Areaとの二重加算を避ける。resizeは1フレームに集約する。

戻るは重大イベントモーダル → HTML dialog/入力 → 最大32件のサブタブ/タブ履歴 → 母港 → 終了確認。Android 13以降はOnBackInvoked、旧版はonBackPressed。終了前保存の失敗時は終了しない。

onPause、画面OFF、visibilityで時計停止。復帰時は既存のgeneration管理を使い二重タイマーを防ぐ。OSプロセス終了時まで同一WebViewを維持できるとはせず、正常セーブから再開する。レンダラ終了時は再起動を案内する。

## BGM / SE

国家別BGMテーマを維持し、ON/OFF・音量変更のフェード、音声フォーカス、バックグラウンド停止/復帰を統合。合成ノードをonendedで切断する。入力ZIPにSE実装がないため、操作ボタンの合成SEと独立したON/OFF・音量を補完した。外部音源は使用しない。

## 問題の分類

| 分類 | 問題 | 対応 |
|---|---|---|
| Android側の不足 | ネイティブ主保存・Androidホストなし | ファイル保存・WebViewホストを実装 |
| Android側の不足 | Fold/Insets/戻る/SAF/ライフサイクルなし | 統合レイヤーへ実装 |
| 今回のAndroid統合で発見 | 不正インポート後の描画で保存が走る | 事前拒否・失敗時の保存抑止 |
| 今回のAndroid統合で発見 | API26向けstyleにAPI27属性 | 不要属性除去、Lint再確認 |
| 既存ゲーム側 | ensureV16Stateが毎回BGMをOFFにする | 既存メモ化normalizer前後でenabled設定を保持 |
| 既存ゲーム側 | loadがnormalize例外を握りつぶしnewGameへ移る | 例外を追加ラッパーで記録し起動時上書きを防止 |
| 既存構造のAndroid上の負荷 | 描画チェーンでsaveが重複 | 正常描画完了時に1回へ集約 |

## 公式資料

[Android WebView](https://developer.android.com/develop/ui/views/layout/webapps/webview)、[edge-to-edge / Insets](https://developer.android.com/develop/ui/views/layout/edge-to-edge)、[Android 15の動作変更](https://developer.android.com/about/versions/15/behavior-changes-15)を設計確認に使用した。これらは実機試験の代用ではない。
