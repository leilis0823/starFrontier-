# STAR FRONTIER v1.85.2 — Architecture Performance Update

## 目的

v1.85.1で行ったDOM削減・非表示画面ガードに加え、Android WebViewでの「タブを押してから画面が反応するまでの待ち」を減らすため、画面遷移の実行順と一部UIコードの読み込み方式を再設計する。

この更新はFeature Freeze中のパフォーマンス更新であり、ゲーム内容・経済・AI・乱数シード進行を変更しない。

## 実装

### 1. Route-first navigation

ユーザーが下部ナビゲーションまたは銀河サブタブを押した場合だけ、専用の`StarFrontierNavigator`を使用する。

1. 対象タブのシェルを即時表示
2. 2回の`requestAnimationFrame`でブラウザへ描画機会を与える
3. 既存の`showTab()` / `showGalaxy()`をそのまま実行
4. 既存描画中に重複するsave要求は遅延保存へ集約

ゲーム内部から呼ばれる`showTab()` / `showGalaxy()`自体は変更していない。そのため旅行、戦闘、イベント、AI等の既存処理順は維持される。

### 2. 艦船UIのDynamic Import

`js/127-v1_82-ship-icons-registry.js`を`index.html`の起動時script列から外した。

艦船画面を初めて開いた後、アイドル時間に次を実行する。

```js
import('./127-v1_82-ship-icons-registry.js')
```

ロード後は搭乗艦アートと艦船レジストリを再描画する。Dynamic Import対象は24,957 bytesであり、起動時のparse/execute対象から除外される。

過去バージョンの巨大統合ファイルはグローバル関数ラッパーと初期化副作用が強いため、現段階では無理にscene chunkへ分割していない。安全な境界が確認できたUI層だけを遅延化した。

### 3. 保存処理の遅延

v1.85.1の保存バッチングを維持したまま、ユーザーナビゲーション中のsaveを750ms後へ送る。`visibilitychange`および`pagehide`では未処理保存を即時flushする。

Androidでは既存の`AndroidNative` / SaveStore保存ブリッジをそのまま使用し、localStorageのみへ置き換える処理は行わない。

### 4. 画面外DOMのレイアウト省略

長い一覧系UIへ`content-visibility:auto`と`contain-intrinsic-size`を適用し、画面外カードのstyle/layout/paint負荷をWebViewへ省略させる。

v1.85.1の艦船レジストリ・図鑑ページング、軽量SVGサムネイルも継続する。

## 採用しなかった最適化

### 危険なensureチェーン短絡

v1.67〜v1.75等の古い状態初期化チェーンを追加キャッシュする実験では、単一画面では一致しても連続UI操作で`marketSeed`が変化するケースが確認されたため撤回した。

### Web Worker

日次AI・経済処理は多数のグローバル状態と`rng()`順序に依存している。現在の構造で個別AIだけをWorker化すると、処理順・乱数消費順が変化する危険があるためv1.85.2では実装しない。

### 全JSの単一バンドル化

Android版はローカルasset配信でありHTTP往復が主要ボトルネックではない。巨大単一bundle化は起動時parse/executeを増やす可能性があるため、現状は「必要になるまで実行しない」方針を優先した。

## RNG / 状態一致

同一初期状態から以下の操作列を比較した。

`home -> galaxy -> gm -> stations -> map -> mine -> market -> ship -> home`

- 既存同期ナビゲーション最終seed: `2196336249`
- v1.85.2ルート最終seed: `2196336249`
- versionを除いたgame JSON: 完全一致
- 比較JSON: `1,468,136 bytes`

v1.81.4専用乱数テストも継続PASS:

- initial: `4213774138`
- direct: `3119341908`
- cached: `3119341908`

## 制御VMベンチマーク

実端末値ではない。

市場タブの同期`showTab('market')`は最終計測で平均約521msだったのに対し、Route-firstナビゲーションの呼び出しは平均約0.16msでシェルを表示して制御を返した。その後、既存の完全描画を次フレーム以降で実行する。

完全描画そのものも同VMでは約573ms -> 約510ms程度へ低下した計測があるが、今回の主目的は総計算量だけでなく「押しても数秒画面が変わらない」メインスレッド占有を分割することである。

艦船画面についてもv1.85.1の制御VM平均約626msに対し、v1.85.2ルートでは最終計測約532msだった。初回Dynamic Importは実WebView環境のI/O・parse時間が加わるため、最終評価はNubia Fold実機で行う。

## 検証

- 28 smoke scripts: PASS
- startup version: `1.85.2`
- v1.81.4 RNG preservation: PASS
- v1.85.1 performance regression test: PASS
- v1.85.2 architecture performance: PASS
- v1.85.2 navigation state equivalence: PASS
- 全Web JavaScript構文: PASS
- index script参照欠落: 0
- static HTML duplicate id: 0
- eager ship registry load: false
- Dynamic Import target: present

`jsdom`本体がこの実行環境に存在せずnpm offline cacheにも不足があるため、`dom-integration.cjs`のみ未実行。

## Android

- `versionCode 18502`
- `versionName 1.85.2`

Android WebViewは`https://appassets.androidplatform.net/www/index.html`を使用し、`.js`へ`application/javascript` MIMEを付与するためDynamic Importのasset経路に対応している。

Gradle実ビルドはGradle 8.9取得時に`services.gradle.org`へ接続できず、この環境では未完了。
