# ビルド・更新・試験手順

## 構成

Android標準WebView + Java、JDK 17、Gradle 8.9、Android Gradle Plugin 8.7.3。
compileSdk/targetSdkは35、Build-Toolsは35.0.0、minSdkは26。
applicationId/namespaceは`com.starfrontier.game`、versionCodeは18104、versionNameは1.81.4。

Capacitorの依存は追加していません。既存の同期型セーブと関数ラッパーを維持するため、薄いWebViewホストを使用します。ゲーム実行に通信は不要ですが、初回ビルドの開発ツール・Gradle依存取得には通信が必要です。


## GitHub Actions（推奨）

リポジトリのルートに `.github/workflows/android-build.yml` を同梱しています。
GitHub の **Actions → Build Android APKs → Run workflow** から手動実行できます。

workflow は JDK 17 を設定し、Android SDK Platform 35 / Build-Tools 35.0.0 を明示導入し、`android/local.properties` を CI 上で生成してから Nubia / Universal の2 APKをビルドします。
ZIP展開時に Gradle Wrapper の実行権限が失われても `chmod +x android/gradlew` を実行するため影響しません。

成功後、Actions の実行ページ下部 **Artifacts** に `STAR_FRONTIER_v1.81.4_APKs`（versionNameから自動生成） が表示されます。

失敗した場合は `Set up Android SDK 35` / `Verify Android SDK 35` / `Build Nubia Fold and Universal debug APKs` の末尾30〜50行が原因特定に最も有効です。

## Android Studio

`android`を開き、Gradle JDKを17へ指定。SDK ManagerでPlatform 35、Build-Tools 35.0.0を導入し、SDKライセンスを確認してGradle Syncを行います。
`www`と`images`はプロジェクトルートに置いたままにしてください。`syncGameAssets`がAPK用の生成assetsへ同期します。

## コマンドライン

ローカル環境の`ANDROID_HOME`、または`android/local.properties`の`sdk.dir`でSDKを指定します。

```sh
cd android
./gradlew assembleNubiaDebug assembleUniversalDebug
```

Windowsは`gradlew.bat`を使用します。Debug出力は`app/build/outputs/apk/nubia/debug/app-nubia-debug.apk`と`app/build/outputs/apk/universal/debug/app-universal-debug.apk`です。

## 署名・更新

Debugは同梱`android/debug.keystore`を固定で使います。aliasは`androiddebugkey`、store/key passwordは`android`です。この鍵は開発用であり、一般配布用の秘密鍵ではありません。
今後の更新はapplicationIdを維持し、versionCodeを18104より増やし、同じ鍵で署名して上書きします。

ReleaseはAndroid StudioのGenerate Signed Bundle / APK、またはSDKのapksignerで、継続使用する自分の鍵を指定して署名してください。鍵とパスワードを保管してください。

```sh
apksigner sign --ks /path/to/release.jks --out STAR_FRONTIER_release.apk app-release-unsigned.apk
apksigner verify --verbose STAR_FRONTIER_release.apk
adb install -r STAR_FRONTIER_release.apk
```

Debugと異なる鍵のReleaseを直接上書きすることはできません。JSONを書き出してから移行してください。旧AndroidビルドのapplicationId・署名はこの入力ZIPに含まれず、旧APKとの上書き互換は未確認です。

## 試験の再実行

JDK 17以上：

```sh
mkdir -p .test-classes
javac -d .test-classes android/app/src/main/java/com/starfrontier/game/SaveStore.java tests/SaveStoreTest.java
java -cp .test-classes SaveStoreTest
```

Node.jsとjsdom：

```sh
cd tests
npm ci
npm test
```

Node試験は同梱の未変更v1.52からDay 101を生成し、v1.53へ移行して追加300日を進めます。NativeBridge、AudioContext、タイマーとvisibilityはモックです。描画やAndroid実機のPASSを意味しません。

```sh
python3 tools/audit.py <生成したAPK>
```

上記は静的監査です。実機での確認項目は`TEST_REPORT.md`にあります。
