# v1.80 Long-Horizon Strategic Decision AI

## Purpose
Provide a strategic layer above the existing specialized AIs. The strategic layer chooses goals and invokes existing systems rather than creating parallel finance, R&D, logistics, security or contract simulations.

## Horizons
- Enterprises: roughly 45–90 days.
- States: roughly 45–90 days.
- Pirates: roughly 20–50 days.
- KPI review/learning: every 30 days.

## Enterprise objectives
Liquidity/credit defense, supply-chain resilience, innovation, capacity expansion, market/location growth, public-contract alignment.

## State objectives
Price stability, fiscal repair, trade security, defense readiness, infrastructure resilience, industrial/technology autonomy and humanitarian stability.

## Pirate objectives
Survival, cash generation, fleet rebuilding, commerce raiding, smuggling and territorial expansion.

## Player control
Advisor mode is default. Limited delegation executes only explicitly permitted low-to-medium-risk corporate actions. Borrowing and capex default off. M&A, war escalation and illegal attacks are never automatically authorized by v1.80.

## Learning
Plans snapshot KPIs when created. Every 30 days the controller performs a rolling checkpoint, stores the result and resets the comparison baseline for the next checkpoint. Outcome deltas modestly bias future objective scoring. Severe strategic shocks (liquidity/credit collapse, extreme geopolitical crisis, inflation/fiscal shock, or pirate Heat/bounty escalation) can trigger early replanning before the nominal horizon. The learning bias is bounded so actors can change strategy when world conditions change.
