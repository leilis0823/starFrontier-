# STAR FRONTIER v1.83.0 — Dynamic Contracts & Exploration

## Goal

v1.83 turns the existing background simulation into player-facing work. Instead of a separate random quest generator, it reads the authoritative systems already present in STAR FRONTIER: logistics shortage, route health, war status, natural disasters, rescue traffic, security and frontier status.

## Dynamic mission board

The board generates up to five local offers from six mission families:

- Emergency supply: reacts primarily to `game.gm.systemLogistics[system].shortage` and route health.
- Disaster relief: reacts to active v1.73 environmental events and logistics stress.
- Emergency courier: baseline government/neutral communication work with extra wartime pressure.
- Convoy escort: reacts to route danger, war and route-health degradation.
- Rescue response: reacts to v1.79 rescue cases and dangerous systems.
- Unknown-signal survey: biased toward unclaimed / dangerous / insufficiently scanned systems.

Players may carry up to three active v1.83 missions. Standard jobs complete at the target system. Survey jobs are multi-stage and require an anomaly investigation before the contract can be handed in.

## World feedback

Mission outcomes modify existing authoritative state rather than creating a parallel economy:

- Supply: raises local logistics stock, reduces shortage and improves route health.
- Relief: reduces active-disaster severity, shortage and slightly improves public infrastructure when available.
- Escort: reduces v1.78 route danger and improves route health.
- Courier: provides a small relation improvement with the target jurisdiction.
- Rescue: improves route health and uses fuel for rescue operations.

## Exploration and anomalies

Long-range scans can reveal:

1. Derelict ship groups
2. Precursor navigation relays
3. Unregistered dense ore fields
4. Bioship migration/nursery regions
5. Axiom echo nodes
6. Abandoned orbital facilities

Each anomaly is stored persistently in `game.dynamicOps.anomalies`. The player can resolve it using:

- Safe investigation
- Preservation/observation
- Salvage-first recovery

Outcomes are deterministic from the anomaly ID, current hull, relevant crew bonuses and ship capability. Poor-fit ships may take deterministic hull damage; stronger survey/support ships obtain better payouts and exploration XP.

## Existing-system integration

- Ore-field discoveries can increase a v1.76 deposit record.
- Bioship observation affects the existing `game.bio` affinity/protection state.
- Axiom anomalies update the existing machine-contact resonance state.
- Derelicts / abandoned facilities can unlock a previously unknown v1.82 ship-codex entry.
- Precursor relays can add a small research benefit to the system owner.

## RNG / seed guarantee

v1.83 never calls the global `rng()` function. Mission selection and anomaly identity use a private deterministic 32-bit FNV-1a-style hash.

A subtle integration issue was also avoided: the legacy wrapped `gmNews()` path eventually reaches the media engine, where event IDs and coverage can consume the global RNG. v1.83 therefore records its news directly in `game.gm.news` instead of calling wrapped `gmNews()`.

Dedicated smoke coverage verifies that accepting/completing a normal mission, completing a full survey/anomaly mission chain and directly resolving an anomaly leave `marketSeed` unchanged at the baseline test value.

## UI

Two panels are mounted into the Home tab:

- Dynamic Contracts / Flight Operations
- Unknown Space / Anomaly Exploration

The layout is responsive for phone/foldable widths and uses the existing STAR FRONTIER UI primitives.

## Files

- `www/js/129-v1_83-dynamic-contracts-exploration.js`
- `www/css/main.css`
- `tests/v183-dynamic-contracts-exploration-smoke.cjs`
- `www/index.html`
- `android/app/build.gradle`
