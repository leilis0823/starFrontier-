# STAR FRONTIER v1.85.1 — Performance Hotfix

## 目的

v1.85.0 Android実機で、母港 / 銀河 / 採掘 / 市場 / 艦船の切替に2〜3秒かかり、銀河画面が一部だけ描画された状態で長時間止まる症状を修正する。

v1.81.4で導入した遅延描画・RNG保存型キャッシュは有効だったが、v1.82〜v1.85で追加された後段ラッパーがその外側でUIと状態確認を再実行し、性能回帰していた。

## 主因

1. **後段UIがv1.81.4の遅延描画を迂回**
   - 艦船レジストリ、艦船図鑑、動的契約、惑星作戦などが最終renderラッパー側で再実行されていた。
   - 非表示タブでも一部DOM生成が発生した。

2. **艦船画面の巨大DOM**
   - 登録艦級が300超に増え、造船所・レジストリ・図鑑が大量のカードとSVGを一括生成していた。
   - v1.85.0初期表示は約3.7MB級のHTMLを生成するケースがあった。

3. **v1.81.4 ready判定そのものの反復コスト**
   - ensureV112State / ensureV114State / ensureV127State の本体はキャッシュされても、キャッシュヒットごとに大きなready predicateを再評価していた。

4. **歴史的renderラッパーからの重複save要求**
   - 一回の描画中に複数世代のラッパーがsave()を呼ぶ。
   - 大きくなったgameオブジェクトのJSONシリアライズがUI操作待ち時間へ影響していた。

## 修正

### 1. 最終ロード位置でhidden UIを再ガード

v1.85.1を全機能ロード後に置き、以下を現在表示中の場合だけ実行する。

- renderGalaxy
- renderMine
- renderMarket
- renderShip
- renderRoutes
- renderMilitary
- renderStations
- renderCommand
- renderGM
- renderMapDetail
- renderV115FinancePanel

これによりv1.82〜v1.85の後付けラッパーもv1.81.4の遅延描画方針へ戻す。

### 2. 艦船UIの段階描画

- 艦船レジストリ: おすすめ初期18件、その他も18件ずつ「さらに表示」
- 艦船図鑑: 12件ずつ段階表示
- 一覧サムネイル: フル装飾SVGではなく軽量SVG
- 現在艦など詳細表示だけ従来の高品質SVGを維持

機能や登録艦数は削除していない。

### 3. v1.81.4 RNG保存キャッシュの高速ヒット経路

v1.81.4の安全条件は維持しつつ、同一performance epochではready判定結果を再利用する。

- ensureV112State
- ensureV114State
- ensureV127State

ensureV127Stateのキャッシュ再利用時には、v1.24由来の「結果は捨てられるが歴史的には消費される乱数」を従来通り補償する。

### 4. 安全性検証

高速経路を無効化した安全版と有効版へ、同一初期状態から以下のUI操作列を実行した。

`母港 render → 銀河 → 情勢 → ステーション → 星系図 → 採掘 → 市場 → 艦船 → 母港 → render`

結果:

- 初期 marketSeed: `4106848233`
- 最終 marketSeed（安全版）: `2005864285`
- 最終 marketSeed（高速版）: `2005864285`
- game JSON SHA-256（version除外）両方: `71959db2131487833e579ef01ed6e16407764f429f075360372b349ee4f5869f`
- JSON bytes: `1468137` 両方一致

またv1.81.4専用回帰では:

- initialSeed `4213774138`
- directSeed `3119341908`
- cachedSeed `3119341908`
- game JSON完全一致
- 高速キャッシュヒット 25

### 5. saveバッチング

render中の重複save要求をpendingフラグへまとめ、最外周render終了時に1回だけコミットする。

重要: v1.85.1では独自localStorage-only保存へ置換せず、既存Android/native persistence bridgeを呼ぶ。これによりAndroidのSaveStore、ネイティブ保存キュー、バックアップ経路を維持する。

## 制御VM計測

同一の初期化済みホーム描画条件で、v1.81.4 ready判定高速経路のみをOFF/ON比較:

- 安全版: 約 `661 ms`
- 高速版: 約 `296〜306 ms`

これはAndroid実機値ではない。実機では端末WebView、DOMレイアウト、熱状態等で変動する。

前段のUI軽量化テストでは、艦船画面HTML量は約3.76MBから約0.21MBまで縮小した。

## テスト

- 26 smoke tests: PASS
- startup: `1.85.1` PASS
- v1.81.4 RNG seed preservation: PASS
- v1.82 Fleet Identity: PASS
- v1.83 Dynamic Contracts & Exploration: PASS
- v1.84 Ship Lifecycle & Used Market: PASS
- v1.85 Strategic Stations & Planetary Operations: PASS
- v1.85.1 Performance Hotfix: PASS
- all Web JavaScript syntax: PASS
- missing index scripts: 0
- duplicate static HTML ids: 0

## Android

- versionCode: `18501`
- versionName: `1.85.1`

v1.85.1はFeature Freeze中の修正版であり、新規ゲーム機能は追加しない。
