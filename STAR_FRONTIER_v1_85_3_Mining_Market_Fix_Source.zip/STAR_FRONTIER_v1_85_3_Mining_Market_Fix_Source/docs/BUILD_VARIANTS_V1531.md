# v1.53.1 Build Variants

## Nubia Fold専用版

```bash
cd android
./gradlew assembleNubiaDebug
```

期待出力: `app/build/outputs/apk/nubia/debug/app-nubia-debug.apk`。

プロファイル: `nubia_8elite_12gb`。Snapdragon 8 Elite / RAM 12GBを前提に、WebView rendererを非表示時にもIMPORTANTで保持し、保存デバウンス180ms、チェックポイント5ゲーム日、ナビゲーション履歴48、メモリ圧迫時のDOM解放を深刻時に限定する。

## Universal版

```bash
cd android
./gradlew assembleUniversalDebug
```

期待出力: `app/build/outputs/apk/universal/debug/app-universal-debug.apk`。

プロファイル: `universal`。保存デバウンス650ms、チェックポイント7ゲーム日、履歴28、メモリ圧迫時に非表示巨大DOMを積極解放する。

## 更新インストール

両variantは`com.starfrontier.game`のまま。現在のv1.53.0 Debug APKと同じ`android/debug.keystore`を使ってDebug版を署名すれば、アンインストールせず更新できる。内部files領域の主セーブを維持するため、先にアプリをアンインストールしないこと。念のため更新前にJSON書き出しを推奨。

Nubia版とUniversal版は同じapplicationIdなので同時インストール不可。ユーザー本人にはNubia版、他者配布にはUniversal版を使う。
