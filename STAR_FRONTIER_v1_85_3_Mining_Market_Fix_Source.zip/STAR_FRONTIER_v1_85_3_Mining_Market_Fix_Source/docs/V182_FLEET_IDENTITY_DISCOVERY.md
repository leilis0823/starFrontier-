# STAR FRONTIER v1.82.0 — Fleet Identity & Discovery

## Goal

v1.82.0 gives individual ships, manufacturers and crews a persistent identity layer without replacing the existing economy, combat, shipyard or v1.81.4 performance architecture. The feature layer intentionally avoids `rng()` so that simply enabling, rendering or progressing these systems does not perturb the simulation RNG stream.

## 1. Procedural 2D ship icons

`www/js/127-v1_82-ship-icons-registry.js` generates SVG ship art as data URIs. Geometry changes by hull class (prospector, freighter, corvette, frigate, cruiser, carrier, battleship, dread), while maker/class themes change accents. Existing explicit image-manifest entries can still override generated art.

The icons are used by the current-ship view, shipyard cards and ship registry. Unknown ships can be rendered as obscured silhouettes by the discovery layer.

## 2. Manufacturer reputation

State is stored in `game.shipIdentity.manufacturerRep`.

- Range: 0–100.
- Existing saves seed a small reputation only for manufacturers whose ships are already owned.
- Buying a maker hull increases reputation based on hull value.
- Reputation 8 unlocks field-evaluation contracts.
- Field-evaluation contracts require operating that maker's hull for 2–3 game days.
- Each 10 reputation grants 1.5% purchase discount, capped at 12%.

Exclusive hulls:

| Manufacturer | Hull | Reputation |
|---|---|---:|
| Regulus | PIONEER-RX | 45 |
| Horizon | COMET-LX | 45 |
| Nox | DEEPCORE-NX | 50 |
| Asterion | PALADIN-AH | 55 |

## 3. Derivative hull development

The player can develop a derivative from the currently owned hull at a major/regional or player shipyard. Only one project may be in development at once.

Branches:

- Mining: +mining capability and cargo capacity.
- Trade: significantly larger cargo capacity.
- Escort: added combat/armor at a cargo cost.
- Range: larger fuel capacity and better propulsion efficiency.
- Support: cargo/fuel reserve plus command/support capability.

Projects use deterministic IDs from `game.shipIdentity.variantSeq`; no RNG is consumed. On completion, the prototype is added to `HULLS`, `ownedHulls`, `hullState` and `shipRecords`.

### Save compatibility

Dynamic hulls are reconstructed from `game.shipIdentity.variants`. v1.82 wraps `normalize(g)` and materializes completed variants before the base normalization checks whether `g.hull` exists. This prevents saves made while flying a derivative hull from falling back to `nomad`.

## 4. Crew traits and hull compatibility

The existing six crew roles are retained. v1.82 adds:

- a role trait with preferred hull classes;
- a deterministic personal trait based on role + crew name;
- per-class familiarity (`classFamiliarity`) gained each game day while aboard;
- compatibility bonus up to +5 on top of the existing crew bonus.

The engineer compatibility bonus also reduces incoming hull damage by up to 5%. Navigator, captain, gunnery and marine bonuses naturally flow through the existing engine/combat/capture code because the existing `crewBonus()` entry point is wrapped rather than replaced.

## 5. Discovery-gated ship encyclopedia

State is stored in `game.shipIdentity.discoveries`.

A hull is identified by:

- owning or flying it;
- seeing it in the local shipyard/market;
- military withdrawal intel;
- local mining traffic;
- local merchant traffic;
- irregular-ship hunt intelligence;
- manual intelligence-officer silhouette analysis.

Unknown hulls show only an unidentified silhouette and signal number. Their names, class and stats are hidden in the encyclopedia and the general registry until discovered.

The intelligence scan is once per game day and costs credits. A strong intelligence-officer bonus lowers the price and can identify two contacts instead of one.

## RNG preservation

The v1.82 feature code contains no direct `rng()` calls. It uses FNV-style deterministic hashing where stable pseudo-selection is needed. It also avoids `gmNews()` for new feature completion notifications because the pre-existing media layer can consume RNG while generating news coverage. Local `addLog()` notifications are used instead.

Dedicated regression:

`tests/v182-fleet-identity-discovery-smoke.cjs`

The test verifies manufacturer discounts and exclusive unlocking, crew compatibility, derivative project completion, dynamic-hull restoration before normalization, discovery lock/unlock, manufacturer contract progression, and confirms that `marketSeed` remains unchanged across all feature-only actions.
