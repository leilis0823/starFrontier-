# STAR FRONTIER v1.53.3 — 企業画面UI重複修正

## 修正内容

企業タブの `契約台帳・取締役会` カードが、企業画面の再描画ごとに削除されず追加され続ける不具合を修正した。

原因は、`renderV117PlayerBusiness()` が `playerCorporationPanel` の兄弟要素として複数パネルを返す一方、再描画前の削除対象が `#v117BusinessPanel` と `#v118GroupPanel` の2つだけで、後から追加された v1.30 の契約統治カードに固定DOM IDが無かったこと。

対策:
- `renderV130PlayerGovernance()` のルートへ `id="v130PlayerGovernance"` を付与。
- 企業画面再描画時の削除対象へ `#v130PlayerGovernance` を追加。
- 契約台帳、取締役会、係争データやセーブ構造そのものは変更しない。

## 他の重複監査

再描画で兄弟DOMを累積しやすい `insertAdjacentHTML('afterend', ...)` を全JSで監査した。該当は2系統のみ。

1. v1.9系の企業勤務・保険追加UI: `#v19CareerExtra` / `#v19InsurerExtra` を挿入前に削除済み。
2. v1.17以降の法人・持株会社・契約統治UI: 本修正で `#v117BusinessPanel` / `#v118GroupPanel` / `#v130PlayerGovernance` を全て挿入前に削除。

同一見出しの静的重複も監査したが、`あなたの事業体` は相互排他的な条件分岐、`過去の企業売却` は後段で置換される旧レンダラー定義であり、同時表示される重複ではない。

## 互換性

- セーブJSON変更なし。
- 国際組織日本語化を維持。
- Nubia / Universal性能プロファイルを維持。
- ゲームロジックの数値・AI判断変更なし。

## バージョン

Androidビルド表記を v1.53.3 に統一。
- versionCode: 15330
- versionName: 1.53.3
