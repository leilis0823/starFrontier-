# STAR FRONTIER v1.85.3 — Mining Market Integration Fix

## Symptom

After v1.76, mined raw ores are stored in `game.miningV176.ores` and refined elements in `game.miningV176.elements`. This is intentional: ore composition, refining and provenance/contraband data cannot be represented safely by the legacy three-resource `game.cargo` object.

The legacy system-market list (`#marketList`), however, still rendered only `game.cargo` (`iron`, `titanium`, `crystal`). As a result, mined ore could consume ship-hold capacity and appear in the cargo overview while being absent from the normal System Market list.

## Fix

`134-v1_85_3-mining-market-integration-fix.js` extends the normal System Market renderer with currently-owned:

- raw ores from `v176State().ores`
- refined elements from `v176State().elements`

Each integrated row shows ship-hold quantity, current local sell price, and 1 / up-to-5 / all sell controls.

The fix deliberately does **not** copy ore into `game.cargo`; that would cause cargo-capacity double counting because v1.76 already extends `cargoUsed()` for ore and refined elements.

Sales delegate to the existing `v176SellOre()` and `v176SellElement()` functions. Therefore later wrappers remain authoritative:

- v1.77 mining-rights / ore provenance / customs behavior
- v1.78 contraband checks for refined elements
- v1.69/v1.76 commodity supply effects

The integration layer itself consumes no RNG.

## Performance compatibility

The late v1.85.1 market visibility guard is preserved. v1.85.3 does not rebuild mining-market rows while the Market tab is hidden. The v1.85.2 route-first navigation and ship-UI Dynamic Import remain unchanged.

## Version

- Web/game version: `1.85.3`
- Android `versionCode`: `18503`
- Android `versionName`: `1.85.3`
