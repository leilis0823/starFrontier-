# v1.77 Advanced Mining Rights & Exploration

## Purpose
Deepen v1.76 mining without creating a parallel inventory, finance or legal economy. v1.76 remains authoritative for ore cargo, refined elements, deposits, mining traffic and salvage. v1.77 adds investment, exploration, rights, environmental and provenance layers.

## Critical minerals
Added Ga, Ge, W, Mo, Ta and Re to the existing v1.76 element inventory and v1.69 commodity market. New ores are scheelite, molybdenite and coltan. Existing bauxite and chalcopyrite now produce small Ga/Ge by-products; molybdenite produces trace Re.

## Deep prospecting
A 700 Cr / 2 fuel deep survey can be performed once every three days per system. It identifies one selected/high-priority ore body and may reveal a bonanza, rich zone, polymetallic zone, unstable high-grade vein, or ordinary prospective deposit. Discoveries expire after 14 days.

## Mining rights and survey-data market
A player can acquire a 60-day claim for the selected ore. Price depends on reserve index, ore value and discovery quality. Claims increase mining yield and are written into the v1.30 contract ledger. Instead of developing the claim, the player can sell exclusive survey data to the local resource economy.

## Tailings and environmental risk
Refining creates tailings. Refinery-equipped systems can reprocess tailings for small critical-mineral recovery. Mining/refining adds local environmental load; restoration and reprocessing reduce it. Environmental load feeds v1.73 environmental/disaster risk rather than creating a new disaster engine.

## Accidents and insurance
Mining/refining accidents scale with vein instability and accumulated environmental stress. Damage/loss remains in existing ship/corporate state. If the player's corporation has applicable v1.63 coverage, mining accidents can generate an insurance claim.

## Illicit ore provenance
Ore looted from a non-belligerent civilian mining vessel is marked as contraband. Selling it in a lawful market carries customs inspection/confiscation risk and uses v1.40 contraband offenses. The underground broker pays less but removes the provenance cleanly.

## Compatibility
No new cash ledger, court, commodity exchange, insurance system, cargo inventory or disaster engine is introduced. Existing v1.30, v1.40, v1.63, v1.69, v1.73 and v1.76 systems are reused.
