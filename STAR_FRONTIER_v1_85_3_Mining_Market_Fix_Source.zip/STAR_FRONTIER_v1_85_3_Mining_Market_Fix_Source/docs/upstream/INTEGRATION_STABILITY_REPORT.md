# STAR FRONTIER v1.51.0 — Integration & Stability Report

## Scope
v1.51 is a completion-phase build. No new major gameplay subsystem was added. The work focused on long-run simulation, save/load integrity, historical-state growth, MOE/ensure recursion, and packaging consistency before player-route completion and Android packaging.

## Fixed integration defects

1. **v1.45 military/MOE daily symbol mismatch**
   - Historical code called `processV145Daily()` while the actual implementation was `v145ProcessDaily()`.
   - A compatibility alias now keeps the public daily call stable.

2. **MOE rebuild re-entry / recursion**
   - Late-version ensure functions could call MOE rebuilding, which could re-enter those ensure functions.
   - v1.51 adds a rebuild re-entry guard.

3. **Repeated historical ensure-chain execution**
   - Late systems repeatedly normalized all older systems in the same logical tick.
   - v1.51 memoizes state-normalization functions inside an init/render/day-advance epoch.
   - Direct actions outside an epoch still run their normal ensure logic.

4. **Diagnostics mutating game version**
   - `v151Metrics()` previously called the legacy `v127AllEnterprises()`, whose ensure chain changed `game.version`.
   - Enterprise counting is now side-effect free.

## Long-run data compaction
The following historical data is now bounded while active world state is preserved:

- banking review history
- inactive corporate loans
- completed capital-project audit entries
- completed military supply convoys
- v1.30 contract-law registry and resolved disputes
- media deduplication keys / cold issue interest
- NPC flavor histories
- `majorEventSeen` old dedup keys
- expired corporate-government contracts
- expired regional sanctions
- inactive monetary sanctions and old sovereign bonds
- expired/orphan technology patents
- terminal technology licences, joint developments, reviews, incidents and acquisitions

## Save strategy change
The old browser strategy could store the main save plus three full JSON backup copies. With multi-megabyte worlds this can exhaust Web Storage.

v1.51 now:

- writes the **primary save first**;
- always uses `AndroidNative.persistBackup()` when the host provides it;
- scales browser backup generations according to save size;
- removes oversized stale browser generations before writing another backup;
- stores no duplicate full browser backup once the save exceeds 2.1M characters;
- records a primary-save quota failure instead of silently pretending that the save succeeded.

This is an interim WebView safeguard. **v1.53 must move the primary save and rotating backups to Android/native file storage.**

## Test results

### 500-day stage
Actual split v1.51 scripts were loaded in a Node VM harness and all normal daily processors were allowed to run.

- Start: Day 1
- End: Day 501
- Simulation time in the test environment: ~23.4 s
- Serialized primary save: **2,584,054 characters**
- `v151Validate()`: **0 issues**

### Save / reload / second 500-day stage
The Day 501 save was loaded in a fresh VM, then simulated for another 500 days.

- Loaded Day 501: PASS
- End: Day 1001
- Second-stage simulation time: ~24.0 s
- Serialized primary save: **2,806,427 characters** before a later load-normalization pass; round-trip test was ~2.816M characters
- `v151Validate()`: **0 issues**
- Factions: 7
- Legislatures: 7
- Active parties: 34
- Enterprises: 51
- NPC actors: 24
- Mercenary groups: 7
- Pirate bands: 4
- Active international organizations: 4
- MOE agents: ~220

### Save/load round trip
Day 1001 state was saved, deliberately mutated in memory, then reloaded from storage.

- Day restored: PASS
- Version remained `1.51.0`: PASS
- Metrics no longer mutate version: PASS
- Validation after reload: 0 issues

### Browser backup recovery
A fresh/small save was backed up, the primary JSON was deliberately corrupted, and `load()` recovered the browser backup.

- Browser backup recovery: PASS
- Validation after recovery: 0 issues

### Native-backup recovery simulation
A large Day 1001 save used a mocked `AndroidNative.persistBackup/getNativeBackup` host. The primary was then deliberately corrupted.

- No duplicate full browser backup for the large save: PASS
- Recovery from native backup: PASS
- Validation after recovery: 0 issues

### Legacy save migration
A minimal `starFrontierSaveV09` save was loaded.

- Core fields preserved: PASS
- v1.47 law/religion state initialized: PASS
- v1.48 international organization state initialized: PASS
- v1.49 parliament state initialized: PASS
- Final version normalized to `1.51.0`: PASS
- Validation: 0 issues

### Repeated save/load cycles
Three cycles of 25 days -> save -> mutate -> reload were run after legacy migration.

- Day continuity: PASS
- Validation each cycle: PASS

### Targeted rare-system tests
Rare branches that did not naturally occur in the 1000-day seed were forced through their public system functions.

- dynamic religion creation: PASS
- religion -> armed parallel-force creation: PASS
- dynamic international organization proposal -> formation: PASS
- player court case -> judicial resolution: PASS
- regional independence -> dynamic sovereign state: PASS
- dynamic state registration into faction/government systems: PASS
- dynamic-state legislature: PASS
- dynamic-state police/court institutions: PASS

### Static package checks
- Every split JS file passes `node --check`.
- Every CSS/JS resource referenced directly by `index.html` exists in the v1.51 package.
- Compatibility placeholders were added for `regional-economy.js` and `android-bridge.js`; Android bridge finalization remains a v1.53 task.

## Remaining known risk
A synthetic localStorage implementation with a strict **5 MiB total quota** cannot store the Day 1001 primary JSON when counted as UTF-16 storage (~5.63 MiB). A 6 MiB synthetic quota succeeds because v1.51 no longer adds a duplicate browser backup.

Therefore v1.51 improves safety but does **not** make localStorage a suitable final persistence layer. Android/native file persistence is a release blocker for v1.53.

## Browser / Android status
Chromium headless execution in this environment still does not terminate reliably because of the game's long-lived real-time timer/runtime behavior, so no browser-runtime PASS is claimed from that route. Android/WebView real-device testing has not yet been performed.

## Gate result
**v1.51 integration gate: PASS for simulation/state/save-load logic, with native-file persistence explicitly deferred to v1.53.**

Next planned build: **v1.52 — player-route completion and gameplay-path audit.**
