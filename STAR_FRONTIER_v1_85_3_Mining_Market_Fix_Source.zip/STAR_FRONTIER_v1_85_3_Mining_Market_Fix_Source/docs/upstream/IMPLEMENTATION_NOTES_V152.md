# STAR FRONTIER v1.52.0 Implementation Notes

## Scope
Player-route completion and progression-blocker fixes only. Feature freeze remains in effect.

## New compatibility layer
`www/js/90-v1_52-player-routes.js`

### Civic career promotion
- Replaced `v141CheckPromotion()` with a live-state-safe loop.
- Reacquires `game.civicCareer` after every major-event dispatch.
- Prevents stale-object writes caused by late-version ensure/MOE normalization.

### Mercenary public procurement
- Keeps v1.44's removal of player-only routine mercenary contracts.
- Replaces `v144AssignOrder()` scoring while keeping the same AI-issued order pool.
- Player company score now includes command/operations competence, inactivity and unsuccessful-tender learning.
- Established NPC groups receive a small mission-fatigue term.
- First two player-company awards use an aggressive new-entrant bid factor (84–94% of posted budget).
- Tracks `v152TenderLosses` and synchronizes `lastAction` on award/closure.

### Corporate employee assignment XP
- Wraps `completeCorporateAssignment()`.
- Detects the v1.13.1 stale `corporateCareer` reference after the built-in one-day work advance.
- Restores 10–16 XP and allowance history only when the live state did not receive them.
- Uses assignment-id hashing rather than a new RNG call, preserving deterministic reload behavior.

### Build/version persistence
- `gmAdvance`, `load`, `save`, `render`, and `initV10` leave the active build at 1.52.0.
- Save retains v1.51 compaction/adaptive backup behavior but serializes `version: 1.52.0`.

### Diagnostics
`StarFrontierPlayerRoutes.status()` exposes compact route-state diagnostics for tests and later Android diagnostics.

## Validation
- All JS files: `node --check` PASS.
- Main route audit: PASS for mining/trading, enterprise founder, mercenary, pirate, parallel military, border guard, politician/parliament, public servant, sovereignty/stations/direct fleet.
- Corporate employee progression (travel fuel kept available): PASS to executive rank.
- Corporate employee save/load continuation: PASS.
- Mercenary procurement repeated test: 5/5 receive an AI-issued award by Day 4.
- Save/load route-state roundtrip: PASS, consistency issues 0.
- 300-day integrated simulation: PASS, consistency issues 0.

## Not claimed
Browser/WebView real-runtime integration and Nubia Fold real-device testing are not claimed as passed. These remain v1.53/v1.54 work.
