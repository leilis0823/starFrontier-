# STAR FRONTIER v1.42.0 国家旗アセット対応

このパッケージは、v1.42.0 の既存 `SF_FLAG_IMAGES` レジストリに合わせて、ユーザー提供の7枚の国旗画像を配置したものです。

## 割り当て
- `league.webp` — 自由交易連盟（青地・軌道儀・金色コンパス）
- `helios.webp` — ヘリオス統合府（白地・黒金・太陽）
- `nyxdom.webp` — ニクス辺境自治領（黒地・紫・三日月と星）
- `concord.webp` — セラフィーン協約（白地・水色の翼・金星）
- `imperium.webp` — カルドラク帝政（赤黒金・双頭鳥・王冠）
- `orpheus.webp` — オルフェウス中立機構（灰白・青緑・軌道紋）
- `volgar.webp` — ヴォルガル軍政復興邦（赤黒橙・歯車・工業都市）

## 配置構造
```
www/index.html
images/flags/league.webp
images/flags/helios.webp
images/flags/nyxdom.webp
images/flags/concord.webp
images/flags/imperium.webp
images/flags/orpheus.webp
images/flags/volgar.webp
```

`www/index.html` 内の既存レジストリは `../images/flags/...` を参照するため、この構造でそのまま読めます。

## 表示される場所
現行コードでは少なくとも以下に国旗が表示されます。
- 銀河情報の国家一覧
- 星系/国家詳細の小型国旗

軍事組織旗は今回未実装です。次回、国家旗とは別の `images/flags/military/` 系統として追加可能です。
