# IMPLEMENTATION NOTES — v1.51.0

Build: `1.51.0`  
Theme: Integration stability / long-run audit / save growth control

## Runtime fixes
- compatibility alias for v1.45 daily processor naming mismatch
- ensure-state epoch memoization
- MOE rebuild re-entry guard
- side-effect-free integration metrics
- validation snapshots every 25 game days

## Persistence / compaction
- bounded high-frequency history collections
- bounded major-event dedup state
- bounded inactive corporate contracts and sanctions
- bounded old bonds while preserving active/player-held bonds
- technology-ledger garbage collection preserving active patents/licences
- v1.30 contract registry keeps all live/open-dispute records plus bounded recent history
- adaptive browser backup generation count
- native backup preferred when `AndroidNative` is present
- explicit primary-save failure return on quota error

## Packaging
- `regional-economy.js` compatibility path now exists in-package; regional simulation is already bundled in versioned scripts
- `android-bridge.js` compatibility path now exists in-package; final Android bridge is scheduled for v1.53

See `INTEGRATION_STABILITY_REPORT.md` for test results and remaining risk.
