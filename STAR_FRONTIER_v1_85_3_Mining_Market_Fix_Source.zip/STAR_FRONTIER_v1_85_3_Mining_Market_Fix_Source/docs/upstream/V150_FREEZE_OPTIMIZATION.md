# STAR FRONTIER v1.50.0 — Feature Freeze / Optimization

## 方針

この版から大型ゲームシステムの追加を凍結し、正式APKへ向けた統合・軽量化・安定化を優先する。

## 実施内容

- 旧1.9MB単一 `www/index.html` から CSS / JavaScript を外部ファイルへ分割。
- JavaScriptは互換性を守るため ES Modules 化せず、既存のグローバル関数再定義チェーンを保ったクラシックスクリプトをバージョン群ごとに分割。
- `defer` でHTML解析をブロックしない読み込みへ変更。
- 180艦級の造船所、銀河情報、軍務、拠点、艦隊司令など重量DOMを非表示中に再構築しない遅延描画を追加。
- 銀河サブタブを開いた時だけ再描画する方式へ変更。
- `game.v150` に `renderCount / lastRenderMs / maxRenderMs` の軽量計測値を保存。
- セーブキー・既存セーブ構造は変更しない。

## 分割ファイル

- `www/css/main.css`
- `www/js/00-core.js`
- `www/js/10-v1_1-v1_17.js`
- `www/js/20-v1_18-v1_31.js`
- `www/js/30-v1_32-v1_38.js`
- `www/js/40-v1_39-v1_43.js`
- `www/js/50-v1_44-v1_46.js`
- `www/js/60-v1_47-v1_49.js`
- `www/js/70-v1_50-optimization.js`
- `www/js/99-bootstrap.js`

## 凍結ルール

正式版までは新しい大型システムを原則追加しない。以後は結合テスト、既存導線、Android/Fold、セーブ安全性、長時間シミュレーションの修正を優先する。
