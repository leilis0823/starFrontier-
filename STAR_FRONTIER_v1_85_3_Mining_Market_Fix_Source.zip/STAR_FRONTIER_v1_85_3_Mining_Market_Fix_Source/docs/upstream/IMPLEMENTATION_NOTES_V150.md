# v1.50.0 Implementation Notes

- Source: v1.49.0
- Original index size: 1,982,040 bytes
- New index size: 14,626 bytes
- Main CSS: 16,608 bytes
- JavaScript chunks: 9
- No save-key migration was introduced.
- Regional economy / Android bridge remain external extension files, as in the source build.
- This is a source-architecture and render-cost optimization pass, not a feature expansion.
