# v1.85.0 — Strategic Stations & Planetary Operations

## Purpose
v1.85 expands STAR FRONTIER from orbital-only infrastructure warfare into a three-layer operational model: **orbit → atmosphere → surface**. The update deliberately keeps the game ship-centric. It does not add a separate tank/infantry strategy game; planetary operations are carried by dual-environment spacecraft, orbital stations, strategic station-ships, and abstracted planetary facilities.

## 1. Expanded station roles
The existing five station modules remain authoritative and eight new modules are appended, for 13 total module types:

- Fleet Naval Base
- Mining Control Station
- Deep-Space Research Station
- Long-Range Intelligence/Sensor Array
- Medical & Rescue Station
- Fuel Refinery / Fleet Depot
- Habitat Ring
- Informal / Black-Market Quarter

Station role labels are inferred from module combinations instead of replacing the existing station object. This preserves old saves and all existing `game.stations` consumers.

## 2. Strategic station-ships
Twelve strategic station-ship families are defined. These are not ordinary player hulls; they are theater-level assets in `game.strategicStations`.

1. BASTILLE-SR — mobile fortress
2. CITADEL — defensive station-ship
3. ARSENAL — mobile weapons factory
4. FOUNDRY — mobile shipyard
5. ATLAS — strategic logistics carrier
6. HOSPITALLER — medical / rescue mothership
7. OBSERVER — intelligence / EW station-ship
8. SOVEREIGN — fleet-command fortress
9. DEVOURER — resource-processing fortress
10. GATEKEEPER — route-denial station-ship
11. LEVIATHAN DOCK — bioship support dock
12. AXIOM NODE — machine-civilization strategic node

Player strategic assets are capped at four and one per class. Construction uses a player shipyard's physical stored materials and a long construction queue. NPC powers receive a limited seed set in strategically appropriate systems.

## 3. Dual-environment surface/space ships
Six hull families are integrated directly into the existing `HULLS` registry so they work with ownership, ship history, v1.82 codex/identity, and v1.84 lifecycle/used-market systems.

- STRIDER-AX — patrol / facility defense corvette
- LANDER-LC — troop, cargo, rescue lander
- HAMMERHEAD-AG — heavy surface attack frigate
- WARDEN-AT — planetary air-defense / base-defense frigate
- RANGER-PX — exploration / colonization vessel
- MARAUDER-RX — pirate landing raider

Large battleships, carriers and dreadnoughts remain orbit-bound by design. Planetary combat therefore preserves scale: strategic ships hold orbit while dedicated small/medium vessels descend.

## 4. Planetary facilities
Each known system is deterministically seeded with two to three surface facilities. Six facility categories are used:

- planetary mine
- surface fuel refinery
- planetary research outpost
- ground logistics depot
- colonial settlement
- planetary defense garrison

Player facilities may be built in systems where the player has an orbital station or territorial claim. Facilities have HP, defense, production level and disruption state.

## 5. Pirate landing raids
Existing v1.24/v1.80 pirate organizations are reused. v1.85 does not create a parallel pirate economy.

Pirates periodically evaluate nearby planetary facilities based on value, local security and defensive strength. A raid then resolves through three defensive layers:

1. **Orbital interception** — orbital stations, fleets, strategic station-ships.
2. **Atmospheric interception** — strategic support, surface-capable reserve ships, local garrisons.
3. **Surface defense** — facility defense, garrisons and landed defense ships.

If the player is physically present in the target system they may intervene. Any ship may attempt orbital interception, but surface-capable ships receive atmospheric/surface combat value and are materially better at stopping a landing.

Successful pirate raids damage or destroy the target, temporarily disrupt its economic contribution, and transfer loot/value back into the existing pirate band's treasury/notoriety.

## 6. Surface defense assignments
Owned dual-environment ships that are not the currently flown hull can be assigned to a player-controlled system as planetary defense reserves. This gives otherwise idle owned hulls a strategic purpose without introducing a second fleet ownership model.

## 7. Economic / strategic effects
New station modules add fixed station income and defensive utility. Planetary facilities lightly feed existing logistics/research state. Strategic station-ships add local defense and specific support effects such as logistics income, intelligence generation, bioship affinity or machine-contact resonance.

## 8. RNG safety
v1.85 never calls the global `rng()` function. All new site seeding, raid targeting, raid strength, combat jitter and strategic IDs use an independent deterministic FNV-1a hash.

Dedicated smoke verification performs:

- v1.85 initialization
- player surface-facility construction
- CITADEL strategic build queue and completion
- WARDEN planetary-defense assignment
- real existing pirate-band landing raid generation
- STRIDER interception and raid resolution

The baseline `marketSeed` remains `4213774138` throughout the v1.85-only operations.

## 9. Compatibility
- Old station objects are not migrated into a replacement schema.
- New station modules append to `STATION_MODULES`.
- Surface ships append to `HULLS` and therefore use established ownership/lifecycle paths.
- Planetary and strategic state are additive (`game.planetaryOps`, `game.strategicStations`).
- v1.81.4 performance/RNG cache behavior remains unchanged.

## Version
- Web/game: `1.85.0`
- Android `versionCode`: `18500`
- Android `versionName`: `1.85.0`
