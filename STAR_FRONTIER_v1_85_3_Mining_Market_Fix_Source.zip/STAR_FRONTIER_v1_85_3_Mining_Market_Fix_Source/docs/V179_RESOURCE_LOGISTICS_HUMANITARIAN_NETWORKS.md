# v1.79 Resource, Logistics & Humanitarian Networks

v1.79 closes several remaining abstraction gaps between mining, physical shipping, population movement, wartime interdiction and service contracts.

## Resource majors and mining concessions
Existing v1.76 ore deposits and v1.77 mining rights remain authoritative. Resource majors evaluate valuable system/ore concessions, bid in auctions and can acquire one another's rights. Payments move through existing corporate/state finance and rights are mirrored into the v1.30 common contract ledger.

Automated mines deplete the real deposit state. Most production is processed into local commodity supply, while part of output is loaded aboard a physical mining fleet. Those ships appear in the existing v1.76 mining-traffic layer and can be attacked under the same lawful-war/piracy rules. Destroyed or captured fleets create a replacement delay, financing loss and security hardening rather than instantly respawning. Surviving fleets periodically offload ore into local supply.

## Passenger and refugee traffic
Passenger liners and humanitarian evacuation ships move physically through the system graph. Refugee population is reserved at departure and transferred only on successful arrival. If an evacuation expires without arrival, the reserved population is returned to the origin demographic pool so population cannot silently disappear.

## Blockades, inspections and sanctions
War fronts can establish system blockades with strength and inspection intensity derived from military balance, crisis and sanctions. Real v1.78 merchants may be delayed or seized. Humanitarian traffic receives a separate inspection path. Player travel is also exposed to inspection, especially when carrying contraband.

## Freight exchange
Enterprises publish freight jobs derived from actual stock and route conditions. Accepting a job removes cargo from the origin stock and loads the player's hold. Delivery adds it to destination inventory. Service compensation is charged to the issuer's existing enterprise/state finances; inability to pay becomes an outstanding v1.30 contract breach rather than newly created money.

## Tow, rescue, repair and salvage
Damaged physical merchants, distressed passenger ships and existing wrecks generate service cases. Successful work repairs/restarts physical traffic or salvages existing cargo. Compensation is paid by the responsible enterprise or state when funds exist; unpaid amounts remain legally outstanding.

## Smuggling networks
Local underground networks have trust, heat and safehouse depth. Covert freight jobs use existing cargo/contraband provenance and customs/crime systems. Trusted networks reduce, but never eliminate, customs exposure.

## Integration principle
v1.79 does not create duplicate finance, inventory, insurance, crime or population engines. It acts as an interaction layer over the systems introduced in earlier versions.
