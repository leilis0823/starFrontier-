# v1.53.2 Version Display Sync

アプリ化前の版表記監査で、Gradle/ZIPはv1.53.2だがWebView側の表示とdiagnosticsがv1.53.1のまま残っていたため修正。

修正箇所:
- `www/index.html` の `<title>` → v1.53.2
- `www/android-bridge.js` の画面タイトル/バッジ → v1.53.2
- `window.StarFrontierAndroid.build` → `1.53.2`
- `diagnostics().build` → `1.53.2`

Gradleは既に `versionCode 15320 / versionName 1.53.2` であり変更なし。ゲームロジック、セーブ形式、国際組織日本語化、Nubia/Universal性能プロファイルには変更なし。
