# v1.54.1 Media & International Organization AI

## Hybrid-intervention-aware media

v1.54 public events now use four explicit media categories:

- `covert`: covert operations, assassinations, attribution investigations
- `hybrid`: unmarked forces, proxy/irregular intervention
- `annexation`: annexation requests and sovereignty transfers
- `sphere`: protectorates, client states, puppets, sphere realignment

Media framing changes with outlet freedom, state bias and sensationalism. High-freedom outlets distinguish confirmed facts from attribution claims; state-aligned outlets emphasize official statements; sensational outlets use stronger framing. Government statements, counter-intelligence statements and selected foreign-policy reactions are also generated.

Existing v1.54 saves are migrated in memory: previously generic media events are reclassified and the issue-interest index is rebuilt without changing save IDs.

## International organization AI overview

The international organization screen now shows an AI-generated functional overview for both creation proposals and active organizations. It explains:

- what the organization exists to do;
- typical joint measures;
- sponsor/core state and voting rule when available;
- latest resolution when available;
- current AI demand signal and the situation keywords driving creation pressure.

Internal organization type IDs, action IDs and voting IDs remain unchanged for save compatibility.
