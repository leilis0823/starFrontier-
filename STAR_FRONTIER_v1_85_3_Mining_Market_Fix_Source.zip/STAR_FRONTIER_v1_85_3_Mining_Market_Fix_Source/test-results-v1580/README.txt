STAR FRONTIER v1.58.0 validation summary

PASS:
- All www JavaScript: node --check
- index.html local resource references: missing 0
- external HTTP(S) runtime URLs: 0
- UI duplicate audit
- v1.58 location-policy smoke
- v1.58 integration smoke: location grant, construction permit acceleration, bubble/correction branch, hollowing branch
- Android metadata sync: versionCode 15800 / versionName 1.58.0
- Android bridge build/save version: 1.58.0

NOT RUN / BASELINE:
- tests/dom-integration.cjs: bundled archive contains jsdom directory entries but no jsdom module files; dependency unavailable in this environment. See dom-integration-unavailable.txt.
- tools/audit.py: unchanged-v1.52 fixture assertion already fails on the supplied v1.56/v1.57 lineage; captured in legacy-audit.txt and not treated as a v1.58 regression.
- Android Gradle/APK build: not run here; no Android SDK/device verification.
