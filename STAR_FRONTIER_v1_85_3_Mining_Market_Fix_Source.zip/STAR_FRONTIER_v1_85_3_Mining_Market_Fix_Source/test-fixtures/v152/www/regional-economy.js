'use strict';
// v1.51 compatibility placeholder.
// Regional-economy simulation is bundled into the versioned core scripts.
// This file remains as a stable asset path for existing Android/WebView projects.
