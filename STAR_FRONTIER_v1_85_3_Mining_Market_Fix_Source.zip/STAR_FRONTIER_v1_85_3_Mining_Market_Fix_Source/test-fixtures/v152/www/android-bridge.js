'use strict';
// v1.51 compatibility placeholder.
// AndroidNative is optional and injected by the Android host when available.
// v1.53 will replace this placeholder with the finalized Capacitor/WebView bridge.
