'use strict';
// ===== v1.52.0: player-route completion / progression blockers =====
const V152_BUILD='1.52.0';

// v1.41 promotion emitted a major event while holding a reference to the civic-career
// object. Late-version ensure chains may replace game.civicCareer while that event is
// processed, leaving the loop to update a stale object after the first promotion.
// Reacquire the live career object after every event so both player and AI-visible state
// advance through the same rank table reliably.
const v152CheckPromotionLegacy=v141CheckPromotion;
v141CheckPromotion=function(){
  ensureV141State();
  let c=game.civicCareer;
  let ranks=v141Ranks();
  let guard=0;
  while(c?.active&&c.rank<ranks.length-1&&c.merit>=ranks[c.rank+1].need&&c.approval>=38&&guard++<ranks.length+2){
    const nextRank=c.rank+1;
    c.rank=nextRank;
    c.authority=clamp((c.authority||0)+12,0,100);
    const track=c.track;
    const label=ranks[nextRank]?.name||`Rank ${nextRank}`;
    v138MajorEvent('公的キャリア昇進',`${label}へ昇進した。権限が拡大し、より重要な政策案件がプレイヤー決裁へ回る。`,'politics','major',`promotion:${track}:${nextRank}`);
    // Any major-event/MOE ensure may have normalized the state object. Continue from
    // the current live object rather than the pre-event reference.
    ensureV141State();
    c=game.civicCareer;
    ranks=v141Ranks();
    if(c.rank<nextRank)c.rank=nextRank;
  }
  return c?.rank||0;
};

// v1.44 correctly removed the old player-only mercenary contract generator. The public
// procurement market therefore remains the sole routine source of legal mercenary work.
// However, a new player company (low reputation) could lose every tender indefinitely to
// established NPC groups. Rebuild the tender score with executive competence and an
// inactivity/new-entrant factor. This does not create player-only jobs or reserve orders:
// the player organization still competes against the same NPC/actor bidders for AI-issued
// state/local/corporate procurement.
const v152AssignOrderLegacy=v144AssignOrder;
v144AssignOrder=function(o){
  if(o.status!=='open')return;
  const d=V144_JOB_TYPES[o.type],cand=[];
  for(const [id,g] of Object.entries(game.gm.irregular?.mercGroups||{})){
    if(g.status==='destroyed'||g.currentJob||v144ProviderBusy('merc',id))continue;
    const fatigue=Math.min(12,(g.missions||0)*.45);
    const score=g.power*6+(g.reputation||0)*.45+(g.discipline||50)*.22-Math.abs((g.risk||50)-o.risk)*.18+(g.home===o.issuerFaction?7:0)-fatigue+rng()*18;
    cand.push({kind:'merc',id,name:g.name,power:g.power,score,obj:g});
  }
  for(const a of Object.values(game.gm.v144.actors||{})){
    if(a.status!=='active'||a.career!=='mercenary'||a.contractId||v144ActorPower(a)<1.5)continue;
    const score=v144ActorPower(a)*7+(a.reputation||0)*.4+(a.skill||50)*.25-Math.abs((a.risk||50)-o.risk)*.2+(a.citizenship===o.issuerFaction?5:0)+rng()*16;
    cand.push({kind:'actor',id:a.id,name:a.name,power:v144ActorPower(a),score,obj:a});
  }
  const po=game.freeCaptains?.organization;
  if(po?.created&&po.type==='merc'&&po.automation&&!po.currentOperation&&!po.v144OrderId){
    const power=v124PlayerOrgPower();
    const commander=po.executives?.commander||{};
    const operations=po.executives?.operations||{};
    const exec=((commander.competence||50)+(operations.operations||operations.competence||50))/2;
    const appetite=((commander.risk||50)+(operations.risk||50))/2;
    const since=Number.isFinite(po.lastAction)?po.lastAction:(po.foundedDay||game.day);
    const idle=Math.max(0,game.day-since);
    const losses=Number(po.v152TenderLosses)||0;
    const newcomer=Math.min(56,idle*5.5+losses*9+Math.max(0,2-(po.missions||0))*5);
    const score=power*6+(po.reputation||0)*.5+exec*.18-Math.abs(appetite-o.risk)*.12+newcomer+rng()*14;
    cand.push({kind:'player_org',id:'player',name:po.name,power,score,obj:po});
  }
  cand.sort((a,b)=>b.score-a.score);
  const p=cand[0];
  if(!p||p.score<25)return;
  if(po?.created&&po.type==='merc'&&po.automation&&!po.currentOperation&&!po.v144OrderId&&p.kind!=='player_org')po.v152TenderLosses=(Number(po.v152TenderLosses)||0)+1;
  o.status='active';o.contractorType=p.kind;o.contractorId=p.id;o.contractorName=p.name;o.start=game.day;o.end=game.day+d.duration;
  if(p.kind==='merc')p.obj.v144OrderId=o.id;
  else if(p.kind==='actor')p.obj.contractId=o.id;
  else{
    p.obj.v144OrderId=o.id;p.obj.lastAction=game.day;p.obj.v152TenderLosses=0;
    // New entrants win early contracts by bidding aggressively rather than receiving a player-only job.
    if((p.obj.missions||0)<2){const factor=clamp(.84+(p.obj.reputation||0)*.0015,.84,.94);o.budget=Math.max(900,Math.round(o.budget*factor));o.playerBidFactor=factor;}
    p.obj.history?.unshift({day:game.day,type:'tender',name:`${v144IssuerLabel(o)}「${d.name}」公開調達を落札`,result:'awarded',pay:o.budget});
  }
};

// Keep the player-organization activity clock in sync when a market contract closes.
// v1.44 already handles money/reputation/mission effects; this wrapper only records the
// end of the procurement cycle for route progression and future tender scoring.
const v152ResolveOrderBase=v144ResolveOrder;
v144ResolveOrder=function(o){
  const wasPlayer=o?.status==='active'&&o.contractorType==='player_org';
  const result=v152ResolveOrderBase(o);
  if(wasPlayer&&o.status!=='active'&&game.freeCaptains?.organization?.created){
    game.freeCaptains.organization.lastAction=game.day;
  }
  return result;
};


// v1.13.1 corporate assignments advance one in-game day before resolving. During that
// gmAdvance(), ensureV19State may normalize corporateCareer into a new object. The legacy
// resolver then credits XP/allowance to its pre-advance reference, so the live employee
// can complete work forever without gaining promotion experience. Repair only when the
// live record did not receive the legacy gain.
const v152CompleteCorporateAssignmentBase=completeCorporateAssignment;
completeCorporateAssignment=function(){
  const a=game.corporateAssignment;
  const employee=!!(a&&game.corporateCareer?.corp===a.corp);
  const cid=a?.corp||null,id=a?.id||null;
  const beforeXp=Number(game.corporateCareer?.xp)||0;
  const beforeAllowance=Number(game.corporateCareer?.allowances)||0;
  const result=v152CompleteCorporateAssignmentBase();
  if(employee&&cid&&id&&game.corporateCareer?.corp===cid){
    const h=(game.corporateAssignmentHistory||[]).find(x=>x?.id===id);
    const cc=game.corporateCareer;
    if(h?.status==='completed'&&(Number(cc.xp)||0)<=beforeXp){
      // Match the historical 10–16 XP range without another random draw, so save/reload
      // does not change the award for a completed assignment.
      let hash=0;for(const ch of id)hash=(hash*31+ch.charCodeAt(0))>>>0;
      const gain=10+(hash%7);
      cc.xp=beforeXp+gain;
      cc.allowances=beforeAllowance+(Number(h.payout)||0);
      cc.workHistory=Array.isArray(cc.workHistory)?cc.workHistory:[];
      cc.workHistory.unshift({day:h.ended||game.day,kind:'assignment',corp:cid,xp:gain,payout:Number(h.payout)||0,result:'completed'});
      cc.workHistory=cc.workHistory.slice(0,40);
    }
  }
  return result;
};

function v152PlayerRouteStatus(){
  ensureV144State();ensureV145State();ensureV149State();
  const civic=game.civicCareer||{};
  const op=game.freeCaptains?.organization||{};
  const corp=game.playerCorporation||{};
  const career=game.career||{};
  const ownStations=typeof playerStations==='function'?playerStations():[];
  return {
    day:game.day,
    merchantMiner:{available:true,cargo:Object.values(game.cargo||{}).reduce((n,v)=>n+(Number(v)||0),0),credits:game.credits},
    enterprise:{active:!!corp.created,treasury:corp.treasury||0},
    irregular:{active:!!op.created,type:op.type||null,missions:op.missions||0,current:op.currentOperation?.name||null,marketOrder:op.v144OrderId||null},
    military:{active:!!career.faction,branch:career.serviceBranch||'regular',rank:career.rank||0,subordinates:(career.subordinates||[]).length},
    publicCareer:{active:!!civic.active,track:civic.track||null,rank:civic.rank||0,partyId:civic.partyId||null},
    sovereignty:{faction:!!game.playerFaction?.created,stations:ownStations.length,directFleets:(game.directCommand?.fleets||[]).filter(f=>!f.destroyed).length}
  };
}


const v152GmAdvanceBase=gmAdvance;
gmAdvance=function(){const out=v152GmAdvanceBase();if(game)game.version=V152_BUILD;return out};

const v152LoadBase=load;
load=function(){const out=v152LoadBase();if(game)game.version=V152_BUILD;return out};

// v1.51's saver intentionally stamps its own integration build. v1.52 is a later layer,
// so serialize the current build while retaining v1.51 compaction and adaptive backups.
const v152SaveBase=save;
save=function(){
  if(typeof v151CompactState==='function')v151CompactState(true);
  if(game)game.version=V152_BUILD;
  let raw;try{raw=JSON.stringify(game)}catch(e){if(game?.v151)game.v151.lastSaveError=`serialize:${e?.message||e}`;return false}
  try{
    localStorage.setItem(SAVE_KEY,raw);
    if(game?.v151){game.v151.lastSaveError=null;game.v151.lastSaveChars=raw.length;game.v151.lastSaveDay=game.day}
  }catch(e){
    if(game?.v151)game.v151.lastSaveError=`primary:${e?.name||'Error'}:${e?.message||e}`;
    try{if(typeof toast==='function')toast('セーブ領域が不足しています。JSON書き出しを推奨します')}catch(_){}
    return false;
  }
  if(typeof sfRotateBackup==='function')sfRotateBackup(raw,false);
  return true;
};

const v152RenderBase=render;
render=function(){
  const out=v152RenderBase();
  game.version=V152_BUILD;
  if(typeof document!=='undefined'){
    const badge=document.querySelector('header .title .badge');if(badge)badge.textContent='v1.52.0';
    const sub=document.querySelector('header .sub');if(sub)sub.textContent='プレイヤールート完成・進行不能修正・公開傭兵調達・キャリア導線';
    document.title='STAR FRONTIER v1.52.0 — Player Route Completion';
  }
  return out;
};
const v152InitBase=initV10;
initV10=function(){const out=v152InitBase();game.version=V152_BUILD;return out};

if(typeof window!=='undefined')window.StarFrontierPlayerRoutes={
  status:v152PlayerRouteStatus,
  checkPromotion:()=>v141CheckPromotion(),
  build:V152_BUILD
};
