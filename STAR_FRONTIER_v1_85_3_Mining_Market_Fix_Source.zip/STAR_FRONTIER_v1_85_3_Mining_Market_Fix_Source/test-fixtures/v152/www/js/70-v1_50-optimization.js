
'use strict';
// ===== v1.50.0: feature freeze, split-source startup, lazy heavy rendering =====
const V150_BUILD='1.50.0';
function v150TabVisible(id){const el=document.getElementById(id);return !!el&&!el.classList.contains('hidden')}
function v150GalaxySubVisible(id){return v150TabVisible('galaxy')&&!!document.getElementById('gal-'+id)&&!document.getElementById('gal-'+id).classList.contains('hidden')}
// Avoid rebuilding the 180-hull shipyard and large galaxy panels while those screens are hidden.
const v150RenderGalaxyBase=renderGalaxy;renderGalaxy=function(){if(!v150TabVisible('galaxy'))return;v150RenderGalaxyBase()};
const v150RenderMineBase=renderMine;renderMine=function(){if(!v150TabVisible('mine'))return;v150RenderMineBase()};
const v150RenderMarketBase=renderMarket;renderMarket=function(){if(!v150TabVisible('market'))return;v150RenderMarketBase()};
const v150RenderShipBase=renderShip;renderShip=function(){if(!v150TabVisible('ship'))return;v150RenderShipBase()};
const v150RenderMilitaryBase=renderMilitary;renderMilitary=function(){if(!v150GalaxySubVisible('military'))return;v150RenderMilitaryBase()};
const v150RenderStationsBase=renderStations;renderStations=function(){if(!v150GalaxySubVisible('stations'))return;v150RenderStationsBase()};
const v150RenderCommandBase=renderCommand;renderCommand=function(){if(!v150GalaxySubVisible('command'))return;v150RenderCommandBase()};
const v150RenderV10Base=renderV10;renderV10=function(){if(!v150GalaxySubVisible('command'))return;v150RenderV10Base()};
const v150RenderFleetMissionsBase=renderFleetMissions;renderFleetMissions=function(){if(!v150GalaxySubVisible('command'))return;v150RenderFleetMissionsBase()};
// Galaxy sub-tab changes used to rely on every hidden panel being pre-rendered. Re-render only after the requested sub-tab becomes visible.
const v150ShowGalaxyBase=showGalaxy;showGalaxy=function(id){v150ShowGalaxyBase(id);render()};
// Expensive late-version panels: keep their current HTML while Galaxy is not visible.
if(typeof renderV142Anomalies==='function'){const b=renderV142Anomalies;renderV142Anomalies=function(){if(!v150TabVisible('galaxy'))return;b()}}
if(typeof renderV143Media==='function'){const b=renderV143Media;renderV143Media=function(){if(!v150TabVisible('galaxy'))return;b()}}
if(typeof renderV149Parliament==='function'){const b=renderV149Parliament;renderV149Parliament=function(){if(!v150TabVisible('galaxy')){const e=document.getElementById('gal-parliament');return e?e.innerHTML:''}return b()}}
if(typeof renderV148International==='function'){const b=renderV148International;renderV148International=function(){if(!v150TabVisible('galaxy')){const e=document.getElementById('gal-international');return e?e.innerHTML:''}return b()}}
if(typeof renderV147Religion==='function'){const b=renderV147Religion;renderV147Religion=function(){if(!v150TabVisible('galaxy')){const e=document.getElementById('gal-religion');return e?e.innerHTML:''}return b()}}
// Rendering diagnostics are intentionally tiny and off by default. Useful for Android profiling without a debugger.
game && (game.v150=game.v150||{renderCount:0,lastRenderMs:0,maxRenderMs:0});
const v150RenderBase=render;render=function(){const t=(typeof performance!=='undefined'&&performance.now)?performance.now():Date.now();v150RenderBase();const e=(typeof performance!=='undefined'&&performance.now)?performance.now():Date.now();if(game){game.v150=game.v150||{};game.v150.renderCount=(game.v150.renderCount||0)+1;game.v150.lastRenderMs=Math.round((e-t)*10)/10;game.v150.maxRenderMs=Math.max(game.v150.maxRenderMs||0,game.v150.lastRenderMs)}game.version=V150_BUILD;const badge=document.querySelector('header .title .badge');if(badge)badge.textContent='v1.50.0';const sub=document.querySelector('header .sub');if(sub)sub.textContent='機能凍結・分割ソース・遅延描画・完成版最適化';document.title='STAR FRONTIER v1.50.0 — Feature Freeze / Optimization'};

