'use strict';
(function(){
  function start(){
    try{
      if(typeof load!=='function') throw new Error('core load() is unavailable');
      load();
      document.documentElement.dataset.sfReady='1';
    }catch(err){
      console.error('[STAR FRONTIER v1.50 bootstrap]',err);
      const t=document.getElementById('toast');
      if(t){t.textContent='起動に失敗しました。セーブを消さずに再起動してください。';t.classList.add('show')}
    }
  }
  start();
})();
