'use strict';
// ===== v1.81.4: performance fix with RNG-seed-preserving ensure cache =====
const V1814_BUILD='1.81.4';

// This cache is deliberately narrower than v1.51's generic ensure memoization.
// It only covers the three legacy hot spots observed in v1.81.3 and only while
// one logical render/day/init pass is active. Direct player actions outside such
// a pass keep the historical behavior unchanged.
let v1814PerfEpoch=0;
let v1814PerfDepth=0;
const v1814PerfStats={ensure:{}};
function v1814WithPerfEpoch(fn){
  const outer=v1814PerfDepth===0;
  if(outer)v1814PerfEpoch++;
  v1814PerfDepth++;
  try{return fn()}
  finally{v1814PerfDepth--}
}
function v1814InsideV151Epoch(){
  try{return typeof v151EnsureDepth!=='undefined'&&v151EnsureDepth>0}catch(_){return false}
}
function v1814Arr(x){return Array.isArray(x)}
function v1814Finite(x){return Number.isFinite(x)}

// --- RNG-sensitive dirty checks ------------------------------------------------
// A cached ensure is reused only when the historical implementation cannot
// consume RNG and the deterministic state it is expected to repair is present.
function v1814V15Ready(){
  const gm=game?.gm;
  return !!gm&&v1814Finite(gm.nextRogueCheckDay)&&!!gm.sim&&!!gm.factions;
}
function v1814V111Ready(){
  const gm=game?.gm;if(!gm)return false;
  for(const fid of (typeof V12_FACTION_IDS!=='undefined'?V12_FACTION_IDS:[])){
    if(!v1814Arr(gm.commanders?.[fid])||gm.commanders[fid].length<3)return false;
  }
  for(const x of gm.frontierPmcs||[])if(!x?.commander)return false;
  return true;
}
function v1814V112Ready(){
  const gm=game?.gm;if(!gm||!v1814V15Ready()||!v1814V111Ready())return false;
  const em=gm.energyMarket;if(!em?.firms)return false;
  for(const cid of v112EnergyCorpIds()){
    const s=em.firms[cid];if(!s?.shares)return false;
    for(const fid of v112MarketFactions())if(!v1814Finite(s.shares[fid]))return false;
  }
  const eq=gm.equipmentMarket;if(!eq?.makers)return false;
  for(const cid of v112EquipmentCorpIds()){
    const st=eq.makers[cid],mods=V17_CORPORATIONS[cid]?.modules||[];
    if(!st||!v1814Finite(st.nextProductionDay)||!st.stock)return false;
    for(const mid of mods)if(!v1814Finite(st.stock[mid]))return false;
  }
  for(const [id,m] of Object.entries(SHIP_MODULES||{}))if(m?.corporate&&!v1814Finite(game.moduleInventory?.[id]))return false;
  return true;
}
function v1814V114Ready(){
  if(!v1814V112Ready())return false;
  const gm=game?.gm;if(!gm?.ministries||!gm?.cabinets||!gm?.localGovernments)return false;
  for(const fid of V12_FACTION_IDS){
    if(!gm.ministries[fid]||!gm.cabinets[fid])return false;
    for(const k of V114_MINISTRY_KEYS)if(!gm.ministries[fid][k])return false;
  }
  for(const [sid,s] of Object.entries(SYSTEMS))if(V12_FACTION_IDS.includes(s.faction)&&!gm.localGovernments[sid])return false;
  return !!gm.volgarIndustrialUnion&&!!gm.corporations?.volgar_union;
}
function v1814V118Ready(){
  const gm=game?.gm;if(!gm?.foodIndustry?.manufacturers)return false;
  const c=game.playerCorporation;if(!c?.created)return true;
  if(!c.group||!v1814Arr(c.group.subsidiaries))return false;
  for(const s of c.group.subsidiaries){
    if(!s?.manager||!v1814Arr(s.rivals)||!s.rivals.length||!v1814Finite(s.marketShare))return false;
  }
  return true;
}
function v1814V119Ready(){
  const c=game.playerCorporation;if(!c?.created)return true;
  if(!c.management?.candidatePool)return false;
  for(const role of Object.keys(V119_EXEC_ROLES))if(!v1814Arr(c.management.candidatePool[role])||!c.management.candidatePool[role].length)return false;
  return true;
}
function v1814V124Ready(){
  const gm=game?.gm,ir=gm?.irregular;if(!ir?.mercGroups||!gm?.securityForces)return false;
  for(const id of Object.keys(V124_NPC_MERCS))if(!ir.mercGroups[id])return false;
  for(const fid of V12_FACTION_IDS){const sf=gm.securityForces[fid];if(!sf||!v1814Arr(sf.patrols)||!sf.patrols.length)return false}
  return true;
}
function v1814V127MigrationPending(){
  const eco=game?.gm?.enterpriseEconomy;if(!eco?.enterprises||!eco?.supportFirms)return true;
  let keys;try{keys=v127EnterpriseKeys()}catch(_){return true}
  for(const key of keys){
    const ref=v127EnterpriseRef(key);if(!ref)continue;
    const e=eco.enterprises[key];if(!e)return true;
    if(!v1814Arr(e.facilities)||!v1814Arr(e.equipment)||!v1814Arr(e.capitalProjects)||!v1814Arr(e.loans)||!v1814Arr(e.products)||!v1814Arr(e.history))return true;
    if(!e.facilities.length&&!e.equipment.length&&!e.capitalProjects.length){
      const oldBusiness=(ref.kind==='corp'||ref.kind==='food'||((ref.kind==='player_parent'&&game.playerCorporation.foundedDay<eco.introducedDay)||(ref.kind==='player_sub'&&(ref.sub.created||0)<eco.introducedDay)));
      if(oldBusiness)return true;
    }
  }
  return false;
}
function v1814V127StockpilePending(){
  const sp=game?.gm?.militaryStockpiles;if(!sp)return true;
  for(const fid of V12_FACTION_IDS){const row=sp[fid];if(!row?.items)return true;for(const k of Object.keys(V127_STOCKPILE_META))if(!v1814Finite(row.items[k]))return true}
  return false;
}
function v1814V127Ready(){
  const gm=game?.gm;
  if(!gm||!v1814V114Ready()||!v1814V118Ready()||!v1814V119Ready()||!v1814V124Ready())return false;
  if(!gm.enterpriseEconomy||!gm.laborMarkets||!gm.militaryManpower)return false;
  return !v1814V127MigrationPending()&&!v1814V127StockpilePending();
}

// v1.24 has one historical quirk: for every existing NPC mercenary group it
// evaluates v124NewMercState() before spreading the saved object over it. That
// consumes exactly two game RNG draws even though the generated values are then
// discarded. When ensureV127 is cached outside the old v1.51 epoch, reproduce
// those draws so the global game RNG seed advances exactly as in v1.81.3.
function v1814ConsumeV124DiscardedRng(){
  const ir=game?.gm?.irregular;if(!ir?.mercGroups||typeof rng!=='function')return;
  for(const id of Object.keys(V124_NPC_MERCS))if(ir.mercGroups[id]){rng();rng()}
}

function v1814MemoEnsure(name,base,ready,onReuse){
  let lastEpoch=-1,lastResult;
  const stat=v1814PerfStats.ensure[name]=v1814PerfStats.ensure[name]||{hits:0,misses:0};
  return function(...args){
    // Preserve the exact behavior already provided by v1.51 inside its original
    // scope; v1.81.4 only fills the late-wrapper gap that v1.51 could not see.
    if(v1814PerfDepth<=0||v1814InsideV151Epoch())return base.apply(this,args);
    if(lastEpoch===v1814PerfEpoch&&ready()){
      stat.hits++;
      if(onReuse)onReuse();
      return lastResult;
    }
    stat.misses++;
    lastResult=base.apply(this,args);lastEpoch=v1814PerfEpoch;return lastResult;
  }
}

if(typeof ensureV112State==='function')ensureV112State=v1814MemoEnsure('ensureV112State',ensureV112State,v1814V112Ready,null);
if(typeof ensureV114State==='function')ensureV114State=v1814MemoEnsure('ensureV114State',ensureV114State,v1814V114Ready,null);
if(typeof ensureV127State==='function')ensureV127State=v1814MemoEnsure('ensureV127State',ensureV127State,v1814V127Ready,v1814ConsumeV124DiscardedRng);

// --- Hidden-screen lazy rendering ---------------------------------------------
function v1814Visible(id){const el=document.getElementById(id);return !!el&&!el.classList.contains('hidden')}
function v1814GalaxyVisible(id){return v1814Visible('galaxy')&&v1814Visible('gal-'+id)}
function v1814Lazy(name,fn,pred,once=true){
  let lastEpoch=-1,lastResult;
  return function(...args){
    if(!pred())return lastResult;
    if(once&&v1814PerfDepth>0&&lastEpoch===v1814PerfEpoch)return lastResult;
    lastResult=fn.apply(this,args);if(v1814PerfDepth>0)lastEpoch=v1814PerfEpoch;return lastResult;
  }
}
if(typeof renderGalaxy==='function')renderGalaxy=v1814Lazy('renderGalaxy',renderGalaxy,()=>v1814Visible('galaxy'));
if(typeof renderMine==='function')renderMine=v1814Lazy('renderMine',renderMine,()=>v1814Visible('mine'));
if(typeof renderMarket==='function')renderMarket=v1814Lazy('renderMarket',renderMarket,()=>v1814Visible('market'));
if(typeof renderShip==='function')renderShip=v1814Lazy('renderShip',renderShip,()=>v1814Visible('ship'));
if(typeof renderRoutes==='function')renderRoutes=v1814Lazy('renderRoutes',renderRoutes,()=>v1814Visible('galaxy'));
if(typeof renderMilitary==='function')renderMilitary=v1814Lazy('renderMilitary',renderMilitary,()=>v1814GalaxyVisible('military'));
if(typeof renderStations==='function')renderStations=v1814Lazy('renderStations',renderStations,()=>v1814GalaxyVisible('stations'));
if(typeof renderCommand==='function')renderCommand=v1814Lazy('renderCommand',renderCommand,()=>v1814GalaxyVisible('command'));
if(typeof renderV10==='function')renderV10=v1814Lazy('renderV10',renderV10,()=>v1814GalaxyVisible('command'));
if(typeof renderFleetMissions==='function')renderFleetMissions=v1814Lazy('renderFleetMissions',renderFleetMissions,()=>v1814GalaxyVisible('command'));
if(typeof renderGM==='function')renderGM=v1814Lazy('renderGM',renderGM,()=>v1814GalaxyVisible('gm'));
if(typeof renderMapDetail==='function')renderMapDetail=v1814Lazy('renderMapDetail',renderMapDetail,()=>v1814GalaxyVisible('map'));
if(typeof renderV115FinancePanel==='function')renderV115FinancePanel=v1814Lazy('renderV115FinancePanel',renderV115FinancePanel,()=>v1814GalaxyVisible('finance'));

// v1.55 used to reorganize/query the whole Galaxy DOM on every home render.
// Keep home alerts/version current, but defer Galaxy layout work until Galaxy is visible.
if(typeof v155PostRender==='function'){
  v155PostRender=function(){
    v155SetVersion();v155RenderHomeAlerts();
    if(v1814Visible('galaxy')){
      v155EnsureGalaxyLayout();
      if(v1814GalaxyVisible('gm'))v155EnsureGMDashboard();
      if(v1814GalaxyVisible('international'))v155CompactInternational();
      if(v1814GalaxyVisible('media'))v155ApplyMediaTab();
    }
  };
  if(typeof StarFrontierUI!=='undefined'&&StarFrontierUI)StarFrontierUI.refresh=v155PostRender;
}

// Final outer pass: all v1.52-v1.81 wrappers are now inside the same performance
// epoch, while direct actions remain uncached. This is separate from v1.51's
// legacy memo epoch so its historical RNG behavior is not changed.
if(typeof initV10==='function'){
  const v1814InitBase=initV10;initV10=function(){const out=v1814WithPerfEpoch(()=>v1814InitBase());if(game)game.version=V1814_BUILD;return out};
}
if(typeof gmAdvance==='function'){
  const v1814AdvanceBase=gmAdvance;gmAdvance=function(){const out=v1814WithPerfEpoch(()=>v1814AdvanceBase());if(game)game.version=V1814_BUILD;return out};
}
if(typeof save==='function'){
  const v1814SaveBase=save;save=function(){if(game)game.version=V1814_BUILD;return v1814SaveBase.apply(this,arguments)};
}
if(typeof load==='function'){
  const v1814LoadBase=load;load=function(){const out=v1814LoadBase.apply(this,arguments);if(game)game.version=V1814_BUILD;return out};
}
if(typeof render==='function'){
  const v1814RenderBase=render;render=function(){
    const out=v1814WithPerfEpoch(()=>v1814RenderBase());
    if(game)game.version=V1814_BUILD;
    const badge=document.querySelector('header .title .badge')||document.querySelector('.version-badge');if(badge)badge.textContent='v1.81.4';
    const sub=document.querySelector('header .sub');if(sub)sub.textContent='Performance Fix / RNG-seed safe cache / Lazy hidden UI';
    document.title='STAR FRONTIER v1.81.4 — Performance Fix';
    return out;
  };
}

if(typeof window!=='undefined')window.StarFrontierPerformance={
  build:V1814_BUILD,
  epoch:()=>v1814PerfEpoch,
  checks:{v112:v1814V112Ready,v114:v1814V114Ready,v127:v1814V127Ready},
  stats:()=>JSON.parse(JSON.stringify(v1814PerfStats))
};
