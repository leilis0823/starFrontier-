'use strict';
// ===== v1.55.0: Adaptive UI / Information Architecture =====
// UI-only reorganization. Simulation rules, IDs and save structures are left intact.

const V155_BUILD='1.55.0';
const V155_TAB_CATEGORY=Object.freeze({
  map:'world',factions:'world',species:'world',classes:'world',
  gm:'politics',parliament:'politics',international:'politics',citizen:'politics',
  corporations:'economy',finance:'economy',stations:'economy',
  military:'security',command:'security',anomalies:'security',
  media:'society',religion:'society'
});
const V155_CATEGORIES=Object.freeze({
  world:{icon:'🌌',name:'世界',desc:'星系・国家・種族・艦級',first:'map'},
  politics:{icon:'🏛',name:'政治',desc:'情勢・議会・国際機構・国民',first:'gm'},
  economy:{icon:'💰',name:'経済',desc:'企業・金融・拠点',first:'corporations'},
  security:{icon:'⚔',name:'安全保障',desc:'軍務・艦隊・異常存在',first:'military'},
  society:{icon:'📰',name:'社会・情報',desc:'メディア・信仰',first:'media'}
});
const V155_REQUIRED_TABS=Object.keys(V155_TAB_CATEGORY);
const v155UI={category:'world',mediaTab:'focus',intelMode:'public',mapFullscreen:false};

function v155SetVersion(){
  if(typeof game!=='undefined'&&game)game.version=V155_BUILD;
  if(typeof document!=='undefined'){
    const badge=document.querySelector('header .title .badge');if(badge)badge.textContent='v1.55.0';
    const sub=document.querySelector('header .sub');if(sub)sub.textContent='Adaptive UI・情報階層再編・公開情報/GM解析分離';
    document.title='STAR FRONTIER v1.55.0 — Adaptive UI';
  }
}
function v155TabsReady(){return V155_REQUIRED_TABS.every(id=>document.getElementById(`seg-${id}`)&&document.getElementById(`gal-${id}`))}
function v155CurrentGalaxyTab(){return document.querySelector('#galaxy .gal-sub:not(.hidden)')?.id?.replace(/^gal-/,'')||'map'}
function v155CategoryFor(id){return V155_TAB_CATEGORY[id]||'world'}
function v155CategoryTarget(cat){const def=V155_CATEGORIES[cat]||V155_CATEGORIES.world;if(document.getElementById(`seg-${def.first}`))return def.first;return Object.keys(V155_TAB_CATEGORY).find(id=>V155_TAB_CATEGORY[id]===cat&&document.getElementById(`seg-${id}`))||'map'}

function v155BuildCategoryNav(){
  const nav=document.createElement('div');nav.id='v155GalaxyCategories';nav.className='sf-galaxy-categories';nav.setAttribute('aria-label','銀河情報カテゴリ');
  nav.innerHTML=Object.entries(V155_CATEGORIES).map(([id,c])=>`<button type="button" data-category="${id}" onclick="StarFrontierUI.setCategory('${id}')"><span>${c.icon}</span>${escapeHtml(c.name)}</button>`).join('');
  return nav;
}
function v155EnsureGalaxyLayout(){
  if(typeof document==='undefined'||!v155TabsReady())return false;
  const panel=document.querySelector('#galaxy > .panel'),seg=document.querySelector('#galaxy .segment');if(!panel||!seg)return false;
  panel.classList.add('sf-galaxy-panel');seg.classList.add('sf-galaxy-subtabs');
  let shell=document.getElementById('v155GalaxyShell'),main=document.getElementById('v155GalaxyMain');
  if(!shell){
    shell=document.createElement('div');shell.id='v155GalaxyShell';shell.className='sf-galaxy-shell';
    main=document.createElement('div');main.id='v155GalaxyMain';main.className='sf-galaxy-main';
    const nav=v155BuildCategoryNav(),context=document.createElement('div');context.id='v155GalaxyContext';context.className='sf-galaxy-context';
    panel.insertBefore(shell,seg);shell.append(nav,main);main.append(context,seg);
    [...panel.querySelectorAll('.gal-sub')].forEach(el=>main.appendChild(el));
  }else{
    main=main||shell.querySelector('.sf-galaxy-main');
    [...panel.querySelectorAll('.gal-sub')].forEach(el=>{if(main&&!main.contains(el))main.appendChild(el)});
    if(main&&!main.contains(seg))main.insertBefore(seg,main.children[1]||null);
  }
  const current=v155CurrentGalaxyTab();v155UI.category=v155CategoryFor(current);v155ApplyCategory();v155EnsureMapToolbar();return true;
}
function v155ApplyCategory(){
  const seg=document.querySelector('#galaxy .sf-galaxy-subtabs');if(!seg)return;
  seg.querySelectorAll('button[id^="seg-"]').forEach(b=>{const id=b.id.replace(/^seg-/,'');b.classList.toggle('sf-cat-hidden',v155CategoryFor(id)!==v155UI.category)});
  document.querySelectorAll('#v155GalaxyCategories button').forEach(b=>b.classList.toggle('active',b.dataset.category===v155UI.category));
  const ctx=document.getElementById('v155GalaxyContext'),c=V155_CATEGORIES[v155UI.category];if(ctx&&c)ctx.textContent=`${c.icon} ${c.name}：${c.desc}`;
}
function v155SetCategory(cat){
  if(!V155_CATEGORIES[cat])return;v155UI.category=cat;v155EnsureGalaxyLayout();v155ApplyCategory();
  const current=v155CurrentGalaxyTab();if(v155CategoryFor(current)!==cat){const target=v155CategoryTarget(cat);if(target)v155ShowGalaxyBase(target)}
  v155ApplyCategory();
}
function v155OpenGalaxy(id){showTab('galaxy');showGalaxy(id)}

function v155EnsureMapToolbar(){
  const root=document.getElementById('gal-map');if(!root||root.querySelector('.v155-map-toolbar'))return;
  const bar=document.createElement('div');bar.className='v155-map-toolbar';bar.innerHTML='<button type="button" class="secondary" onclick="StarFrontierUI.toggleMapFullscreen()">⛶ 星系図を全画面表示</button>';root.insertBefore(bar,root.firstChild);
}
function v155ToggleMapFullscreen(force){
  const root=document.getElementById('gal-map');if(!root)return false;v155UI.mapFullscreen=typeof force==='boolean'?force:!root.classList.contains('sf-map-fullscreen');root.classList.toggle('sf-map-fullscreen',v155UI.mapFullscreen);
  const b=root.querySelector('.v155-map-toolbar button');if(b)b.textContent=v155UI.mapFullscreen?'✕ 全画面を閉じる':'⛶ 星系図を全画面表示';return v155UI.mapFullscreen;
}

function v155RenderHomeAlerts(){
  const el=document.getElementById('v155HomeAlerts');if(!el||typeof game==='undefined'||!game)return;const rows=[];
  if(game.war?.active){const a=FACTIONS[game.war.a]?.short||game.war.a,b=FACTIONS[game.war.b]?.short||game.war.b;rows.push({icon:'⚔',title:`国家間戦争：${a} vs ${b}`,detail:`戦況 ${Math.round(game.war.balance||50)} / 100`,tab:'military'})}
  const inv=(game.invasions||[]).find(x=>!x.resolved);if(inv){const st=typeof stationById==='function'?stationById(inv.station):null;rows.push({icon:'🚨',title:'自勢力への侵攻警報',detail:`目標 ${st?.name||'拠点'} / ETA Day ${inv.eta}`,tab:'command'})}
  if(game.bioEncounter){const b=BIOSHIPS[game.bioEncounter.type];rows.push({icon:'🧬',title:'生体艦との遭遇',detail:b?.name||'未確認生体艦',home:true})}
  const forces=Object.values(game.gm?.v154?.unmarkedForces||{}).filter(x=>x.status==='active'&&x.system===game.system);if(forces.length)rows.push({icon:'◩',title:'現在宙域で所属不明部隊を確認',detail:`確認戦力 ${forces.reduce((n,x)=>n+(Number(x.power)||0),0).toFixed(1)}`,tab:'gm'});
  const q=game.civicCareer?.currentCase;if(q)rows.push({icon:'🏛',title:'公的決裁案件が上申中',detail:q.name||'重要政策案件',tab:'citizen'});
  if(!rows.length){el.classList.add('hidden');el.innerHTML='';return}
  el.classList.remove('hidden');el.innerHTML=`<div class="section-title"><h2>⚠ 重要警報・現在の案件</h2><span class="pill">PRIORITY</span></div><div class="sf-alert-list">${rows.slice(0,4).map(r=>`<div class="sf-alert-item"><div class="sf-alert-icon">${r.icon}</div><div class="sf-alert-copy"><b>${escapeHtml(r.title)}</b><small>${escapeHtml(r.detail||'')}</small></div>${r.tab?`<button class="secondary" onclick="StarFrontierUI.openGalaxy('${r.tab}')">確認</button>`:''}</div>`).join('')}</div>`;
}

const V155_GM_SECTIONS=Object.freeze([
  {id:'overview',icon:'🌐',name:'概況・国家AI'},
  {id:'military',icon:'⚔',name:'軍事・戦争'},
  {id:'politics',icon:'🏛',name:'政治・政府'},
  {id:'regional',icon:'⚑',name:'地方・独立運動'},
  {id:'economy',icon:'💳',name:'経済・財政'},
  {id:'covert',icon:'🕶',name:'治安・諜報・秘密工作'}
]);
function v155ClassifyGMNode(el){
  const id=(el.id||'').toLowerCase(),txt=(el.querySelector?.('h2,h3,b')?.textContent||el.textContent||'').slice(0,160).toLowerCase();
  const s=`${id} ${txt}`;
  if(/v154|秘密|諜報|防諜|工作|暗殺|所属不明|intel|covert|espion/.test(s))return'covert';
  if(/v136|財政|予算|経済|金融|債務|銀行|企業政治|economic|fiscal|budget|bank/.test(s))return'economy';
  if(/v137|v138|v139|地方|地域|自治|独立|内戦|分離|secession|regional|local/.test(s))return'regional';
  if(/v133|v145|軍事|戦争|国境|艦隊|安全保障|moe|war|military|security|border/.test(s))return'military';
  if(/v134|v135|v146|政府|政治|政体|省庁|崩壊|government|politic|regime|ministry|collapse/.test(s))return'politics';
  return'overview';
}
function v155EnsureGMDashboard(){
  const root=document.getElementById('gal-gm');if(!root)return;
  let toolbar=document.getElementById('v155GmToolbar');
  if(!toolbar){
    toolbar=document.createElement('div');toolbar.id='v155GmToolbar';toolbar.className='v155-gm-toolbar';toolbar.innerHTML='<div><h3>銀河情勢ダッシュボード</h3><div class="smallnote">概要から入り、必要な領域だけ展開します。</div></div><div class="v155-intel-toggle"><button type="button" data-mode="public" onclick="StarFrontierUI.setIntelMode(\'public\')">公開情報</button><button type="button" data-mode="gm" onclick="StarFrontierUI.setIntelMode(\'gm\')">GM解析</button></div>';
    const summary=document.createElement('div');summary.id='v155GmSummary';summary.className='v155-gm-summary';
    const alerts=document.createElement('div');alerts.id='v155GmAlerts';alerts.className='v155-gm-alerts';
    const sections=document.createElement('div');sections.id='v155GmSections';sections.className='v155-gm-sections';
    for(const [i,c] of V155_GM_SECTIONS.entries()){
      const d=document.createElement('details');d.id=`v155GmSection-${c.id}`;d.className='v155-gm-section';if(i===0)d.open=true;
      d.innerHTML=`<summary><span>${c.icon} ${escapeHtml(c.name)}</span><span class="v155-gm-count" data-count>0項目</span></summary><div class="v155-gm-body" data-gm-body="${c.id}"></div>`;sections.appendChild(d);
    }
    root.insertBefore(toolbar,root.firstChild);toolbar.after(summary,alerts,sections);
  }
  const owned=new Set(['v155GmToolbar','v155GmSummary','v155GmAlerts','v155GmSections']);
  [...root.children].forEach(el=>{if(owned.has(el.id))return;const cat=v155ClassifyGMNode(el),body=root.querySelector(`[data-gm-body="${cat}"]`)||root.querySelector('[data-gm-body="overview"]');body?.appendChild(el)});
  v155UpdateGMDashboard();v155ApplyIntelMode();
}
function v155UpdateGMDashboard(){
  const el=document.getElementById('v155GmSummary');if(!el||typeof game==='undefined'||!game)return;
  const civil=Object.values(game.gm?.civilWars||{}).filter(x=>x.status==='active').length;
  const war=game.war?.active?1:0;
  const secess=Object.values(game.gm?.secessionCrises||{}).filter(x=>['declared','civil_war'].includes(x.status)).length;
  const regions=Object.values(game.gm?.regionalPolitics||{}).filter(x=>x.status==='active'&&((x.unrest||0)>=70||(x.independence?.support||0)>=70)).length;
  const v154=game.gm?.v154||{},covert=Object.values(v154.sponsorships||{}).filter(x=>x.status==='active').length+Object.values(v154.unmarkedForces||{}).filter(x=>x.status==='active').length+(v154.investigations||[]).filter(x=>x.status==='active').length;
  let issues=[];try{issues=typeof v143TopIssues==='function'?v143TopIssues():[]}catch(_){}
  const mediaHot=issues.filter(x=>(x.heat||0)>=45).length,news=(game.gm?.news||[]).length;
  el.innerHTML=[[`戦争`,war],[`内戦`,civil],[`独立危機`,secess+regions],[`秘密工作`,covert],[`注目争点`,mediaHot],[`ニュース`,news]].map(([k,v])=>`<div class="v155-gm-metric">${k}<b>${v}</b></div>`).join('');
  const a=document.getElementById('v155GmAlerts');if(a){const top=issues.slice(0,3);const fallback=(game.gm?.news||[]).slice(0,3).map(text=>({label:String(text).replace(/^【[^】]+】/,'').slice(0,110),heat:null}));const rows=top.length?top:fallback;a.innerHTML=`<b>🔥 最重要情勢</b>${rows.length?rows.map(x=>`<div class="news-item">${escapeHtml(x.label||'情勢更新')}${x.heat!=null?` <span class="pill">関心 ${Math.round(x.heat)}</span>`:''}</div>`).join(''):'<div class="hint">重大情勢はありません。</div>'}`}
  document.querySelectorAll('.v155-gm-section').forEach(d=>{const n=d.querySelector('.v155-gm-body')?.children.length||0;const c=d.querySelector('[data-count]');if(c)c.textContent=`${n}項目`});
}
function v155SetIntelMode(mode){if(!['public','gm'].includes(mode))return;v155UI.intelMode=mode;v155ApplyIntelMode()}
function v155ApplyIntelMode(){
  document.documentElement.dataset.sfIntelMode=v155UI.intelMode;
  document.querySelectorAll('.v155-intel-toggle button').forEach(b=>b.classList.toggle('active',b.dataset.mode===v155UI.intelMode));
  const t=document.querySelector('#v155GmToolbar .smallnote');if(t)t.textContent=v155UI.intelMode==='public'?'公開情報：未立証の後援国・内部スポンサーを隠します。':'GM解析：シミュレーション内部の実行主体・後援関係も表示します。';
}

function v155RenderMediaLayout(){
  const root=document.getElementById('mediaPanel');if(!root||typeof v143EnsureState!=='function')return;const m=v143EnsureState(),top=(typeof v143TopIssues==='function'?v143TopIssues():[])[0];
  root.innerHTML=`<div class="section-title"><h3>📰 銀河メディア・世論・公式反応</h3><span class="pill">PUBLIC SPHERE</span></div><p class="desc">報道、政府声明、国家行動を分けて追跡します。v1.54系の秘密工作・所属不明部隊・編入・勢力圏も専用カテゴリとして扱います。</p><div class="station-stock"><div>追跡争点<b>${(typeof v143TopIssues==='function'?v143TopIssues():[]).length}</b></div><div>報道記事<b>${m.articles.length}</b></div><div>公式声明<b>${m.statements.length}</b></div><div>対外行動<b>${m.actions.length}</b></div></div>${top?`<div class="kv"><span>現在の最大関心</span><b>${escapeHtml(top.label)} / ${Math.round(top.heat)}</b></div>`:''}<div class="v155-media-tabs"><button data-media="focus" onclick="StarFrontierUI.setMediaTab('focus')">注目</button><button data-media="articles" onclick="StarFrontierUI.setMediaTab('articles')">記事</button><button data-media="statements" onclick="StarFrontierUI.setMediaTab('statements')">声明</button><button data-media="actions" onclick="StarFrontierUI.setMediaTab('actions')">各国行動</button></div><div class="v155-media-panes"><section class="v155-media-pane" data-media="focus"><h3>🔥 世間の関心</h3>${v143RenderInterest()}</section><section class="v155-media-pane" data-media="articles"><h3>🗞 各国メディアの報道</h3>${v143RenderCoverage()}</section><section class="v155-media-pane" data-media="statements"><h3>🎙 政府・大臣・省庁・軍の声明</h3>${v143RenderStatements()}</section><section class="v155-media-pane" data-media="actions"><h3>🌐 各国の立場</h3>${v143RenderPositions()}<div class="separator"></div><h3>✦ 支援・批判・制裁・仲介</h3>${v143RenderActions()}</section></div>`;
  v155ApplyMediaTab();
}
function v155SetMediaTab(tab){if(!['focus','articles','statements','actions'].includes(tab))return;v155UI.mediaTab=tab;v155ApplyMediaTab()}
function v155ApplyMediaTab(){document.querySelectorAll('.v155-media-tabs button').forEach(b=>b.classList.toggle('active',b.dataset.media===v155UI.mediaTab));document.querySelectorAll('.v155-media-pane').forEach(p=>p.classList.toggle('hidden',p.dataset.media!==v155UI.mediaTab))}

function v155CompactInternational(){
  const root=document.getElementById('gal-international');if(!root)return;
  root.querySelectorAll('.station-card').forEach(card=>{
    if(card.querySelector(':scope > .v155-org-expand'))return;const head=card.querySelector(':scope > .station-head'),desc=card.querySelector(':scope > p.desc');
    const move=[...card.children].filter(x=>x!==head&&x!==desc);if(!move.length)return;
    const d=document.createElement('details');d.className='v155-org-expand';d.innerHTML='<summary>加盟国・予算・制度詳細を見る</summary><div class="v155-org-expand-body"></div>';const body=d.querySelector('.v155-org-expand-body');move.forEach(x=>body.appendChild(x));card.appendChild(d);
  });
}

function v155PostRender(){v155SetVersion();v155RenderHomeAlerts();v155EnsureGalaxyLayout();if(document.getElementById('gal-gm')&&!document.getElementById('gal-gm').classList.contains('hidden'))v155EnsureGMDashboard();else if(document.getElementById('v155GmToolbar')){v155EnsureGMDashboard()}v155CompactInternational();v155ApplyMediaTab()}

// Media renderer is rebuilt after the v1.43/v1.54.1 media engine has produced state.
const v155MediaRenderBase=typeof renderV143Media==='function'?renderV143Media:null;
if(v155MediaRenderBase)renderV143Media=function(){v155MediaRenderBase();v155RenderMediaLayout()};

const v155ShowGalaxyBase=showGalaxy;
showGalaxy=function(id){v155UI.category=v155CategoryFor(id);const out=v155ShowGalaxyBase(id);v155EnsureGalaxyLayout();v155ApplyCategory();if(id==='gm')v155EnsureGMDashboard();if(id==='international')v155CompactInternational();if(id==='media')v155ApplyMediaTab();return out};

const v155RenderBase=render;
render=function(){const out=v155RenderBase();v155PostRender();return out};

// Android system back closes map focus mode before navigating away.
if(typeof StarFrontierAndroid!=='undefined'&&StarFrontierAndroid?.back){const base=StarFrontierAndroid.back.bind(StarFrontierAndroid);StarFrontierAndroid.back=function(){if(document.getElementById('gal-map')?.classList.contains('sf-map-fullscreen')){v155ToggleMapFullscreen(false);return true}return base()}}

if(typeof window!=='undefined')window.StarFrontierUI={
  build:V155_BUILD,
  setCategory:v155SetCategory,
  openGalaxy:v155OpenGalaxy,
  toggleMapFullscreen:v155ToggleMapFullscreen,
  setIntelMode:v155SetIntelMode,
  setMediaTab:v155SetMediaTab,
  refresh:v155PostRender,
  state:()=>({...v155UI})
};
