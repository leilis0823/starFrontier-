'use strict';
// ============================================================================
// v1.77.0 — Advanced Mining Rights, Deep Prospecting & Responsible Extraction
// Builds on v1.76.  Adds critical-mineral by-products, deep geological surveys,
// mining claims, survey-data monetisation, tailings recovery, mining accidents,
// environmental stress, and provenance-aware contraband ore.  Existing finance,
// commodity, legal, insurance and disaster systems remain authoritative.
// ============================================================================
const V177_BUILD='1.77.0';

const V177_CRITICAL_ELEMENTS={
 gallium:{name:'ガリウム',symbol:'Ga',icon:'◩',base:420,unit:'t',consumers:['data','aero_parts','research','energy']},
 germanium:{name:'ゲルマニウム',symbol:'Ge',icon:'◪',base:465,unit:'t',consumers:['data','research','aerospace','aero_parts']},
 tungsten:{name:'タングステン',symbol:'W',icon:'⬣',base:335,unit:'t',consumers:['arms','shipbuilding','aero_engine','infrastructure']},
 molybdenum:{name:'モリブデン',symbol:'Mo',icon:'⬢',base:275,unit:'t',consumers:['shipbuilding','aero_engine','energy','infrastructure']},
 tantalum:{name:'タンタル',symbol:'Ta',icon:'◈',base:590,unit:'t',consumers:['data','aero_parts','research','aerospace']},
 rhenium:{name:'レニウム',symbol:'Re',icon:'✥',base:760,unit:'t',consumers:['aero_engine','aerospace','research']}
};

// Extend v1.76's mutable ore/element catalogues instead of creating a second
// inventory system. Trace by-products are intentionally low-yield but valuable.
Object.assign(V176_ELEMENTS,V177_CRITICAL_ELEMENTS);
V176_ORES.bauxite.composition.gallium=V176_ORES.bauxite.composition.gallium??.012;
V176_ORES.chalcopyrite.composition.germanium=V176_ORES.chalcopyrite.composition.germanium??.006;
V176_ORES.scheelite=V176_ORES.scheelite||{name:'灰重石',icon:'⬣',rarity:'希少',base:245,composition:{tungsten:.47,molybdenum:.025},tags:['W','Mo']};
V176_ORES.molybdenite=V176_ORES.molybdenite||{name:'輝水鉛鉱',icon:'⬢',rarity:'希少',base:260,composition:{molybdenum:.55,rhenium:.012},tags:['Mo','Re']};
V176_ORES.coltan=V176_ORES.coltan||{name:'コルタン鉱',icon:'◈',rarity:'極希少',base:365,composition:{tantalum:.31,rare_earth:.035},tags:['Ta','REE']};
for(const [sid,bias] of Object.entries({
 nyx:{coltan:1.45,molybdenite:1.24},forge:{scheelite:1.52,molybdenite:1.28},drakon:{scheelite:1.46,molybdenite:1.32},
 bastion:{scheelite:1.34,coltan:1.10},halcyon:{coltan:1.55,molybdenite:1.16},kronos:{molybdenite:1.42,scheelite:1.22},
 cinder:{molybdenite:1.38,scheelite:1.30},orion:{coltan:1.24},umbra:{coltan:1.20}
}))Object.assign(V176_ORE_BIAS[sid]||(V176_ORE_BIAS[sid]={}),bias);

if(typeof V169_COMMODITIES!=='undefined'){
 for(const [k,m] of Object.entries(V177_CRITICAL_ELEMENTS))if(!V169_COMMODITIES[k])V169_COMMODITIES[k]={name:`${m.name} (${m.symbol})`,icon:m.icon,unit:m.unit,base:m.base,vol:(k==='rhenium'||k==='tantalum')?.067:.049,carry:.045,producerIndustries:['mining'],consumerIndustries:m.consumers};
}

const V177_DISCOVERY_TYPES={
 bonanza:{name:'超高品位鉱脈',icon:'💎',yieldBonus:.55,hazard:.02,dataMult:1.55,desc:'局所的に極めて高い品位。短期間で大きな採掘益を狙える。'},
 rich:{name:'富鉱帯',icon:'✨',yieldBonus:.30,hazard:.012,dataMult:1.25,desc:'安定した高品位帯。採掘権取得との相性が良い。'},
 polymetallic:{name:'多金属鉱化帯',icon:'🧬',yieldBonus:.18,hazard:.018,dataMult:1.38,desc:'副産物に富む複合鉱床。精錬価値が高い。'},
 unstable:{name:'断裂高品位鉱脈',icon:'⚠️',yieldBonus:.46,hazard:.10,dataMult:1.42,desc:'高収量だが崩落・機器損傷リスクが高い。'},
 ordinary:{name:'有望鉱床',icon:'🛰',yieldBonus:.10,hazard:.008,dataMult:1.0,desc:'大きな異常はないが、通常調査より精度の高い鉱床情報。'}
};

function v177Clamp(n,a=0,b=100){return Math.max(a,Math.min(b,n))}
function v177Round(n,p=1){const m=10**p;return Math.round((Number(n)||0)*m)/m}
function v177State(){
 const x=game.miningV177=game.miningV177||{version:1,claims:{},discoveries:{},contraband:{},tailings:{},environment:{},lastDeepSurvey:{},history:[],lastDay:game.day-1,metrics:{deepSurveys:0,discoveries:0,claimsBought:0,surveyDataSold:0,surveyRevenue:0,claimSpend:0,claimYield:0,accidents:0,accidentLoss:0,tailingsReprocessed:0,contrabandFenced:0,contrabandRevenue:0}};
 x.claims=x.claims||{};x.discoveries=x.discoveries||{};x.contraband=x.contraband||{};x.tailings=x.tailings||{};x.environment=x.environment||{};x.lastDeepSurvey=x.lastDeepSurvey||{};x.history=Array.isArray(x.history)?x.history:[];x.metrics=x.metrics||{};
 for(const k of Object.keys(V176_ORES))x.contraband[k]=Math.max(0,Number(x.contraband[k])||0);
 for(const sid of Object.keys(SYSTEMS||{})){x.tailings[sid]=Math.max(0,Number(x.tailings[sid])||0);x.environment[sid]=v177Clamp(Number(x.environment[sid])||0,0,100)}
 for(const k of ['deepSurveys','discoveries','claimsBought','surveyDataSold','surveyRevenue','claimSpend','claimYield','accidents','accidentLoss','tailingsReprocessed','contrabandFenced','contrabandRevenue'])x.metrics[k]=Number(x.metrics[k])||0;
 return x
}
function v177ClaimKey(sid,ore){return `${sid}:${ore}`}
function v177Claim(sid=game.system,ore=v176State().selectedOre){const c=v177State().claims[v177ClaimKey(sid,ore)];return c&&c.status==='active'&&c.expires>=game.day?c:null}
function v177Discovery(sid=game.system,ore=v176State().selectedOre){const d=v177State().discoveries[v177ClaimKey(sid,ore)];return d&&d.status==='active'&&d.expires>=game.day?d:null}
function v177ClaimPrice(sid=game.system,ore=v176State().selectedOre){if(!V176_ORES[ore])return 0;const dep=v176EnsureDeposits(sid)[ore]||40,dis=v177Discovery(sid,ore),quality=dis?.quality||100,scarcity=1+Math.max(0,v176OrePrice(ore)-120)/900;return Math.round((4200+dep*52+v176OrePrice(ore)*9)*scarcity*(.90+quality/500))}
function v177StateTreasury(fid,n){const f=game.gm?.factions?.[fid];if(f&&Number.isFinite(f.treasury))f.treasury=Math.max(0,f.treasury+n)}
function v177SyncClaim(c){if(!c||typeof v130UpsertContract!=='function')return;const fid=SYSTEMS[c.system]?.faction||'league';v130UpsertContract(`mining-claim:${c.id}`,{type:'mining_claim',sourceType:'mining_right',sourceId:c.id,parties:['player',`state:${fid}`],status:c.status==='active'&&c.expires>=game.day?'active':'completed',value:c.price||0,outstanding:0,nextDue:c.expires,governingFaction:fid,breachLevel:0,summary:`${SYSTEMS[c.system]?.name||c.system} / ${V176_ORES[c.ore]?.name||c.ore} 採掘権 / Day ${c.expires}まで`})}
function v177AcquireClaim(ore=v176State().selectedOre){
 const x=v177State(),sid=game.system;if(!V176_ORES[ore])return null;const old=v177Claim(sid,ore);if(old){toast?.('この鉱区権はすでに保有中');return old}const price=v177ClaimPrice(sid,ore);if((game.credits||0)<price){toast?.(`採掘権取得には ${price.toLocaleString()} Cr 必要`);return null}
 game.credits-=price;const fid=SYSTEMS[sid]?.faction;if(fid&&fid!=='unclaimed')v177StateTreasury(fid,price);const dis=v177Discovery(sid,ore),c={id:`claim-${sid}-${ore}-${game.day}`,system:sid,ore,holder:'player',started:game.day,expires:game.day+60,status:'active',price,quality:dis?.quality||100,yieldBonus:.18+(dis?Math.min(.08,(dis.quality-100)/250):0)};x.claims[v177ClaimKey(sid,ore)]=c;x.metrics.claimsBought++;x.metrics.claimSpend+=price;x.history.unshift({day:game.day,type:'claim',text:`${SYSTEMS[sid]?.name||sid} ${V176_ORES[ore].name}の採掘権を ${price.toLocaleString()} Crで取得`});v177SyncClaim(c);addLog(`採掘権取得：${V176_ORES[ore].name} / Day ${c.expires}まで / ${price.toLocaleString()} Cr。`);toast?.('鉱区権を取得');render?.();return c
}
function v177RelinquishClaim(ore=v176State().selectedOre){const x=v177State(),c=v177Claim(game.system,ore);if(!c)return;const remain=v177Clamp((c.expires-game.day)/60,0,1),refund=Math.round(c.price*.42*remain);c.status='relinquished';c.closed=game.day;game.credits+=refund;const fid=SYSTEMS[c.system]?.faction;if(fid&&fid!=='unclaimed')v177StateTreasury(fid,-Math.min(refund,game.gm?.factions?.[fid]?.treasury||0));v177SyncClaim(c);addLog(`${V176_ORES[c.ore].name}鉱区権を返上。清算 ${refund.toLocaleString()} Cr。`);toast?.(`+${refund.toLocaleString()} Cr`);render?.()}

function v177PickDiscoveryType(){const r=rng();return r<.16?'bonanza':r<.47?'rich':r<.68?'polymetallic':r<.83?'unstable':'ordinary'}
function v177DeepSurvey(){
 const x=v177State(),sid=game.system;if((x.lastDeepSurvey[sid]??-99)>=game.day-2){toast?.('同一星系の深部探査は3日ごとに実施できます');return null}const fee=700;if((game.credits||0)<fee||game.fuel<2){toast?.('深部探査には700 Crと燃料2が必要');return null}game.credits-=fee;game.fuel-=2;x.lastDeepSurvey[sid]=game.day;x.metrics.deepSurveys++;
 const survey=v176Survey(sid,true),chosen=(v176State().selectedOre&&survey.rows.some(r=>r.k===v176State().selectedOre))?v176State().selectedOre:survey.rows[0]?.k;if(!chosen)return null;const type=v177PickDiscoveryType(),meta=V177_DISCOVERY_TYPES[type],row=survey.rows.find(r=>r.k===chosen),quality=Math.round(v177Clamp((row?.grade||90)+18+rng()*28,90,165)),d={id:`disc-${sid}-${chosen}-${game.day}`,system:sid,ore:chosen,type,quality,yieldBonus:meta.yieldBonus,hazard:meta.hazard,started:game.day,expires:game.day+14,status:'active',sold:false};x.discoveries[v177ClaimKey(sid,chosen)]=d;x.metrics.discoveries++;x.history.unshift({day:game.day,type:'discovery',text:`${SYSTEMS[sid]?.name||sid}で${meta.name}：${V176_ORES[chosen].name} / 品位 ${quality}`});addLog(`深部地質探査：${meta.name}を発見。${V176_ORES[chosen].name} 品位指数 ${quality}、Day ${d.expires}まで有効。`);toast?.(`${meta.icon} ${meta.name}を発見`);render?.();return d
}
function v177SurveyDataValue(d){if(!d)return 0;const meta=V177_DISCOVERY_TYPES[d.type]||V177_DISCOVERY_TYPES.ordinary,dep=v176EnsureDeposits(d.system)[d.ore]||40;return Math.round((900+v176OrePrice(d.ore)*5+dep*18)*(d.quality/100)*meta.dataMult)}
function v177SellSurveyData(ore=v176State().selectedOre){const x=v177State(),d=v177Discovery(game.system,ore);if(!d||d.sold){toast?.('売却できる独占地質データがありません');return}if(v177Claim(game.system,ore)){toast?.('採掘権保有中の鉱床データは売却できません');return}let pay=v177SurveyDataValue(d),fid=SYSTEMS[game.system]?.faction,treasury=game.gm?.factions?.[fid]?.treasury;if(Number.isFinite(treasury))pay=Math.min(pay,Math.max(500,Math.round(treasury*.035)));game.credits+=pay;if(fid&&fid!=='unclaimed')v177StateTreasury(fid,-Math.min(pay,game.gm?.factions?.[fid]?.treasury||0));d.sold=true;d.status='sold';d.soldDay=game.day;x.metrics.surveyDataSold++;x.metrics.surveyRevenue+=pay;x.history.unshift({day:game.day,type:'survey_sale',text:`${V176_ORES[d.ore].name}地質データを ${pay.toLocaleString()} Crで売却`});addLog(`深部探査データを資源企業へ売却：${pay.toLocaleString()} Cr。`);toast?.(`+${pay.toLocaleString()} Cr`);render?.()}

function v177Pollution(sid=game.system,n=0){const x=v177State();x.environment[sid]=v177Clamp((x.environment[sid]||0)+n,0,100);return x.environment[sid]}
function v177AccidentRisk(ore,dis){let p=.006+(v177State().environment[game.system]||0)*.00025;if(ore==='uraninite'||ore==='molybdenite')p+=.008;if(dis)p+=dis.hazard||0;return Math.min(.18,p)}
const v177MineBase=v176MineCore;
v176MineCore=function(silent=false,acc=null){
 const x=v176State(),before={...x.ores},ok=v177MineBase(silent,acc);if(!ok)return ok;let ore=null,mined=0;for(const k of Object.keys(x.ores)){const d=(x.ores[k]||0)-(before[k]||0);if(d>mined){mined=d;ore=k}}if(!ore||mined<=0)return ok;
 const c=v177Claim(game.system,ore),d=v177Discovery(game.system,ore);let bonus=(c?.yieldBonus||0)+(d?.yieldBonus||0),extra=Math.min(Math.floor(cargoFree()),Math.max(0,Math.floor(mined*bonus)));if(extra>0){x.ores[ore]=v177Round((x.ores[ore]||0)+extra,1);x.metrics.mined+=extra;v176EnsureDeposits(game.system)[ore]=Math.max(0,(v176EnsureDeposits(game.system)[ore]||0)-extra*.045);v177State().metrics.claimYield+=extra;if(acc)acc[ore]=(acc[ore]||0)+extra;if(!silent)addLog(`鉱区権・深部探査ボーナス：${V176_ORES[ore].name} +${extra}。`)}
 v177Pollution(game.system,mined*.018+extra*.02);if(rng()<v177AccidentRisk(ore,d)){const dmg=Math.round(3+rng()*13),loss=Math.min(x.ores[ore]||0,Math.max(1,Math.round(mined*(.10+rng()*.22))));x.ores[ore]=v177Round(Math.max(0,(x.ores[ore]||0)-loss),1);try{damageShip(dmg)}catch(_){}const val=Math.round(v176OrePrice(ore)*loss+dmg*90),s=v177State();s.metrics.accidents++;s.metrics.accidentLoss+=val;s.history.unshift({day:game.day,type:'accident',text:`${V176_ORES[ore].name}採掘事故 / 船体損傷 ${dmg}% / 鉱石損失 ${loss}`});if(game.playerCorporation?.created&&typeof v163FileClaim==='function')try{v163FileClaim('player:parent','property',val,`mining-accident:${game.day}:${ore}:${s.metrics.accidents}`,'mining_accident',`${SYSTEMS[game.system]?.name||game.system} 採掘事故`)}catch(_){}addLog(`⚠ 採掘事故：船体 ${dmg}%損傷、${V176_ORES[ore].name} ${loss} unitsを喪失。`);if(!silent)toast?.('採掘事故が発生')}
 return ok
};

const v177RefineBase=v176RefineOre;
v176RefineOre=function(k,qty=null,industrial=true){const have=v176State().ores[k]||0,n=Math.min(have,qty==null?have:Math.max(0,Number(qty)||0));const ok=v177RefineBase(k,qty,industrial);if(ok&&n>0){const s=v177State(),tail=n*(industrial?.055:.24);s.tailings[game.system]=v177Round((s.tailings[game.system]||0)+tail,1);v177Pollution(game.system,n*(industrial?.065:.018));if(industrial&&rng()<.012+(s.environment[game.system]||0)*.00016){const dmg=Math.round(250+n*22);s.metrics.accidents++;s.metrics.accidentLoss+=dmg;s.history.unshift({day:game.day,type:'refinery_incident',text:`精錬設備事故 / 推定損失 ${dmg.toLocaleString()} Cr`});if(game.playerCorporation?.created&&typeof v163FileClaim==='function')try{v163FileClaim('player:parent','property',dmg,`refinery-incident:${game.day}:${k}:${s.metrics.accidents}`,'mining_refinery','鉱石精錬設備事故')}catch(_){}addLog(`精錬設備で小規模事故。推定損失 ${dmg.toLocaleString()} Cr。`)}}return ok};
function v177ReprocessTailings(qty=null){const s=v177State(),have=s.tailings[game.system]||0,n=Math.min(have,qty==null?have:Math.max(0,Number(qty)||0));if(n<=0){toast?.('再処理できる尾鉱がない');return false}if(!v176HasRefinery()){toast?.('尾鉱再処理には精錬所が必要');return false}const fee=Math.ceil(n*9);if((game.credits||0)<fee){toast?.(`再処理費 ${fee.toLocaleString()} Cr が不足`);return false}game.credits-=fee;s.tailings[game.system]=v177Round(have-n,1);const keys=Object.keys(V177_CRITICAL_ELEMENTS),k=keys[Math.min(keys.length-1,Math.floor(rng()*keys.length))],out=v177Round(n*(.055+rng()*.045),1);v176AddProduct(k,out);s.metrics.tailingsReprocessed+=n;v177Pollution(game.system,-n*.12);addLog(`尾鉱 ${v177Round(n,1)}を再処理し、${V176_ELEMENTS[k].name} ${out}を回収。環境負荷も低減。`);toast?.(`${V176_ELEMENTS[k].symbol} +${out}`);render?.();return true}
function v177RestoreSite(){const s=v177State(),p=s.environment[game.system]||0;if(p<4){toast?.('追加の鉱区修復は不要');return}const cut=Math.min(20,p),cost=Math.round(350+cut*42);if((game.credits||0)<cost){toast?.(`修復費 ${cost.toLocaleString()} Cr が不足`);return}game.credits-=cost;v177Pollution(game.system,-cut);const fid=SYSTEMS[game.system]?.faction;if(fid&&fid!=='unclaimed')v177StateTreasury(fid,Math.round(cost*.35));addLog(`鉱区修復・尾鉱安定化を実施。環境負荷 -${Math.round(cut)} / ${cost.toLocaleString()} Cr。`);toast?.('鉱区を修復');render?.()}

// Track provenance of ore seized from civilian/non-belligerent mining vessels.
const v177LootBase=v176LootMiningWreck;
v176LootMiningWreck=function(id){const s=v177State(),w=v176State().wrecks.find(q=>q.id===id&&!q.empty),before={...v176State().ores},illegal=!!(w&&!v176IsLegalRaid(w.owner));const out=v177LootBase(id);if(illegal){for(const k of Object.keys(V176_ORES)){const d=(v176State().ores[k]||0)-(before[k]||0);if(d>0)s.contraband[k]=v177Round((s.contraband[k]||0)+d,1)}}return out};
const v177SellOreBase=v176SellOre;
v176SellOre=function(k,qty=1){const s=v177State(),have=v176State().ores[k]||0,n=Math.min(have,Math.max(0,Number(qty)||0)),stolen=Math.min(s.contraband[k]||0,n),fid=typeof v140Jurisdiction==='function'?v140Jurisdiction(game.system):SYSTEMS[game.system]?.faction;if(stolen>0&&fid&&fid!=='unclaimed'){const sec=SYSTEMS[game.system]?.security,check=sec==='軍管'?.30:sec==='高'?.22:.14;if(rng()<check){const val=Math.round(v176OrePrice(k)*stolen);v176State().ores[k]=v177Round(Math.max(0,(v176State().ores[k]||0)-stolen),1);s.contraband[k]=v177Round(Math.max(0,(s.contraband[k]||0)-stolen),1);const fine=Math.min(game.credits||0,Math.round(val*.75+900));game.credits=Math.max(0,(game.credits||0)-fine);try{v140RecordOffense(fid,'contraband',val,game.system)}catch(_){}addLog(`税関検査で出所不明鉱石 ${V176_ORES[k].name} ${stolen}を没収。即時徴収 ${fine.toLocaleString()} Cr。`);toast?.('密輸鉱石を摘発された');const legal=n-stolen;if(legal>0)return v177SellOreBase(k,legal);render?.();return}}
 if(stolen>0)s.contraband[k]=v177Round(Math.max(0,(s.contraband[k]||0)-stolen),1);return v177SellOreBase(k,n)};
function v177FenceOre(k,qty=null){const s=v177State(),have=Math.min(v176State().ores[k]||0,s.contraband[k]||0),n=Math.min(have,qty==null?have:Math.max(0,Number(qty)||0));if(n<=0){toast?.('売却できる出所不明鉱石がない');return}const mult=SYSTEMS[game.system]?.faction==='unclaimed'?.82:.70,rev=Math.round(v176OrePrice(k)*n*mult);v176State().ores[k]=v177Round((v176State().ores[k]||0)-n,1);s.contraband[k]=v177Round((s.contraband[k]||0)-n,1);game.credits+=rev;s.metrics.contrabandFenced+=n;s.metrics.contrabandRevenue+=rev;if(game.freeCaptains)game.freeCaptains.heat=v177Clamp((game.freeCaptains.heat||0)+1,0,100);addLog(`地下仲買へ${V176_ORES[k].name} ${n}を ${rev.toLocaleString()} Crで処分。`);toast?.(`+${rev.toLocaleString()} Cr`);render?.()}

// Feed mining pollution into the existing v1.73 disaster risk model.
if(typeof v173System==='function'){const v177EnvBase=v173System;v173System=function(sid){const out=v177EnvBase(sid),p=v177State().environment[sid]||0;out.miningPollution=p;out.environmentalRisk=v177Clamp((out.environmentalRisk||0)+p*.16,5,100);return out}}
function v177ProcessDaily(){const s=v177State();if(s.lastDay===game.day)return;s.lastDay=game.day;for(const [k,c] of Object.entries(s.claims)){if(c.status==='active'&&game.day>c.expires){c.status='expired';v177SyncClaim(c)}}for(const d of Object.values(s.discoveries))if(d.status==='active'&&game.day>d.expires)d.status='expired';for(const sid of Object.keys(SYSTEMS||{})){s.environment[sid]=v177Clamp((s.environment[sid]||0)*.992,0,100);s.tailings[sid]=Math.max(0,s.tailings[sid]||0)}s.history=s.history.slice(0,140);game.version=V177_BUILD}

function v177CriticalList(){return Object.entries(V177_CRITICAL_ELEMENTS).map(([k,m])=>`${m.symbol} ${m.name}`).join(' / ')}
function v177RenderPanel(){
 const s=v177State(),sid=game.system,ore=v176State().selectedOre,claim=ore?v177Claim(sid,ore):null,disc=ore?v177Discovery(sid,ore):null,claimPrice=ore?v177ClaimPrice(sid,ore):0,poll=s.environment[sid]||0,tail=s.tailings[sid]||0,contr=Object.entries(s.contraband).filter(([,n])=>n>.04),dm=disc?V177_DISCOVERY_TYPES[disc.type]:null;
 return `<div data-v177="advanced-mining"><div class="panel"><div class="section-title"><h2>🛰 深部探査・鉱区権</h2><span class="pill">v1.77</span></div><p class="desc">深部探査で高品位鉱脈を発見し、自分で採掘権を取得するか地質データを資源企業へ売却できます。鉱区権は60日間、同じ鉱石の採掘収量を約18%以上引き上げます。</p><div class="actions"><button onclick="v177DeepSurvey()">深部探査 700 Cr / 燃料2</button>${ore&&!claim?`<button class="good" onclick="v177AcquireClaim('${ore}')">${escapeHtml(V176_ORES[ore].name)}鉱区権 ${claimPrice.toLocaleString()} Cr</button>`:''}${claim?`<button class="secondary" onclick="v177RelinquishClaim('${ore}')">鉱区権を返上</button>`:''}${disc&&!claim?`<button class="purple" onclick="v177SellSurveyData('${ore}')">地質データ売却 ${v177SurveyDataValue(disc).toLocaleString()} Cr前後</button>`:''}</div>${disc?`<div class="news-item"><b>${dm.icon} ${escapeHtml(dm.name)} / ${escapeHtml(V176_ORES[disc.ore].name)}</b><br>品位指数 ${disc.quality} / 収量補正 +${Math.round(disc.yieldBonus*100)}% / 事故リスク +${Math.round(disc.hazard*100)}pt / Day ${disc.expires}まで<br>${escapeHtml(dm.desc)}</div>`:'<div class="hint">深部探査を行うと、通常スキャンでは見えない鉱化帯を発見できることがあります。</div>'}${claim?`<div class="news-item"><b>📜 採掘権保有中</b> ${escapeHtml(V176_ORES[claim.ore].name)} / 収量 +${Math.round(claim.yieldBonus*100)}% / Day ${claim.expires}まで / 取得額 ${claim.price.toLocaleString()} Cr</div>`:''}</div><div class="wide-grid"><div class="panel"><h2>♻ 尾鉱・環境管理</h2><div class="station-stock"><div>尾鉱<b>${v177Round(tail,1)}</b></div><div>鉱業環境負荷<b>${Math.round(poll)}</b></div><div>事故累計<b>${s.metrics.accidents}</b></div><div>探査売上<b>${Math.round(s.metrics.surveyRevenue).toLocaleString()} Cr</b></div></div><div class="actions"><button onclick="v177ReprocessTailings()" ${tail<1?'disabled':''}>尾鉱を再処理</button><button class="good" onclick="v177RestoreSite()" ${poll<4?'disabled':''}>鉱区修復</button></div><div class="hint">採掘・工業精錬は環境負荷を蓄積します。v1.73の災害リスクへ接続され、尾鉱再処理・修復で軽減できます。</div></div><div class="panel"><h2>🧪 重要鉱物</h2><p>${escapeHtml(v177CriticalList())}</p><div class="hint">Ga/Geは既存鉱石の微量副産物、W/Mo/Ta/Reは新規希少鉱石から回収。v1.69の商品市場・先物・長期調達へ自動登録されます。</div></div></div>${contr.length?`<div class="panel hot"><h2>☠ 出所不明鉱石</h2><p class="desc">非交戦民間船から奪った鉱石には来歴が残ります。正規市場では検査・没収・禁制品違反のリスクがあります。地下仲買なら安値ですが確実に処分できます。</p>${contr.map(([k,n])=>`<div class="market-row"><div><b>${escapeHtml(V176_ORES[k]?.name||k)}</b><div class="own">出所不明 ${v177Round(n,1)} / 正規原鉱価 ${v176OrePrice(k).toLocaleString()} Cr</div></div><button class="warn" onclick="v177FenceOre('${k}',${n})">地下市場へ売却</button></div>`).join('')}</div>`:''}</div>`
}

const v177MiningRenderBase=v176RenderMining;v176RenderMining=function(){return v177MiningRenderBase()+v177RenderPanel()};
function ensureV177State(){if(typeof ensureV176State==='function')ensureV176State();const s=v177State();try{v169State?.()}catch(_){}game.version=V177_BUILD;return s}
const v177InitBase=initV10;initV10=function(){const out=v177InitBase();ensureV177State();game.version=V177_BUILD;return out};
const v177AdvanceBase=gmAdvance;gmAdvance=function(){ensureV177State();const out=v177AdvanceBase();v177ProcessDaily();game.version=V177_BUILD;return out};
if(typeof render==='function'){const v177RenderBase=render;render=function(){const out=v177RenderBase();try{ensureV177State();const badge=document.querySelector('header .title .badge')||document.querySelector('.version-badge');if(badge)badge.textContent='v1.77.0';const sub=document.querySelector('header .sub');if(sub)sub.textContent='Deep Prospecting / Mining Rights / Critical Minerals / Responsible Extraction';document.title='STAR FRONTIER v1.77.0 — Advanced Mining & Prospecting'}catch(_){}return out}}
if(typeof window!=='undefined')window.StarFrontierMiningV177={ensure:ensureV177State,state:v177State,critical:V177_CRITICAL_ELEMENTS,deepSurvey:v177DeepSurvey,acquireClaim:v177AcquireClaim,sellSurvey:v177SellSurveyData,reprocessTailings:v177ReprocessTailings,fence:v177FenceOre};
