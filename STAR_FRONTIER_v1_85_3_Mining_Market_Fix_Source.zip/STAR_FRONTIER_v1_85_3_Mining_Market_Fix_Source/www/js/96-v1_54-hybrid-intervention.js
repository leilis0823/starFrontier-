'use strict';
// ===== v1.54.0: covert statecraft / hybrid intervention / annexation & sphere AI =====
// Simulation note: violent/covert actions are intentionally abstract. The model tracks
// authorization, political risk, success, detection and attribution without operational methods.

const V154_BUILD='1.54.1';
const V154_OPERATION_LABELS=Object.freeze({
  political_support:'秘密政治支援',
  proxy_support:'代理勢力支援',
  unmarked_force:'所属不明部隊の介入',
  assassination:'国家暗殺作戦'
});
const V154_EXECUTOR_LABELS=Object.freeze({
  government:'政府情報・安全保障機構',
  regular:'正規軍',
  border:'国境警備隊',
  parallel:'並列武装組織'
});
const V154_SPHERE_LABELS=Object.freeze({
  aligned_state:'友好・勢力圏国家',
  security_client:'安全保障従属国',
  protectorate:'保護国',
  puppet_state:'傀儡国家'
});

function v154LabelFaction(fid){
  if(fid==='player')return game.playerFaction?.name||'自勢力';
  return FACTIONS[fid]?.short||FACTIONS[fid]?.name||fid;
}
function v154Clamp01(n){return clamp(Number(n)||0,0,100)}
function v154PairTension(a,b){try{return v133PairTension(a,b)||0}catch(_){return 0}}
function v154ChangeTension(a,b,n){try{v133ChangeTension(a,b,n)}catch(_){}}
function v154NpcStates(){
  const ids=new Set(Array.isArray(V12_FACTION_IDS)?V12_FACTION_IDS:[]);
  return [...ids].filter(fid=>fid&&fid!=='unclaimed'&&game.gm.governments?.[fid]&&FACTIONS[fid]);
}
function v154OwnedSystems(fid){return Object.keys(SYSTEMS).filter(s=>SYSTEMS[s]?.faction===fid)}
function v154AdjacentToSystem(fid,sid){
  if(!sid)return false;
  for(const own of v154OwnedSystems(fid))if(Object.prototype.hasOwnProperty.call(SYSTEMS[own]?.routes||{},sid))return true;
  return false;
}
function v154AdjacentToRegion(fid,region){return !!region&&v154AdjacentToSystem(fid,region.system)}
function v154SecurityAlert(fid){
  return v154Clamp01(game.gm.v154?.alerts?.[fid]?.level||0);
}
function v154RaiseSecurityAlert(fid,amount,reason=''){
  const x=game.gm.v154;if(!x||!fid)return;
  const a=x.alerts[fid]||(x.alerts[fid]={level:0,lastDay:game.day,history:[]});
  a.level=v154Clamp01((a.level||0)+Math.max(0,Number(amount)||0));a.lastDay=game.day;
  if(reason){a.history.unshift({day:game.day,reason,level:Math.round(a.level)});a.history=a.history.slice(0,20)}
  const g=game.gm.governments?.[fid];if(g)g.internalSecurity=v154Clamp01((g.internalSecurity||50)+Math.min(2.4,(Number(amount)||0)*.06));
}
function v154TargetCounterIntel(fid){
  const g=game.gm.governments?.[fid],s=game.gm.factions?.[fid],alert=v154SecurityAlert(fid);
  return v154Clamp01((g?.internalSecurity||50)*.52+(s?.intel||45)*.38+alert*.22);
}
function v154StateStrength(fid){
  const s=game.gm.factions?.[fid]||{},g=game.gm.governments?.[fid]||{};
  return Math.max(1,(s.fleet||20)*.34+(s.logistics||45)*.18+(s.industry||45)*.14+(s.intel||40)*.14+(g.stability||55)*.10+(g.administrativeCapacity||55)*.10);
}
function v154PolicySeed(fid){
  const g=game.gm.governments?.[fid]||{},s=game.gm.factions?.[fid]||{},t=typeof v134Template==='function'?v134Template(g.regimeId||'presidential_republic'):null;
  return {
    faction:fid,
    aggression:v154Clamp01(24+(g.dimensions?.military||50)*.38+(g.dimensions?.head||50)*.18+(100-(g.dimensions?.local||50))*.08),
    expansion:v154Clamp01(18+(g.foreignPosture||50)*.24+(g.dimensions?.military||50)*.22+(g.dimensions?.head||50)*.12+(t?.dimensions?.corporate||50)*.05),
    deniability:v154Clamp01(40+(s.intel||45)*.31+(g.ministers?.foreign?.competence||55)*.16+(g.ministers?.interior?.competence||55)*.12),
    counterIntel:v154TargetCounterIntel(fid),
    capacity:v154Clamp01(52+(s.intel||45)*.22+(g.administrativeCapacity||55)*.18),
    lastAction:game.day-10,
    lastAssassination:game.day-24,
    operations:0
  };
}
function ensureV154State(){
  ensureV139State();
  if(typeof ensureV145State==='function')ensureV145State();
  const old=game.gm.v154||{};
  game.gm.v154={
    policies:old.policies||{},
    operations:Array.isArray(old.operations)?old.operations:[],
    sponsorships:old.sponsorships||{},
    unmarkedForces:old.unmarkedForces||{},
    investigations:Array.isArray(old.investigations)?old.investigations:[],
    annexationRequests:Array.isArray(old.annexationRequests)?old.annexationRequests:[],
    spheres:old.spheres||{},
    alerts:old.alerts||{},
    stats:{operations:0,successes:0,detected:0,attributed:0,assassinations:0,unmarked:0,annexations:0,autonomousActions:0,disruptions:0,...(old.stats||{})},
    lastDay:Number.isFinite(old.lastDay)?old.lastDay:game.day-1
  };
  for(const fid of v154NpcStates()){
    game.gm.v154.policies[fid]={...v154PolicySeed(fid),...(game.gm.v154.policies[fid]||{})};
    const p=game.gm.v154.policies[fid];
    p.capacity=v154Clamp01(p.capacity);
    const a=game.gm.v154.alerts[fid]||{};game.gm.v154.alerts[fid]={level:v154Clamp01(a.level||0),lastDay:Number.isFinite(a.lastDay)?a.lastDay:game.day-1,history:Array.isArray(a.history)?a.history:[]};
  }
  game.gm.v154.operations=game.gm.v154.operations.slice(0,160);
  game.gm.v154.investigations=game.gm.v154.investigations.slice(0,80);
  game.gm.v154.annexationRequests=game.gm.v154.annexationRequests.slice(0,40);
}

function v154ParallelCandidates(fid){
  return Object.values(game.gm.parallelForces||{}).filter(o=>o&&o.parent===fid&&o.status!=='disbanded'&&o.status!=='destroyed');
}
function v154ExecutorProfiles(fid,region=null){
  const p=game.gm.v154.policies[fid]||v154PolicySeed(fid),g=game.gm.governments?.[fid]||{},sf=game.gm.securityForces?.[fid],state=game.gm.factions?.[fid]||{};
  const navy=(sf?.patrols||[]).filter(x=>x.kind!=='border'),border=(sf?.patrols||[]).filter(x=>x.kind==='border');
  const avg=(arr,key,def)=>arr.length?arr.reduce((n,x)=>n+(Number(x[key])||def),0)/arr.length:def;
  const rows=[
    {type:'government',id:fid,name:`${v154LabelFaction(fid)} 政府情報・安全保障機構`,skill:v154Clamp01((state.intel||45)*.46+(g.ministers?.foreign?.competence||55)*.22+(g.ministers?.interior?.competence||55)*.22+10),deniability:v154Clamp01(p.deniability+8),aggression:v154Clamp01(p.aggression*.78),autonomy:v154Clamp01((g.delegation?.foreign||55)*.55+(g.delegation?.interior||55)*.45)},
    {type:'regular',id:fid,name:sf?.navyName||`${v154LabelFaction(fid)}正規軍`,skill:v154Clamp01(avg(navy,'commanderSkill',58)*.52+(state.intel||45)*.20+avg(navy,'readiness',68)*.28),deniability:v154Clamp01(p.deniability-18),aggression:v154Clamp01(p.aggression+10),autonomy:v154Clamp01((g.delegation?.defense||55)+4)},
    {type:'border',id:fid,name:sf?.borderName||`${v154LabelFaction(fid)}国境警備隊`,skill:v154Clamp01(avg(border,'commanderSkill',56)*.48+(state.intel||45)*.18+avg(border,'readiness',68)*.34),deniability:v154Clamp01(p.deniability-5),aggression:v154Clamp01(p.aggression-4),autonomy:v154Clamp01((g.delegation?.interior||55)+8),adjacent:region?v154AdjacentToRegion(fid,region):true}
  ];
  for(const o of v154ParallelCandidates(fid))rows.push({type:'parallel',id:o.id,name:o.name||'並列武装組織',skill:v154Clamp01((o.readiness||58)*.35+(o.influence||50)*.22+(o.loyalty||55)*.10+(state.intel||45)*.18+(o.governmentRelation||50)*.15),deniability:v154Clamp01(p.deniability+15),aggression:v154Clamp01(p.aggression+18+(100-(o.loyalty||55))*.08),autonomy:v154Clamp01(58+(o.influence||50)*.30)});
  return rows;
}
function v154ExecutorDecision(fid,type,a,region=null,targetFaction=null){
  const p=game.gm.v154.policies[fid]||v154PolicySeed(fid),g=game.gm.governments?.[fid]||{};
  const tension=targetFaction?v154PairTension(fid,targetFaction):region?.parent?v154PairTension(fid,region.parent):45;
  const war=!!(targetFaction&&game.war?.active&&[fid,targetFaction].every(x=>[game.war.a,game.war.b].includes(x)));
  let score=a.skill*.20+a.aggression*.24+a.autonomy*.16+p.capacity*.14+tension*.18+(war?13:0)+rng()*12;
  let threshold=52,authorized=true,decisionOrigin=a.type;
  if(type==='political_support'){threshold=48;if(a.type==='government')score+=13;if(a.type==='regular')score-=10}
  if(type==='proxy_support'){threshold=53;if(a.type==='parallel')score+=15;if(a.type==='border'&&region)score+=8}
  if(type==='unmarked_force'){threshold=59;if(a.type==='parallel')score+=18;if(a.type==='regular')score+=8;if(a.type==='government')score-=12}
  if(type==='assassination'){threshold=61;if(a.type==='government')score+=13;if(a.type==='parallel')score+=15;if(a.type==='border')score-=5}
  if(a.type==='regular')score+=(g.delegation?.defense||50)*.07;
  if(a.type==='border')score+=(g.delegation?.interior||50)*.07;
  if(a.type==='government')score+=((g.delegation?.foreign||50)+(g.delegation?.interior||50))*.035;
  if(a.type==='parallel'){
    const o=game.gm.parallelForces?.[a.id]||{};
    const autonomousDrive=a.autonomy*.46+(100-(o.loyalty??55))*.22+(100-(o.governmentRelation??50))*.18+a.aggression*.14;
    if(autonomousDrive>66&&rng()<clamp(.10+(autonomousDrive-66)*.012,.10,.52)){authorized=false;decisionOrigin='autonomous_parallel';score+=10}
  }
  if(a.type==='border'&&region&&a.adjacent===false)return{approved:false,score:-999,authorized,decisionOrigin};
  return{approved:score>=threshold,score,threshold,authorized,decisionOrigin};
}
function v154ChooseExecutor(fid,type,region=null,targetFaction=null){
  const rows=v154ExecutorProfiles(fid,region).filter(a=>a.type!=='border'||a.adjacent!==false),approved=[];
  for(const a of rows){
    const decision=v154ExecutorDecision(fid,type,a,region,targetFaction);if(!decision.approved)continue;
    let fit=a.skill*.38+a.deniability*.22+a.aggression*.18+a.autonomy*.10+rng()*18+decision.score*.12;
    if(type==='political_support'){if(a.type==='government')fit+=18;if(a.type==='border'&&region)fit+=12;if(a.type==='regular')fit-=10}
    if(type==='proxy_support'){if(a.type==='parallel')fit+=22;if(a.type==='border')fit+=10}
    if(type==='unmarked_force'){if(a.type==='parallel')fit+=26;if(a.type==='regular')fit+=12;if(a.type==='government')fit-=12}
    if(type==='assassination'){if(a.type==='government')fit+=20;if(a.type==='parallel')fit+=18;if(a.type==='border')fit-=12}
    a.score=fit;a.decisionScore=decision.score;a.authorized=decision.authorized;a.decisionOrigin=decision.decisionOrigin;approved.push(a);
  }
  return approved.sort((a,b)=>b.score-a.score)[0]||null;
}
function v154OperationOutcome(op,executor,targetFaction){
  const p=game.gm.v154.policies[op.sponsor],targetCI=v154TargetCounterIntel(targetFaction),difficulty={political_support:35,proxy_support:47,unmarked_force:58,assassination:64}[op.type]||50;
  const successChance=clamp(.26+executor.skill*.0042+p.capacity*.0018-difficulty*.0025-targetCI*.0020,.08,.88);
  const success=rng()<successChance;
  const detectChance=clamp(.22+targetCI*.0041+difficulty*.0022-executor.deniability*.0032,.08,.88);
  const detected=rng()<detectChance;
  const attributionChance=clamp(.14+targetCI*.0040+(success?-.03:.08)-executor.deniability*.0023,.06,.82);
  const attributed=detected&&rng()<attributionChance;
  const evidence=detected?v154Clamp01(20+targetCI*.45+(attributed?28:0)+rng()*22-executor.deniability*.16):0;
  return{success,detected,attributed,evidence,successChance,detectChance};
}
function v154RecordOperation(op){
  const x=game.gm.v154;x.operations.unshift(op);x.operations=x.operations.slice(0,160);x.stats.operations++;if(op.success)x.stats.successes++;if(op.detected)x.stats.detected++;if(op.attributed)x.stats.attributed++;if(op.type==='assassination')x.stats.assassinations++;if(op.type==='unmarked_force')x.stats.unmarked++;if(op.executor?.decisionOrigin==='autonomous_parallel')x.stats.autonomousActions++;
  const p=x.policies[op.sponsor];if(p){p.operations=(p.operations||0)+1;p.lastAction=game.day;p.capacity=v154Clamp01(p.capacity-(op.type==='assassination'?12:op.type==='unmarked_force'?10:6));}
}
function v154ApplyBlowback(op,severity=10){
  const targetGov=game.gm.governments?.[op.targetFaction];if(targetGov)targetGov.internalSecurity=v154Clamp01((targetGov.internalSecurity||50)+Math.min(3,severity*.07));
  if(!op.attributed)return;
  const sponsorGov=game.gm.governments?.[op.sponsor];
  if(sponsorGov){sponsorGov.stability=v154Clamp01((sponsorGov.stability||55)-severity*.022);sponsorGov.cohesion=v154Clamp01((sponsorGov.cohesion||55)-severity*.018)}
  const p=game.gm.v154.policies?.[op.sponsor];if(p)p.capacity=v154Clamp01(p.capacity-Math.min(5,severity*.10));
  if(op.executor?.type==='parallel'&&op.executor?.decisionOrigin==='autonomous_parallel'){
    const o=game.gm.parallelForces?.[op.executor.id];if(o){o.governmentRelation=v154Clamp01((o.governmentRelation??50)-severity*.30);o.loyalty=v154Clamp01((o.loyalty??55)-severity*.08)}
  }
}
function v154PublicExposure(op,severity=10){
  if(!op.detected)return;
  v154RaiseSecurityAlert(op.targetFaction,8+severity*.42,op.attributed?'外国工作の帰属確定':'秘密活動を検知');
  if(op.attributed){
    v154ApplyBlowback(op,severity);v154ChangeTension(op.sponsor,op.targetFaction,severity);
    const rogue=op.executor?.decisionOrigin==='autonomous_parallel'?' 実行組織が政府の正式承認を得ていたかは不明。':'';
    const text=`${v154LabelFaction(op.sponsor)}による${V154_OPERATION_LABELS[op.type]||op.type}への関与を示す証拠が公表された。${v154LabelFaction(op.targetFaction)}は公式に抗議し、安全保障態勢を引き上げた。${rogue}`;
    gmNews(`【秘密工作露見】${text}`);
    v138MajorEvent('国家秘密工作の露見',text,'politics',severity>=18?'critical':'major',`v154exp:${op.id}`);
    if(typeof v145MoeObserve==='function')v145MoeObserve(text,{priority:severity,source:'v154'});
  }else{
    const text=`${v154LabelFaction(op.targetFaction)}当局が${V154_OPERATION_LABELS[op.type]||op.type}の痕跡を確認したが、実行主体の特定には至っていない。`;
    gmNews(`【所属不明の秘密活動】${text}`);
    game.gm.v154.investigations.unshift({id:`inv154-${op.id}`,operationId:op.id,targetFaction:op.targetFaction,suspectedSponsor:op.sponsor,evidence:op.evidence||20,status:'active',started:game.day,lastDay:game.day-1});
  }
}

function v154Sponsorship(region){
  if(!region)return null;
  const x=game.gm.v154,s=x.sponsorships[region.id];
  if(s&&s.status==='active')return s;
  return null;
}
function v154StartSponsorship(sponsor,region,type='political_support'){
  if(!region||region.parent===sponsor)return null;
  const x=game.gm.v154,p=x.policies[sponsor],executor=v154ChooseExecutor(sponsor,type,region,region.parent);if(!p||!executor)return null;
  const out=v154OperationOutcome({type,sponsor},executor,region.parent),id=`v154-${type}-${game.day}-${Math.floor(rng()*1e8)}`;
  const op={id,day:game.day,type,sponsor,targetFaction:region.parent,regionId:region.id,system:region.system,executor:{type:executor.type,id:executor.id,name:executor.name,authorized:executor.authorized!==false,decisionOrigin:executor.decisionOrigin||executor.type,decisionScore:Math.round(executor.decisionScore||0)},success:out.success,detected:out.detected,attributed:out.attributed,evidence:out.evidence,status:'resolved'};
  if(out.success){
    let s=x.sponsorships[region.id];
    if(!s||s.status!=='active')s=x.sponsorships[region.id]={id:`sponsor-${region.id}`,regionId:region.id,system:region.system,parent:region.parent,sponsor,status:'active',started:game.day,lastDay:game.day,influence:0,political:0,material:0,force:0,history:[]};
    if(s.sponsor!==sponsor&&s.influence<55){s.sponsor=sponsor;s.influence=Math.max(8,s.influence-10)}
    const gain=type==='proxy_support'?11+rng()*9:7+rng()*8;
    s.influence=v154Clamp01(s.influence+gain);s.lastDay=game.day;s.political=v154Clamp01(s.political+(type==='political_support'?gain:gain*.35));s.material=v154Clamp01(s.material+(type==='proxy_support'?gain:gain*.25));s.history.unshift({day:game.day,type,executor:executor.type,detected:out.detected,attributed:out.attributed});s.history=s.history.slice(0,30);
    const i=region.independence;i.externalSupport=v154Clamp01((i.externalSupport||0)+(type==='proxy_support'?7:4));i.organization=v154Clamp01(i.organization+(type==='proxy_support'?3.8:2.3));i.support=v154Clamp01(i.support+(type==='political_support'?1.8:.8));region.centralTrust=v154Clamp01(region.centralTrust-(type==='political_support'?.8:.35));
  }
  v154RecordOperation(op);v154PublicExposure(op,type==='proxy_support'?11:8);return op;
}
function v154SponsorshipCandidate(sponsor){
  const p=game.gm.v154.policies[sponsor];if(!p||p.capacity<18)return null;
  const rows=[];
  for(const r of v138ActiveRegions()){
    if(!r.independence||r.parent===sponsor)continue;
    const tension=v154PairTension(sponsor,r.parent),adj=v154AdjacentToRegion(sponsor,r),existing=v154Sponsorship(r);
    if(existing&&existing.sponsor!==sponsor&&existing.influence>48)continue;
    const grievance=(100-r.centralTrust)*.34+r.unrest*.22+(r.independence.support||0)*.36+(r.independence.organization||0)*.20;
    let score=grievance+tension*.42+p.expansion*.26+(adj?20:-10)+(existing?.sponsor===sponsor?12:0)+rng()*20;
    if(tension<42)score-=28;if((r.independence.support||0)<15)score-=16;
    rows.push({region:r,score,tension,adj});
  }
  return rows.sort((a,b)=>b.score-a.score)[0]||null;
}
function v154MaybeSponsorSeparatism(fid){
  const p=game.gm.v154.policies[fid];if(!p||game.day-(p.lastAction||0)<4||rng()>.085)return;
  const c=v154SponsorshipCandidate(fid);if(!c||c.score<73)return;
  const type=(c.region.independence.organization||0)>34&&p.aggression>58&&rng()<.48?'proxy_support':'political_support';
  v154StartSponsorship(fid,c.region,type);
}

function v154ActiveCivilWarForRegion(region){
  const crisis=Object.values(game.gm.secessionCrises||{}).find(c=>c.system===region.system&&c.status==='civil_war');
  return crisis?.civilWarId?game.gm.civilWars?.[crisis.civilWarId]:null;
}
function v154CreateUnmarkedForce(sponsor,region){
  const s=v154Sponsorship(region),p=game.gm.v154.policies[sponsor];if(!s||s.sponsor!==sponsor||!p||game.gm.v154.unmarkedForces[region.id]?.status==='active')return null;
  const executor=v154ChooseExecutor(sponsor,'unmarked_force',region,region.parent);if(!executor)return null;
  const out=v154OperationOutcome({type:'unmarked_force',sponsor},executor,region.parent),id=`v154-unmarked-${game.day}-${Math.floor(rng()*1e8)}`;
  const power=Math.round((5+p.aggression*.08+executor.skill*.05+s.influence*.06)*(0.8+rng()*.4)*10)/10;
  const op={id,day:game.day,type:'unmarked_force',sponsor,targetFaction:region.parent,regionId:region.id,system:region.system,executor:{type:executor.type,id:executor.id,name:executor.name,authorized:executor.authorized!==false,decisionOrigin:executor.decisionOrigin||executor.type,decisionScore:Math.round(executor.decisionScore||0)},success:out.success,detected:out.detected,attributed:out.attributed,evidence:out.evidence,status:'resolved',power};
  if(out.success){
    game.gm.v154.unmarkedForces[region.id]={id:`ug-${region.system}-${game.day}`,regionId:region.id,system:region.system,sponsor,targetFaction:region.parent,executorType:executor.type,publicAttribution:out.attributed?sponsor:null,power,status:'active',started:game.day,endDay:game.day+4+Math.floor(rng()*6),lastDay:game.day-1};
    s.force=v154Clamp01(s.force+12);s.influence=v154Clamp01(s.influence+8);region.independence.externalSupport=v154Clamp01((region.independence.externalSupport||0)+9);region.independence.organization=v154Clamp01(region.independence.organization+5);region.militaryInfluence=v154Clamp01(region.militaryInfluence+3);
    const cw=v154ActiveCivilWarForRegion(region);if(cw){cw.rebelStrength+=power*.42;cw.rebelLogistics=v154Clamp01(cw.rebelLogistics+5);cw.rebelMorale=v154Clamp01(cw.rebelMorale+3)}
    gmNews(`【所属不明部隊】${SYSTEMS[region.system]?.name||region.system}で識別標識を持たない武装部隊の活動が確認された。現地独立派は関係を否定している。`);
  }
  v154RecordOperation(op);v154PublicExposure(op,16);return op;
}
function v154MaybeDeployUnmarked(fid){
  const p=game.gm.v154.policies[fid];if(!p||p.capacity<28||game.day-(p.lastAction||0)<4||rng()>.045)return;
  const candidates=[];
  for(const r of v138ActiveRegions()){
    const s=v154Sponsorship(r);if(!s||s.sponsor!==fid||s.influence<42)continue;
    const tension=v154PairTension(fid,r.parent),crisis=v139ActiveCrisisForRegion(r),cw=v154ActiveCivilWarForRegion(r);
    let score=s.influence*.40+(r.independence.organization||0)*.28+tension*.30+(crisis?18:0)+(cw?24:0)+(v154AdjacentToRegion(fid,r)?14:0)+rng()*16;
    candidates.push({r,score});
  }
  const best=candidates.sort((a,b)=>b.score-a.score)[0];if(best&&best.score>74)v154CreateUnmarkedForce(fid,best.r);
}
function v154ProcessUnmarkedForces(){
  for(const [key,u] of Object.entries(game.gm.v154.unmarkedForces)){
    if(!u||u.status!=='active')continue;
    if(u.lastDay===game.day)continue;u.lastDay=game.day;
    const r=game.gm.regionalPolitics[u.regionId]||v135RegionBySystem(u.system);
    if(!r||game.day>=(u.endDay||game.day)){u.status='withdrawn';continue}
    r.independence.externalSupport=v154Clamp01((r.independence.externalSupport||0)+.42);r.independence.organization=v154Clamp01(r.independence.organization+.24);
    const cw=v154ActiveCivilWarForRegion(r);if(cw){cw.rebelStrength+=u.power*.035;cw.rebelLogistics=v154Clamp01(cw.rebelLogistics+.16)}
    if(game.day>=u.endDay)u.status='withdrawn';
  }
}

function v154AssassinationTarget(targetFaction,sponsor){
  const gov=game.gm.governments?.[targetFaction];if(!gov)return null;
  const supported=Object.values(game.gm.v154.sponsorships||{}).filter(s=>s.status==='active'&&s.sponsor===sponsor&&s.parent===targetFaction).sort((a,b)=>b.influence-a.influence)[0];
  const region=supported&&(game.gm.regionalPolitics[supported.regionId]||v135RegionBySystem(supported.system));
  if(region&&region.officials&&rng()<.44){
    const role=(region.independence.organization||0)>55?'security':'executive',o=region.officials[role];if(o)return{kind:'regional',regionId:region.id,role,name:o.name,title:o.title||role};
  }
  const roles=['defense','interior','foreign'];if(v154PairTension(sponsor,targetFaction)>88||game.war?.active&&[sponsor,targetFaction].every(x=>[game.war.a,game.war.b].includes(x)))roles.unshift('chief');
  const role=roles[Math.floor(rng()*roles.length)],o=role==='chief'?gov.chief:gov.ministers?.[role];
  return o?{kind:'central',role,name:o.name,title:o.title||role}:null;
}
function v154ApplyAssassination(targetFaction,target){
  if(!target)return;
  if(target.kind==='regional'){
    const r=game.gm.regionalPolitics[target.regionId];if(!r)return;
    r.officials[target.role]=v135RegionalOfficial(r,target.role);r.unrest=v154Clamp01(r.unrest+7);r.legitimacy=v154Clamp01(r.legitimacy-4);r.centralTrust=v154Clamp01(r.centralTrust-2);if(r.independence){r.independence.support=v154Clamp01(r.independence.support+2);r.independence.organization=v154Clamp01(r.independence.organization+1.5)}
    r.history.unshift({day:game.day,text:`${target.title} ${target.name}が暗殺され、後任が就任`});r.history=r.history.slice(0,60);
  }else{
    const g=game.gm.governments?.[targetFaction];if(!g)return;
    if(target.role==='chief')g.chief=v134Official('chief',g.regimeId);else g.ministers[target.role]=v134Official(target.role,g.regimeId);
    g.stability=v154Clamp01(g.stability-(target.role==='chief'?5:2.5));g.cohesion=v154Clamp01(g.cohesion-(target.role==='chief'?6:3));g.internalSecurity=v154Clamp01(g.internalSecurity+4);
    g.history.unshift({day:game.day,text:`${target.title} ${target.name}暗殺を受けて後任人事と警護強化を実施`});g.history=g.history.slice(0,60);
  }
}
function v154MaybeAssassinate(fid){
  const p=game.gm.v154.policies[fid];if(!p||game.day-(p.lastAssassination||0)<12)return;
  const autonomousPotential=v154ParallelCandidates(fid).some(o=>(o.autonomy??0)>66&&(o.influence??0)>42&&(o.readiness??50)>42);
  if((p.capacity<32||p.aggression<48)&&!autonomousPotential)return;if(rng()>(.026+(autonomousPotential ? .010 : 0)))return;
  const candidates=v154NpcStates().filter(x=>x!==fid).map(target=>{const tension=v154PairTension(fid,target),war=game.war?.active&&[fid,target].every(x=>[game.war.a,game.war.b].includes(x));const targetGov=game.gm.governments[target];return{target,score:tension*.62+(war?35:0)+(100-(targetGov?.stability||60))*.14+p.aggression*.12+rng()*16,tension}}).sort((a,b)=>b.score-a.score);
  const c=candidates[0];if(!c||c.tension<68||c.score<75)return;
  const target=v154AssassinationTarget(c.target,fid),executor=v154ChooseExecutor(fid,'assassination',null,c.target);if(!target||!executor)return;
  const out=v154OperationOutcome({type:'assassination',sponsor:fid},executor,c.target),id=`v154-assassination-${game.day}-${Math.floor(rng()*1e8)}`;
  const op={id,day:game.day,type:'assassination',sponsor:fid,targetFaction:c.target,target:{...target},system:null,executor:{type:executor.type,id:executor.id,name:executor.name,authorized:executor.authorized!==false,decisionOrigin:executor.decisionOrigin||executor.type,decisionScore:Math.round(executor.decisionScore||0)},success:out.success,detected:out.detected,attributed:out.attributed,evidence:out.evidence,status:'resolved'};
  p.lastAssassination=game.day;
  if(out.success){v154ApplyAssassination(c.target,target);gmNews(`【要人暗殺】${v154LabelFaction(c.target)}の${target.title} ${target.name}が暗殺された。治安当局は国家関与を含む複数の可能性を捜査している。`);v138MajorEvent('国家要人暗殺',`${v154LabelFaction(c.target)}の${target.title} ${target.name}が暗殺された。後任人事と警護強化が開始され、国内政治と対外関係が不安定化している。`,'politics','critical',`v154ass:${id}`)}else if(out.detected)gmNews(`【暗殺未遂】${v154LabelFaction(c.target)}当局が${target.title}を狙った暗殺計画を阻止した。実行主体の特定が進められている。`);
  v154RecordOperation(op);v154PublicExposure(op,22);
}

function v154ProcessCounterIntelligence(){
  const x=game.gm.v154;
  for(const fid of v154NpcStates()){
    const a=x.alerts[fid]||(x.alerts[fid]={level:0,lastDay:game.day,history:[]});
    const decay=.45+(game.gm.governments?.[fid]?.internalSecurity||50)*.0025;a.level=v154Clamp01((a.level||0)-decay);a.lastDay=game.day;
  }
  for(const s of Object.values(x.sponsorships||{})){
    if(!s||s.status!=='active')continue;const r=game.gm.regionalPolitics?.[s.regionId]||v135RegionBySystem(s.system);if(!r)continue;
    const alert=v154SecurityAlert(r.parent);if(alert<48)continue;
    const pressure=(alert-45)*.008;s.influence=v154Clamp01(s.influence-pressure);
    if(r.independence)r.independence.externalSupport=v154Clamp01((r.independence.externalSupport||0)-pressure*.20);
    if(rng()<clamp((alert-48)*.0035,.01,.16)){s.material=v154Clamp01(s.material-(1+rng()*2));x.stats.disruptions++;s.history.unshift({day:game.day,type:'counterintel_disruption',alert:Math.round(alert)});s.history=s.history.slice(0,30)}
  }
}

function v154ProcessInvestigations(){
  for(const inv of game.gm.v154.investigations){
    if(inv.status!=='active'||inv.lastDay===game.day)continue;inv.lastDay=game.day;
    const op=game.gm.v154.operations.find(x=>x.id===inv.operationId);if(!op){inv.status='closed';continue}
    const ci=v154TargetCounterIntel(inv.targetFaction);inv.evidence=v154Clamp01((inv.evidence||0)+ci*.025+rng()*1.8-.35);
    if(inv.evidence>58&&rng()<clamp(.04+(inv.evidence-55)*.006+ci*.001,.04,.34)){
      inv.status='attributed';inv.resolvedDay=game.day;op.attributed=true;op.detected=true;op.evidence=inv.evidence;game.gm.v154.stats.attributed++;v154PublicExposure(op,op.type==='assassination'?22:op.type==='unmarked_force'?17:10);
    }else if(game.day-inv.started>24&&inv.evidence<45){inv.status='cold';inv.resolvedDay=game.day}
  }
}

function v154SponsorForFormerRegion(oldRegionId,system){
  const x=game.gm.v154,s=x.sponsorships[oldRegionId];if(s?.status==='active')return s;
  return Object.values(x.sponsorships).filter(a=>a.status==='active'&&a.system===system).sort((a,b)=>b.influence-a.influence)[0]||null;
}
function v154CreateSphere(subject,patron,kind,influence=55){
  if(!subject||!patron||subject===patron)return null;
  const x=game.gm.v154,old=x.spheres[subject]||{},sphere=x.spheres[subject]={subject,patron,kind,started:old.started||game.day,status:'active',influence:v154Clamp01(Math.max(old.influence||0,influence)),militaryAccess:['security_client','protectorate','puppet_state'].includes(kind),tradeAlignment:true,history:Array.isArray(old.history)?old.history:[]};
  sphere.history.unshift({day:game.day,text:`${V154_SPHERE_LABELS[kind]||kind}として${v154LabelFaction(patron)}の勢力圏へ参加`});sphere.history=sphere.history.slice(0,30);
  const st=game.gm.breakawayStates?.[subject];if(st){st.v154Patron=patron;st.v154SphereKind=kind;st.policyNote=`${v154LabelFaction(patron)}との安全保障・通商協調を優先`;}
  gmNews(`【勢力圏形成】${v154LabelFaction(subject)}が${v154LabelFaction(patron)}の${V154_SPHERE_LABELS[kind]||kind}となった。形式上の主権は維持される。`);
  return sphere;
}
function v154QueueAnnexation(st,sponsor,sp){
  if(!st||!sponsor||game.gm.v154.annexationRequests.some(q=>q.subject===st.id&&q.status==='pending'))return null;
  const q={id:`annexreq-${st.id}-${game.day}`,subject:st.id,sponsor,formerParent:st.formerParent,system:st.system,created:game.day,resolveDay:game.day+2+Math.floor(rng()*3),status:'pending',support:sp?.influence||0};game.gm.v154.annexationRequests.unshift(q);
  gmNews(`【編入要請】${st.name}政府が${v154LabelFaction(sponsor)}への編入要請を採択した。後援国政府が受諾可否を審査している。`);return q;
}
function v154PostIndependence(st,oldRegionId){
  const sp=v154SponsorForFormerRegion(oldRegionId,st.system);if(!sp||sp.influence<38)return;
  sp.status='completed';sp.subject=st.id;sp.completedDay=game.day;
  const p=game.gm.v154.policies[sp.sponsor]||{},adj=v154AdjacentToSystem(sp.sponsor,st.system),formerTension=v154PairTension(sp.sponsor,st.formerParent);
  const annexScore=sp.influence*.44+p.expansion*.32+(adj?22:-8)+formerTension*.10+(100-(st.stability||58))*.08;
  if(sp.influence>=68&&adj&&annexScore>82&&rng()<.58){v154QueueAnnexation(st,sp.sponsor,sp);return}
  const kind=sp.influence>84&&st.stability<58?'puppet_state':sp.influence>70?'protectorate':sp.influence>55?'security_client':'aligned_state';v154CreateSphere(st.id,sp.sponsor,kind,sp.influence);
}
function v154ResolveAnnexation(q){
  const st=game.gm.breakawayStates?.[q.subject],p=game.gm.v154.policies[q.sponsor];if(!st||!p||!['recognized','independent'].includes(st.status)){q.status='invalid';return}
  const parentStrength=v154StateStrength(st.formerParent),sponsorStrength=v154StateStrength(q.sponsor),tension=v154PairTension(q.sponsor,st.formerParent),acceptScore=p.expansion*.38+q.support*.32+(sponsorStrength>parentStrength?15:3)+tension*.10+(v154AdjacentToSystem(q.sponsor,st.system)?18:-25)+rng()*14;
  if(acceptScore<72){q.status='rejected';q.resolvedDay=game.day;v154CreateSphere(st.id,q.sponsor,q.support>72?'security_client':'aligned_state',q.support);gmNews(`【編入要請保留】${v154LabelFaction(q.sponsor)}は${st.name}の編入を見送り、独立国家としての安全保障協力を選択した。`);return}
  const oldRegion=v135RegionBySystem(st.system),oldId=oldRegion?.id;SYSTEMS[st.system].faction=q.sponsor;st.status='annexed';st.annexedDay=game.day;st.annexedBy=q.sponsor;
  if(oldRegion){delete game.gm.regionalPolitics[oldId];oldRegion.parent=q.sponsor;oldRegion.id=v135RegionKey(q.sponsor,oldRegion.system);oldRegion.name=v135RegionName(q.sponsor,oldRegion.system,oldRegion.regimeId);oldRegion.autonomy=clamp(Math.max(42,oldRegion.autonomy-22),0,100);oldRegion.centralTrust=46;oldRegion.independence.status='dormant';oldRegion.independence.support=v154Clamp01(oldRegion.independence.support*.42);oldRegion.independence.organization=v154Clamp01(oldRegion.independence.organization*.45);oldRegion.status='active';game.gm.regionalPolitics[oldRegion.id]=oldRegion;}
  q.status='accepted';q.resolvedDay=game.day;game.gm.v154.stats.annexations++;delete game.gm.v154.spheres[st.id];v154ChangeTension(q.sponsor,st.formerParent,28);
  const sg=game.gm.governments?.[q.sponsor];if(sg)sg.stability=v154Clamp01(sg.stability-1.2);
  const text=`${st.name}の編入要請を${v154LabelFaction(q.sponsor)}が受諾し、${SYSTEMS[st.system]?.name||st.system}の主権移管を宣言した。旧母国 ${v154LabelFaction(st.formerParent)} は強く反発している。`;
  gmNews(`【編入成立】${text}`);v138MajorEvent('編入・主権移管',text,'collapse','critical',`v154annex:${q.id}`);if(typeof v145MoeObserve==='function')v145MoeObserve(text,{priority:24,source:'v154'});
}
function v154ProcessAnnexationRequests(){for(const q of game.gm.v154.annexationRequests)if(q.status==='pending'&&game.day>=q.resolveDay)v154ResolveAnnexation(q)}
function v154ProcessSpheres(){
  for(const s of Object.values(game.gm.v154.spheres||{})){
    if(!s||s.status!=='active')continue;const patron=game.gm.factions?.[s.patron],subject=game.gm.factions?.[s.subject],sg=game.gm.governments?.[s.subject];if(!patron||!subject)continue;
    s.influence=v154Clamp01(s.influence-(s.kind==='puppet_state'?.018:.035));
    if(subject.treasury<9000&&patron.treasury>22000&&game.day%7===0){const aid=Math.min(900,Math.round((patron.treasury-20000)*.015));patron.treasury-=aid;subject.treasury+=aid;s.influence=v154Clamp01(s.influence+.8);s.history.unshift({day:game.day,text:`財政・安全保障支援 ${aid.toLocaleString()} Cr`})}
    if(sg){sg.foreignPosture=v154Clamp01(sg.foreignPosture+(s.influence-50)*.0015);if(s.kind==='puppet_state')sg.cohesion=v154Clamp01(sg.cohesion+.012)}
    if(s.influence<24){s.status='loosened';s.ended=game.day;gmNews(`【勢力圏離脱】${v154LabelFaction(s.subject)}が${v154LabelFaction(s.patron)}への政策依存を縮小し、勢力圏から離脱した。`)}
  }
}

// Existing v1.39 civil-war mechanics remain authoritative; v1.54 only injects already-earned external support.
const v154StartCivilWarBase=v139StartCivilWar;
v139StartCivilWar=function(crisis){
  const cw=v154StartCivilWarBase(crisis);try{ensureV154State();const r=crisis&&game.gm.regionalPolitics?.[crisis.regionId],sp=r&&v154Sponsorship(r),u=r&&game.gm.v154.unmarkedForces?.[r.id];if(cw&&sp){cw.rebelStrength+=sp.influence*.055+sp.material*.035;cw.rebelLogistics=v154Clamp01(cw.rebelLogistics+sp.influence*.06);cw.rebelMorale=v154Clamp01(cw.rebelMorale+sp.political*.035);cw.externalSponsor=sp.sponsor}if(cw&&u?.status==='active'){cw.rebelStrength+=u.power*.36;cw.rebelLogistics=v154Clamp01(cw.rebelLogistics+4)}}catch(_){}return cw;
};
const v154FinalizeIndependenceBase=v139FinalizeIndependence;
v139FinalizeIndependence=function(crisis,mode='war'){
  const oldRegionId=crisis?.regionId,st=v154FinalizeIndependenceBase(crisis,mode);try{ensureV154State();if(st)v154PostIndependence(st,oldRegionId)}catch(_){}return st;
};

function v154DecisionLoop(){
  for(const fid of v154NpcStates()){
    const p=game.gm.v154.policies[fid];if(!p)continue;
    const s=game.gm.factions?.[fid]||{},g=game.gm.governments?.[fid]||{};
    p.capacity=v154Clamp01(p.capacity+.34+(s.intel||40)*.003+(g.administrativeCapacity||50)*.0015);
    p.counterIntel=v154TargetCounterIntel(fid);
    v154MaybeSponsorSeparatism(fid);v154MaybeDeployUnmarked(fid);v154MaybeAssassinate(fid);
  }
}
function processV154Daily(){
  ensureV154State();const x=game.gm.v154;if(x.lastDay===game.day)return;x.lastDay=game.day;
  v154ProcessUnmarkedForces();v154ProcessCounterIntelligence();v154ProcessInvestigations();v154ProcessAnnexationRequests();v154ProcessSpheres();v154DecisionLoop();
  x.operations=x.operations.filter(o=>game.day-o.day<220).slice(0,160);x.investigations=x.investigations.filter(i=>i.status==='active'||game.day-(i.resolvedDay||i.started)<90).slice(0,80);
}

function v154OperationPublicStatus(o){return o.attributed?'関与確定':o.detected?'実行主体不明':'未露見'}
function renderV154World(){
  ensureV154State();const x=game.gm.v154,ops=x.operations.slice(0,12),spons=Object.values(x.sponsorships).filter(s=>s.status==='active'),forces=Object.values(x.unmarkedForces).filter(u=>u.status==='active'),spheres=Object.values(x.spheres).filter(s=>s.status==='active'),inv=x.investigations.filter(i=>i.status==='active');
  return `<div id="v154HybridWorld" class="panel"><div class="section-title"><h2>🕶 秘密工作・ハイブリッド介入</h2><span class="pill">v1.54 / COVERT STATECRAFT</span></div><p class="desc">政府・正規軍・国境警備隊・並列武装組織が、権限・緊張度・情報能力・露見リスクを比較して秘密工作を自律判断します。暗殺や非正規介入は抽象化され、成否・発覚・国家帰属の立証が別々に判定されます。</p><div class="station-stock"><div>累計工作<b>${x.stats.operations}</b></div><div>組織独自行動<b>${x.stats.autonomousActions||0}</b></div><div>防諜阻止<b>${x.stats.disruptions||0}</b></div><div>進行中秘密支援<b>${spons.length}</b></div><div>所属不明部隊<b>${forces.length}</b></div><div>勢力圏国家<b>${spheres.length}</b></div></div>${spons.length?`<h3>秘密支援中の独立運動</h3>${spons.slice(0,8).map(s=>{const r=game.gm.regionalPolitics[s.regionId]||v135RegionBySystem(s.system);return `<div class="news-item"><b>${escapeHtml(r?.name||SYSTEMS[s.system]?.name||s.system)}</b> / <span class="sf-public-only">後援国：未特定</span><span class="sf-gm-only">内部後援：${escapeHtml(v154LabelFaction(s.sponsor))}</span><br>影響 ${Math.round(s.influence)} / 政治 ${Math.round(s.political)} / 物資 ${Math.round(s.material)} / 軍事介入 ${Math.round(s.force)}</div>`}).join('')}`:''}${forces.length?`<h3>所属不明部隊</h3>${forces.slice(0,8).map(u=>`<div class="news-item"><b>${escapeHtml(SYSTEMS[u.system]?.name||u.system)}</b> / 戦力 ${Number(u.power).toFixed(1)} / Day ${u.endDay}まで<br>公的帰属：${u.publicAttribution?escapeHtml(v154LabelFaction(u.publicAttribution)):'不明'} / <span class="sf-public-only">内部後援：非公開</span><span class="sf-gm-only">内部後援：${escapeHtml(v154LabelFaction(u.sponsor))}</span></div>`).join('')}`:''}${spheres.length?`<h3>傀儡・保護・勢力圏</h3>${spheres.slice(0,10).map(s=>`<div class="news-item"><b>${escapeHtml(v154LabelFaction(s.subject))}</b> → ${escapeHtml(v154LabelFaction(s.patron))}<br>${escapeHtml(V154_SPHERE_LABELS[s.kind]||s.kind)} / 影響 ${Math.round(s.influence)} / 軍事アクセス ${s.militaryAccess?'あり':'なし'}</div>`).join('')}`:''}${Object.entries(x.alerts).some(([,a])=>(a.level||0)>=35)?`<h3>防諜警戒態勢</h3>${Object.entries(x.alerts).filter(([,a])=>(a.level||0)>=35).sort((a,b)=>(b[1].level||0)-(a[1].level||0)).slice(0,8).map(([fid,a])=>`<div class="news-item"><b>${escapeHtml(v154LabelFaction(fid))}</b> / 警戒 ${Math.round(a.level)} / 防諜 ${Math.round(v154TargetCounterIntel(fid))}</div>`).join('')}`:''}<h3>最近の秘密作戦</h3>${ops.length?ops.map(o=>`<div class="news-item">Day ${o.day}: <b>${escapeHtml(V154_OPERATION_LABELS[o.type]||o.type)}</b> / ${escapeHtml(V154_EXECUTOR_LABELS[o.executor?.type]||o.executor?.type||'不明')}<br><span class="sf-public-only">${o.attributed?escapeHtml(v154LabelFaction(o.sponsor)):'実行主体不明'} → ${escapeHtml(v154LabelFaction(o.targetFaction))}</span><span class="sf-gm-only">内部後援：${escapeHtml(v154LabelFaction(o.sponsor))} → ${escapeHtml(v154LabelFaction(o.targetFaction))}</span> / ${o.success?'成功':'失敗'} / ${escapeHtml(v154OperationPublicStatus(o))}${o.executor?.decisionOrigin==='autonomous_parallel'?' / <b>組織独自行動</b>':''}</div>`).join(''):'<div class="hint">まだ秘密工作記録はありません。</div>'}${inv.length?`<h3>未解決の帰属調査</h3>${inv.slice(0,6).map(i=>`<div class="news-item">${escapeHtml(v154LabelFaction(i.targetFaction))}捜査当局 / 証拠強度 ${Math.round(i.evidence)} / Day ${i.started}開始</div>`).join('')}`:''}</div>`;
}
function renderV154MapStatus(sid){
  ensureV154State();const region=v135RegionBySystem(sid),s=region&&v154Sponsorship(region),u=region&&game.gm.v154.unmarkedForces?.[region.id];if(!s&&!u)return'';
  const publicSponsor=(u?.publicAttribution||game.gm.v154.operations.find(o=>o.regionId===region?.id&&o.attributed)?.sponsor)||null;
  return `<div id="v154MapStatus" class="lore-card"><div class="lore-head"><strong>🕶 ハイブリッド介入</strong><span class="pill">${u?.status==='active'?'所属不明部隊活動中':'秘密支援兆候'}</span></div><div class="kv"><span>外部支援</span><b>${Math.round(region?.independence?.externalSupport||0)}</b></div><div class="kv"><span>公的に確認された後援国</span><b>${publicSponsor?escapeHtml(v154LabelFaction(publicSponsor)):'未特定'}</b></div>${u?.status==='active'?`<div class="kv"><span>識別不能部隊</span><b>戦力 ${Number(u.power).toFixed(1)} / Day ${u.endDay}まで</b></div>`:''}</div>`;
}

const v154RenderGMBase=renderGM;
renderGM=function(){v154RenderGMBase();ensureV154State();document.getElementById('v154HybridWorld')?.remove();document.getElementById('gal-gm')?.insertAdjacentHTML('beforeend',renderV154World())};
const v154RenderMapBase=renderMapDetail;
renderMapDetail=function(){v154RenderMapBase();const el=document.getElementById('mapDetail'),sid=mapSelected||game.system;document.getElementById('v154MapStatus')?.remove();if(el){const h=renderV154MapStatus(sid);if(h)el.insertAdjacentHTML('beforeend',h)}};
const v154GmAdvanceBase=gmAdvance;
gmAdvance=function(){const out=v154GmAdvanceBase();processV154Daily();if(game)game.version=V154_BUILD;return out};
const v154InitBase=initV10;
initV10=function(){const out=v154InitBase();ensureV154State();game.version=V154_BUILD;return out};
const v154LoadBase=load;
load=function(){const out=v154LoadBase();ensureV154State();game.version=V154_BUILD;return out};
const v154SaveBase=save;
save=function(){if(game)game.version=V154_BUILD;return v154SaveBase()};
const v154RenderBase=render;
render=function(){const out=v154RenderBase();ensureV154State();game.version=V154_BUILD;if(typeof document!=='undefined'){const badge=document.querySelector('header .title .badge');if(badge)badge.textContent='v1.54.1';const sub=document.querySelector('header .sub');if(sub)sub.textContent='秘密工作・国家暗殺AI・所属不明部隊・独立工作・編入要請・傀儡/勢力圏AI';document.title='STAR FRONTIER v1.54.1 — Hybrid Intervention';}return out};

if(typeof window!=='undefined')window.StarFrontierHybridIntervention={
  build:V154_BUILD,
  ensure:ensureV154State,
  state:()=>game.gm.v154,
  sponsor:(fid,regionId,type='political_support')=>{ensureV154State();const r=game.gm.regionalPolitics?.[regionId];return r?v154StartSponsorship(fid,r,type):null},
  deployUnmarked:(fid,regionId)=>{ensureV154State();const r=game.gm.regionalPolitics?.[regionId];return r?v154CreateUnmarkedForce(fid,r):null},
  spheres:()=>game.gm.v154.spheres,
  alerts:()=>game.gm.v154.alerts
};
