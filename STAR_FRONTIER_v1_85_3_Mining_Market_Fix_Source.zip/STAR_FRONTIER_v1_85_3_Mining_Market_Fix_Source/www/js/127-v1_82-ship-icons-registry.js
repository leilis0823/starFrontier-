'use strict';
// ============================================================================
// v1.82.0 — Procedural 2D ship icons + ship registry / profiles
// - Replaces missing ship image assets with deterministic SVG silhouettes.
// - Adds a ship operations/profile panel and registry view in the Ship tab.
// - Does not change simulation balance or version metadata.
// ============================================================================
(function(){
 const clamp01=(n,min=0,max=100)=>Math.max(min,Math.min(max,Number(n)||0));
 const ICON_BG='#07131f';
 const CLASS_THEMES={
  prospect:{primary:'#7dd9ff',secondary:'#214d73',glow:'#9fe7ff',badge:'PROSPECT'},
  freighter:{primary:'#7fe0b5',secondary:'#215842',glow:'#b7ffd6',badge:'FREIGHTER'},
  corvette:{primary:'#ffb56d',secondary:'#624019',glow:'#ffd9b1',badge:'CORVETTE'},
  frigate:{primary:'#cfb6ff',secondary:'#4a2f73',glow:'#ecdcff',badge:'FRIGATE'},
  cruiser:{primary:'#ff8f95',secondary:'#69262b',glow:'#ffc3c6',badge:'CRUISER'},
  carrier:{primary:'#d6dfef',secondary:'#425669',glow:'#ffffff',badge:'CARRIER'},
  battleship:{primary:'#ffd163',secondary:'#6e5618',glow:'#ffe7a4',badge:'BATTLESHIP'},
  dread:{primary:'#ff6767',secondary:'#6f1f1f',glow:'#ffc0c0',badge:'DREAD'},
  dreadnought:{primary:'#ff6767',secondary:'#6f1f1f',glow:'#ffc0c0',badge:'DREAD'}
 };
 const MAKER_COLORS={
  regulus:'#63d7ff',horizon:'#ffb460',nox:'#b694ff',pilgrim:'#8be3b2',meridian:'#ff9aa6',helix:'#7be3cc',
  arclight:'#ffcc72',bulwark:'#9fc4ff',synapse:'#f2a8ff',asterion:'#ff8a8a',crownforge:'#d6b25f',
  crownstar:'#d6b25f',crownstar_materials:'#d6b25f',demeter:'#e4cc6e',njord:'#9db8ff',sleipnir:'#9fd4ff',
  origin:'#c8d3e4',vector:'#d5abff'
 };
 const REGISTRY_STATE={filter:'recommended',limit:18};
 const ROLE_LABELS={mining:'採掘',trade:'交易',combat:'戦闘',range:'航続',support:'支援'};
 const LOOP_LABELS={mining:'鉱石採掘・深部探査',trade:'交易・船団輸送',combat:'軍務・私掠・護衛',range:'長距離航海・調査遠征',support:'艦隊支援・救難・復旧'};
 
 function sfRegistryEnsureMount(){
  const shipTab=document.getElementById('ship'); if(!shipTab) return null;
  let panel=document.getElementById('sfShipRegistryPanel');
  if(panel) return panel;
  panel=document.createElement('div');
  panel.id='sfShipRegistryPanel';
  panel.className='panel';
  const saveWrap=shipTab.querySelector?.('.reset-wrap');
  if(saveWrap&&saveWrap.parentElement===shipTab) shipTab.insertBefore(panel,saveWrap);
  else shipTab.appendChild(panel);
  return panel;
 }
 function sfHullRef(id){
  if(HULLS?.[id]) return HULLS[id];
  const p=(game?.prizeShips||[]).find(x=>x.uid===id);
  return p&&HULLS?.[p.baseHull]?{...HULLS[p.baseHull],name:p.name,baseHull:p.baseHull,captured:true,origin:p.origin}:HULLS?.nomad||null;
 }
 function sfHullAssetKey(id){
  if(HULLS?.[id]) return id;
  const p=(game?.prizeShips||[]).find(x=>x.uid===id);
  return p?.baseHull||id;
 }
 function sfHullTheme(id){
  const h=sfHullRef(id)||{};
  const base=CLASS_THEMES[h.class]||CLASS_THEMES.prospect;
  const accent=MAKER_COLORS[h.maker]||base.primary;
  return {...base,accent};
 }
 function sfIconBodyGeometry(cls){
  switch(cls){
   case 'prospect': return {
    main:'M44 69 L86 56 L136 58 L188 47 L232 50 L276 70 L232 90 L188 93 L136 82 L86 84 Z',
    details:['M86 57 L101 45 L121 42 L118 58 Z','M132 61 L173 61 L195 70 L173 79 L132 79 Z','M214 51 L237 42 L257 44 L247 57 Z'],
    pods:[['60','83','16','10'],['93','82','18','11'],['214','81','25','11']],
    engines:[[39,70,7],[31,70,5]], bridge:['111','49','16','10']
   };
   case 'freighter': return {
    main:'M32 72 L63 52 L110 52 L148 46 L208 46 L255 58 L286 74 L255 90 L208 94 L148 94 L110 88 L63 88 Z',
    details:['M76 52 L76 88','M112 53 L112 89','M151 47 L151 94','M208 47 L208 93','M244 57 L264 50 L279 58'],
    pods:[['53','87','22','12'],['82','87','21','12'],['119','89','24','10'],['156','94','28','10'],['196','94','32','10']],
    engines:[[26,74,8],[18,74,5]], bridge:['228','49','14','8']
   };
   case 'corvette': return {
    main:'M34 70 L89 47 L153 54 L248 60 L289 70 L248 80 L153 86 L89 93 Z',
    details:['M92 55 L133 70 L92 85 Z','M162 58 L217 58 L241 70 L217 82 L162 82 Z'],
    pods:[['110','85','18','9'],['177','82','20','8']],
    engines:[[28,70,7],[20,70,4]], bridge:['141','50','12','7']
   };
   case 'frigate': return {
    main:'M28 70 L81 46 L149 46 L208 56 L272 61 L297 70 L272 79 L208 84 L149 94 L81 94 Z',
    details:['M96 47 L130 70 L96 93 Z','M149 47 L149 94','M170 57 L221 57 L245 70 L221 83 L170 83 Z'],
    pods:[['86','93','24','9'],['171','84','26','10'],['225','79','20','8']],
    engines:[[21,70,8],[12,70,5]], bridge:['152','48','15','8']
   };
   case 'cruiser': return {
    main:'M22 70 L71 42 L139 42 L196 50 L243 50 L287 61 L308 70 L287 79 L243 90 L196 90 L139 98 L71 98 Z',
    details:['M86 46 L122 70 L86 94 Z','M140 43 L140 98','M180 52 L233 52 L260 70 L233 88 L180 88 Z','M253 51 L279 44 L297 53'],
    pods:[['72','98','30','10'],['181','89','31','10'],['244','90','24','9']],
    engines:[[16,70,8],[8,70,5]], bridge:['147','44','16','8']
   };
   case 'carrier': return {
    main:'M24 70 L68 48 L118 48 L151 40 L196 40 L225 48 L265 48 L298 60 L312 70 L298 80 L265 92 L225 92 L196 100 L151 100 L118 92 L68 92 Z',
    details:['M78 48 L78 92','M118 48 L118 92','M152 41 L152 100','M196 41 L196 99','M231 48 L231 92','M255 48 L255 92'],
    pods:[['54','92','18','10'],['98','92','18','10'],['140','100','20','10'],['187','99','21','10'],['241','92','18','10']],
    engines:[[17,63,6],[17,77,6],[9,70,4]], bridge:['207','42','14','8']
   };
   case 'battleship': return {
    main:'M18 70 L64 40 L138 40 L188 47 L233 47 L281 58 L312 70 L281 82 L233 93 L188 93 L138 100 L64 100 Z',
    details:['M87 44 L122 70 L87 96 Z','M138 41 L138 100','M169 49 L223 49 L252 70 L223 91 L169 91 Z','M259 52 L287 44 L304 53'],
    pods:[['67','100','27','11'],['172','92','34','12'],['241','93','30','11']],
    engines:[[14,61,6],[14,79,6],[7,70,4]], bridge:['146','42','18','9']
   };
   case 'dread':
   case 'dreadnought':
    return {
     main:'M14 70 L59 36 L140 36 L198 44 L253 44 L303 57 L322 70 L303 83 L253 96 L198 96 L140 104 L59 104 Z',
     details:['M86 42 L126 70 L86 98 Z','M141 37 L141 104','M176 46 L241 46 L272 70 L241 94 L176 94 Z','M278 49 L309 42 L320 50'],
     pods:[['58','104','30','12'],['174','95','40','12'],['253','96','32','11']],
     engines:[[10,60,6],[10,80,6],[3,70,4]], bridge:['150','39','19','10']
    };
   default: return sfIconBodyGeometry('prospect');
  }
 }
 function sfShipGeneratedIconSvg(id,opts={}){
  const h=sfHullRef(id)||{};
  const theme=sfHullTheme(id), geom=sfIconBodyGeometry(h.class||'prospect');
  const width=opts.width||320, height=opts.height||140;
  const label=(SHIP_CLASSES?.[h.class]?.name)||'艦艇';
  const maker=(h.maker&&V17_CORPORATIONS?.[h.maker]?.short)||'';
  const badge=(theme.badge||String(h.class||'SHIP').toUpperCase()).slice(0,16);
  const currentName=opts.title||h.name||'SHIP';
  const starDots=Array.from({length:18},(_,i)=>{
   const x=18+((i*47)%284), y=12+((i*29)%116), r=(i%4===0)?1.5:(i%3===0?1.1:0.8), op=(i%4===0)?'.55':'.35';
   return `<circle cx="${x}" cy="${y}" r="${r}" fill="#dfefff" opacity="${op}"/>`;
  }).join('');
  const detailLines=(geom.details||[]).map(d=>/^M/.test(d)?`<path d="${d}" fill="none" stroke="${theme.glow}" stroke-width="3" stroke-linecap="round" opacity=".55"/>`:'').join('');
  const cargoPods=(geom.pods||[]).map(p=>`<rect x="${p[0]}" y="${p[1]}" width="${p[2]}" height="${p[3]}" rx="4" fill="${theme.secondary}" stroke="${theme.accent}" stroke-width="2" opacity=".92"/>`).join('');
  const engines=(geom.engines||[]).map(e=>`<g><circle cx="${e[0]}" cy="${e[1]}" r="${e[2]}" fill="${theme.glow}" opacity=".18"/><circle cx="${e[0]}" cy="${e[1]}" r="${Math.max(2,e[2]-2)}" fill="${theme.glow}" opacity=".68"/></g>`).join('');
  const bridge=geom.bridge?`<rect x="${geom.bridge[0]}" y="${geom.bridge[1]}" width="${geom.bridge[2]}" height="${geom.bridge[3]}" rx="3" fill="#e9f5ff" opacity=".85"/>`:'';
  const fins=(h.class==='carrier'||h.class==='freighter')?`<path d="M119 48 L105 30 L120 33 L134 48" fill="${theme.accent}" opacity=".6"/><path d="M224 48 L238 30 L223 33 L209 48" fill="${theme.accent}" opacity=".6"/>`:'';
  const outline=h.special?`<rect x="7" y="7" width="306" height="126" rx="16" fill="none" stroke="#d6b25f" stroke-width="2.4" opacity=".6"/>`:'';
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 320 140" role="img" aria-label="${currentName}">
 <defs>
  <linearGradient id="bg" x1="0" x2="1" y1="0" y2="1"><stop offset="0%" stop-color="#081423"/><stop offset="100%" stop-color="#10253a"/></linearGradient>
  <linearGradient id="body" x1="0" x2="1"><stop offset="0%" stop-color="${theme.secondary}"/><stop offset="55%" stop-color="${theme.primary}"/><stop offset="100%" stop-color="#eff8ff"/></linearGradient>
  <linearGradient id="stripe" x1="0" x2="1"><stop offset="0%" stop-color="${theme.accent}"/><stop offset="100%" stop-color="${theme.glow}"/></linearGradient>
  <filter id="shadow"><feDropShadow dx="0" dy="4" stdDeviation="4" flood-color="#000" flood-opacity=".35"/></filter>
 </defs>
 <rect width="320" height="140" rx="16" fill="url(#bg)"/>
 <path d="M0 101 C61 86, 129 117, 320 86 L320 140 L0 140 Z" fill="#173048" opacity=".55"/>
 <path d="M0 22 C100 14, 186 38, 320 16 L320 0 L0 0 Z" fill="#173048" opacity=".35"/>
 <g>${starDots}</g>
 <g opacity=".16" stroke="#81b3d6" stroke-width="1">
  <path d="M16 104 H304"/><path d="M16 36 H304"/><path d="M64 20 V120"/><path d="M256 20 V120"/>
 </g>
 <g filter="url(#shadow)">${engines}<path d="${geom.main}" fill="url(#body)" stroke="#eff8ff" stroke-width="2.4" stroke-linejoin="round"/><path d="M70 70 H247" stroke="url(#stripe)" stroke-width="3" opacity=".85"/>${detailLines}${cargoPods}${bridge}${fins}</g>
 <g font-family="Arial, 'Hiragino Sans', sans-serif" fill="#e8f4ff">
  <rect x="14" y="14" width="90" height="18" rx="9" fill="#16324a" opacity=".82"/><text x="22" y="27" font-size="11" font-weight="700">${label}</text>
  <rect x="224" y="14" width="82" height="18" rx="9" fill="#16324a" opacity=".82"/><text x="232" y="27" font-size="11" font-weight="700">${badge}</text>
  <text x="17" y="123" font-size="12" font-weight="700">${String(currentName).replace(/[<>&]/g,'')}</text>
  <text x="17" y="134" font-size="10" opacity=".82">${maker||'Independent Registry'}</text>
 </g>
 ${outline}
</svg>`;
 }
 function sfShipGeneratedIconUri(id,opts={}){ return `data:image/svg+xml;utf8,${encodeURIComponent(sfShipGeneratedIconSvg(id,opts))}`; }
 
 function sfShipMiniIconSvg(id,opts={}){
  const h=sfHullRef(id)||{},theme=sfHullTheme(id),geom=sfIconBodyGeometry(h.class||'prospect');
  const engines=(geom.engines||[]).slice(0,3).map(e=>`<circle cx="${e[0]}" cy="${e[1]}" r="${Math.max(2,e[2]-1)}" fill="${theme.glow}" opacity=".8"/>`).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 140" role="img" aria-label="ship"><rect width="320" height="140" rx="14" fill="#081522"/><path d="M0 106 L320 82 V140 H0Z" fill="#112b40" opacity=".6"/><g>${engines}<path d="${geom.main}" fill="${theme.secondary}" stroke="${theme.primary}" stroke-width="3" stroke-linejoin="round"/><path d="M74 70 H246" stroke="${theme.accent}" stroke-width="3" opacity=".78"/></g></svg>`;
 }
 function sfShipMiniIconUri(id,opts={}){return `data:image/svg+xml;utf8,${encodeURIComponent(sfShipMiniIconSvg(id,opts))}`}

 // Export generators for later use (SVG asset generation / external tools).
 if(typeof window!=='undefined'){
  window.StarFrontierShipIcons={svg:sfShipGeneratedIconSvg,uri:sfShipGeneratedIconUri,miniSvg:sfShipMiniIconSvg,miniUri:sfShipMiniIconUri,hull:sfHullRef};
 }
 
 // Override the image path helper so ship art always resolves even without
 // pre-rendered webp assets. Explicit manifest entries still win.
 if(typeof sfShipImagePath==='function'){
  const basePath=sfShipImagePath;
  sfShipImagePath=function(id){
   try{
    const key=typeof sfShipAssetKey==='function'?sfShipAssetKey(id):sfHullAssetKey(id);
    if(typeof SF_SHIP_IMAGE_MANIFEST!=='undefined'&&SF_SHIP_IMAGE_MANIFEST&&SF_SHIP_IMAGE_MANIFEST[key]) return SF_SHIP_IMAGE_MANIFEST[key];
    // Honor prebuilt relative ship image files only when an explicit override exists;
    // otherwise use deterministic SVG art to avoid broken image boxes.
    return sfShipGeneratedIconUri(id,{title:(game?.customNames||{})?.[id]||sfHullRef(id)?.name||id});
   }catch(_){
    return basePath(id);
   }
  };
 }
 if(typeof sfShipImageHtml==='function'){
  sfShipImageHtml=function(id,alt='',cls='sf-ship-visual'){
   const mini=String(cls||'').includes('thumb'),key=sfHullAssetKey(id),explicit=(typeof SF_SHIP_IMAGE_MANIFEST!=='undefined'&&SF_SHIP_IMAGE_MANIFEST&&SF_SHIP_IMAGE_MANIFEST[key])||null;
   const src=explicit||(mini?sfShipMiniIconUri(id,{title:alt||sfHullRef(id)?.name||id}):sfShipImagePath(id));
   return `<div class="${cls}"><img src="${src}" alt="${escapeHtml(alt||'艦艇画像')}" loading="lazy" onload="this.parentElement.classList.add('sf-has-image')" onerror="this.parentElement.remove()"></div>`;
  };
 }
 
 function sfRoleScores(id){
  const h=sfHullRef(id)||{};
  const cargo=Number(h.baseCargo)||0, fuel=Number(h.baseFuel)||0, mining=Number(h.mining)||0;
  const combat=(COMBAT_POWER?.[h.class]||10)+(h.combatBonus||0), armor=(h.armorBonus||0), command=(h.directFleetPowerBonus||0);
  const engine=Number(h.engine)||0;
  return {
   mining:clamp01(34+mining*14+cargo*.16+(h.class==='prospect'?18:0)+(h.class==='freighter'?4:0)),
   trade:clamp01(22+cargo*.28+fuel*.10+engine*120+(h.class==='freighter'?18:0)+(h.marketHull?4:0)),
   combat:clamp01(10+combat*.92+(h.military||0)*7+(h.class==='carrier'?5:0)+(h.class==='battleship'?10:0)+(h.class==='dread'||h.class==='dreadnought'?14:0)),
   range:clamp01(18+fuel*.22+engine*145+(h.class==='cruiser'?4:0)+(h.class==='carrier'?3:0)),
   support:clamp01(18+cargo*.18+armor*230+command*420+(/救難|補給|修理|医療|支援|指揮|護衛/.test(h.desc||'')?12:0)+(h.class==='carrier'?18:0))
  };
 }
 function sfPrimaryRoles(scores){
  return Object.entries(scores).sort((a,b)=>b[1]-a[1]).slice(0,2).map(([k])=>k);
 }
 function sfHullTags(id){
  const h=sfHullRef(id)||{}; const tags=[];
  if(h.special) tags.push('特別艦');
  if(h.marketHull) tags.push('量産市場');
  if(h.military) tags.push(`軍用Tier ${h.military}`);
  if(h.heritageSeries) tags.push('系譜艦');
  if(h.service) tags.push('官給艦');
  if(h.corporate) tags.push('企業専用');
  if(/採掘|探査/.test(h.desc||'')) tags.push('探査');
  if(/輸送|交易|貨物|商船/.test(h.desc||'')) tags.push('物流');
  if(/護衛|哨戒|防空/.test(h.desc||'')) tags.push('護衛');
  if(/救難|修理|補給|医療/.test(h.desc||'')) tags.push('支援');
  if(/指揮/.test(h.desc||'')) tags.push('指揮');
  return [...new Set(tags)].slice(0,5);
 }
 function sfStatusBadges(id){
  const out=[];
  if(game?.hull===id) out.push('搭乗中');
  if(game?.ownedHulls?.includes?.(id)) out.push('保有');
  if((game?.prizeShips||[]).some(p=>p.uid===id)) out.push('鹵獲艦');
  const market=sfCurrentMarketHullIds();
  if(market.includes(id)) out.push(canBuyHull?.(id)?'現在地で取得可':'現在地カタログ');
  if(HULLS?.[id]?.marketSystems?.includes?.(game?.system)) out.push('地域派生');
  return out.slice(0,4);
 }
 function sfCurrentMarketHullIds(){
  const set=new Set();
  try{
   if(typeof V13_COMMON_YARD_HULLS!=='undefined') for(const id of V13_COMMON_YARD_HULLS) if(HULLS[id]) set.add(id);
   if(typeof regionalYardFaction==='function'&&typeof regionalHullIds==='function'){
    const fid=regionalYardFaction(); if(fid) for(const id of regionalHullIds(fid)) if(HULLS[id]) set.add(id);
   }
   if(game?.career?.faction&&typeof serviceHullIds==='function') for(const id of serviceHullIds(game.career.faction)) if(HULLS[id]) set.add(id);
   const v181=(typeof StarFrontierIndustrialV181!=='undefined'&&StarFrontierIndustrialV181)||window?.StarFrontierIndustrialV181;
   if(v181?.marketHulls) for(const id of Object.keys(v181.marketHulls)) if(HULLS[id]) set.add(id);
   if(v181?.heritageDerivatives){
    for(const id of Object.keys(v181.heritageDerivatives)){
     const h=HULLS[id]; if(!h) continue;
     if(!Array.isArray(h.marketSystems)||!h.marketSystems.length||h.marketSystems.includes(game.system)) set.add(id);
    }
   }
   if(game?.ownedHulls?.includes?.('groza')||game?.system==='kronos') set.add('groza');
   if(game?.ownedHulls?.includes?.('krechet')||game?.system==='kronos') set.add('krechet');
   if(game?.ownedHulls?.includes?.('bastille')) set.add('bastille');
  }catch(_){ }
  return [...set].filter(id=>!!HULLS[id]);
 }
 function sfVisibleHullIds(){
  return Object.keys(HULLS).filter(id=>{
   const h=HULLS[id]; if(!h) return false;
   if(h.irregular&&!game?.ownedHulls?.includes?.(id)) return false;
   if(h.corporate&&!game?.ownedHulls?.includes?.(id)) return false;
   return true;
  });
 }
 function sfRegistryIds(filter){
  if(filter==='owned') return [...new Set([...(game?.ownedHulls||[]), ...((game?.prizeShips||[]).map(p=>p.uid))])].filter(Boolean);
  if(filter==='market') return sfCurrentMarketHullIds();
  if(filter==='military') return sfVisibleHullIds().filter(id=>!!HULLS[id]?.military||!!HULLS[id]?.service);
  if(filter==='all') return sfVisibleHullIds();
  // Recommended is intentionally compact. v1.85 had appended every visible hull,
  // creating multi-megabyte HTML on every Ship render.
  const candidates=[game?.hull,...(game?.ownedHulls||[]),...sfCurrentMarketHullIds()];
  try{if(window?.StarFrontierFleetIdentity?.isDiscovered){for(const id of sfVisibleHullIds())if(window.StarFrontierFleetIdentity.isDiscovered(id))candidates.push(id)}}catch(_){}
  const seen=new Set(), out=[];
  for(const id of candidates){ if(!id||seen.has(id)) continue; seen.add(id); out.push(id); if(out.length>=18)break; }
  return out;
 }
 function sfSortRegistry(ids){
  return ids.slice().sort((a,b)=>{
   const pa=(game?.hull===a?1000:0)+(game?.ownedHulls?.includes?.(a)?500:0)+(sfCurrentMarketHullIds().includes(a)?120:0)+((HULLS[a]?.military||0)*12)+(HULLS[a]?.special?18:0)+(HULLS[a]?.cost||0)/1000;
   const pb=(game?.hull===b?1000:0)+(game?.ownedHulls?.includes?.(b)?500:0)+(sfCurrentMarketHullIds().includes(b)?120:0)+((HULLS[b]?.military||0)*12)+(HULLS[b]?.special?18:0)+(HULLS[b]?.cost||0)/1000;
   return pb-pa || String((sfHullRef(a)||{}).name||a).localeCompare(String((sfHullRef(b)||{}).name||b),'ja');
  });
 }
 function sfScoreBarHtml(label,val){
  return `<div class="sf-score-row"><span>${escapeHtml(label)}</span><div class="sf-score-bar"><div class="sf-score-fill" style="width:${clamp01(val)}%"></div></div><b>${Math.round(val)}</b></div>`;
 }
 function sfRegistryCardHtml(id){
  const h=sfHullRef(id); if(!h) return '';
  const discoveryApi=(typeof window!=='undefined'&&window.StarFrontierFleetIdentity)||null;
  if(discoveryApi&&!discoveryApi.isDiscovered(id)){
   return `<div class="shop-item ship-card sf-registry-card v182-unknown-registry"><div>${typeof sfShipImageHtml==='function'?sfShipImageHtml(id,'未確認艦影','sf-ship-thumb'):''}<div class="shop-head"><strong>未確認艦級</strong><span class="pill">UNKNOWN</span></div><div class="statsline">識別情報不足 / 艦級・性能未確定</div><p>航路遭遇、地域造船所、軍事情報、情報士官の艦影解析で詳細を解放できます。</p></div><div><button disabled>未識別</button></div></div>`;
  }
  const c=SHIP_CLASSES?.[h.class]||{name:h.class||'艦艇',role:'---'};
  const scores=sfRoleScores(id), primary=sfPrimaryRoles(scores), tags=[...sfStatusBadges(id),...sfHullTags(id)].slice(0,6);
  const name=(game?.customNames?.[id]||h.name||id);
  const price=(h.cost||0)>0?`${Math.round(h.cost).toLocaleString()} Cr`:'非売品';
  const badges=tags.map(t=>`<span class="sf-mini-tag">${escapeHtml(t)}</span>`).join('');
  return `<div class="shop-item ship-card sf-registry-card"><div>${typeof sfShipImageHtml==='function'?sfShipImageHtml(id,name,'sf-ship-thumb'):''}<div class="shop-head"><strong>${escapeHtml(name)}</strong><span class="pill">${escapeHtml(c.name)}</span></div><div class="statsline">${escapeHtml(c.role)} / 船倉 ${h.baseCargo||0} / 燃料 ${h.baseFuel||0} / 戦闘 ${Math.round(scores.combat)}</div><div class="sf-registry-tags">${badges||'<span class="smallnote">登録タグなし</span>'}</div><p>${escapeHtml(h.desc||'')}</p><div class="smallnote">推奨運用：${primary.map(k=>ROLE_LABELS[k]).join('・')} / 価格 ${price}</div><div class="sf-score-mini">${sfScoreBarHtml('採掘',scores.mining)}${sfScoreBarHtml('交易',scores.trade)}${sfScoreBarHtml('戦闘',scores.combat)}${sfScoreBarHtml('航続',scores.range)}${sfScoreBarHtml('支援',scores.support)}</div></div><div>${game?.hull===id?'<button disabled>搭乗中</button>':game?.ownedHulls?.includes?.(id)?`<button class="good" onclick="switchHull('${id}')">乗り換え</button>`:(HULLS[id]&&canBuyHull?.(id)?`<button onclick="buyHull('${id}')" ${(game?.credits||0)<(HULLS[id].cost||0)?'disabled':''}>取得候補</button>`:'<button disabled>情報閲覧</button>')}</div></div>`;
 }
 function sfCurrentShipSummaryHtml(){
  const id=game?.hull, h=sfHullRef(id); if(!h) return '';
  const scores=sfRoleScores(id), primary=sfPrimaryRoles(scores), c=SHIP_CLASSES?.[h.class]||{name:h.class||'艦艇'};
  const rec=primary.map(k=>LOOP_LABELS[k]).join(' / ');
  return `<div class="sf-ship-profile"><div class="section-title"><h3>🧭 運用プロファイル</h3><span class="pill">${escapeHtml(c.name)}</span></div><p class="desc">現在の搭乗艦を、採掘・交易・戦闘・航続・支援の5軸で簡易評価します。ゲーム内の世界観に合わせて「どの任務に向く艦か」をすぐ判断できます。</p><div class="sf-score-grid">${sfScoreBarHtml('採掘',scores.mining)}${sfScoreBarHtml('交易',scores.trade)}${sfScoreBarHtml('戦闘',scores.combat)}${sfScoreBarHtml('航続',scores.range)}${sfScoreBarHtml('支援',scores.support)}</div><div class="news-item"><b>推奨プレイ導線：</b>${escapeHtml(rec)}<br><span class="smallnote">主役割: ${primary.map(k=>ROLE_LABELS[k]).join('・')} / タグ: ${sfHullTags(id).join('・')||'汎用'}</span></div></div>`;
 }
 function sfRegistryToolbarHtml(){
  const defs=[['recommended','おすすめ'],['owned','保有'],['market','現在地カタログ'],['military','軍用'],['all','全登録']];
  return `<div class="segment sf-registry-toolbar">${defs.map(([k,label])=>`<button class="${REGISTRY_STATE.filter===k?'active':''}" onclick="StarFrontierShipRegistry.setFilter('${k}')">${escapeHtml(label)}</button>`).join('')}</div>`;
 }
 function sfRegistryHtml(){
  const filter=REGISTRY_STATE.filter||'recommended';
  const allIds=sfSortRegistry(sfRegistryIds(filter)),limit=filter==='recommended'?18:Math.max(18,REGISTRY_STATE.limit||18),ids=allIds.slice(0,limit);
  const list=ids.map(sfRegistryCardHtml).join('')||'<div class="hint">該当する登録艦はありません。</div>';
  const more=allIds.length>ids.length?`<button class="secondary sf-registry-more" onclick="StarFrontierShipRegistry.more()">さらに表示（${ids.length}/${allIds.length}）</button>`:'';
  const totals={owned:(game?.ownedHulls?.length||0)+(game?.prizeShips?.length||0),market:sfCurrentMarketHullIds().length,all:sfVisibleHullIds().length};
  return `${sfCurrentShipSummaryHtml()}<div class="separator"></div><div class="section-title"><h3>📚 艦船レジストリ</h3><span class="pill">保有 ${totals.owned} / 市場 ${totals.market} / 登録 ${totals.all}</span></div><p class="desc">2Dアイコン付きで、保有艦・現在地の造船カタログ・代表艦を一覧できます。全登録は端末負荷を抑えるため段階表示します。</p>${sfRegistryToolbarHtml()}<div class="sf-registry-list">${list}</div>${more}`;
 }
 function sfRenderShipRegistryPanel(){
  const tab=document.getElementById('ship');if(!tab||tab.classList?.contains('hidden'))return;
  const panel=sfRegistryEnsureMount(); if(!panel) return;
  panel.innerHTML=sfRegistryHtml();
 }
 if(typeof window!=='undefined'){
  window.StarFrontierShipRegistry={
   setFilter(filter){ REGISTRY_STATE.filter=String(filter||'recommended');REGISTRY_STATE.limit=18; try{sfRenderShipRegistryPanel()}catch(_){ try{renderShip?.()}catch(__){} } },
   more(){REGISTRY_STATE.limit=Math.min(360,(REGISTRY_STATE.limit||18)+18);sfRenderShipRegistryPanel()},
   rerender:sfRenderShipRegistryPanel
  };
 }
 
 // Hook into ship rendering only; no gameplay or RNG side effects.
 if(typeof renderShip==='function'){
  const baseRenderShip=renderShip;
  renderShip=function(){ baseRenderShip(); try{ sfRenderShipRegistryPanel(); }catch(_){} };
 }
})();
