'use strict';
// ============================================================================
// v1.81.3 — Ore-backed ship/equipment manufacturing + Android startup fix
// hulls, expanded equipment circulation, and civilian derivatives of selected
// mythic/heritage designs. Existing heritage originals and signature equipment
// remain governed by their original regional/military acquisition rules.
// ============================================================================
const V181_BUILD='1.81.3';

const V181_ORE_LABELS={
 hematite:'赤鉄鉱',ilmenite:'チタン鉄鉱',bauxite:'ボーキサイト',chalcopyrite:'黄銅鉱',pentlandite:'ペントランド鉱',
 spodumene:'スポジュメン',uraninite:'閃ウラン鉱',monazite:'モナズ石',pgm_ore:'白金族鉱石',silicate:'高品位珪酸塩鉱',star_matrix:'星晶母岩'
};
const V181_HULL_BASE_RECIPES={
 prospect:{hematite:6,ilmenite:3,bauxite:5,chalcopyrite:3,silicate:3},
 freighter:{hematite:12,ilmenite:6,bauxite:10,chalcopyrite:7,pentlandite:2,spodumene:2,silicate:5},
 corvette:{hematite:10,ilmenite:8,bauxite:5,chalcopyrite:6,pentlandite:3,spodumene:1,silicate:4},
 frigate:{hematite:14,ilmenite:11,bauxite:6,chalcopyrite:7,pentlandite:5,spodumene:2,monazite:1,silicate:5},
 cruiser:{hematite:20,ilmenite:16,bauxite:8,chalcopyrite:10,pentlandite:8,spodumene:3,monazite:1,pgm_ore:1,silicate:6,star_matrix:1},
 carrier:{hematite:22,ilmenite:18,bauxite:12,chalcopyrite:12,pentlandite:8,spodumene:4,uraninite:1,monazite:2,pgm_ore:1,silicate:7,star_matrix:2},
 battleship:{hematite:30,ilmenite:24,bauxite:10,chalcopyrite:14,pentlandite:12,spodumene:4,uraninite:3,monazite:3,pgm_ore:2,silicate:7,star_matrix:3},
 dread:{hematite:38,ilmenite:30,bauxite:12,chalcopyrite:18,pentlandite:14,spodumene:5,uraninite:5,monazite:4,pgm_ore:3,silicate:9,star_matrix:5}
};
const V181_MODULE_SLOT_RECIPES={
 '主砲':{hematite:3,ilmenite:3,chalcopyrite:2,pentlandite:2},'副砲':{bauxite:2,chalcopyrite:2,monazite:1,silicate:2},
 '防御':{hematite:3,ilmenite:2,pentlandite:2,bauxite:1},'機関':{ilmenite:3,pentlandite:2,spodumene:1,pgm_ore:1},
 '航法':{bauxite:1,chalcopyrite:2,spodumene:1,monazite:1,silicate:2},'火器管制':{chalcopyrite:2,monazite:1,silicate:2},
 '電子戦':{chalcopyrite:2,spodumene:1,monazite:2,silicate:2,star_matrix:1},'指揮':{chalcopyrite:2,monazite:2,silicate:2,star_matrix:1},
 '支援':{bauxite:2,chalcopyrite:2,spodumene:1,silicate:1},'特殊':{uraninite:1,monazite:2,pgm_ore:1,star_matrix:2}
};

const V181_MARKET_HULLS={
 regulus_surveyor:{name:'SURVEYOR-R3〈サーベイヤー〉',class:'prospect',cost:17800,baseCargo:72,baseFuel:156,mining:2,engine:.10,maker:'regulus',marketHull:true,desc:'レグルス造船の量産探査艇。補修部品の共通化と低運用費を重視した民間標準型。'},
 regulus_mariner:{name:'MARINER-R6〈マリナー〉',class:'freighter',cost:26800,baseCargo:146,baseFuel:194,mining:-1,engine:.09,maker:'regulus',marketHull:true,desc:'船団会社・独立船主向けの量産中型商船。貨物量、航続、保守費のバランスを重視。'},
 horizon_swift:{name:'SWIFT-LX〈スウィフト〉',class:'freighter',cost:31800,baseCargo:124,baseFuel:228,mining:0,engine:.18,maker:'horizon',marketHull:true,desc:'ホライズン物流が市場投入する高速宅配・高価値貨物船。大型商船より小回りを優先する。'},
 horizon_bulkstar:{name:'BULKSTAR-LX〈バルクスター〉',class:'freighter',cost:44600,baseCargo:238,baseFuel:216,mining:-1,engine:.04,maker:'horizon',marketHull:true,desc:'鉱石・建材・食料の定期輸送向け量産バルカー。船倉容積と荷役互換性を最大化。'},
 nox_quarryman:{name:'QUARRYMAN-NX〈クォリーマン〉',class:'prospect',cost:29400,baseCargo:94,baseFuel:158,mining:3,engine:.03,maker:'nox',marketHull:true,desc:'ノクス資源の重作業艇を一般鉱業市場向けに簡略化した量産採掘艇。'},
 pilgrim_tanker:{name:'PILGRIM-T4〈ピルグリム・タンカー〉',class:'freighter',cost:38200,baseCargo:170,baseFuel:292,mining:-1,engine:.08,maker:'pilgrim',marketHull:true,desc:'分散燃料セルを標準装備した共同体規格の給油・危険物輸送船。'},
 meridian_responder:{name:'RESPONDER-MR〈レスポンダー〉',class:'freighter',cost:46800,baseCargo:132,baseFuel:238,mining:-1,engine:.10,maker:'meridian',marketHull:true,desc:'復旧工事・救難・曳航支援向けの公共作業船。資材搭載余裕と冗長電源を持つ。'},
 helix_mercy:{name:'MERCY-HB〈マーシー〉',class:'freighter',cost:52400,baseCargo:118,baseFuel:242,mining:-1,engine:.11,maker:'helix',marketHull:true,desc:'ヘリックス生体工業が医療輸送・難民救護向けに量産する民生医療船。'},
 arclight_spear:{name:'SPEAR-AL〈スピア〉',class:'corvette',cost:39800,baseCargo:44,baseFuel:184,mining:-1,engine:.19,maker:'arclight',marketHull:true,desc:'民間警備・船団自衛向けの武装コルベット。軍用暗号と重兵装を省き合法市場へ流通する。'},
 bulwark_warden:{name:'WARDEN-BW〈ウォーデン〉',class:'corvette',cost:43200,baseCargo:48,baseFuel:180,mining:-1,engine:.12,maker:'bulwark',marketHull:true,desc:'警備会社・重要貨物護衛向け量産防護艇。火力より装甲・迎撃能力を優先。'},
 synapse_vector:{name:'VECTOR-SV〈ベクター〉',class:'corvette',cost:45800,baseCargo:42,baseFuel:202,mining:-1,engine:.23,maker:'synapse',marketHull:true,desc:'電子航法と危険回避を重視した高速護送・情報連絡艇。'},
 asterion_frontier:{name:'FRONTIER-AH〈フロンティア〉',class:'frigate',cost:67500,baseCargo:72,baseFuel:210,mining:-2,engine:.12,maker:'asterion',marketHull:true,desc:'企業警備、鉱区護衛、遠隔地拠点防衛向けに兵装を抑えたアステリオン量産フリゲート。'}
};
Object.assign(HULLS,V181_MARKET_HULLS);
for(const id of Object.keys(V181_MARKET_HULLS))if(typeof V13_COMMON_YARD_HULLS!=='undefined'&&!V13_COMMON_YARD_HULLS.includes(id))V13_COMMON_YARD_HULLS.push(id);

const V181_HERITAGE_DERIVATIVES={
 demeter_provision:{name:'DEMETER-CV〈デメテル・プロビジョン〉',class:'freighter',cost:92500,baseCargo:250,baseFuel:284,mining:-2,engine:.07,maker:'regulus',marketHull:true,heritageDerivative:'demeter',marketSystems:['aurora','forge','umbra'],desc:'DEMETER級の補給思想だけを民間規格へ移植した大型食料・生活物資船。原型の軍用管制・専用装備は搭載できない。'},
 njord_merchant:{name:'NJORD-M〈ニョルズ・マーチャント〉',class:'cruiser',cost:112000,baseCargo:150,baseFuel:270,mining:-2,engine:.16,maker:'crownforge',marketHull:true,heritageDerivative:'njord',marketSystems:['drakon','nyx','kronos'],desc:'NJORD級から戦域火器管制を外し、長距離交易・護送へ再設計した武装商船型。原型の北欧系譜専用品は非互換。'},
 sleipnir_express:{name:'SLEIPNIR-X〈スレイプニル・エクスプレス〉',class:'freighter',cost:104000,baseCargo:168,baseFuel:306,mining:-2,engine:.24,maker:'horizon',marketHull:true,heritageDerivative:'sleipnir',marketSystems:['aurora','orion','drakon'],desc:'SLEIPNIR級の高推力設計を高速貨物船へ転用したライセンス生産型。軍用強襲設備を削り、航続と運賃効率を優先。'},
 nirai_expedition:{name:'NIRAI-KANAI-E〈ニライカナイ・エクスペディション〉',class:'freighter',cost:118000,baseCargo:218,baseFuel:338,mining:-1,engine:.13,maker:'regulus',marketHull:true,heritageDerivative:'nirai_kanai',marketSystems:['aurora','orion','cinder'],desc:'ニライカナイ級の長距離航海思想を開拓・移民・探検船向けに転用した民生派生型。原型の艦隊支援機能は省略。'},
 mammon_reclaimer:{name:'MAMMON-R〈マモン・リクレーマー〉',class:'freighter',cost:108000,baseCargo:264,baseFuel:252,mining:-2,engine:.08,maker:'nox',marketHull:true,heritageDerivative:'mammon',marketSystems:['nyx','cinder','meridian'],desc:'MAMMON級の巨大回収区画を合法サルベージ・廃船回収向けに再設計した辺境市場型。私掠用襲撃艇と禁制装備は撤去済み。'}
};
Object.assign(HULLS,V181_HERITAGE_DERIVATIVES);

Object.assign(SHIP_MODULES,{
 corp_arclight_coil:{name:'AL-18汎用コイル砲',slot:'主砲',weight:9,power:10,cost:8200,combat:15,defense:0,generated:true,corporate:true,corporation:'arclight',corpTrust:0,marketProduct:true,desc:'警備艇からフリゲートまで幅広く搭載される量産電磁砲。'},
 corp_arclight_pdlaser:{name:'AL近接レーザー迎撃器',slot:'副砲',weight:5,power:8,cost:7600,combat:5,defense:13,generated:true,corporate:true,corporation:'arclight',corpTrust:0,marketProduct:true,desc:'民間護衛船向けの低反動・自動近接防御レーザー。'},
 corp_arclight_tracker:{name:'アークライト民生射撃追尾器',slot:'火器管制',weight:4,power:6,cost:6900,combat:10,defense:3,generated:true,corporate:true,corporation:'arclight',corpTrust:0,marketProduct:true,desc:'輸出規制に触れにくい民生センサーを使った標準射撃補助器。'},
 corp_bulwark_ceramic:{name:'BWセラメタル軽量装甲',slot:'防御',weight:10,power:1,cost:7900,combat:0,defense:18,speed:-.01,generated:true,corporate:true,corporation:'bulwark',corpTrust:0,marketProduct:true,desc:'商船・救難船向けの交換式軽量複合装甲。'},
 corp_bulwark_damage:{name:'ブルワーク自動損傷封鎖器',slot:'支援',weight:6,power:5,cost:8400,combat:0,defense:16,generated:true,corporate:true,corporation:'bulwark',corpTrust:0,marketProduct:true,desc:'被弾・衝突時に区画を自動隔離し二次損害を抑える量産安全装備。'},
 corp_bulwark_guardian:{name:'BW-G2船団防御アレイ',slot:'副砲',weight:7,power:9,cost:9700,combat:7,defense:18,generated:true,corporate:true,corporation:'bulwark',corpTrust:4,marketProduct:true,desc:'商船護衛向けに迎撃範囲を拡大した一般流通型防御システム。'},
 corp_synapse_nav:{name:'SV民生航路予測AI',slot:'航法',weight:3,power:4,cost:7200,combat:0,defense:3,speed:.11,generated:true,corporate:true,corporation:'synapse',corpTrust:0,marketProduct:true,desc:'危険宙域・燃料価格・航路混雑を同時評価する民生航法AI。'},
 corp_synapse_sensor:{name:'シナプス広域商用センサーマスト',slot:'電子戦',weight:5,power:7,cost:9100,combat:6,defense:11,speed:.02,generated:true,corporate:true,corporation:'synapse',corpTrust:0,marketProduct:true,desc:'貨物船・採掘船・護衛船向けの長距離識別センサー。'},
 corp_synapse_counter:{name:'SV適応妨害デコイ',slot:'電子戦',weight:5,power:9,cost:10800,combat:8,defense:15,speed:.03,generated:true,corporate:true,corporation:'synapse',corpTrust:6,marketProduct:true,desc:'ミサイル・追跡レーダーへ偽目標を生成する合法市場向け電子防御装備。'}
});
for(const [cid,mods] of Object.entries({arclight:['corp_arclight_coil','corp_arclight_pdlaser','corp_arclight_tracker'],bulwark:['corp_bulwark_ceramic','corp_bulwark_damage','corp_bulwark_guardian'],synapse:['corp_synapse_nav','corp_synapse_sensor','corp_synapse_counter']})){
 if(V17_CORPORATIONS?.[cid])for(const mid of mods)if(!V17_CORPORATIONS[cid].modules.includes(mid))V17_CORPORATIONS[cid].modules.push(mid);
}

function v181State(){
 const s=game.gm.v181=game.gm.v181||{systems:{},metrics:{hullsBuilt:0,modulesBuilt:0,oreConsumed:0,oreSupplied:0,marketHullSales:0,heritageDerivativeSales:0},history:[],lastDay:game.day-1};
 s.systems=s.systems||{};s.metrics=s.metrics||{};s.history=Array.isArray(s.history)?s.history:[];
 for(const sid of Object.keys(SYSTEMS||{})){
  if(!s.systems[sid])s.systems[sid]={ores:{},demand:0,lastDay:game.day};
  const z=s.systems[sid];z.ores=z.ores||{};
  const dep=typeof v176EnsureDeposits==='function'?v176EnsureDeposits(sid):{};
  for(const k of Object.keys(V181_ORE_LABELS))if(!Number.isFinite(z.ores[k])){
   const rare=['uraninite','monazite','pgm_ore','star_matrix'].includes(k),base=rare?8:28;
   z.ores[k]=Math.round(base+(Number(dep?.[k])||40)*(rare?.15:.42));
  }
 }
 for(const k of ['hullsBuilt','modulesBuilt','oreConsumed','oreSupplied','marketHullSales','heritageDerivativeSales'])s.metrics[k]=Number(s.metrics[k])||0;
 return s
}
function v181CloneRecipe(r){return Object.fromEntries(Object.entries(r||{}).filter(([,n])=>n>0).map(([k,n])=>[k,Math.max(1,Math.round(n))]))}
function v181HullRecipe(hid){
 const h=HULLS[hid];if(!h)return{};let r=v181CloneRecipe(V181_HULL_BASE_RECIPES[h.class]||V181_HULL_BASE_RECIPES.corvette);
 if(h.baseCargo>=180){r.bauxite=(r.bauxite||0)+3;r.hematite=(r.hematite||0)+3}
 if((h.engine||0)>=.18){r.spodumene=(r.spodumene||0)+2;r.pgm_ore=(r.pgm_ore||0)+1}
 if(h.mining>=2){r.hematite=(r.hematite||0)+2;r.pentlandite=(r.pentlandite||0)+2;r.chalcopyrite=(r.chalcopyrite||0)+1}
 if(h.heritageSeries||h.heritageDerivative){r.monazite=(r.monazite||0)+1;r.star_matrix=(r.star_matrix||0)+1}
 if(h.class==='cruiser'&&h.heritageDerivative){r.uraninite=(r.uraninite||0)+1}
 return v181CloneRecipe(r)
}
function v181ModuleRecipe(mid){
 const m=SHIP_MODULES[mid];if(!m||m.loot)return{};let r=v181CloneRecipe(V181_MODULE_SLOT_RECIPES[m.slot]||V181_MODULE_SLOT_RECIPES['支援']);
 if((m.combat||0)>=20){r.ilmenite=(r.ilmenite||0)+1;r.pentlandite=(r.pentlandite||0)+1}
 if((m.defense||0)>=20){r.hematite=(r.hematite||0)+1;r.bauxite=(r.bauxite||0)+1}
 if((m.speed||0)>=.1){r.spodumene=(r.spodumene||0)+1}
 if((m.power||0)>=15){r.uraninite=(r.uraninite||0)+1}
 return v181CloneRecipe(r)
}
function v181Stock(sid=game.system){return v181State().systems[sid]?.ores||{}}
function v181CanConsume(sid,recipe,qty=1){const st=v181Stock(sid);return Object.entries(recipe||{}).every(([k,n])=>(st[k]||0)+1e-9>=n*qty)}
function v181MaxBuild(sid,recipe){const st=v181Stock(sid),rows=Object.entries(recipe||{});return rows.length?Math.max(0,Math.floor(Math.min(...rows.map(([k,n])=>(st[k]||0)/Math.max(.01,n))))):999}
function v181Consume(sid,recipe,qty=1,reason='industrial'){
 if(!v181CanConsume(sid,recipe,qty))return false;const st=v181Stock(sid);let total=0;for(const [k,n] of Object.entries(recipe||{})){const use=n*qty;st[k]=Math.max(0,(st[k]||0)-use);total+=use}const x=v181State();x.metrics.oreConsumed+=total;x.systems[sid].demand=(x.systems[sid].demand||0)+total;x.history.unshift({day:game.day,type:'consume',system:sid,reason,qty,total});x.history=x.history.slice(0,120);return true
}
function v181RecipeText(recipe){return Object.entries(recipe||{}).map(([k,n])=>`${V181_ORE_LABELS[k]||k} ${n}`).join(' / ')||'標準部材'}
function v181ShortageText(sid,recipe){const st=v181Stock(sid),miss=Object.entries(recipe||{}).filter(([k,n])=>(st[k]||0)<n).map(([k,n])=>`${V181_ORE_LABELS[k]} ${Math.max(0,n-(st[k]||0)).toFixed(0)}`);return miss.join(' / ')}
function v181HullBuildSystem(hid){const h=HULLS[hid],cid=h?.corp||h?.maker;return V17_CORPORATIONS?.[cid]?.home||game.system}
function v181MarketAvailable(hid){const h=HULLS[hid];return !h?.marketSystems||h.marketSystems.includes(game.system)}

function v181OreSpot(k){if(typeof v176OrePrice==='function')return v176OrePrice(k);return V176_ORES?.[k]?.base||80}
function v181SupplyOre(k,qty=5){
 const x=typeof v176State==='function'?v176State():null;if(!x||!V181_ORE_LABELS[k])return;qty=Math.min(Math.max(0,Number(qty)||0),x.ores[k]||0);if(qty<=0)return toast?.('供給できる原鉱がありません');
 const fid=SYSTEMS[game.system]?.faction,pay=Math.round(v181OreSpot(k)*qty*1.08);let paid=0;
 const corpIds=['regulus','crownforge','asterion'].filter(cid=>V17_CORPORATIONS?.[cid]&&SYSTEMS[V17_CORPORATIONS[cid].home]?.faction===fid);
 if(corpIds.length){const cid=corpIds[0],cs=game.gm.corporations?.[cid];if(cs){paid=Math.min(pay,Math.max(0,Math.floor(cs.wealth||0)));cs.wealth-=paid}}
 if(paid<pay&&game.gm.factions?.[fid]){const f=game.gm.factions[fid],gap=Math.min(pay-paid,Math.max(0,Math.floor(f.treasury||0)));f.treasury-=gap;paid+=gap}
 const actual=pay>0?qty*(paid/pay):0;if(actual<=.01)return toast?.('造船産業側に買付資金がありません');
 x.ores[k]=Math.max(0,(x.ores[k]||0)-actual);const st=v181Stock();st[k]=(st[k]||0)+actual;game.credits+=paid;v181State().metrics.oreSupplied+=actual;addLog?.(`${V181_ORE_LABELS[k]} ${actual.toFixed(1)}u を造船・装備産業へ供給し ${paid.toLocaleString()} Crを受領。`);render?.()
}

// Ordinary market hulls use the existing shipyard purchase pipeline, but their
// material bill is now real. Existing hulls also receive an ore recipe.
const v181BuyHullBase=typeof buyHull==='function'?buyHull:null;
if(v181BuyHullBase)buyHull=function(id){
 const h=HULLS[id];if(!h)return;const sid=v181HullBuildSystem(id),r=v181HullRecipe(id);
 if(!v181MarketAvailable(id)){toast?.('このライセンス生産型は現在地では流通していません');return}
 if(!v181CanConsume(sid,r)){toast?.(`造船資材不足：${v181ShortageText(sid,r)}`);return}
 const before=game.ownedHulls.includes(id),credits=game.credits;v181BuyHullBase(id);
 if(!before&&game.ownedHulls.includes(id)){
  v181Consume(sid,r,1,`hull:${id}`);const s=v181State();s.metrics.hullsBuilt++;if(h.marketHull)s.metrics.marketHullSales++;if(h.heritageDerivative)s.metrics.heritageDerivativeSales++;
  const cid=h.maker;if(cid&&game.gm.corporations?.[cid])game.gm.corporations[cid].wealth+=Math.round((credits-game.credits)*.42);
 }
 return true
};

const v181CommissionBase=typeof commissionCorporateHull==='function'?commissionCorporateHull:null;
if(v181CommissionBase)commissionCorporateHull=function(cid,hid){const sid=V17_CORPORATIONS?.[cid]?.home||game.system,r=v181HullRecipe(hid);if(!v181CanConsume(sid,r)){toast?.(`企業造船資材不足：${v181ShortageText(sid,r)}`);return}const before=(game.corporateOrders||[]).length;const o=v181CommissionBase(cid,hid);if((game.corporateOrders||[]).length>before){v181Consume(sid,r,1,`corp_hull:${hid}`);v181State().metrics.hullsBuilt++}return o};

// Materialize the existing equipment manufacturers: any newly produced market
// stock must be backed by ore inputs. If materials run out, that production lot
// is cancelled rather than creating free inventory.
const v181EquipProcessBase=typeof processV112Equipment==='function'?processV112Equipment:null;
if(v181EquipProcessBase)processV112Equipment=function(){
 const before={};for(const cid of (typeof v112EquipmentCorpIds==='function'?v112EquipmentCorpIds():[])){const st=game.gm.equipmentMarket?.makers?.[cid];before[cid]={};for(const mid of V17_CORPORATIONS[cid]?.modules||[])before[cid][mid]=st?.stock?.[mid]||0}
 const out=v181EquipProcessBase();
 for(const cid of Object.keys(before)){const sid=V17_CORPORATIONS[cid]?.home||game.system,st=game.gm.equipmentMarket?.makers?.[cid];if(!st)continue;for(const mid of V17_CORPORATIONS[cid]?.modules||[]){let made=(st.stock[mid]||0)-(before[cid][mid]||0);if(made<=0)continue;const r=v181ModuleRecipe(mid),max=v181MaxBuild(sid,r),keep=Math.min(made,max);if(keep>0){v181Consume(sid,r,keep,`module:${mid}`);v181State().metrics.modulesBuilt+=keep}if(keep<made)st.stock[mid]=Math.max(0,(st.stock[mid]||0)-(made-keep))}}
 return out
};

function v181ProcessDaily(){
 const s=v181State();if(s.lastDay>=game.day)return;const days=Math.min(30,game.day-s.lastDay);s.lastDay=game.day;
 for(const [sid,z] of Object.entries(s.systems)){
  const dep=typeof v176EnsureDeposits==='function'?v176EnsureDeposits(sid):{};const miningBonus=(game.gm.v179?.mining?.bases||[]).filter(b=>b.system===sid&&b.status==='active').length*.9;
  for(const k of Object.keys(V181_ORE_LABELS)){const rare=['uraninite','monazite','pgm_ore','star_matrix'].includes(k),regen=days*((rare?.18:.72)+(Number(dep?.[k])||40)*(rare?.004:.012)+miningBonus*(rare?.12:.35));z.ores[k]=Math.min(rare?65:220,(z.ores[k]||0)+regen)}
  z.demand=Math.max(0,(z.demand||0)*Math.pow(.88,days));z.lastDay=game.day
 }
 game.version=V181_BUILD
}

function v181IndustryHtml(){
 const sid=game.system,st=v181Stock(sid),raw=typeof v176State==='function'?v176State().ores:{};
 const rows=Object.keys(V181_ORE_LABELS).map(k=>`<div class="market-row"><div><b>${escapeHtml(V181_ORE_LABELS[k])}</b><div class="own">造船産業在庫 ${Math.floor(st[k]||0)}u / 自船原鉱 ${(raw[k]||0).toFixed?.(1)||0}u</div></div><button class="mini good" onclick="v181SupplyOre('${k}',5)" ${(raw[k]||0)<=0?'disabled':''}>5u供給</button></div>`).join('');
 return `<div data-v181="industry" class="panel"><div class="section-title"><h2>🏭 造船・装備原料市場</h2><span class="pill">ORE-BACKED</span></div><p class="desc">艦船と量産装備は実鉱石レシピを消費します。資源不足時は建造・装備生産が止まり、採掘して造船所へ原鉱を供給する新しい需要先になります。</p>${rows}</div>`
}
function v181DerivativeCard(id){const h=HULLS[id],own=game.ownedHulls.includes(id),available=v181MarketAvailable(id),r=v181HullRecipe(id),sid=v181HullBuildSystem(id),canMat=v181CanConsume(sid,r);return `<div class="shop-item ship-card ${available?'':'hot'}"><div><div class="shop-head"><strong>${escapeHtml(h.name)}</strong><span class="pill">系譜民生派生</span></div><div class="statsline">${SHIP_CLASSES[h.class]?.name||h.class} / 船倉 ${h.baseCargo} / 燃料 ${h.baseFuel} / ${h.cost.toLocaleString()} Cr</div><div class="tagline"><span class="license">原型 ${escapeHtml(HULLS[h.heritageDerivative]?.name||h.heritageDerivative)}</span><span class="license">専用装備非互換</span></div><p>${escapeHtml(h.desc)}</p><div class="hint">鉱石レシピ：${escapeHtml(v181RecipeText(r))}${canMat?'':'<br><b class="badtext">不足：'+escapeHtml(v181ShortageText(sid,r))+'</b>'}</div></div><div>${own?`<button class="good" onclick="switchHull('${id}')">乗り換え</button>`:`<button onclick="buyHull('${id}')" ${!available||!canMat||game.credits<h.cost?'disabled':''}>市場購入</button>`}</div></div>`}
function v181MarketFleetHtml(){return `<div data-v181="fleet"><div class="lore-card"><b>🏢 企業量産艦市場</b><p>企業提案のワンオフ・契約艦とは別に、造船各社が一般船主へ量産販売する標準船です。主要造船所なら地域を問わず購入できます。</p></div><div class="lore-card battlefield"><b>✦ 神話・伝承系譜 — ライセンス民生派生型</b><p>原型艦そのものは従来どおり地域軍・専用取得枠です。市場に出るのは軍用管制・艦級専用品を外した派生型だけで、原型の特別感と性能差を維持します。</p></div>${Object.keys(V181_HERITAGE_DERIVATIVES).map(v181DerivativeCard).join('')}</div>`}

// Add material-bill annotations to every normal shipyard card without changing
// the original licensing rules.
const v181ShipyardCardBase=typeof shipyardCard==='function'?shipyardCard:null;
if(v181ShipyardCardBase)shipyardCard=function(id,h){let html=v181ShipyardCardBase(id,h);if(!html||h?.service)return html;const r=v181HullRecipe(id),sid=v181HullBuildSystem(id),maker=h?.maker&&V17_CORPORATIONS?.[h.maker]?.short?` / 製造 ${V17_CORPORATIONS[h.maker].short}`:'';return html.replace('</p></div><div>',`</p><div class="hint">鉱石BOM：${escapeHtml(v181RecipeText(r))}${maker}</div></div><div>`)};

const v181RegionalBase=typeof renderRegionalShipyard==='function'?renderRegionalShipyard:null;
if(v181RegionalBase)renderRegionalShipyard=function(){const o=v181RegionalBase();const el=document.getElementById('shipyard');if(el){el.querySelector?.('[data-v181="fleet"]')?.remove();el.insertAdjacentHTML('beforeend',v181MarketFleetHtml())}return o};
const v181RenderMarketBase=typeof renderMarket==='function'?renderMarket:null;
if(v181RenderMarketBase)renderMarket=function(){const o=v181RenderMarketBase();document.querySelector?.('[data-v181="industry"]')?.remove();document.getElementById('market')?.insertAdjacentHTML('beforeend',v181IndustryHtml());return o};

function ensureV181State(){if(typeof ensureV180State==='function')ensureV180State();const s=v181State();if(typeof ensureV112State==='function')ensureV112State();for(const cid of ['arclight','bulwark','synapse']){const st=game.gm.equipmentMarket?.makers?.[cid];if(st)for(const mid of V17_CORPORATIONS[cid].modules)if(!Number.isFinite(st.stock[mid]))st.stock[mid]=1+Math.floor(rng()*3)}game.version=V181_BUILD;return s}
const v181InitBase=initV10;initV10=function(){const o=v181InitBase();ensureV181State();game.version=V181_BUILD;return o};
const v181AdvanceBase=gmAdvance;gmAdvance=function(){ensureV181State();const o=v181AdvanceBase();v181ProcessDaily();game.version=V181_BUILD;return o};
if(typeof render==='function'){const b=render;render=function(){const o=b();try{ensureV181State();const z=document.querySelector('header .title .badge')||document.querySelector('.version-badge');if(z)z.textContent='v1.81.3';const s=document.querySelector('header .sub');if(s)s.textContent='Ore-backed Shipbuilding / Corporate Mass Market / Heritage Derivatives';document.title='STAR FRONTIER v1.81.3 — Industrial Ship & Equipment Market'}catch(_){}return o}};
if(typeof window!=='undefined')window.StarFrontierIndustrialV181={ensure:ensureV181State,state:v181State,hullRecipe:v181HullRecipe,moduleRecipe:v181ModuleRecipe,marketHulls:V181_MARKET_HULLS,heritageDerivatives:V181_HERITAGE_DERIVATIVES,supplyOre:v181SupplyOre};
