'use strict';
// ============================================================================
// v1.85.3 — Mining Cargo / System Market Integration Fix
//
// v1.76 intentionally stores raw ores and refined elements outside legacy
// game.cargo so their composition/provenance can be preserved. The legacy
// system-market list only reads game.cargo, however, which made mined cargo
// appear in the ship hold overview while being absent from the normal market.
//
// This layer fixes the presentation/integration boundary only. It does NOT
// mirror ores into game.cargo (which would double-count cargo capacity), and
// it delegates sales to the existing v1.77/v1.78 wrapped functions so customs,
// contraband and commodity-supply behavior remain authoritative.
// No RNG is consumed by this layer.
// ============================================================================
(function(){
 const BUILD='1.85.3';
 const round1=n=>Math.round((Number(n)||0)*10)/10;
 const esc=s=>typeof escapeHtml==='function'?escapeHtml(String(s??'')):String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

 function miningState(){
  try{return typeof v176State==='function'?v176State():null}catch(_){return null}
 }
 function stolenOreQty(k){
  try{return Math.max(0,Number(v177State?.().contraband?.[k])||0)}catch(_){return 0}
 }
 function stolenElementQty(k){
  try{return Math.max(0,Number(v178ContrabandQty?.('element',k))||0)}catch(_){return 0}
 }
 function marketRowsHtml(){
  const x=miningState();
  if(!x||typeof V176_ORES==='undefined'||typeof V176_ELEMENTS==='undefined')return'';
  const ores=Object.entries(V176_ORES)
   .filter(([k])=>(Number(x.ores?.[k])||0)>.04)
   .sort((a,b)=>(typeof v176OrePrice==='function'?v176OrePrice(b[0]):0)-(typeof v176OrePrice==='function'?v176OrePrice(a[0]):0));
  const elements=Object.entries(V176_ELEMENTS)
   .filter(([k])=>(Number(x.elements?.[k])||0)>.04)
   .sort((a,b)=>(typeof v176ElementPrice==='function'?v176ElementPrice(b[0]):0)-(typeof v176ElementPrice==='function'?v176ElementPrice(a[0]):0));
  if(!ores.length&&!elements.length)return'';

  const oreHtml=ores.map(([k,o])=>{
   const qty=round1(x.ores[k]),price=Math.round(typeof v176OrePrice==='function'?v176OrePrice(k):0),stolen=round1(stolenOreQty(k));
   const five=Math.min(5,qty),all=qty;
   return `<div class="market-row" data-v1853-mining-market="ore:${esc(k)}"><div><b>${o.icon||'⛏'} ${esc(o.name)}</b><div class="own">採掘船倉 ${qty} / 星系売価 ${price.toLocaleString()} Cr/u${stolen>0?`<br><span class="warn">出所不明 ${stolen} — 税関検査対象</span>`:''}</div></div><div class="price">売 ${price.toLocaleString()} Cr<br><small>未精錬鉱</small></div><div class="mini-stack"><button class="mini good" onclick="v176SellOre('${k}',1)" ${qty<1?'disabled':''}>1売る</button><button class="mini good" onclick="v176SellOre('${k}',${five})" ${five<=0?'disabled':''}>${five===5?'5売る':`${five}売る`}</button><button class="mini secondary" onclick="v176SellOre('${k}',${all})">全売却</button></div></div>`;
  }).join('');

  const elementHtml=elements.map(([k,m])=>{
   const qty=round1(x.elements[k]),spot=Math.round(typeof v176ElementPrice==='function'?v176ElementPrice(k):0),sell=Math.round(spot*.94),stolen=round1(stolenElementQty(k));
   const five=Math.min(5,qty),all=qty;
   return `<div class="market-row" data-v1853-mining-market="element:${esc(k)}"><div><b>${m.icon||'◆'} ${esc(m.name)} <span class="pill">${esc(m.symbol||k)}</span></b><div class="own">精錬貨物 ${qty} / 星系売価 ${sell.toLocaleString()} Cr/${esc(m.unit||'u')}${stolen>0?`<br><span class="warn">追跡対象貨物 ${stolen} — 税関検査対象</span>`:''}</div></div><div class="price">売 ${sell.toLocaleString()} Cr<br><small>精錬元素</small></div><div class="mini-stack"><button class="mini good" onclick="v176SellElement('${k}',1)" ${qty<1?'disabled':''}>1売る</button><button class="mini good" onclick="v176SellElement('${k}',${five})" ${five<=0?'disabled':''}>${five===5?'5売る':`${five}売る`}</button><button class="mini secondary" onclick="v176SellElement('${k}',${all})">全売却</button></div></div>`;
  }).join('');

  return `<div data-v1853-mining-market-section="1"><div class="separator"></div><div class="section-title"><h3>⛏ 採掘・精錬貨物</h3><span class="pill">SHIP HOLD → SYSTEM MARKET</span></div><p class="desc">採掘船倉と精錬貨物を現在地の星系市場へ直接売却できます。船倉容量は既存の採掘貨物管理を使用するため二重計上されません。</p>${oreHtml}${elementHtml}</div>`;
 }
 function marketVisible(){const el=document.getElementById?.('market');return !!el&&!el.classList?.contains?.('hidden')}
 function integrateMarket(){
  if(!marketVisible())return false;
  const list=document.getElementById?.('marketList');if(!list)return false;
  list.querySelector?.('[data-v1853-mining-market-section="1"]')?.remove?.();
  const html=marketRowsHtml();if(html)list.insertAdjacentHTML?.('beforeend',html);
  return !!html;
 }

 if(typeof renderMarket==='function'){
  const base=renderMarket;
  renderMarket=function(){const out=base.apply(this,arguments);try{if(marketVisible())integrateMarket()}catch(e){console.warn?.('[STAR FRONTIER] mining market integration failed',e)}return out};
 }
 // Refreshing the cargo overview may happen without a full market render. If the
 // market is already visible, keep its sellable inventory synchronized too.
 if(typeof v176RefreshCargoOverview==='function'){
  const base=v176RefreshCargoOverview;
  v176RefreshCargoOverview=function(){const out=base.apply(this,arguments);try{const market=document.getElementById?.('market');if(market&&!market.classList?.contains?.('hidden'))integrateMarket()}catch(_){}return out};
 }

 if(typeof window!=='undefined')window.StarFrontierMiningMarketFix={build:BUILD,render:integrateMarket,html:marketRowsHtml};
})();
