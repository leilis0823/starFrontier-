'use strict';
// ===== v1.53.2: restored Japanese localization hotfix for international-organization UI/events =====
// Internal action/status IDs remain unchanged for save compatibility. Only user-facing text is localized.

const V1521_INTL_ACTION_LABELS=Object.freeze({
  mediation:'停戦仲介・和平調整',
  aid:'人道支援',
  loan:'復興・開発融資',
  joint_patrol:'共同航路哨戒',
  research_mission:'共同研究・調査任務',
  investigation:'国際調査団派遣',
  trade_relief:'通商救済措置',
  sanction:'共同制裁',
  monitor:'共同監視',
  military_support:'軍事支援',
  readiness:'共同即応態勢'
});

const V1521_INTL_VOTING_LABELS=Object.freeze({
  consensus:'全会一致',
  qualified:'特別多数決',
  simple:'単純多数決'
});

function v1521InternationalActionLabel(action){
  const k=String(action??'');
  return V1521_INTL_ACTION_LABELS[k]||k;
}
function v1521InternationalVotingLabel(rule){
  const k=String(rule??'');
  return V1521_INTL_VOTING_LABELS[k]||k;
}
function v1521LocalizeInternationalText(text){
  let s=String(text??'');
  // Support both the actual stored IDs and previously displayed variants such as "Militarysupport".
  const pairs=[
    ['research_mission','共同研究・調査任務'],['Research Mission','共同研究・調査任務'],['ResearchMission','共同研究・調査任務'],
    ['military_support','軍事支援'],['Military Support','軍事支援'],['MilitarySupport','軍事支援'],['Militarysupport','軍事支援'],
    ['joint_patrol','共同航路哨戒'],['Joint Patrol','共同航路哨戒'],['JointPatrol','共同航路哨戒'],
    ['trade_relief','通商救済措置'],['Trade Relief','通商救済措置'],['TradeRelief','通商救済措置'],
    ['investigation','国際調査団派遣'],
    ['mediation','停戦仲介・和平調整'],
    ['readiness','共同即応態勢'],
    ['monitor','共同監視'],
    ['sanction','共同制裁'],
    ['aid','人道支援'],
    ['loan','復興・開発融資']
  ];
  for(const [raw,ja] of pairs){
    const esc=raw.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    s=s.replace(new RegExp(`\\b${esc}\\b`,'gi'),ja);
  }
  s=s.replace(/議決方式\s+consensus\b/gi,'議決方式 全会一致')
     .replace(/議決方式\s+qualified\b/gi,'議決方式 特別多数決')
     .replace(/議決方式\s+simple\b/gi,'議決方式 単純多数決')
     .replace(/\bconsensus議決\b/gi,'全会一致')
     .replace(/\bqualified議決\b/gi,'特別多数決')
     .replace(/\bsimple議決\b/gi,'単純多数決');
  return s;
}

function v1521MigrateExistingInternationalDisplayText(){
  if(!globalThis.game?.gm)return;
  if(Array.isArray(game.gm.news))game.gm.news=game.gm.news.map(v1521LocalizeInternationalText);
  if(Array.isArray(game.gm.majorEvents)){
    for(const e of game.gm.majorEvents){
      if(e?.title)e.title=v1521LocalizeInternationalText(e.title);
      if(e?.text)e.text=v1521LocalizeInternationalText(e.text);
    }
  }
  const orgs=game.gm.v148?.organizations||{};
  for(const o of Object.values(orgs)){
    if(Array.isArray(o?.history))for(const h of o.history)if(h?.text)h.text=v1521LocalizeInternationalText(h.text);
  }
}

// Translate newly emitted international-organization news before media/MOE layers receive it.
const v1521GmNewsBase=gmNews;
gmNews=function(text){return v1521GmNewsBase(v1521LocalizeInternationalText(text));};

const v1521MajorEventBase=v138MajorEvent;
v138MajorEvent=function(title,text,category='politics',severity='major',key=''){
  return v1521MajorEventBase(v1521LocalizeInternationalText(title),v1521LocalizeInternationalText(text),category,severity,key);
};

// Keep internal voting/action IDs intact while localizing the international-organization panel.
const v1521RenderInternationalBase=renderV148International;
renderV148International=function(){
  let html=v1521RenderInternationalBase();
  html=String(html)
    .replace(/consensus議決/g,'全会一致')
    .replace(/qualified議決/g,'特別多数決')
    .replace(/simple議決/g,'単純多数決');
  // Future-safe: if a later card displays raw resolution IDs, localize them here as well.
  return v1521LocalizeInternationalText(html);
};

// Make the label functions available to later Android/UI work without exposing internal IDs as Japanese save values.
if(typeof window!=='undefined'){
  window.StarFrontierInternationalLabels={
    action:v1521InternationalActionLabel,
    voting:v1521InternationalVotingLabel,
    actions:V1521_INTL_ACTION_LABELS,
    votingRules:V1521_INTL_VOTING_LABELS
  };
}

const v1521LoadBase=load;
load=function(){const out=v1521LoadBase();v1521MigrateExistingInternationalDisplayText();return out;};
const v1521InitBase=initV10;
initV10=function(){const out=v1521InitBase();v1521MigrateExistingInternationalDisplayText();return out;};
