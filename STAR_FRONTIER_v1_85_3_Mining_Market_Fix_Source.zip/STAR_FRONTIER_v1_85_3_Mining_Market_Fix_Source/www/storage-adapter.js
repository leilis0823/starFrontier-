'use strict';
// A classic-script lexical binding routes unchanged historical scripts to the
// native bridge. window.localStorage is used only for one-time legacy migration.
const SF153Persistence=(()=>{
 const native=!!window.AndroidNative?.readSave,primary='starFrontierSaveV11';
 const state={native,raw:null,staged:undefined,ready:false,error:null,migrated:false};
 function unwrap(raw){const r=JSON.parse(raw);if(!r.ok)throw new Error(r.error||'Native storage failed');return r.value;}
 if(native)try{
  state.raw=unwrap(AndroidNative.readSave());
  if(state.raw===null){
   for(const key of [primary,'starFrontierSaveV10','starFrontierSaveV09',...Array.from({length:3},(_,i)=>primary+'Backup'+(i+1))]){
    const raw=window.localStorage.getItem(key);
    if(raw){try{const o=JSON.parse(raw);if(o&&Number(o.day)>=1&&typeof o.system==='string'&&Number.isFinite(Number(o.credits))){state.raw=raw;state.migrated=true;break;}}catch(_){}state.error='旧セーブを検証できません';}
   }
   if(state.raw!==null)state.error=null;
  }
 }catch(e){state.error=String(e.message||e);}
 const facade=native?{
  getItem(k){if(k===primary)return state.staged!==undefined?state.staged:state.raw;if(/^starFrontierSaveV1[01]Backup[123]$/.test(k))return unwrap(AndroidNative.readBackup(Number(k.slice(-1))));if(k==='starFrontierSaveV10'||k==='starFrontierSaveV09')return null;return AndroidNative.getSetting(k);},
  setItem(k,v){v=String(v);if(k===primary){if(!state.ready)return;unwrap(AndroidNative.writeSave(v));state.raw=v;return;}if(k.startsWith(primary+'Backup'))return;if(!AndroidNative.setSetting(k,v))throw new Error('設定の保存に失敗');},
  removeItem(k){if(k.startsWith('starFrontierSave'))return;AndroidNative.setSetting(k,null);}
 }:window.localStorage;
 return {state,facade,unwrap};
})();
const localStorage=SF153Persistence.facade;
