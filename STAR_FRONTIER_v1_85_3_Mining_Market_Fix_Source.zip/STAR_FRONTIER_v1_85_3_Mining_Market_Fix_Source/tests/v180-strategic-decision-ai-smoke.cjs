'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/124-v1_80-strategic-decision-ai.js'),'utf8');

const SYSTEMS={
 aurora:{name:'オーロラ',faction:'league',security:'高'},
 frontier:{name:'フロンティア',faction:'league',security:'低'},
 forge:{name:'フォージ',faction:'imperium',security:'軍管'}
};
const FACTIONS={league:{short:'連盟'},imperium:{short:'帝国'}};
const V12_FACTION_IDS=['league','imperium'];
const V127_ENTERPRISE_STRATEGIES={
 conservative:{name:'保守',reserve:.35},efficiency:{name:'効率',reserve:.22},innovation:{name:'革新',reserve:.20},growth:{name:'成長',reserve:.15},market:{name:'市場',reserve:.18},state:{name:'国家案件',reserve:.20}
};
const V127_STATE_PRIORITIES={league:['aerospace','infrastructure'],imperium:['arms','shipbuilding']};
const V169_COMMODITIES={titanium:{name:'チタン鉱'},fuel:{name:'融合燃料'}};
const V168_DOMAINS={propulsion:{name:'推進技術'},automation:{name:'産業AI'}};
const V175_CATS={munitions:{name:'弾薬'},fleet_parts:{name:'艦隊部品'},fuel:{name:'燃料'},rations:{name:'糧食'}};

const enterprises={
 'corp:distress':{key:'corp:distress',faction:'league',industry:'aerospace',home:'aurora',locationSystem:'aurora',strategy:'growth',status:'operating',distress:78,debt:42000,lastProfit:-4500,marketShare:11,quality:62,revenueTotal:18000,techLevel:1},
 'corp:innovator':{key:'corp:innovator',faction:'league',industry:'aerospace',home:'aurora',locationSystem:'aurora',strategy:'market',status:'operating',distress:0,debt:5000,lastProfit:5200,marketShare:22,quality:58,revenueTotal:42000,techLevel:1},
 'player:parent':{key:'player:parent',faction:'league',industry:'aerospace',home:'aurora',locationSystem:'aurora',strategy:'growth',status:'operating',distress:65,debt:26000,lastProfit:-1800,marketShare:8,quality:60,revenueTotal:26000,techLevel:1}
};
const cash={'corp:distress':1800,'corp:innovator':90000,'player:parent':2200};
const credit={'corp:distress':{score:470},'corp:innovator':{score:760},'player:parent':{score:520}};
let rv=.5;
const calls={loan:0,consult:0,supply:0,future:0,research:0,capex:0,policy:0,support:0,tender:0,award:0,infra:0,grant:0,raid:0,occupation:0};
const logs=[];
const game={day:100,version:'1.79.0',war:{active:false,a:'league',b:'imperium'},playerCorporation:{created:true},freeCaptains:{heat:0,organization:{created:true,type:'pirate',treasury:9000,heat:18}},gm:{
 enterpriseEconomy:{enterprises},creditMarket:{profiles:credit},commodityMarket:{benchmarks:{titanium:{volatility:.08,momentum:1.2}},supplyContracts:[],futures:[]},consulting:{engagements:[]},geoeconomicCrisis:{systems:{aurora:{severity:15},frontier:{severity:8},forge:{severity:25}}},
 factions:{league:{treasury:70000,stability:62},imperium:{treasury:65000,stability:58}},
 irregular:{pirateBands:{red:{id:'red',name:'紅牙団',status:'active',system:'aurora',treasury:14000,power:13,heat:96,notoriety:55}},bounties:[{status:'open',targetKey:'pirate:red',amount:24000}]},
 v178:{routeDanger:{aurora:70,frontier:5,forge:35}},governments:{league:{},imperium:{}},publicInfrastructure:{systems:{aurora:{overall:80},frontier:{overall:68},forge:{overall:76}}},populationLabor:{factions:{league:{unemployment:5},imperium:{unemployment:7}}}
}};

function rng(){return rv}
function escapeHtml(s){return String(s??'')}
function addLog(s){logs.push(s)}
function toast(){}
function render(){}
function renderGM(){}
function renderPlayerCorporation(){}
function initV10(){return true}
function gmAdvance(){game.day++;return true}
function ensureV179State(){game.version='1.79.0'}
function v127EnterpriseRef(k){return {key:k}}
function v127GetCash(ref){return cash[ref.key]||0}
function v127AddCash(ref,n){cash[ref.key]=(cash[ref.key]||0)+n;return cash[ref.key]}
function v127AssetReadiness(e){return e.key==='corp:innovator'?.95:.82}
function v168EffectiveTech(e){return e.key==='corp:innovator'?{generation:1,frontier:4,adoption:28,gap:3}:{generation:1,frontier:1,adoption:65,gap:0}}
function v169InputCommodity(){return 'titanium'}
function v169HedgeCoverage(){return 0}
function v127RequestCorporateLoan(e,amt){calls.loan++;cash[e.key]=(cash[e.key]||0)+amt;return amt}
function v161CreateEngagement(client,specialty){calls.consult++;const q={id:`c${calls.consult}`,client,specialty,status:'active'};game.gm.consulting.engagements.push(q);return q}
function v169CreateSupplyContract(buyer,commodity){calls.supply++;const q={id:`s${calls.supply}`,buyer,commodity,status:'active'};game.gm.commodityMarket.supplyContracts.push(q);return q}
function v169OpenFuture(owner,commodity){calls.future++;const q={id:`f${calls.future}`,owner,commodity,status:'open'};game.gm.commodityMarket.futures.push(q);return q}
function v168StartProgram(e){calls.research++;return {domain:'propulsion',generation:2}}
function v127StartCapitalProject(){calls.capex++;return {id:'capex'}}
function v159EnterpriseState(e){return {currentSystem:e.home}}
function v159LocationScore(){return 72}
function v159CreateProposal(){return {id:'move'}}
function v127EnterpriseName(k){return k}
const macro={league:{inflation:12.5,policyRate:.03,fx:1.25},imperium:{inflation:2.2,policyRate:.04,fx:1.0}};
function v170Macro(fid){return macro[fid]}
function v175Threat(fid){return fid==='imperium'?82:35}
function v124PiracyPressure(sid){return sid==='aurora'?55:sid==='frontier'?12:25}
function v127StockRatio(fid,k){return fid==='imperium'?.35:.85}
function v170PolicyAI(){calls.policy++;return true}
function v126StartSupportContract(){calls.support++;return {id:'support'}}
function v124SystemTradeValue(sid){return sid==='aurora'?50000:12000}
function v175OpenTender(){calls.tender++;return {id:'tender'}}
function v175AwardTender(){calls.award++;return true}
function v167SystemProfile(sid){const p=game.gm.publicInfrastructure.systems[sid];return {systemId:sid,overall:p.overall,powerReliability:65,waterReliability:80,telecomReliability:85,transitReliability:75}}
function v167StartPublicProject(){calls.infra++;return {name:'送電網更新'}}
function v168GovernmentGrants(){calls.grant++;return true}
function v126Sec(){return {objective:''}}
function v124PatrolCoverage(sid){return sid==='aurora'?48:sid==='frontier'?4:35}
function v124NpcPirateRaid(b){calls.raid++;b.treasury+=1200;return true}
function v125MaybeNpcOccupation(){calls.occupation++;return true}
function v124PlayerOrgPower(){return 12}
const document={title:'',querySelector:()=>null,getElementById:()=>null};

const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,SYSTEMS,FACTIONS,V12_FACTION_IDS,V127_ENTERPRISE_STRATEGIES,V127_STATE_PRIORITIES,V169_COMMODITIES,V168_DOMAINS,V175_CATS,game,rng,escapeHtml,addLog,toast,render,renderGM,renderPlayerCorporation,initV10,gmAdvance,ensureV179State,v127EnterpriseRef,v127GetCash,v127AddCash,v127AssetReadiness,v168EffectiveTech,v169InputCommodity,v169HedgeCoverage,v127RequestCorporateLoan,v161CreateEngagement,v169CreateSupplyContract,v169OpenFuture,v168StartProgram,v127StartCapitalProject,v159EnterpriseState,v159LocationScore,v159CreateProposal,v127EnterpriseName,v170Macro,v175Threat,v124PiracyPressure,v127StockRatio,v170PolicyAI,v126StartSupportContract,v124SystemTradeValue,v175OpenTender,v175AwardTender,v167SystemProfile,v167StartPublicProject,v168GovernmentGrants,v126Sec,v124PatrolCoverage,v124NpcPirateRaid,v125MaybeNpcOccupation,v124PlayerOrgPower,document};
ctx.window=ctx;ctx.global=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);
vm.runInContext('ensureV180State()',ctx);
assert.equal(game.version,'1.80.0');

// 1. Distressed firm must choose financial defence rather than growth and align existing short-term AI strategy.
let p=vm.runInContext("v180PlanEnterprise(game.gm.enterpriseEconomy.enterprises['corp:distress'],true)",ctx);
assert.equal(p.objective,'liquidity','distressed enterprise did not prioritize liquidity');
assert.equal(enterprises['corp:distress'].strategy,'conservative','strategic plan did not align underlying enterprise AI');
game.day=p.nextActionDay;vm.runInContext("v180EnterpriseAction(game.gm.enterpriseEconomy.enterprises['corp:distress'],v180State().enterprises['corp:distress'].plan,{manual:false})",ctx);
assert(calls.loan+calls.consult>0,'liquidity plan did not invoke existing finance/consulting system');

// 2. A profitable firm with a large technology gap should prioritize innovation and use the existing R&D engine.
game.day+=10;game.gm.strategicAI.enterprises['corp:innovator'].plan=null;
p=vm.runInContext("v180PlanEnterprise(game.gm.enterpriseEconomy.enterprises['corp:innovator'],true)",ctx);
assert.equal(p.objective,'innovation','technology-lagging profitable firm did not prioritize innovation');
assert.equal(enterprises['corp:innovator'].strategy,'innovation');
game.day=p.nextActionDay;vm.runInContext("v180EnterpriseAction(game.gm.enterpriseEconomy.enterprises['corp:innovator'],v180State().enterprises['corp:innovator'].plan,{manual:false})",ctx);
assert(calls.research>0,'innovation plan did not invoke existing R&D');

// 3. High inflation / FX stress should make the state prioritize price stability and call existing monetary-policy AI.
game.day+=10;game.gm.strategicAI.states.league.plan=null;vm.runInContext("v180StateAI('league')",ctx);
let sp=game.gm.strategicAI.states.league.plan;assert.equal(sp.objective,'price_stability','high-inflation state did not prioritize price stability');
game.day=sp.nextActionDay;vm.runInContext("v180StateAI('league')",ctx);assert(calls.policy>0,'state strategic AI did not invoke existing monetary policy AI');

// 4. High heat, bounty and patrol pressure should force pirates into survival mode and away from the hot system.
game.day+=10;game.gm.strategicAI.pirates.red.plan=null;const beforeSys=game.gm.irregular.pirateBands.red.system,beforeHeat=game.gm.irregular.pirateBands.red.heat;vm.runInContext("v180PirateAI(game.gm.irregular.pirateBands.red)",ctx);let pp=game.gm.strategicAI.pirates.red.plan;assert.equal(pp.objective,'survival','high-heat pirate did not prioritize survival');game.day=pp.nextActionDay;vm.runInContext("v180PirateAI(game.gm.irregular.pirateBands.red)",ctx);assert.notEqual(game.gm.irregular.pirateBands.red.system,beforeSys,'survival plan did not relocate pirate');assert(game.gm.irregular.pirateBands.red.heat<beforeHeat,'survival plan did not lower heat');assert.equal(calls.raid,0,'survival plan should not raid');

// 5. Player defaults to advisor mode and cannot silently borrow / capex without permission.
game.day+=10;const ps=vm.runInContext('v180State().player',ctx);assert.equal(ps.mode,'advisor');assert.equal(ps.permissions.borrowing,false);assert.equal(ps.permissions.capex,false);const loanBefore=calls.loan,capexBefore=calls.capex;vm.runInContext("v180PlanEnterprise(game.gm.enterpriseEconomy.enterprises['player:parent'],true);v180ProcessPlayerAI()",ctx);assert.equal(calls.loan,loanBefore,'advisor mode silently borrowed');assert.equal(calls.capex,capexBefore,'advisor mode silently invested');const recs=vm.runInContext('v180RefreshPlayerRecommendations(true)',ctx);assert(recs.length>0,'player strategic recommendations missing');

// 6. Limited delegation still respects explicit permissions.
vm.runInContext("v180SetPlayerMode('limited')",ctx);assert.equal(ps.mode,'limited');const playerPlan=vm.runInContext("v180PlanEnterprise(game.gm.enterpriseEconomy.enterprises['player:parent'],true)",ctx);assert.equal(playerPlan.objective,'liquidity');game.day=playerPlan.nextActionDay;vm.runInContext("v180EnterpriseAction(game.gm.enterpriseEconomy.enterprises['player:parent'],v180State().enterprises['player:parent'].plan,{manual:false})",ctx);assert.equal(calls.loan,loanBefore,'limited mode borrowed despite borrowing permission OFF');
vm.runInContext("v180TogglePermission('borrowing')",ctx);game.gm.strategicAI.enterprises['player:parent'].plan.nextActionDay=game.day;vm.runInContext("v180EnterpriseAction(game.gm.enterpriseEconomy.enterprises['player:parent'],v180State().enterprises['player:parent'].plan,{manual:false})",ctx);assert(calls.loan>loanBefore,'explicit borrowing permission was not honored');

// 7. KPI review learns from outcomes without replacing authoritative systems.
const ep=game.gm.strategicAI.enterprises['corp:innovator'].plan;ep.reviewed=false;ep.baseline={...ep.baseline,techGap:5,techAdoption:20};enterprises['corp:innovator'].techLevel=2;game.day+=31;game.gm.strategicAI.lastQuarterDay=game.day-31;vm.runInContext('v180LearningReview()',ctx);assert(game.gm.strategicAI.enterprises['corp:innovator'].learning.innovation!==undefined,'KPI learning was not updated');

console.log('V180_STRATEGIC_DECISION_AI_SMOKE_PASS',JSON.stringify({enterpriseObjective:game.gm.strategicAI.enterprises['corp:innovator'].plan.objective,stateObjective:game.gm.strategicAI.states.league.plan.objective,pirateObjective:game.gm.strategicAI.pirates.red.plan.objective,playerMode:ps.mode,actions:game.gm.strategicAI.metrics.actions,recommendations:game.gm.strategicAI.metrics.playerRecommendations,calls},null,2));
