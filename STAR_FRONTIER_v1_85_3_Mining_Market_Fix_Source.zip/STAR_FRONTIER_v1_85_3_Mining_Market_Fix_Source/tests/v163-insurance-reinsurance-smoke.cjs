'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/107-v1_63-insurance-reinsurance.js'),'utf8');
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const V19_INSURERS={
 aegis:{name:'Aegis',short:'Aegis',capital:92000},polaris:{name:'Polaris',short:'Polaris',capital:128000},argent:{name:'Argent',short:'Argent',capital:81000},wayline:{name:'Wayline',short:'Wayline',capital:61000}
};
const V129_INSURER_HOME={aegis:'league',polaris:'helios',argent:'league',wayline:'orpheus'};
const V120_INSURER_BY_INDUSTRY={airline:'polaris'};
const V130_CONTRACT_TYPES={};
const V160_AIRCRAFT_TYPES={a180:{name:'A180',price:20000}};
const SYSTEMS={aurora:{name:'Aurora',faction:'league'},forge:{name:'Forge',faction:'helios'}};
const FACTIONS={league:{short:'League'},helios:{short:'Helios'},orpheus:{short:'Orpheus'}};
const cash={'player:parent':50000,'aviation:test_air':90000};
const game={day:100,version:'1.62.0',system:'aurora',war:{active:true,a:'league',b:'helios'},playerCorporation:{created:true,name:'PlayerCo',homeFaction:'league',treasury:50000,businessLines:['infrastructure']},gm:{
 insurers:{aegis:{capital:92000,claims:0},polaris:{capital:128000,claims:0},argent:{capital:81000,claims:0},wayline:{capital:61000,claims:0}},
 v129:{insurance:{providers:{aegis:{baseline:92000,rateIndex:1,underwriting:'normal',premiums:0,claims:0},polaris:{baseline:128000,rateIndex:1,underwriting:'normal',premiums:0,claims:0},argent:{baseline:81000,rateIndex:1,underwriting:'normal',premiums:0,claims:0},wayline:{baseline:61000,rateIndex:1,underwriting:'normal',premiums:0,claims:0}},history:[]}},
 enterpriseEconomy:{enterprises:{
  'player:parent':{key:'player:parent',industry:'infrastructure',faction:'league',home:'aurora',lastRevenue:900,facilities:[{cost:12000}],equipment:[{cost:5000}],capitalProjects:[{id:'proj1',name:'Factory',status:'building',cost:18000}],history:[],v129:{insurance:{insurer:'aegis',until:112,premium:900,risk:45,status:'active',claims:0}}},
  'aviation:test_air':{key:'aviation:test_air',industry:'airline',faction:'league',home:'aurora',lastRevenue:1200,facilities:[{cost:10000}],equipment:[],capitalProjects:[],history:[],v129:{insurance:{insurer:'polaris',until:112,premium:1100,risk:55,status:'active',claims:0}}}
 }},
 realEstate:{buildings:{foreign1:{id:'foreign1',systemId:'forge',owner:'state:helios',previousOwner:'player:parent',value:18000,crisisAssetStatus:'seized'}},parcels:{}},
 geoeconomicCrisis:{systems:{aurora:{severity:92},forge:{severity:100}},seizures:[{id:'seize1',kind:'building_seizure',assetId:'foreign1',previousOwner:'player:parent',paid:2000,compensation:4000,reason:'war'}]},
 systemLogistics:{aurora:{routeHealth:30}},
 aviation:{aircraft:{ac1:{id:'ac1',typeId:'a180',owner:'aviation:test_air',operator:'aviation:test_air',condition:52,status:'maintenance_due'}},routes:{r1:{id:'r1',operator:'aviation:test_air',from:'aurora',to:'forge',status:'suspended',lastRisk:100,revenue:6000,flights:12}}},
 v130:{contracts:{},contractOrder:[],disputes:[],nextDispute:1}
}};
function v127EnterpriseRef(k){const e=game.gm.enterpriseEconomy.enterprises[k];return e?{key:k,kind:k==='player:parent'?'player_parent':'aviation',faction:e.faction,industry:e.industry,home:e.home}:null}
function v127GetCash(ref){return cash[ref.key]||0}
function v127AddCash(ref,n){cash[ref.key]=Math.max(0,(cash[ref.key]||0)+n);if(ref.key==='player:parent')game.playerCorporation.treasury=cash[ref.key]}
function v130PartyName(k){if(k.startsWith('insurer:'))return k;if(k.startsWith('state:'))return k;return k}
function v130PartyFaction(k){if(k.startsWith('insurer:'))return V129_INSURER_HOME[k.slice(8)]||'league';if(k.startsWith('state:'))return k.slice(6);return game.gm.enterpriseEconomy.enterprises[k]?.faction||'league'}
function v130PartyCash(k){if(k.startsWith('insurer:'))return game.gm.insurers[k.slice(8)]?.capital||0;if(k.startsWith('state:'))return 0;return cash[k]||0}
function v130AddPartyCash(k,n){if(k.startsWith('insurer:')){const f=game.gm.insurers[k.slice(8)];f.capital=Math.max(0,f.capital+n);return}cash[k]=Math.max(0,(cash[k]||0)+n)}
function v130UpsertContract(id,d){const old=game.gm.v130.contracts[id];game.gm.v130.contracts[id]=old?Object.assign(old,d):{id,created:game.day,breachLevel:0,...d};if(!game.gm.v130.contractOrder.includes(id))game.gm.v130.contractOrder.unshift(id);return game.gm.v130.contracts[id]}
function v130OpenDispute(c,issue,claimAmount,severity){const d={id:'d'+game.gm.v130.nextDispute++,contractId:c.id,issue,claimAmount,severity};game.gm.v130.disputes.push(d);c.disputeId=d.id;c.status='disputed';return d}
function v129InsurerState(id){return game.gm.v129.insurance.providers[id]}
function v129EnterpriseRisk(e){return e.industry==='airline'?65:50}
function v129EnterpriseAssetValue(e){return [...(e.facilities||[]),...(e.equipment||[])].reduce((n,a)=>n+(a.cost||0),0)}
function v1283LiquidityProfile(){return{reserve:2500}}
function v129ReviewEnterpriseInsurance(){return null}
function v129MaybeEnterpriseIncident(){return null}
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,clamp,game,V19_INSURERS,V129_INSURER_HOME,V120_INSURER_BY_INDUSTRY,V130_CONTRACT_TYPES,V160_AIRCRAFT_TYPES,SYSTEMS,FACTIONS,
 v127EnterpriseRef,v127GetCash,v127AddCash,v130PartyName,v130PartyFaction,v130PartyCash,v130AddPartyCash,v130UpsertContract,v130OpenDispute,v129InsurerState,v129EnterpriseRisk,v129EnterpriseAssetValue,v1283LiquidityProfile,v129ReviewEnterpriseInsurance,v129MaybeEnterpriseIncident,
 ensureV162State:()=>{},v130SyncContracts:()=>{},initV10:()=>{},gmAdvance:()=>{game.day++;return true},renderV117PlayerBusiness:()=>'',renderGM:()=>{},render:()=>{},escapeHtml:s=>String(s??''),document:{querySelector:()=>null,getElementById:()=>null}
};
ctx.global=ctx;ctx.window=ctx;vm.createContext(ctx);vm.runInContext(src,ctx,{filename:'107-v1_63-insurance-reinsurance.js'});
vm.runInContext('ensureV163State()',ctx);
assert.equal(Object.keys(game.gm.insuranceReinsurance.reinsurers).length,3,'reinsurer count');
assert.equal(Object.keys(game.gm.insuranceReinsurance.treaties).length,4,'treaty count');
const pp=Object.values(game.gm.insuranceReinsurance.policies).find(p=>p.holder==='player:parent');
const ap=Object.values(game.gm.insuranceReinsurance.policies).find(p=>p.holder==='aviation:test_air');
assert(pp&&pp.lines.construction&&pp.lines.political,'player specialized lines missing');
assert(ap&&ap.lines.aviation&&ap.lines.interruption,'aviation specialized lines missing');
// Crisis construction contract should trigger a construction claim.
v130UpsertContract('crisis-construction:proj1',{type:'construction_crisis',parties:['player:parent','support:prime'],status:'active',value:18000,outstanding:0,breachLevel:70,summary:'war delay'});
const playerBefore=cash['player:parent'];
vm.runInContext('v163ProcessCrisisClaims()',ctx);
assert(game.gm.insuranceReinsurance.claimOrder.length>=2,'crisis claims missing');
assert(cash['player:parent']>playerBefore,'claim cash did not reach player');
assert(game.gm.insuranceReinsurance.metrics.politicalClaims>=1,'political claim missing');
assert(game.gm.insuranceReinsurance.metrics.constructionClaims>=1,'construction claim missing');
// Airspace + hull claims should hit airline and trigger reinsurance recovery.
const airBefore=cash['aviation:test_air'];
vm.runInContext('v163ProcessAviationClaims()',ctx);
assert(cash['aviation:test_air']>airBefore,'aviation claim payout missing');
assert(game.gm.insuranceReinsurance.metrics.airspaceClaims>=1,'airspace claim counter missing');
assert(game.gm.insuranceReinsurance.metrics.reinsurancePaid>0,'reinsurance recovery missing');
// Force a reinsurer shortage and verify recovery default becomes legal contract/dispute.
vm.runInContext('game.gm.insuranceReinsurance.reinsurers.helios_re.capital=36000',ctx);
const c=vm.runInContext('v163FileClaim("aviation:test_air","aviation",50000,"forced-cat","test","catastrophe")',ctx);
assert(c,'forced catastrophic claim not created');
assert(game.gm.insuranceReinsurance.metrics.reinsuranceDefaults>=1,'reinsurance default missing');
assert(Object.values(game.gm.v130.contracts).some(c=>c.type==='reinsurance_recovery'&&c.outstanding>0),'reinsurance breach contract missing');
assert(game.gm.v130.disputes.length>=1,'reinsurance dispute missing');
vm.runInContext('v163SyncContracts()',ctx);
assert(Object.values(game.gm.v130.contracts).some(c=>c.type==='insurance_policy'),'policy contract missing');
assert(Object.values(game.gm.v130.contracts).some(c=>c.type==='insurance_claim'),'claim contract missing');
assert(Object.values(game.gm.v130.contracts).some(c=>c.type==='reinsurance_treaty'),'reinsurance treaty contract missing');
assert.doesNotThrow(()=>JSON.parse(vm.runInContext('JSON.stringify(game.gm.insuranceReinsurance)',ctx)));
assert.equal(vm.runInContext('game.version',ctx),'1.63.0');
console.log('V163_INSURANCE_REINSURANCE_SMOKE_PASS',JSON.stringify({reinsurers:Object.keys(game.gm.insuranceReinsurance.reinsurers).length,policies:Object.keys(game.gm.insuranceReinsurance.policies).length,claims:game.gm.insuranceReinsurance.claimOrder.length,reinsurancePaid:game.gm.insuranceReinsurance.metrics.reinsurancePaid,reinsuranceDefaults:game.gm.insuranceReinsurance.metrics.reinsuranceDefaults,disputes:game.gm.v130.disputes.length},null,2));
