'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/125-v1_81-industrial-recipes-equipment-mythic.js'),'utf8');

const ores=['hematite','ilmenite','bauxite','chalcopyrite','pentlandite','spodumene','uraninite','monazite','pgm_ore','silicate','star_matrix'];
const SYSTEMS={aurora:{name:'Aurora',faction:'league'},forge:{name:'Forge',faction:'helios'},umbra:{name:'Umbra',faction:'orpheus'},drakon:{name:'Drakon',faction:'imperium'},nyx:{name:'Nyx',faction:'nyxdom'},kronos:{name:'Kronos',faction:'volgar'},orion:{name:'Orion',faction:'league'},cinder:{name:'Cinder',faction:'nyxdom'},meridian:{name:'Meridian',faction:'orpheus'},elysia:{name:'Elysia',faction:'concord'}};
const HULLS={
 demeter:{name:'DEMETER-class',class:'carrier',cost:150000,baseCargo:180,baseFuel:260,mining:-3,engine:.05,military:3,heritageSeries:'greek'},
 njord:{name:'NJORD-class',class:'cruiser',cost:140000,baseCargo:130,baseFuel:260,mining:-3,engine:.12,military:3,heritageSeries:'norse'},
 sleipnir:{name:'SLEIPNIR-class',class:'cruiser',cost:145000,baseCargo:100,baseFuel:300,mining:-3,engine:.25,military:3,heritageSeries:'norse'},
 nirai_kanai:{name:'NIRAI-KANAI-class',class:'carrier',cost:170000,baseCargo:190,baseFuel:320,mining:-2,engine:.10,military:3,heritageSeries:'ryukyu'},
 mammon:{name:'MAMMON-class',class:'carrier',cost:171000,baseCargo:190,baseFuel:250,mining:-4,engine:.04,military:3,heritageSeries:'infernal'},
 base_freighter:{name:'Base Freighter',class:'freighter',cost:10000,baseCargo:80,baseFuel:100,mining:0,engine:.02}
};
const SHIP_MODULES={base_gun:{name:'Base gun',slot:'主砲',weight:5,power:5,cost:1000,combat:5,defense:0}};
const SHIP_CLASSES={prospect:{name:'探査艇'},freighter:{name:'貨物船'},corvette:{name:'コルベット'},frigate:{name:'フリゲート'},cruiser:{name:'巡洋艦'},carrier:{name:'空母'},battleship:{name:'戦艦'},dread:{name:'超大型艦'}};
const V13_COMMON_YARD_HULLS=['base_freighter'];
const V17_CORPORATIONS={
 regulus:{name:'Regulus',short:'Regulus',home:'aurora',modules:[]},crownforge:{name:'Crownforge',short:'Crownforge',home:'drakon',modules:[]},asterion:{name:'Asterion',short:'Asterion',home:'forge',modules:[]},
 horizon:{name:'Horizon',short:'Horizon',home:'aurora',modules:[]},nox:{name:'Nox',short:'Nox',home:'cinder',modules:[]},pilgrim:{name:'Pilgrim',short:'Pilgrim',home:'aurora',modules:[]},meridian:{name:'Meridian',short:'Meridian',home:'umbra',modules:[]},helix:{name:'Helix',short:'Helix',home:'elysia',modules:[]},
 arclight:{name:'Arclight',short:'Arclight',home:'forge',modules:['base_gun']},bulwark:{name:'Bulwark',short:'Bulwark',home:'umbra',modules:[]},synapse:{name:'Synapse',short:'Synapse',home:'aurora',modules:[]}
};
const V176_ORES=Object.fromEntries(ores.map(k=>[k,{base:100}]));
const deposits=Object.fromEntries(Object.keys(SYSTEMS).map(sid=>[sid,Object.fromEntries(ores.map(k=>[k,70]))]));
const playerOre=Object.fromEntries(ores.map(k=>[k,20]));
const game={day:20,version:'1.80.0',system:'aurora',credits:500000,ownedHulls:[],corporateOrders:[],gm:{corporations:{},factions:{league:{treasury:100000},helios:{treasury:100000},orpheus:{treasury:100000},imperium:{treasury:100000},nyxdom:{treasury:100000},volgar:{treasury:100000},concord:{treasury:100000}},v179:{mining:{bases:[]}},equipmentMarket:{makers:{}}}};
for(const cid of Object.keys(V17_CORPORATIONS))game.gm.corporations[cid]={wealth:100000};
for(const cid of ['arclight','bulwark','synapse'])game.gm.equipmentMarket.makers[cid]={stock:{}};
let lastToast='', logs=[];
function rng(){return .5} function escapeHtml(s){return String(s??'')} function toast(s){lastToast=String(s||'')} function addLog(s){logs.push(s)} function render(){} function renderMarket(){} function renderRegionalShipyard(){} function shipyardCard(){return '<div><p>x</p></div><div></div>'}
function v176EnsureDeposits(sid){return deposits[sid]} function v176State(){return {ores:playerOre}} function v176OrePrice(){return 100}
function ensureV180State(){game.version='1.80.0'} function ensureV112State(){} function initV10(){return true} function gmAdvance(){game.day++;return true}
function v112EquipmentCorpIds(){return ['arclight','bulwark','synapse']}
function processV112Equipment(){for(const cid of v112EquipmentCorpIds()){const st=game.gm.equipmentMarket.makers[cid];for(const mid of V17_CORPORATIONS[cid].modules)st.stock[mid]=(st.stock[mid]||0)+1}return true}
function buyHull(id){const h=HULLS[id];if(!h||game.credits<h.cost||game.ownedHulls.includes(id))return false;game.credits-=h.cost;game.ownedHulls.push(id);return true}
function commissionCorporateHull(cid,hid){game.corporateOrders.push({cid,hid});return {cid,hid}}
const document={title:'',querySelector:()=>null,getElementById:()=>null};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,HULLS,SHIP_MODULES,SHIP_CLASSES,V13_COMMON_YARD_HULLS,V17_CORPORATIONS,V176_ORES,SYSTEMS,game,rng,escapeHtml,toast,addLog,render,renderMarket,renderRegionalShipyard,shipyardCard,v176EnsureDeposits,v176State,v176OrePrice,ensureV180State,ensureV112State,initV10,gmAdvance,v112EquipmentCorpIds,processV112Equipment,buyHull,commissionCorporateHull,document};ctx.window=ctx;ctx.global=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);vm.runInContext('ensureV181State()',ctx);

// 1. All requested ores are wired into production, and the heavy recipe uses every one.
const labels=vm.runInContext('Object.keys(V181_ORE_LABELS)',ctx);assert.deepEqual(Array.from(labels),ores);
const heavy=vm.runInContext("v181CloneRecipe(V181_HULL_BASE_RECIPES.battleship)",ctx);for(const k of ores)assert(heavy[k]>0,`battleship recipe missing ${k}`);

// 2. Ordinary mass-market catalogue is substantially expanded and remains ordinary/non-special.
const marketIds=vm.runInContext('Object.keys(V181_MARKET_HULLS)',ctx);assert(marketIds.length>=12,'ordinary market catalogue too small');
for(const id of marketIds){const h=HULLS[id];assert.equal(h.marketHull,true);assert(!h.special,`${id} became special`);assert(!h.military,`${id} unexpectedly requires military license`);assert(V13_COMMON_YARD_HULLS.includes(id),`${id} not in common yard catalogue`)}

// 3. Heritage designs are derivatives only: originals retain military/heritage identity.
const derivIds=vm.runInContext('Object.keys(V181_HERITAGE_DERIVATIVES)',ctx);assert(derivIds.length>=5);
for(const id of derivIds){const h=HULLS[id],p=HULLS[h.heritageDerivative];assert(p&&p.heritageSeries,'heritage original missing');assert(p.military,'heritage original lost special military gate');assert.equal(h.marketHull,true);assert(!h.heritageSeries,'derivative should not replace original heritage identity');assert.notEqual(id,h.heritageDerivative)}

// 4. New equipment is distributed through existing corporate market producer lists.
for(const cid of ['arclight','bulwark','synapse']){const mids=V17_CORPORATIONS[cid].modules.filter(mid=>SHIP_MODULES[mid]?.marketProduct);assert(mids.length>=3,`${cid} did not receive enough mass-market equipment`);for(const mid of mids)assert.equal(SHIP_MODULES[mid].corporation,cid)}

// 5. Buying an ordinary hull consumes the producer's actual ore stock and shortage blocks production.
const hid='regulus_mariner',sid='aurora';const recipe=vm.runInContext(`v181HullRecipe('${hid}')`,ctx);const st=game.gm.v181.systems[sid].ores;for(const [k,n] of Object.entries(recipe))st[k]=n+5;const before=Object.fromEntries(Object.entries(recipe).map(([k])=>[k,st[k]]));ctx.buyHull(hid);assert(game.ownedHulls.includes(hid),'market hull purchase failed');for(const [k,n] of Object.entries(recipe))assert(Math.abs(st[k]-(before[k]-n))<1e-9,`${k} was not consumed`);
const hid2='regulus_surveyor',recipe2=vm.runInContext(`v181HullRecipe('${hid2}')`,ctx);for(const k of Object.keys(recipe2))st[k]=0;lastToast='';ctx.buyHull(hid2);assert(!game.ownedHulls.includes(hid2),'hull built without raw materials');assert(lastToast.includes('造船資材不足'),'shortage feedback missing');

// 6. Equipment production cannot create free stock when producer materials are exhausted.
for(const cid of ['arclight','bulwark','synapse'])for(const mid of V17_CORPORATIONS[cid].modules)game.gm.equipmentMarket.makers[cid].stock[mid]=0;
for(const z of Object.values(game.gm.v181.systems))for(const k of ores)z.ores[k]=0;
ctx.processV112Equipment();
for(const cid of ['arclight','bulwark','synapse'])for(const mid of V17_CORPORATIONS[cid].modules)assert.equal(game.gm.equipmentMarket.makers[cid].stock[mid]||0,0,`free equipment produced: ${cid}/${mid}`);

// 7. Player ore supply replenishes industrial stock and transfers real money.
const rawBefore=playerOre.hematite,indBefore=game.gm.v181.systems.aurora.ores.hematite,crBefore=game.credits;ctx.v181SupplyOre('hematite',5);assert(playerOre.hematite<rawBefore);assert(game.gm.v181.systems.aurora.ores.hematite>indBefore);assert(game.credits>crBefore);

console.log('V181_INDUSTRIAL_RECIPES_EQUIPMENT_MYTHIC_SMOKE_PASS',JSON.stringify({marketHulls:marketIds.length,heritageDerivatives:derivIds.length,marketEquipment:['arclight','bulwark','synapse'].reduce((n,c)=>n+V17_CORPORATIONS[c].modules.filter(m=>SHIP_MODULES[m]?.marketProduct).length,0),ores:ores.length,version:game.version},null,2));
