'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'../www');
function noop(){}
function makeClassList(){const s=new Set();return {add(...xs){xs.forEach(x=>s.add(x))},remove(...xs){xs.forEach(x=>s.delete(x))},toggle(x){if(s.has(x)){s.delete(x);return false}s.add(x);return true},contains(x){return s.has(x)}}}
function makeEl(id=''){
 const el={id,textContent:'',innerHTML:'',value:'',checked:false,disabled:false,hidden:false,dataset:{},style:{},className:'',classList:makeClassList(),children:[],parentElement:null,firstChild:null,lastChild:null,nextSibling:null,clientWidth:1200,clientHeight:800,offsetWidth:1200,offsetHeight:800,
  append(...xs){for(const x of xs){if(x&&typeof x==='object'){x.parentElement=this;this.children.push(x);if(!this.firstChild)this.firstChild=x;this.lastChild=x}}},appendChild(x){this.append(x);return x},insertBefore(x){this.append(x);return x},after:noop,before:noop,remove:noop,replaceChildren(...xs){this.children=[];this.firstChild=null;this.lastChild=null;this.append(...xs)},
  setAttribute(k,v){this[k]=String(v)},getAttribute(k){return this[k]??null},removeAttribute(k){delete this[k]},querySelector(){return null},querySelectorAll(){return []},closest(){return null},matches(){return false},addEventListener:noop,removeEventListener:noop,insertAdjacentHTML:noop,scrollIntoView:noop,focus:noop,click:noop
 };return el;
}
const els=new Map();for(const id of ['home','ship','crewPanel','sfShipRegistryPanel'])els.set(id,makeEl(id));
const document={title:'',documentElement:makeEl('html'),body:makeEl('body'),head:makeEl('head'),readyState:'complete',getElementById(id){if(!els.has(id))els.set(id,makeEl(id));return els.get(id)},querySelector(){return makeEl('q')},querySelectorAll(){return []},createElement(tag){return makeEl(tag)},createTextNode(t){return{textContent:String(t)}},addEventListener:noop,removeEventListener:noop};
const storage=new Map(),ls={getItem:k=>storage.has(k)?storage.get(k):null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k),clear:()=>storage.clear()};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Boolean,BigInt,Set,Map,WeakMap,WeakSet,RegExp,Promise,Error,TypeError,RangeError,Intl,parseInt,parseFloat,isNaN,isFinite,encodeURIComponent,decodeURIComponent,document,localStorage:ls,navigator:{userAgent:'probe'},location:{href:'https://appassets.androidplatform.net/www/index.html'},performance:{now:()=>0},requestAnimationFrame:fn=>0,cancelAnimationFrame:noop,setTimeout:fn=>0,clearTimeout:noop,setInterval:fn=>0,clearInterval:noop,AudioContext:function(){},webkitAudioContext:function(){},Blob:function(){},URL:{createObjectURL:()=>'',revokeObjectURL:noop},FileReader:function(){},alert:noop,confirm:()=>true,prompt:(m,d)=>d??'TEST',HTMLElement:function(){},Node:function(){},CSS:{escape:s=>String(s)}};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;ctx.window.localStorage=ls;ctx.window.addEventListener=noop;ctx.window.removeEventListener=noop;ctx.window.innerWidth=1200;ctx.window.innerHeight=800;ctx.window.matchMedia=()=>({matches:false,addEventListener:noop,removeEventListener:noop});
vm.createContext(ctx);
const html=fs.readFileSync(path.join(root,'index.html'),'utf8'),scripts=[...html.matchAll(/<script defer src="([^"]+)"/g)].map(m=>m[1]);
for(const rel of scripts){if(rel==='js/99-bootstrap.js')continue;vm.runInContext(fs.readFileSync(path.join(root,rel),'utf8'),ctx,{filename:rel});}
const evalx=code=>vm.runInContext(code,ctx);
evalx('game=newGame(); initV10(); game.credits=1000000; game.fuel=999; game.maxFuel=999; game.cargoMax=999; render=function(){};');
const seed0=evalx('game.marketSeed');
evalx('StarFrontierDynamicOps.ensure();');
if(evalx('game.marketSeed')!==seed0)throw new Error('v183 ensure consumed global RNG');
const offers=evalx('StarFrontierDynamicOps.generate(game.system,true)');
if(!Array.isArray(offers)||offers.length<2)throw new Error('dynamic mission board did not generate enough offers');
const travelOffer=offers.find(o=>o.type!=='survey')||offers[0];ctx.__offer=travelOffer;
evalx('StarFrontierDynamicOps.accept(__offer.id)');
if(!evalx('game.dynamicOps.active.some(m=>m.id===__offer.id&&m.status==="active")'))throw new Error('mission accept failed');
evalx('game.system=__offer.target; StarFrontierDynamicOps.resolveMission(__offer.id)');
if(!evalx('game.dynamicOps.active.some(m=>m.id===__offer.id&&m.status==="completed")'))throw new Error('standard mission did not complete');

const surveyOffer=offers.find(o=>o.type==='survey')||evalx('StarFrontierDynamicOps.generate(game.system,true).find(o=>o.type==="survey")');
if(!surveyOffer)throw new Error('survey mission missing');ctx.__survey=surveyOffer;
evalx('game.cargoMax=999; StarFrontierDynamicOps.accept(__survey.id); game.system=__survey.target; StarFrontierDynamicOps.resolveMission(__survey.id)');
const surveyMission=evalx('game.dynamicOps.active.find(m=>m.id===__survey.id)');
if(!surveyMission||surveyMission.stage!=='investigate'||!surveyMission.anomalyId)throw new Error('survey mission did not enter anomaly stage');ctx.__anomalyId=surveyMission.anomalyId;
evalx("StarFrontierDynamicOps.resolveAnomaly(__anomalyId,'secure'); StarFrontierDynamicOps.resolveMission(__survey.id)");
if(!evalx('game.dynamicOps.active.find(m=>m.id===__survey.id).status==="completed"'))throw new Error('survey mission chain did not complete');

// Direct deterministic exploration path.
evalx("game.system='cinder'");const a=evalx("StarFrontierDynamicOps.revealAnomaly('cinder','test',true)");if(!a||a.system!=='cinder')throw new Error('forced anomaly reveal failed');ctx.__a=a;
evalx("StarFrontierDynamicOps.resolveAnomaly(__a.id,'observe')");if(evalx('game.dynamicOps.anomalies[__a.id].status')!=='resolved')throw new Error('anomaly resolution failed');
if(evalx('game.dynamicOps.explorationXP')<=0)throw new Error('exploration XP did not increase');
if(evalx('game.marketSeed')!==seed0)throw new Error(`v183 feature actions consumed global RNG: ${seed0} -> ${evalx('game.marketSeed')}`);
console.log('V183_DYNAMIC_CONTRACTS_EXPLORATION_SMOKE_PASS',JSON.stringify({seed:seed0,offers:offers.length,mission:travelOffer.type,surveyAnomaly:surveyMission.anomalyId,rank:evalx('StarFrontierDynamicOps.rank().name'),xp:evalx('game.dynamicOps.explorationXP')}));
