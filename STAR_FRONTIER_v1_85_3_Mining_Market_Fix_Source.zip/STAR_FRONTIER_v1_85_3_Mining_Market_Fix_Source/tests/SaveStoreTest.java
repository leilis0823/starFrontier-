import com.starfrontier.game.SaveStore;
import java.io.*;import java.nio.file.*;import java.nio.channels.FileChannel;import java.util.*;
public class SaveStoreTest {
 static int checks=0;
 static void check(boolean c,String label){if(!c)throw new AssertionError(label);checks++;System.out.println("PASS JVM: "+label);}
 static SaveStore open(Path p)throws Exception{return new SaveStore(p.toFile(),s->{if(!s.startsWith("{\"day\":")||!s.endsWith("}"))throw new IOException("Invalid test JSON");},d->{try(FileChannel c=FileChannel.open(d.toPath(),StandardOpenOption.READ)){c.force(true);}});}
 static String raw(int day){return "{\"day\":"+day+",\"system\":\"aurora\",\"credits\":1200,\"payload\":\""+"星艦".repeat(600000)+"\"}";}
 public static void main(String[] args)throws Exception{
  if(args.length>0&&args[0].equals("crash")){SaveStore s=open(Paths.get(args[1]));s.load();s.setFaultHook(p->{if(p.equals("before-main-replace"))Runtime.getRuntime().halt(91);});s.save(raw(99),false);return;}
  Path p=Files.createTempDirectory("sf1531-");SaveStore s=open(p);check(s.load()==null,"fresh store");String first=raw(1);check(first.getBytes("UTF-8").length>3*1024*1024,"over 3 MiB UTF-8 fixture");s.save(first,false);check(first.equals(open(p).load()),"save and reopen exact bytes");
  for(String point:List.of("after-temp-sync","after-validation","before-main-replace")){s.setFaultHook(where->{if(where.equals(point))throw new IOException("injected failure");});try{s.save(raw(2),false);throw new AssertionError();}catch(IOException expected){}check(first.equals(open(p).load()),point+" preserves primary");}
  s.setFaultHook(point->{});try{s.save("bad",false);throw new AssertionError();}catch(IOException expected){}check(first.equals(s.load()),"invalid input rejected");
  Process child=new ProcessBuilder(System.getProperty("java.home")+"/bin/java","-cp",System.getProperty("java.class.path"),"SaveStoreTest","crash",p.toString()).inheritIO().start();check(child.waitFor()==91,"writer process killed before main replace");check(first.equals(open(p).load()),"reopen after process death");
  // Fast autosaves update only primary; generation creation is explicit.
  for(int d=2;d<=4;d++)s.save(raw(d),false);check(s.backupFileCount()==0,"fast autosaves do not create generation I/O");
  for(int d=5;d<=11;d++)s.save(raw(d),true);check(s.backupCount()==5,"five checkpoint generations");check(s.backup(1).equals(raw(10)),"newest checkpoint is previous primary");
  Files.writeString(p.resolve("main.sav"),"broken");SaveStore recovered=open(p);check(recovered.load().equals(raw(10)),"recover truncated primary");recovered.save(raw(12),false);check(open(p).load().equals(raw(12)),"fast write repairs primary after backup recovery");
  byte[] b=Files.readAllBytes(p.resolve("main.sav"));b[b.length-2]^=1;Files.write(p.resolve("main.sav"),b);check(!open(p).load().equals(raw(12)),"checksum detects corruption");Path bad=Files.createTempDirectory("sf1531-bad-");Files.writeString(bad.resolve("main.sav"),"bad");try{open(bad).save(first,false);throw new AssertionError();}catch(IOException expected){}check(Files.readString(bad.resolve("main.sav")).equals("bad"),"all-corrupt store blocks writes");
  // Coarse performance guard: cached primary autosaves should not need reading/hash of old primary.
  Path bench=Files.createTempDirectory("sf1531-bench-");SaveStore bs=open(bench);bs.save(raw(20),false);long t=System.nanoTime();for(int d=21;d<=25;d++)bs.save(raw(d),false);long ms=(System.nanoTime()-t)/1_000_000L;System.out.println("BENCH JVM: five >3MiB fast autosaves = "+ms+" ms");check(bs.backupFileCount()==0,"benchmark fast path remains generation-free");
  System.out.println("JVM checks passed: "+checks);
 }
}
