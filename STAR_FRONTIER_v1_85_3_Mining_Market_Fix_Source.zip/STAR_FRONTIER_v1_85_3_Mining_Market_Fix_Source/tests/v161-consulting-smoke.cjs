'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/105-v1_61-consulting.js'),'utf8');
const fids=['league','helios','nyxdom','concord','imperium','orpheus','volgar'];
const SYSTEMS={aurora:{faction:'league'},forge:{faction:'helios'},nyx:{faction:'nyxdom'},elysia:{faction:'concord'},drakon:{faction:'imperium'},umbra:{faction:'orpheus'},kronos:{faction:'volgar'},meridian:{faction:'orpheus'},verdant:{faction:'concord'}};
const FACTIONS={};for(const id of fids)FACTIONS[id]={short:id.toUpperCase()};
const V17_CORPORATIONS={alpha:{name:'Alpha Industries',short:'ALPHA',home:'aurora'},beta:{name:'Beta Systems',short:'BETA',home:'forge'}};
const game={day:40,version:'1.60.0',war:{active:false},playerCorporation:{created:true,treasury:52000,businessLines:['manufacturing']},gm:{factions:{},corporations:{alpha:{wealth:42000},beta:{wealth:36000}},systemLogistics:{aurora:{routeHealth:92,shortage:3},forge:{routeHealth:78,shortage:12}},laborMarkets:{league:{wageIndex:104,unemployment:4.8},helios:{wageIndex:108,unemployment:2.4}},enterpriseEconomy:{enterprises:{},supportFirms:{}},capitalMarkets:{companies:{alpha:{totalShares:10000,player:0,stateHoldings:{},corpHoldings:{}},beta:{totalShares:10000,player:0,stateHoldings:{},corpHoldings:{}}}},v130:{contracts:{},contractOrder:[],disputes:[]},realEstate:{},employeeLabor:{}}};
for(const fid of fids)game.gm.factions[fid]={treasury:250000};
const V117_PERMITS={},V117_INDUSTRIES={},V127_ASSET_NEEDS={diversified:{facility:'base',equipment:'base',facilityCost:1000,equipmentCost:800,days:3}},V127_LABOR_SKILL={},V127_STATE_PRIORITIES={};for(const id of fids)V127_STATE_PRIORITIES[id]=[];
const V130_CONTRACT_TYPES={},V157_INDUSTRY_PROGRAM={},V159_INDUSTRY_WEIGHTS={};
const V117_BUSINESS_LAWS={};for(const id of fids)V117_BUSINESS_LAWS[id]={corpTax:.2};
const V130_BOARD_AGENDAS={restructuring:{},liquidity:{},capex:{},market:{},research:{},settlement:{},labor:{}};
const V127_SUPPORT_FIRMS={
 low:{kind:'equipment',specialties:['manufacturing'],faction:'league',reliability:60,quality:65},
 high:{kind:'equipment',specialties:['manufacturing'],faction:'league',reliability:92,quality:88},
 fac:{kind:'facility',specialties:['manufacturing'],faction:'league',reliability:78,quality:75}
};
const cash={};
function baseRef(key){
 if(key==='player:parent')return{key,kind:'player',id:'parent',name:'Player Holdings',faction:'league',industry:'manufacturing',home:'aurora'};
 if(key?.startsWith('corp:')){const id=key.slice(5),d=V17_CORPORATIONS[id];if(d)return{key,kind:'corp',id,name:d.name,faction:SYSTEMS[d.home].faction,industry:id==='alpha'?'manufacturing':'technology',home:d.home}}
 if(key?.startsWith('support:'))return{key,kind:'support',id:key.slice(8),name:key,faction:'league',industry:'support',home:'aurora'};
 return null;
}
function baseKeys(){return['player:parent','corp:alpha','corp:beta']}
function baseName(key){return baseRef(key)?.name||key}
function baseGet(ref){return ref?cash[ref.key]||0:0}
function baseSet(ref,n){if(ref)cash[ref.key]=Math.max(0,Number(n)||0)}
function baseAdd(ref,n){baseSet(ref,baseGet(ref)+n)}
function baseDefault(ref){return{key:ref.key,kind:ref.kind,industry:ref.industry,faction:ref.faction,home:ref.home,locationSystem:ref.home,strategy:'growth',status:'operating',employees:40,quality:72,productivity:1,capacity:68,creditScore:650,debt:0,facilities:[{condition:90}],equipment:[{condition:90}],capitalProjects:[],loans:[],products:[],researchPoints:5,techLevel:1,marketShare:7,lastRevenue:500,lastProfit:50,revenueTotal:5000,profitTotal:500,distress:18,history:[]}}
function baseOperate(e){e.lastRevenue=300;e.lastProfit=45}
function baseDemand(){return 1}
function v130UpsertContract(id,d){const old=game.gm.v130.contracts[id];game.gm.v130.contracts[id]=old?Object.assign(old,d):{id,created:game.day,breachLevel:0,...d};if(!game.gm.v130.contractOrder.includes(id))game.gm.v130.contractOrder.unshift(id);return game.gm.v130.contracts[id]}
function v130PartyFaction(key){if(key==='player:parent')return'league';const r=ctx.v127EnterpriseRef(key);return r?.faction||'league'}
function v130PartyCash(key){return ctx.v127GetCash(ctx.v127EnterpriseRef(key))}
function v130AddPartyCash(key,n){const r=ctx.v127EnterpriseRef(key);if(r)ctx.v127SetCash(r,ctx.v127GetCash(r)+n)}
const supportStates={low:{backlog:0},high:{backlog:0},fac:{backlog:0}};
let capexStarts=0;
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,game,SYSTEMS,FACTIONS,V17_CORPORATIONS,V117_PERMITS,V117_INDUSTRIES,V117_BUSINESS_LAWS,V127_ASSET_NEEDS,V127_LABOR_SKILL,V127_STATE_PRIORITIES,V127_SUPPORT_FIRMS,V130_CONTRACT_TYPES,V130_BOARD_AGENDAS,V157_INDUSTRY_PROGRAM,V159_INDUSTRY_WEIGHTS,
 rng:()=>.2,pairTension:()=>10,v117SanctionBetween:()=>null,
 v127EnterpriseRef:baseRef,v127EnterpriseKeys:baseKeys,v127EnterpriseName:baseName,v127GetCash:baseGet,v127SetCash:baseSet,v127AddCash:baseAdd,v127DefaultEnterprise:baseDefault,v127OperateEnterprise:baseOperate,v117IndustryDemand:baseDemand,
 v127AssetReadiness:e=>Math.min(...[...(e.facilities||[]),...(e.equipment||[])].map(x=>(x.condition??100)/100),1),
 v127BestVendor:(e,kind)=>({id:'low',def:V127_SUPPORT_FIRMS.low,state:supportStates.low,score:50}),v127SupportState:id=>supportStates[id]||{},
 v127CapitalAI:()=>true,v127StartCapitalProject:(e,kind)=>{capexStarts++;e.capitalProjects.push({id:'capex-'+capexStarts,kind,status:'building',readyDay:game.day+4});return true},
 v130PartyFaction,v130PartyCash,v130AddPartyCash,v130UpsertContract,v130SyncContracts:()=>true,v130ChooseAgenda:()=> 'market',
 v113SharePrice:cid=>cid==='alpha'?12:8,v113FreeFloat:()=>6000,v113Strategic:()=>false,v120CorpHomeFaction:cid=>SYSTEMS[V17_CORPORATIONS[cid].home].faction,
 v159LocationScore:()=>72,v159CreateProposal:()=>true,
 initV10:()=>true,gmAdvance:()=>{game.day++;return true},renderV117PlayerBusiness:()=>'',renderGM:()=>true,render:()=>true,toast:()=>{},escapeHtml:s=>String(s??''),document:{querySelector:()=>null,getElementById:()=>null}
};
ctx.ensureV127State=()=>{for(const key of ctx.v127EnterpriseKeys()){if(!game.gm.enterpriseEconomy.enterprises[key]){const ref=ctx.v127EnterpriseRef(key);if(ref)game.gm.enterpriseEconomy.enterprises[key]=ctx.v127DefaultEnterprise(ref)}}};
ctx.global=ctx;ctx.window=ctx;vm.createContext(ctx);vm.runInContext(src,ctx,{filename:'105-v1_61-consulting.js'});
vm.runInContext('ensureV161State()',ctx);
assert.equal(vm.runInContext('Object.keys(game.gm.consulting.firms).length',ctx),9,'consulting firm count');
assert.equal(vm.runInContext('Object.values(game.gm.enterpriseEconomy.enterprises).filter(e=>e.key.startsWith("consulting:")).length',ctx),9,'consulting enterprise integration');
assert.equal(vm.runInContext('Object.keys(V161_SCOPE_META).length',ctx),8,'consulting scopes including integrated');
// Seed client economics after enterprise initialization.
ctx.v127SetCash(ctx.v127EnterpriseRef('player:parent'),52000);ctx.v127SetCash(ctx.v127EnterpriseRef('corp:alpha'),24000);ctx.v127SetCash(ctx.v127EnterpriseRef('corp:beta'),15000);
let player=game.gm.enterpriseEconomy.enterprises['player:parent'];player.distress=76;player.debt=62000;player.lastRevenue=400;player.lastProfit=-90;player.creditScore=520;player.marketShare=4;player.quality=62;player.facilities=[{condition:60}];player.equipment=[{condition:58}];
const beforePlayer=ctx.v127GetCash(ctx.v127EnterpriseRef('player:parent'));
vm.runInContext(`globalThis.__eng=v161CreateEngagement('player:parent','integrated',null,{automatic:false})`,ctx);
assert(vm.runInContext('__eng && __eng.status==="active"',ctx),'integrated engagement not created');
assert(ctx.v127GetCash(ctx.v127EnterpriseRef('player:parent'))<beforePlayer,'deposit not charged');
assert(vm.runInContext('Object.keys(game.gm.v130.contracts).some(k=>k.startsWith("consulting:consult-"))',ctx),'consulting contract not synced');
vm.runInContext('game.day=__eng.dueDay; v161TrySettle(__eng); v161SyncContracts()',ctx);
assert.equal(vm.runInContext('__eng.status',ctx),'completed','engagement not settled');
assert(vm.runInContext('__eng.reportId!=null',ctx),'report not issued');
assert(vm.runInContext('game.gm.consulting.reports[0].recommendation.kind==="financial_restructuring" || game.gm.consulting.reports[0].recommendation.kind==="portfolio_restructure"',ctx),'integrated report failed to prioritize distress');
// Explicit finance report -> advisory signal -> existing board agenda.
vm.runInContext(`globalThis.__fin=v161CreateEngagement('player:parent','finance',null,{automatic:false}); game.day=__fin.dueDay; v161TrySettle(__fin); globalThis.__fr=game.gm.consulting.reports.find(r=>r.id===__fin.reportId); v161ApplyAdvice(__fr,false)`,ctx);
assert.equal(vm.runInContext('__fr.recommendation.kind',ctx),'financial_restructuring','finance recommendation');
assert.equal(vm.runInContext(`v130ChooseAgenda('player:governance')`,ctx),'restructuring','advice did not feed existing board agenda');
// SCM advice changes the next existing equipment-vendor decision.
vm.runInContext(`game.gm.consulting.signals['player:parent']={kind:'supplier_reorg',expires:game.day+20}; globalThis.__vendor=v127BestVendor(game.gm.enterpriseEconomy.enterprises['player:parent'],'equipment',false)`,ctx);
assert.equal(vm.runInContext('__vendor.id',ctx),'high','SCM advice did not prefer reliable alternate vendor');
// Existing capex engine is triggered for NPC technology advice.
vm.runInContext(`game.gm.consulting.signals['corp:alpha']={kind:'equipment_refresh',expires:game.day+20}; v127CapitalAI(game.gm.enterpriseEconomy.enterprises['corp:alpha'])`,ctx);
assert.equal(capexStarts,1,'technology advice did not call existing capital-project engine');
// M&A is screening only: watchlist/report, no capital-market mutation.
const cmBefore=JSON.stringify(game.gm.capitalMarkets);
vm.runInContext(`globalThis.__ma=v161CreateEngagement('corp:alpha','ma',null,{automatic:false}); game.day=__ma.dueDay; v161TrySettle(__ma); globalThis.__mar=game.gm.consulting.reports.find(r=>r.id===__ma.reportId)`,ctx);
assert(vm.runInContext('__mar && ["ma_screen","ma_hold","divestiture"].includes(__mar.recommendation.kind)',ctx),'M&A report missing');
assert.equal(JSON.stringify(game.gm.capitalMarkets),cmBefore,'consultant must not execute parallel M&A transaction');
// Unpaid balance becomes contract breach once, not one metric hit per day.
ctx.v127SetCash(ctx.v127EnterpriseRef('corp:beta'),5000);
vm.runInContext(`globalThis.__unpaid=v161CreateEngagement('corp:beta','strategy',null,{automatic:false}); v127SetCash(v127EnterpriseRef('corp:beta'),0); game.day=__unpaid.dueDay; v161TrySettle(__unpaid); v161SyncContracts(); globalThis.__u1=game.gm.consulting.metrics.unpaid`,ctx);
assert.equal(vm.runInContext('__unpaid.status',ctx),'payment_due','unpaid engagement status');
assert(vm.runInContext(`game.gm.v130.contracts['consulting:'+__unpaid.id].breachCause==='payment'`,ctx),'unpaid did not reach contract ledger');
vm.runInContext('game.day++; v161TrySettle(__unpaid); globalThis.__u2=game.gm.consulting.metrics.unpaid',ctx);
assert.equal(vm.runInContext('__u2',ctx),vm.runInContext('__u1',ctx),'unpaid metric double counted');
assert.doesNotThrow(()=>JSON.parse(vm.runInContext('JSON.stringify(game.gm.consulting)',ctx)),'consulting state must serialize');
vm.runInContext('v161ProcessDaily()',ctx);
assert.equal(vm.runInContext('game.version',ctx),'1.61.0');
console.log('V161_CONSULTING_SMOKE_PASS',JSON.stringify({firms:9,scopes:8,reports:vm.runInContext('game.gm.consulting.metrics.reports',ctx),adopted:vm.runInContext('game.gm.consulting.metrics.adopted',ctx),contracts:Object.keys(game.gm.v130.contracts).filter(k=>k.startsWith('consulting:')).length,unpaid:vm.runInContext('game.gm.consulting.metrics.unpaid',ctx),capexStarts},null,2));
