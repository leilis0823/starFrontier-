'use strict';
const fs=require('fs');
const vm=require('vm');
const path=require('path');
const assert=require('assert');

const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/103-v1_59-real-estate-ai.js'),'utf8');
const cash={ 'player:parent':50000, 'corp:npc':90000, 'realestate:f1':30000 };
let contractSyncs=0;
const capitalCalls=[];
const news=[];
const toasts=[];
const budget={target:30000};
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));

const game={
 day:40, version:'1.58.0', war:{active:false},
 playerCorporation:{created:true,name:'Frontier Works',treasury:50000,homeFaction:'fA',industry:'banking',compliance:{branches:[]},management:{delegation:{mode:'direct'},executives:{ceo:{diplomacy:84,competence:78},cfo:{finance:88},coo:{operations:76}}}},
 gm:{
  realEstate:{
   regions:{
    home:{systemId:'home',logistics:34,demand:42,infrastructure:40,wageIndex:132,regulation:72,vacancy:7,marketPhase:'stable',rentIndex:105,landPriceIndex:100},
    target:{systemId:'target',logistics:91,demand:88,infrastructure:93,wageIndex:94,regulation:34,vacancy:21,marketPhase:'stable',rentIndex:108,landPriceIndex:104}
   },
   buildings:{
    b1:{id:'b1',systemId:'target',parcelId:'p0',name:'Target Business Center',zoning:'commercial',owner:'realestate:f1',condition:94,occupancy:70,value:52000,listedForSale:false,units:[{id:'u1',label:'10F',area:120,tenant:null,leaseId:null}]},
    b2:{id:'b2',systemId:'target',parcelId:'p2',name:'Target Existing Tower',zoning:'commercial',owner:'realestate:f1',condition:89,occupancy:78,value:48000,listedForSale:true,units:[]}
   },
   parcels:{
    p0:{id:'p0',systemId:'target',name:'Target Core',zoning:'commercial',owner:'realestate:f1',areaHa:3,landValuePerHa:5000,developmentPotential:80,buildingIds:['b1']},
    p2:{id:'p2',systemId:'target',name:'Target Tower Lot',zoning:'commercial',owner:'realestate:f1',areaHa:3,landValuePerHa:5200,developmentPotential:75,buildingIds:['b2']},
    p3:{id:'p3',systemId:'target',name:'Target Expansion Lot',zoning:'commercial',owner:'realestate:f1',areaHa:4,landValuePerHa:8000,developmentPotential:88,buildingIds:[],listedForSale:true}
   },
   firms:{f1:{capital:30000,deals:0}}, leases:[],sales:[],history:[],nextLease:1,nextSale:1,
   listings:[
    {id:'rent:u1',kind:'unit_lease',assetId:'b1',unitId:'u1',systemId:'target',seller:'realestate:f1',rent:900,deposit:1800,periodDays:10,termDays:120,status:'open',created:25},
    {id:'sale:b2',kind:'building_sale',assetId:'b2',systemId:'target',seller:'realestate:f1',price:48000,status:'open',created:25},
    {id:'sale:p3',kind:'land_sale',assetId:'p3',systemId:'target',seller:'realestate:f1',price:32000,status:'open',created:25}
   ]
  },
  locationPolicy:{regions:{
   home:{policyAttraction:-2,investorConfidence:44,speculation:8,hollowing:12,program:'standard'},
   target:{policyAttraction:14,investorConfidence:80,speculation:7,hollowing:0,program:'development_zone'}
  }},
  enterpriseEconomy:{enterprises:{}}, construction:{pendingSpec:null}, v130:{boards:{}}
 }
};
const player={key:'player:parent',kind:'player',status:'operating',industry:'banking',home:'home',faction:'fA',strategy:'growth',creditScore:760,quality:78,marketShare:11,lastProfit:45,capitalProjects:[],facilities:[],equipment:[],history:[]};
const npc={key:'corp:npc',kind:'corp',status:'operating',industry:'banking',home:'home',faction:'fA',strategy:'efficiency',creditScore:720,quality:76,marketShare:9,lastProfit:55,capitalProjects:[],facilities:[],equipment:[],history:[]};
game.gm.enterpriseEconomy.enterprises[player.key]=player;
game.gm.enterpriseEconomy.enterprises[npc.key]=npc;

const ctx={
 console, Math, Date, JSON, Object, Array, Number, String, Set, Map,
 game,
 SYSTEMS:{home:{name:'Home',faction:'fA'},target:{name:'Target',faction:'fA'}},
 V159_BUILD:'ignored',
 V127_ENTERPRISE_STRATEGIES:{growth:{reserve:.18,capex:1},efficiency:{reserve:.24,capex:1}},
 V117_INDUSTRIES:{banking:{baseRevenue:300}},
 V127_ASSET_NEEDS:{banking:{facility:'本社',facilityCost:12000,equipment:'端末',equipmentCost:4000,days:8},diversified:{facility:'複合拠点',facilityCost:12000,equipment:'設備',equipmentCost:4000,days:8}},
 V1201_DELEGATION_MODES:{direct:{name:'直接経営'},operations:{name:'業務委任'},owner:{name:'所有者経営'}},
 V156_ZONE_META:{commercial:{name:'商業',rent:1},mixed:{name:'複合',rent:1}},
 clamp,
 rng:()=>0.5,
 pairTension:()=>10,
 v156Hash:()=>0.72,
 ensureV156State:()=>game.gm.realEstate,
 ensureV157State:()=>{}, ensureV158State:()=>{},
 v157ProgramForIndustry:()=> 'office',
 v157Program:()=>({name:'業務本部',zones:['commercial','mixed'],baseCost:14000,days:9}),
 v157ZoneCompatible:(_id,z)=>['commercial','mixed'].includes(z),
 v157ParcelHasCapacity:p=>(p.buildingIds||[]).length<2,
 v127ProjectScale:()=>1,
 v156OwnerCash:k=> k==='player:parent'?game.playerCorporation.treasury:(cash[k]??0),
 v156AddOwnerCash:(k,n)=>{ if(k==='player:parent')game.playerCorporation.treasury+=n; else cash[k]=(cash[k]||0)+n; },
 v156PlayerReserve:()=>5000,
 v156FindUnit:l=>game.gm.realEstate.buildings[l.buildingId]?.units.find(u=>u.id===l.unitId),
 v156SyncContracts:()=>{contractSyncs++},
 v156BuyLand:id=>{
  const l=game.gm.realEstate.listings.find(x=>x.id===id); if(!l||l.status!=='open')return;
  if(game.playerCorporation.treasury-l.price<5000)return;
  const a=game.gm.realEstate.parcels[l.assetId],seller=a.owner; game.playerCorporation.treasury-=l.price; cash[seller]=(cash[seller]||0)+l.price; a.owner='player:parent'; l.status='closed'; game.gm.realEstate.sales.unshift({id:'ps'+game.day,assetId:a.id,assetKind:'land',buyer:'player:parent',seller,price:l.price,day:game.day,status:'completed'}); contractSyncs++;
 },
 v156BuyBuilding:id=>{
  const l=game.gm.realEstate.listings.find(x=>x.id===id); if(!l||l.status!=='open')return;
  if(game.playerCorporation.treasury-l.price<5000)return;
  const a=game.gm.realEstate.buildings[l.assetId],seller=a.owner; game.playerCorporation.treasury-=l.price; cash[seller]=(cash[seller]||0)+l.price; a.owner='player:parent'; l.status='closed'; game.gm.realEstate.sales.unshift({id:'pb'+game.day,assetId:a.id,assetKind:'building',buyer:'player:parent',seller,price:l.price,day:game.day,status:'completed'}); contractSyncs++;
 },
 v156LeaseUnit:id=>{
  const l=game.gm.realEstate.listings.find(x=>x.id===id),b=game.gm.realEstate.buildings[l?.assetId],u=b?.units.find(x=>x.id===l.unitId); if(!l||l.status!=='open'||u?.tenant)return;
  const total=l.rent+l.deposit;if(game.playerCorporation.treasury-total<5000)return;
  game.playerCorporation.treasury-=total;cash[l.seller]=(cash[l.seller]||0)+total;
  const lease={id:'pl'+game.day,listingId:l.id,buildingId:b.id,unitId:u.id,systemId:l.systemId,lessor:l.seller,lessee:'player:parent',rent:l.rent,deposit:l.deposit,periodDays:l.periodDays,started:game.day,nextPayment:game.day+l.periodDays,termEnd:game.day+l.termDays,status:'active',defaults:0,arrears:0};
  game.gm.realEstate.leases.unshift(lease);u.tenant='player:parent';u.leaseId=lease.id;l.status='leased';contractSyncs++;
 },
 v158PolicyState:sid=>game.gm.locationPolicy.regions[sid],
 v158Regional:sid=>sid,
 v158Program:id=>({acquisitionGrant:id==='development_zone'?.05:0}),
 v135RegionBudget:sid=>budget[sid]||0,
 v135AddRegionBudget:(sid,n)=>{budget[sid]=(budget[sid]||0)+n},
 v127EnterpriseRef:e=>e,
 v127GetCash:ref=>ctx.v156OwnerCash(ref.key||ref),
 v127AddCash:(ref,n)=>ctx.v156AddOwnerCash(ref.key||ref,n),
 v127CompleteProjects:()=>{},
 v127StartCapitalProject:(e,kind)=>{capitalCalls.push(kind);e.capitalProjects.push({id:'cap'+capitalCalls.length,kind,status:'building'});return true},
 v127AssetReadiness:()=>.1,
 v127OperatingPerformance:()=>1,
 v127CapitalAI:()=>{capitalCalls.push('legacy')},
 v127EnterpriseName:k=>k==='player:parent'?'Frontier Works':'NPC Bank',
 v1201DelegationLog:()=>{},
 v130EnsurePlayerBoard:()=>({strategicProposals:[],members:[]}),
 gmNews:t=>news.push(t), toast:t=>toasts.push(t), escapeHtml:s=>String(s??''),
 gmAdvance:()=>true, initV10:()=>{}, renderGM:()=>{}, render:()=>{},
 document:{querySelector:()=>null,getElementById:()=>null},
};
ctx.global=ctx;ctx.window=ctx;
vm.createContext(ctx);
vm.runInContext(src,ctx,{filename:'103-v1_59-real-estate-ai.js'});

// Delegation boundary: small operational deals can be delegated; strategic development cannot.
game.playerCorporation.management.delegation.mode='operations';
assert.strictEqual(vm.runInContext(`v159ApprovalForPlayer({selected:{kind:'lease',systemId:'target',financial:{upfront:1000}},advantage:9})`,ctx),'management');
game.playerCorporation.management.delegation.mode='owner';
assert.strictEqual(vm.runInContext(`v159ApprovalForPlayer({selected:{kind:'buy_building',systemId:'target',financial:{upfront:4000}},advantage:12})`,ctx),'management');
assert.strictEqual(vm.runInContext(`v159ApprovalForPlayer({selected:{kind:'buy_land_build',systemId:'target',financial:{upfront:4000}},advantage:20})`,ctx),'player');
game.playerCorporation.management.delegation.mode='direct';

// Candidate generation: every strategic form is considered, with lease the affordable winner.
const candidates=vm.runInContext('v159CollectCandidates(game.gm.enterpriseEconomy.enterprises["player:parent"])',ctx);
assert(candidates.some(c=>c.kind==='lease'),'lease candidate missing');
assert(candidates.some(c=>c.kind==='buy_building'),'building purchase candidate missing');
assert(candidates.some(c=>c.kind==='buy_land_build'),'land+build candidate missing');
const leaseCand=candidates.find(c=>c.kind==='lease');
const neg=vm.runInContext('v159NegotiateCandidate(game.gm.enterpriseEconomy.enterprises["player:parent"], v159CollectCandidates(game.gm.enterpriseEconomy.enterprises["player:parent"]).find(c=>c.kind==="lease"))',ctx);
assert(neg.accepted,'lease negotiation should accept');
assert(neg.final<=neg.ask,'negotiation did not improve ask');
assert(neg.rounds.length>=1&&neg.rounds.length<=3,'unexpected negotiation rounds');

const proposal=vm.runInContext('v159CreateProposal(game.gm.enterpriseEconomy.enterprises["player:parent"], true)',ctx);
assert(proposal&&proposal.status==='pending','direct-management proposal must await founder');
assert(proposal.finalists.length>=1&&proposal.finalists.length<=3,'finalist comparison missing');
assert(proposal.selected.kind==='lease',`expected lease to win test economics, got ${proposal.selected.kind}`);
assert(proposal.selected.negotiation?.accepted,'winning listing was not negotiated');
const oldCash=game.playerCorporation.treasury;
ctx.v159ApproveProposal ? ctx.v159ApproveProposal(proposal.id) : vm.runInContext(`v159ApproveProposal('${proposal.id}')`,ctx);
assert(proposal.status==='executed','approved proposal not executed');
assert(game.playerCorporation.treasury<oldCash,'lease did not consume cash');
assert(game.gm.realEstate.listings.find(x=>x.id==='rent:u1').status==='leased','listing did not close as leased');
const est=vm.runInContext('v159EnterpriseState(game.gm.enterpriseEconomy.enterprises["player:parent"])',ctx);
assert(est.tenure==='lease'&&est.currentSystem==='target','lease not recognized as operating site');
assert(game.gm.realEstateAI.metrics.relocations===1,'relocation metric should count old -> target');
assert(contractSyncs>0,'contract ledger sync not called');

// Existing capital AI should treat leased property as a facility and only seek equipment.
const ready=vm.runInContext('v127AssetReadiness(game.gm.enterpriseEconomy.enterprises["player:parent"])',ctx);
assert(ready>.5,'leased operating premise did not improve readiness');
capitalCalls.length=0;
vm.runInContext('game.gm.enterpriseEconomy.enterprises["player:parent"].lastDecisionDay=0; v127CapitalAI(game.gm.enterpriseEconomy.enterprises["player:parent"])',ctx);
assert.deepStrictEqual(capitalCalls,['equipment'],'capital AI attempted duplicate facility instead of equipment');
const perf=vm.runInContext('v127OperatingPerformance(game.gm.enterpriseEconomy.enterprises["player:parent"])',ctx);
assert(perf>1,'strong target location should improve operating performance');

// 30-day review produces an auditable outcome.
game.day=proposal.reviewDay;player.lastProfit=95;
vm.runInContext('v159PostReview()',ctx);
assert(proposal.postReview&&proposal.postReview.day===game.day,'post-investment review missing');

// NPC AI can autonomously negotiate and execute a remaining real-estate strategy.
game.day+=35;
const npcProposal=vm.runInContext('v159CreateProposal(game.gm.enterpriseEconomy.enterprises["corp:npc"], true)',ctx);
assert(npcProposal,'npc proposal missing');
assert(npcProposal.status==='executed','npc management AI did not auto-execute');
assert(game.gm.realEstateAI.metrics.autoExecuted>=1,'auto-execution metric missing');

console.log('V159_REAL_ESTATE_AI_SMOKE_PASS', JSON.stringify({
 candidateKinds:candidates.map(c=>c.kind),
 selected:proposal.selected.kind,
 negotiation:{ask:proposal.selected.negotiation.ask,final:proposal.selected.negotiation.final,rounds:proposal.selected.negotiation.rounds.length},
 relocation:game.gm.realEstateAI.metrics.relocations,
 readiness:Number(ready.toFixed(3)), performance:Number(perf.toFixed(3)),
 postReview:proposal.postReview.result,
 npc:npcProposal.selected.kind,
 contractSyncs,
 savings:Math.round(game.gm.realEstateAI.metrics.negotiatedSavings)
},null,2));
