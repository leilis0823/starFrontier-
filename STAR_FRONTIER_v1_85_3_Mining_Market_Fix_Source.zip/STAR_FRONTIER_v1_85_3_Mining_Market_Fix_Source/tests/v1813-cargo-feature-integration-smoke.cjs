'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/120-v1_76-mining-ores-elements-salvage.js'),'utf8');
const SYSTEMS={aurora:{name:'オーロラ',faction:'league',security:'中',yield:{iron:55,titanium:34,crystal:12},base:{iron:62,titanium:118,crystal:245}}};
const FACTIONS={league:{short:'連盟'}}; const HULLS={nomad:{name:'ノマド',class:'corvette',mining:1},pathfinder:{name:'探鉱艇'},mole:{name:'採掘船'}};
const RES={iron:{name:'鉄鉱石',icon:'◼'},titanium:{name:'チタン鉱',icon:'◆'},crystal:{name:'星晶石',icon:'✧'}};
const V169_COMMODITIES={iron:{name:'鉄',base:62},titanium:{name:'チタン',base:118},crystal:{name:'星晶石',base:245}};
const game={day:1,version:'1.75.0',system:'aurora',fuel:80,credits:1200,cargoMax:60,cargo:{iron:0,titanium:0,crystal:0},prices:{aurora:{iron:62,titanium:118,crystal:245}},hull:'nomad',loadouts:{nomad:[]},career:{faction:null,activeContract:null},contracts:[],war:{active:false},freeCaptains:{heat:0},stations:[],stationOrders:[],gm:{commodityMarket:{benchmarks:{}},factions:{},v130:{contracts:{},contractOrder:[]}}};
for(const [k,v] of Object.entries({aluminum:92,copper:108,nickel:146,cobalt:238,lithium:205,uranium:355,rare_earth:315,platinum:510,silicon:128,thorium:270}))game.gm.commodityMarket.benchmarks[k]={spot:v};
let rv=.1;function rng(){return rv} function miningBonus(){return 2} function combatPower(){return 50} function crewBonus(){return 0} function gmObserve(){} function gmRel(){} function gmPriceMult(){return 1} function escapeHtml(s){return String(s??'')} function addLog(){} function toast(){} function damageShip(){} function shipyardStations(){return[]} function orderProfitBonus(){return 1}
function cargoUsed(){return Object.values(game.cargo).reduce((a,b)=>a+b,0)} function cargoFree(){return Math.max(0,game.cargoMax-cargoUsed())}
function mineOnce(){} function mineBatch(){} function renderMine(){} function renderMarket(){} function renderContracts(){} function initV10(){return true} function gmAdvance(){game.day++;return true} function travel(){return true} function executeContract(){} function directIntervene(){} function ensureV175State(){} function render(){}
function v169State(){return game.gm.commodityMarket} function v169DemandSupply(){return{demand:100,supply:100}}
const els={cargoList:{innerHTML:''},cargo:{textContent:''}}; const document={title:'',getElementById:id=>els[id]||null,querySelector:()=>null};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,SYSTEMS,FACTIONS,HULLS,RES,V169_COMMODITIES,game,rng,miningBonus,combatPower,crewBonus,gmObserve,gmRel,gmPriceMult,escapeHtml,addLog,toast,damageShip,shipyardStations,orderProfitBonus,cargoUsed,cargoFree,mineOnce,mineBatch,renderMine,renderMarket,renderContracts,initV10,gmAdvance,travel,executeContract,directIntervene,ensureV175State,render,v169State,v169DemandSupply,document};ctx.window=ctx;ctx.global=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);
vm.runInContext('ensureV176State(); v176State().ores.hematite=3; v176State().ores.bauxite=2; v176State().elements.copper=1.5; v176RefreshCargoOverview()',ctx);
assert(els.cargoList.innerHTML.includes('赤鉄鉱'),'raw ore missing from main cargo UI');
assert(els.cargoList.innerHTML.includes('ボーキサイト'),'second raw ore missing from main cargo UI');
assert(els.cargoList.innerHTML.includes('銅 (Cu)'),'refined element missing from main cargo UI');
assert.equal(els.cargo.textContent,'5.8 / 60','integrated cargo usage not reflected in header');
const before=vm.runInContext('v176RawOreUnits()',ctx);vm.runInContext("v176SelectOre(v176Survey('aurora').rows[0].k); mineOnce(true); v176RefreshCargoOverview()",ctx);const after=vm.runInContext('v176RawOreUnits()',ctx);assert(after>before,'mining did not increase raw ore inventory');assert(els.cargo.textContent!=='5.8 / 60','cargo header did not update after mining');
console.log('V1813_CARGO_FEATURE_INTEGRATION_SMOKE_PASS',JSON.stringify({cargo:els.cargo.textContent,rawOre:after,htmlLength:els.cargoList.innerHTML.length}));
