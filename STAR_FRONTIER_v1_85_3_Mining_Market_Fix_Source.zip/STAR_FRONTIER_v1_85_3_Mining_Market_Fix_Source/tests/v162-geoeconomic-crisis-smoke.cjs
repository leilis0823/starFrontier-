'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/106-v1_62-geoeconomic-crisis.js'),'utf8');
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const SYSTEMS={aurora:{name:'Aurora',faction:'league',routes:{forge:1}},forge:{name:'Forge',faction:'helios',routes:{aurora:1}},elysia:{name:'Elysia',faction:'concord',routes:{aurora:1}}};
const FACTIONS={league:{short:'League'},helios:{short:'Helios'},concord:{short:'Concord'}};
const game={day:70,version:'1.61.0',system:'aurora',war:{active:true,a:'league',b:'helios'},playerCorporation:{created:true,name:'Player Co',homeFaction:'league'},gm:{
 factions:{league:{treasury:900,stability:62},helios:{treasury:80000,stability:50},concord:{treasury:50000,stability:75}},
 monetary:{sanctions:[{id:'san1',from:'league',target:'helios',type:'clearing',severity:80,active:true,until:120}]},
 techTrade:{measures:[{id:'tar1',type:'tariff',from:'league',target:'helios',industry:'all',rate:.25,active:true,until:120}]},
 systemLogistics:{aurora:{routeHealth:20,shortage:82,throughput:15,capacity:60},forge:{routeHealth:32,shortage:68,throughput:18,capacity:65},elysia:{routeHealth:90,shortage:5,throughput:50,capacity:90}},
 realEstate:{regions:{aurora:{logistics:38},forge:{logistics:42},elysia:{logistics:86}},parcels:{
  p1:{id:'p1',systemId:'aurora',name:'Foreign Logistics Parcel',zoning:'commercial',areaHa:40,landValuePerHa:100,owner:'corp:beta',buildingIds:[]},
  p2:{id:'p2',systemId:'aurora',name:'Player Industrial Parcel',zoning:'industrial',areaHa:30,landValuePerHa:120,owner:'player:parent',buildingIds:[]},
  p3:{id:'p3',systemId:'aurora',name:'League Estate Parcel',zoning:'commercial',areaHa:25,landValuePerHa:90,owner:'realestate:league',buildingIds:['b1']}
 },buildings:{b1:{id:'b1',systemId:'aurora',parcelId:'p3',name:'Helios Foreign Office',owner:'corp:beta',value:12000,occupancy:92,condition:90,units:[]}},listings:[],leases:[],sales:[],firms:{league:{faction:'league',name:'League Estate',capital:20000}}},
 enterpriseEconomy:{enterprises:{
  'player:parent':{key:'player:parent',name:'Player Co',faction:'league',home:'aurora',status:'operating',distress:20,creditScore:660,monthlyPayroll:900,capitalProjects:[],history:[]},
  'corp:alpha':{key:'corp:alpha',name:'Alpha Construction Client',faction:'league',home:'aurora',status:'operating',distress:25,creditScore:640,monthlyPayroll:800,capitalProjects:[],history:[]},
  'corp:beta':{key:'corp:beta',name:'Beta Foreign Holdings',faction:'helios',home:'forge',status:'operating',distress:12,creditScore:670,capitalProjects:[],history:[]}
 }},
 aviation:{routes:{r1:{id:'r1',from:'aurora',to:'forge',status:'active',lastRisk:0}},orders:[]},
 construction:{metrics:{delayDays:0,incidents:0}},
 v130:{contracts:{},contractOrder:[],disputes:[],nextDispute:1,lastDisputeScan:0}
}};
const project={id:'proj-1',name:'Strategic Factory',kind:'facility',status:'building',cost:10000,paid:2500,vendor:'prime',readyDay:80,midDay:76,construction:{systemId:'aurora',baseDays:10,delayDays:0,incidents:[],subcontracts:{materials:{firm:'helios_materials',total:2400,paid:400,status:'active'}}}};
game.gm.enterpriseEconomy.enterprises['corp:alpha'].capitalProjects.push(project);
const cash={'player:parent':10000,'corp:alpha':800,'corp:beta':20000,'support:prime':12000,'construction:helios_materials':9000,'aviation:maker':50000};
const V130_CONTRACT_TYPES={};
function partyFaction(k){if(k?.startsWith('state:'))return k.slice(6);if(k==='player:parent')return'league';if(k==='corp:alpha')return'league';if(k==='corp:beta')return'helios';if(k==='support:prime')return'league';if(k==='construction:helios_materials')return'helios';if(k==='aviation:maker')return'helios';if(k?.startsWith('realestate:'))return k.slice(11);return'unclaimed'}
function partyCash(k){if(k?.startsWith('state:'))return game.gm.factions[k.slice(6)]?.treasury||0;if(k?.startsWith('realestate:'))return game.gm.realEstate.firms[k.slice(11)]?.capital||0;return cash[k]||0}
function addCash(k,n){if(k?.startsWith('state:')){game.gm.factions[k.slice(6)].treasury=Math.max(0,(game.gm.factions[k.slice(6)].treasury||0)+n);return}if(k?.startsWith('realestate:')){const f=game.gm.realEstate.firms[k.slice(11)];if(f)f.capital=Math.max(0,(f.capital||0)+n);return}cash[k]=Math.max(0,(cash[k]||0)+n)}
function partyName(k){return game.gm.enterpriseEconomy.enterprises[k]?.name||k}
function upsert(id,d){const old=game.gm.v130.contracts[id];game.gm.v130.contracts[id]=old?Object.assign(old,d):{id,created:game.day,breachLevel:0,...d};if(!game.gm.v130.contractOrder.includes(id))game.gm.v130.contractOrder.unshift(id);return game.gm.v130.contracts[id]}
function disputeExists(id){return game.gm.v130.disputes.some(d=>d.contractId===id)}
function openDispute(c,issue,claimAmount,severity=50){if(!c||disputeExists(c.id))return null;const d={id:'d'+game.gm.v130.nextDispute++,contractId:c.id,claimant:c.parties[0],respondent:c.parties[1],issue,claimAmount,severity,forum:'commercial_court',status:'pending'};game.gm.v130.disputes.push(d);c.status='disputed';return d}
function scanBreaches(){for(const id of game.gm.v130.contractOrder){const c=game.gm.v130.contracts[id];if(c&&['active','disputed'].includes(c.status)&&c.breachLevel>=40&&!disputeExists(c.id))ctx.v130OpenDispute(c,'契約不履行',Math.max(300,c.outstanding||c.value*.18),c.breachLevel)}}
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,game,SYSTEMS,FACTIONS,V130_CONTRACT_TYPES,clamp,
 v156Hash:s=>{let h=0;for(const c of String(s))h=(h*31+c.charCodeAt(0))>>>0;return(h%10000)/10000},
 v156OwnerFaction:partyFaction,v156OwnerName:partyName,v156OwnerCash:partyCash,v156AddOwnerCash:addCash,
 v157FirmDef:id=>id==='helios_materials'?{id,faction:'helios',name:'Helios Materials'}:null,
 v157ProjectRisk:()=>{},v157ParcelHasCapacity:()=>true,ensureV156State:()=>{},ensureV157State:()=>{},ensureV160State:()=>{},
 v158Regional:()=>({unrest:18}),v158MarketInputs:()=>({target:72}),
 v160Faction:k=>partyFaction(k),v160RouteRisk:()=>20,v160ProcessRoute:r=>{r.lastRisk=Math.round(ctx.v160RouteRisk(r.from,r.to));if(r.lastRisk>=88)r.status='suspended';else if(r.status==='suspended'&&r.lastRisk<68)r.status='active'},
 v160OrderSupplyRisk:()=>15,v160Cash:partyCash,v160Money:addCash,v160DeliverOrder:o=>{const rem=(o.total||0)-(o.paid||0);if(partyCash(o.buyer)<rem){o.status='awaiting_payment';return false}addCash(o.buyer,-rem);addCash(o.manufacturer,rem);o.paid=o.total;o.status='completed';return true},
 V160_COMPANIES:{maker:{home:'forge',faction:'helios'}},
 v130PartyFaction:partyFaction,v130PartyCash:partyCash,v130AddPartyCash:addCash,v130PartyName:partyName,v130UpsertContract:upsert,v130SyncContracts:()=>{},v130DisputeExists:disputeExists,v130OpenDispute:openDispute,v130ScanBreaches:scanBreaches,
 v127EnterpriseName:k=>partyName(k),
 gmNews:()=>{},toast:()=>{},escapeHtml:s=>String(s??''),initV10:()=>{},gmAdvance:()=>{game.day++;return true},renderV117PlayerBusiness:()=>'',renderGM:()=>{},renderMapDetail:()=>{},render:()=>{},document:{querySelector:()=>null,getElementById:()=>null}
};
ctx.global=ctx;ctx.window=ctx;vm.createContext(ctx);vm.runInContext(src,ctx,{filename:'106-v1_62-geoeconomic-crisis.js'});
vm.runInContext('ensureV162State()',ctx);
const exp=vm.runInContext('v162Exposure("aurora")',ctx);assert(exp.severity>=78,'war/logistics system should be emergency');
const routeRisk=vm.runInContext('v160RouteRisk("aurora","forge")',ctx);assert(routeRisk>=88,'direct-war route should close');
vm.runInContext('v160ProcessRoute(game.gm.aviation.routes.r1)',ctx);assert.equal(game.gm.aviation.routes.r1.status,'suspended','route was not suspended');
cash['player:parent']=12000;const treasuryBefore=game.gm.factions.league.treasury;ctx.__airOrder={id:'test-air-order',buyer:'player:parent',manufacturer:'aviation:maker',total:8000,paid:2000,status:'building'};vm.runInContext('v160DeliverOrder(__airOrder)',ctx);assert.equal(ctx.__airOrder.status,'completed','tariffed aircraft delivery failed');assert(ctx.__airOrder.v162TariffSettled,'aviation tariff was not settled');assert(game.gm.factions.league.treasury>treasuryBefore,'aviation tariff did not reach state treasury');assert(game.gm.geoeconomicCrisis.tariffPayments.length===1,'aviation tariff payment not recorded');game.gm.factions.league.treasury=900;
const beforeReady=project.readyDay;vm.runInContext('v162ApplyConstructionCrisis(game.gm.enterpriseEconomy.enterprises["corp:alpha"],game.gm.enterpriseEconomy.enterprises["corp:alpha"].capitalProjects[0],true)',ctx);assert(project.readyDay>=beforeReady+3,'forced crisis delay missing');assert(project.construction.v162CrisisDelayDays>=3,'crisis delay not tracked');assert(game.gm.geoeconomicCrisis.charges.length>0,'material shock charge missing');
vm.runInContext('v162SyncContracts(); v130ScanBreaches()',ctx);assert(Object.values(game.gm.v130.contracts).some(c=>c.type==='construction_crisis'&&c.breachLevel>=40),'construction crisis contract missing');assert(Object.values(game.gm.v130.contracts).some(c=>c.type==='crisis_material_adjustment'&&c.outstanding>0),'material adjustment payment breach missing');assert(game.gm.v130.disputes.some(d=>d.issue.includes('地政学・供給網障害')||d.issue.includes('危機時建材')),'crisis dispute did not use specific legal issue');
const market=vm.runInContext('v158MarketInputs("aurora",{})',ctx);assert(market.target<72,'real-estate demand was not reduced by crisis');
vm.runInContext('v162ApplySystemPolicy("aurora",true); v162SyncContracts()',ctx);assert(game.gm.geoeconomicCrisis.zoningChanges.length>=1,'emergency zoning change missing');assert(game.gm.geoeconomicCrisis.requisitions.length>=1,'land requisition missing');assert(game.gm.geoeconomicCrisis.seizures.some(s=>s.kind==='land_expropriation'),'land expropriation missing');assert(game.gm.geoeconomicCrisis.seizures.some(s=>s.kind==='building_seizure'),'foreign building seizure missing');assert.equal(game.gm.realEstate.buildings.b1.crisisAssetStatus,'seized','building not seized');assert(Object.values(game.gm.v130.contracts).some(c=>c.type==='public_compensation'&&c.outstanding>0),'unpaid public compensation claim missing');
vm.runInContext('v162TrackEnterpriseDistress(); game.gm.enterpriseEconomy.enterprises["corp:alpha"].status="distressed"; v162TrackEnterpriseDistress()',ctx);assert(game.gm.geoeconomicCrisis.history.some(h=>h.type==='causal_chain'&&h.text.includes('資金繰り悪化')),'distress causal chain not recorded');
assert.doesNotThrow(()=>JSON.parse(vm.runInContext('JSON.stringify(game.gm.geoeconomicCrisis)',ctx)),'geoeconomic state must serialize');
assert.equal(vm.runInContext('game.version',ctx),'1.62.0');
console.log('V162_GEOECONOMIC_CRISIS_SMOKE_PASS',JSON.stringify({severity:exp.severity,routeRisk,aviationTariff:ctx.__airOrder.v162TariffDue,delay:project.construction.v162CrisisDelayDays,charges:game.gm.geoeconomicCrisis.charges.length,zoning:game.gm.geoeconomicCrisis.zoningChanges.length,requisitions:game.gm.geoeconomicCrisis.requisitions.length,seizures:game.gm.geoeconomicCrisis.seizures.length,disputes:game.gm.v130.disputes.length},null,2));
