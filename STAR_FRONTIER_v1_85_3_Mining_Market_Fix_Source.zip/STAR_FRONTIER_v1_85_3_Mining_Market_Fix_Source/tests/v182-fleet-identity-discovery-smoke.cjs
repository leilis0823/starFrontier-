'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'../www');
function noop(){}
function makeClassList(){const s=new Set();return {add(...xs){xs.forEach(x=>s.add(x))},remove(...xs){xs.forEach(x=>s.delete(x))},toggle(x){if(s.has(x)){s.delete(x);return false}s.add(x);return true},contains(x){return s.has(x)}}}
function makeEl(id=''){
 const el={id,textContent:'',innerHTML:'',value:'',checked:false,disabled:false,hidden:false,dataset:{},style:{},className:'',classList:makeClassList(),children:[],parentElement:null,firstChild:null,lastChild:null,clientWidth:1200,clientHeight:800,offsetWidth:1200,offsetHeight:800,
  append(...xs){for(const x of xs){if(x&&typeof x==='object'){x.parentElement=this;this.children.push(x);if(!this.firstChild)this.firstChild=x;this.lastChild=x}}},appendChild(x){this.append(x);return x},insertBefore(x){this.append(x);return x},after:noop,before:noop,remove:noop,replaceChildren(...xs){this.children=[];this.firstChild=null;this.lastChild=null;this.append(...xs)},
  setAttribute(k,v){this[k]=String(v)},getAttribute(k){return this[k]??null},removeAttribute(k){delete this[k]},
  querySelector(){return null},querySelectorAll(){return []},closest(){return null},matches(){return false},
  addEventListener:noop,removeEventListener:noop,insertAdjacentHTML:noop,scrollIntoView:noop,focus:noop,click:noop,
 };
 return el;
}
const els=new Map();
for(const id of ['ship','crewPanel','sfShipRegistryPanel'])els.set(id,makeEl(id));
const document={title:'',documentElement:makeEl('html'),body:makeEl('body'),head:makeEl('head'),readyState:'complete',
 getElementById(id){if(!els.has(id))els.set(id,makeEl(id));return els.get(id)},querySelector(){return makeEl('q')},querySelectorAll(){return []},
 createElement(tag){return makeEl(tag)},createTextNode(t){return {textContent:String(t)}},addEventListener:noop,removeEventListener:noop};
const storage=new Map();
const ls={getItem:k=>storage.has(k)?storage.get(k):null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k),clear:()=>storage.clear()};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Boolean,BigInt,Set,Map,WeakMap,WeakSet,RegExp,Promise,Error,TypeError,RangeError,Intl,parseInt,parseFloat,isNaN,isFinite,encodeURIComponent,decodeURIComponent,
 document,localStorage:ls,navigator:{userAgent:'probe'},location:{href:'https://appassets.androidplatform.net/www/index.html'},performance:{now:()=>0},
 requestAnimationFrame:fn=>0,cancelAnimationFrame:noop,setTimeout:fn=>0,clearTimeout:noop,setInterval:fn=>0,clearInterval:noop,
 AudioContext:function(){},webkitAudioContext:function(){},Blob:function(){},URL:{createObjectURL:()=>'',revokeObjectURL:noop},FileReader:function(){},
 alert:noop,confirm:()=>true,prompt:(msg,def)=>def??'TEST',HTMLElement:function(){},Node:function(){},CSS:{escape:s=>String(s)}};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;ctx.window.localStorage=ls;ctx.window.addEventListener=noop;ctx.window.removeEventListener=noop;ctx.window.innerWidth=1200;ctx.window.innerHeight=800;ctx.window.matchMedia=()=>({matches:false,addEventListener:noop,removeEventListener:noop});
vm.createContext(ctx);
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const scripts=[...html.matchAll(/<script defer src="([^"]+)"/g)].map(m=>m[1]);
for(const rel of scripts){if(rel==='js/99-bootstrap.js')continue;vm.runInContext(fs.readFileSync(path.join(root,rel),'utf8'),ctx,{filename:rel});}
function evalx(code){return vm.runInContext(code,ctx)}
evalx('game=newGame(); initV10(); game.credits=1000000; render=function(){};');
const seed0=evalx('game.marketSeed');
evalx('StarFrontierFleetIdentity.ensure(); StarFrontierFleetIdentity.syncDiscoveries(false);');
const seedAfterEnsure=evalx('game.marketSeed');
if(seedAfterEnsure!==seed0)throw new Error(`feature ensure consumed RNG: ${seed0} -> ${seedAfterEnsure}`);

evalx("game.shipIdentity.manufacturerRep.regulus=50");
const price=evalx("StarFrontierFleetIdentity.price('regulus_surveyor')"),basePrice=evalx("HULLS.regulus_surveyor.cost");
if(!(price<basePrice))throw new Error(`manufacturer discount missing: ${price} >= ${basePrice}`);
if(evalx("StarFrontierFleetIdentity.discount('regulus')")<=0)throw new Error('manufacturer discount rate missing');
evalx("game.shipIdentity.manufacturerRep.regulus=44"); if(evalx("canBuyHull('regulus_pioneer')"))throw new Error('exclusive hull unlocked too early'); evalx("game.shipIdentity.manufacturerRep.regulus=45"); if(!evalx("canBuyHull('regulus_pioneer')"))throw new Error('exclusive hull did not unlock');

evalx("game.hull='caravan'; if(!game.ownedHulls.includes('caravan'))game.ownedHulls.push('caravan'); game.hullState.caravan={condition:100}; game.crew.navigator={name:'TEST NAV',xp:160,loyalty:90,classFamiliarity:{freighter:16}}; applyStats();");
const comp=evalx("StarFrontierFleetIdentity.crewCompatibility('navigator','caravan')");
if(!comp.match||comp.bonus<4)throw new Error('crew compatibility bonus not active: '+JSON.stringify(comp));

evalx("game.hull='nomad'; applyStats(); StarFrontierFleetIdentity.startVariant('range');");
const pending=evalx("game.shipIdentity.variants.find(x=>x.status==='developing')");
if(!pending)throw new Error('variant project not created');
evalx(`game.day=${pending.readyDay}; StarFrontierFleetIdentity.processDaily();`);
const complete=evalx(`game.shipIdentity.variants.find(x=>x.id==='${pending.id}')`);
if(complete.status!=='complete')throw new Error('variant project did not complete');
if(!evalx(`!!HULLS['${pending.id}'] && game.ownedHulls.includes('${pending.id}')`))throw new Error('completed variant not registered/owned');
const saved=evalx('JSON.stringify(game)'); evalx(`delete HULLS['${pending.id}']`); ctx.__savedVariant=saved; evalx('normalize(JSON.parse(__savedVariant))'); if(!evalx(`!!HULLS['${pending.id}']`))throw new Error('variant was not restored before normalize');

evalx("game.hull='regulus_surveyor'; if(!game.ownedHulls.includes('regulus_surveyor'))game.ownedHulls.push('regulus_surveyor'); game.hullState.regulus_surveyor={condition:100}; game.shipIdentity.manufacturerRep.regulus=12; StarFrontierFleetIdentity.acceptContract('regulus');"); const contract=evalx("game.shipIdentity.contracts.find(x=>x.status==='active')"); if(!contract)throw new Error('manufacturer contract not accepted'); for(let i=0;i<contract.target;i++)evalx('StarFrontierFleetIdentity.processDaily()'); if(evalx("game.shipIdentity.contracts.find(x=>x.id==='"+contract.id+"').status")!=='completed')throw new Error('manufacturer contract did not complete');

const unknown='tiamat';
if(evalx(`StarFrontierFleetIdentity.isDiscovered('${unknown}')`))throw new Error('remote hull unexpectedly discovered in baseline');
evalx(`StarFrontierFleetIdentity.discover('${unknown}','TEST',false)`);
if(!evalx(`StarFrontierFleetIdentity.isDiscovered('${unknown}')`))throw new Error('manual discovery failed');
const seedFinal=evalx('game.marketSeed');
if(seedFinal!==seed0)throw new Error(`feature-only actions consumed RNG: ${seed0} -> ${seedFinal}`);
console.log('V182_FLEET_IDENTITY_DISCOVERY_SMOKE_PASS',JSON.stringify({seed:seedFinal,discountedPrice:price,basePrice,crewBonus:comp.bonus,variant:pending.id,discovered:unknown}));
