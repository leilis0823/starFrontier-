'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/111-v1_67-energy-public-infrastructure.js'),'utf8');
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const SYSTEMS={
  aurora:{name:'Aurora',faction:'league',fuel:18,routes:{forge:1}},
  forge:{name:'Forge',faction:'helios',fuel:28,routes:{aurora:1}}
};
const V12_FACTION_IDS=['league','helios'];
const V130_CONTRACT_TYPES={},V156_BUILDING_META={},V157_PROGRAMS={},V157_PROGRAM_LABELS={};
const game={day:90,version:'1.66.0',system:'aurora',war:{active:false},gm:{
  factions:{league:{treasury:80000,stability:90,research:86,logistics:88},helios:{treasury:80000,stability:52,research:50,logistics:46}},
  energyMarket:{firms:{
    heliodyne:{capacity:95,shares:{league:95,helios:12},sales:0},
    novacore:{capacity:76,shares:{league:70,helios:10},sales:0},
    pilgrim:{capacity:66,shares:{league:35,helios:8},sales:0}
  }},
  energySecurity:{crises:{helios:{severity:92,until:150}},embargoes:[]},
  populationLabor:{systems:{aurora:{population:160000},forge:{population:3600000}}},
  realEstate:{regions:{aurora:{infrastructure:92,logistics:90},forge:{infrastructure:32,logistics:36}},parcels:{
    pa:{id:'pa',systemId:'aurora',zoning:'civic',buildingIds:[]},pf:{id:'pf',systemId:'forge',zoning:'civic',buildingIds:[]}
  },buildings:{},firms:{}},
  enterpriseEconomy:{enterprises:{
    'corp:lab':{key:'corp:lab',industry:'research',faction:'league',locationSystem:'aurora',home:'aurora',employees:80,status:'operating',capitalProjects:[],history:[]},
    'corp:forgeworks':{key:'corp:forgeworks',industry:'aerospace',faction:'helios',locationSystem:'forge',home:'forge',employees:340,status:'operating',capitalProjects:[{id:'build-1',name:'Forge Plant',status:'building',readyDay:100,construction:{systemId:'forge',delayDays:0,incidents:[]}}],history:[]}
  }},
  aviation:{airports:{aurora:{systemId:'aurora'},forge:{systemId:'forge'}},companies:{test:{capital:50000}},metrics:{}},
  tourismEconomy:{systems:{aurora:{demandIndex:82,roomShortage:.1},forge:{demandIndex:70,roomShortage:.2}}},
  construction:{metrics:{delayDays:0}},
  corporations:{heliodyne:{wealth:100000},gridworks:{wealth:30000}},
  v130:{contracts:{}}
}};
function v112EnergyCorpIds(){return['heliodyne','novacore','pilgrim']}
function v112FuelQuote(sid){return{price:sid==='forge'?29:18,supplier:'heliodyne'}}
function v113ActiveEmbargo(){return[]}
function ensureV113State(){}
function ensureV166State(){}
function ensureV156State(){}
function v135RegionBySystem(sid){return{system:sid,demographics:{population:game.gm.populationLabor.systems[sid].population,livingCostIndex:80,netMigration:100}}}
function v166Buildings(sid,type){return Object.values(game.gm.realEstate.buildings).filter(b=>b.systemId===sid&&b.type===type)}
function v127OperatingPerformance(){return 1}
function v138ProcessDemographics(region){return region}
function v166SystemProfile(sid){const s=game.gm.tourismEconomy.systems[sid]||{demandIndex:70,roomShortage:.1};game.gm.tourismEconomy.systems[sid]=s;return s}
function v160ProcessRoute(r){r.status='active';r.flights=(r.flights||0)+1;r.passengers=(r.passengers||0)+100;r.revenue=(r.revenue||0)+1000;return true}
function v127EnterpriseRef(k){if(k==='aviation:test')return{kind:'aviation',key:'test'};if(k.startsWith('corp:'))return{kind:'corp',key:k.slice(5)};return game.gm.enterpriseEconomy.enterprises[k]||null}
function v127AddCash(ref,n){if(!ref)return;if(ref.kind==='aviation'){game.gm.aviation.companies[ref.key].capital=(game.gm.aviation.companies[ref.key].capital||0)+n}else if(ref.kind==='corp'&&game.gm.corporations[ref.key])game.gm.corporations[ref.key].wealth=(game.gm.corporations[ref.key].wealth||0)+n}
function v130AddPartyCash(k,n){const ref=v127EnterpriseRef(k);if(ref)v127AddCash(ref,n)}
function v126DomesticVendor(fid,ind){return ind==='infrastructure'?'gridworks':null}
function v130UpsertContract(id,data){game.gm.v130.contracts[id]={id,...data};return game.gm.v130.contracts[id]}
function v130SyncContracts(){return true}
function v156Hash(s){let h=2166136261;for(const c of String(s)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return((h>>>0)%10000)/10000}
function escapeHtml(s){return String(s??'')}
const document={querySelector:()=>null,getElementById:()=>null};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,clamp,SYSTEMS,V12_FACTION_IDS,V130_CONTRACT_TYPES,V156_BUILDING_META,V157_PROGRAMS,V157_PROGRAM_LABELS,game,v112EnergyCorpIds,v112FuelQuote,v113ActiveEmbargo,ensureV113State,ensureV166State,ensureV156State,v135RegionBySystem,v166Buildings,v127OperatingPerformance,v138ProcessDemographics,v166SystemProfile,v160ProcessRoute,v127EnterpriseRef,v127AddCash,v130AddPartyCash,v126DomesticVendor,v130UpsertContract,v130SyncContracts,v156Hash,escapeHtml,document,mapSelected:null,initV10:()=>true,gmAdvance:()=>{game.day++;return true},renderMapDetail:()=>{},renderGM:()=>{},render:()=>{}};
ctx.global=ctx;ctx.window=ctx;vm.createContext(ctx);vm.runInContext(src,ctx,{filename:'111-v1_67-energy-public-infrastructure.js'});

vm.runInContext('ensureV167State()',ctx);
assert.equal(vm.runInContext('game.version',ctx),'1.67.0','version not upgraded');
assert(Object.keys(game.gm.realEstate.buildings).filter(k=>k.startsWith('building:utility:')).length===2,'state utility assets were not seeded into real estate');

// Force a pronounced weak-grid condition in Forge and refresh profiles.
const forgeUtility=game.gm.realEstate.buildings['building:utility:forge'];
forgeUtility.condition=20;forgeUtility.utilityCapacity=0;forgeUtility.storageBoost=0;forgeUtility.waterBoost=0;forgeUtility.telecomBoost=0;forgeUtility.transitBoost=0;
const aurora=vm.runInContext("v167SystemProfile('aurora')",ctx),forge=vm.runInContext("v167SystemProfile('forge')",ctx);
assert(aurora.overall>forge.overall,'energy/security/infrastructure differences are not reflected');
assert(forge.powerReliability<52,'Forge should be under power stress in fixture');

// Existing enterprise performance is reduced instead of running a second enterprise model.
const stressed=game.gm.enterpriseEconomy.enterprises['corp:forgeworks'];
const perf=vm.runInContext('v127OperatingPerformance',ctx)(stressed);
assert(perf<1,'utility stress did not affect existing enterprise performance');

// Severe utility outage constrains an existing aviation route.
game.gm.publicInfrastructure.systems.forge={...forge,powerReliability:12,overall:22};
const route={operator:'aviation:test',from:'aurora',to:'forge',kind:'passenger',status:'active',reliability:80,flights:0,passengers:0,revenue:0};
vm.runInContext('v160ProcessRoute',ctx)(route);
assert.equal(route.status,'airport_power_restriction','airport power restriction did not stop route');

// Construction is delayed by an existing capital project under a severe outage.
const cp=stressed.capitalProjects[0],beforeReady=cp.readyDay;
vm.runInContext('v167ConstructionOutages()',ctx);
assert.equal(cp.readyDay,beforeReady+1,'grid outage did not delay existing construction project');
assert(game.gm.construction.metrics.delayDays>=1,'construction metrics not updated');

// Tourism demand is reduced by poor public infrastructure via the existing v1.66 profile.
game.gm.tourismEconomy.systems.forge={demandIndex:80,roomShortage:.1};
const t=vm.runInContext("v166SystemProfile('forge')",ctx);
assert(t.demandIndex<80&&t.utilityReliability===22,'tourism demand did not inherit infrastructure reliability');

// Demographic model remains authoritative but migration is worsened by unreliable utilities.
const region={system:'forge',demographics:{population:3600000,livingCostIndex:80,netMigration:100}};
vm.runInContext('v138ProcessDemographics',ctx)(region);
assert(region.demographics.netMigration<100&&region.demographics.livingCostIndex>80,'utilities did not affect existing demographic output');

// Public investment uses state treasury, common contracts, and upgrades the physical real-estate asset.
game.gm.publicInfrastructure.systems.forge={...forge,powerReliability:12,overall:22};
const beforeCondition=forgeUtility.condition,beforeTreasury=game.gm.factions.helios.treasury;
const project=vm.runInContext("v167StartPublicProject('forge','grid',true)",ctx);
assert(project&&project.status==='active','public grid project did not start');
assert(game.gm.factions.helios.treasury<beforeTreasury,'project deposit did not use existing state treasury');
assert(game.gm.v130.contracts[`public-utility:${project.id}`],'public project not registered in common contract ledger');
game.day=project.readyDay;vm.runInContext('v167CompleteProjects()',ctx);
assert.equal(project.status,'completed','public project did not complete');
assert(forgeUtility.condition>beforeCondition&&forgeUtility.utilityCapacity>0,'completed grid project did not upgrade real-estate utility asset');
assert.equal(game.gm.v130.contracts[`public-utility:${project.id}`].status,'completed','common contract not completed');

// Healthy route pays existing energy supplier for fuel rather than creating a second fuel market.
game.gm.publicInfrastructure.systems.aurora={...aurora,powerReliability:95,overall:92};
game.gm.publicInfrastructure.systems.forge={...forge,powerReliability:90,overall:86};
const fuelBefore=game.gm.energyMarket.firms.heliodyne.sales,airlineBefore=game.gm.aviation.companies.test.capital;
const route2={operator:'aviation:test',from:'aurora',to:'forge',kind:'passenger',status:'active',reliability:90,flights:0,passengers:0,revenue:0};
vm.runInContext('v160ProcessRoute',ctx)(route2);
assert(route2.flights===1&&route2.fuelCost>0,'normal flight/fuel purchase bridge failed');
assert(game.gm.energyMarket.firms.heliodyne.sales>fuelBefore,'fuel payment did not reach existing energy market');
assert(game.gm.aviation.companies.test.capital<airlineBefore,'airline did not pay fuel cost');

console.log('V167_ENERGY_PUBLIC_INFRASTRUCTURE_SMOKE_PASS',JSON.stringify({auroraOverall:Math.round(aurora.overall),forgeOverall:Math.round(forge.overall),forgePower:Math.round(forge.powerReliability),enterprisePerformance:Number(perf.toFixed(3)),project:project.status,utilityCondition:forgeUtility.condition,utilityCapacity:forgeUtility.utilityCapacity,fuelCost:route2.fuelCost,contracts:Object.keys(game.gm.v130.contracts).length},null,2));
