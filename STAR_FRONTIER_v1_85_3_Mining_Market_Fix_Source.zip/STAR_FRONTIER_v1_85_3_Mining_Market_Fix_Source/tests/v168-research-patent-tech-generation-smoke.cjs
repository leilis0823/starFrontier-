'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/112-v1_68-research-patent-tech-generation.js'),'utf8');
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const V12_FACTION_IDS=['league','helios'];
const FACTIONS={league:{short:'League'},helios:{short:'Helios'}};
const SYSTEMS={aurora:{faction:'league'},forge:{faction:'helios'}};
const V127_STATE_PRIORITIES={league:['aerospace','research'],helios:['aerospace']};
const V128_STRATEGIC_INDUSTRIES=new Set(['research','data']);
const game={day:100,version:'1.67.0',war:{active:false},playerCorporation:{created:false},gm:{
 factions:{league:{treasury:80000,research:88},helios:{treasury:60000,research:72}},
 enterpriseEconomy:{enterprises:{},productHistory:[]},
 techTrade:{patents:{},patentOrder:[],licenses:[],nextPatent:1},
 laborMarkets:{league:{engineers:900},helios:{engineers:620}},
 populationLabor:{systems:{aurora:{highSkill:2600,laborForce:14000},forge:{highSkill:1400,laborForce:12000}}},
 publicInfrastructure:{systems:{aurora:{overall:94},forge:{overall:76}}}
}};
function ent(key,faction='league',industry='aerospace',cash=50000){return{key,faction,industry,home:faction==='league'?'aurora':'forge',locationSystem:faction==='league'?'aurora':'forge',status:'operating',techLevel:1,researchPoints:0,quality:78,productivity:1,creditScore:680,strategy:'innovation',cash,lastResearchDay:0,facilities:[{id:key+':f1',installed:30,condition:90,cost:9000}],equipment:[{id:key+':e1',installed:50,condition:92,cost:6000},{id:key+':e2',installed:60,condition:88,cost:5500}],products:[],patents:[],licensedPatents:[],groupTechAccess:[],history:[]}}
const maker=ent('aviation:maker'),follower=ent('aviation:follower','helios'),laggard=ent('aviation:laggard','helios');
game.gm.enterpriseEconomy.enterprises[maker.key]=maker;game.gm.enterpriseEconomy.enterprises[follower.key]=follower;game.gm.enterpriseEconomy.enterprises[laggard.key]=laggard;
function v127AllEnterprises(){return Object.values(game.gm.enterpriseEconomy.enterprises)}
function v127EnterpriseRef(key){return game.gm.enterpriseEconomy.enterprises[key]||null}
function v127EnterpriseName(key){return key}
function v127GetCash(ref){return ref?.cash||0}
function v127AddCash(ref,n){if(ref)ref.cash=Math.max(0,(ref.cash||0)+n)}
function v127ResearchAI(e){if(game.day-(e.lastResearchDay||0)<7)return;e.lastResearchDay=game.day;v127AddCash(e,-12000);e.researchPoints+=45}
function v127MarketScore(){return 100}
function v127OperatingPerformance(){return 1}
function v130ApplyBoardDecision(){return true}
function v128CreatePatent(e,product,owners,name){const id=`pat-${game.gm.techTrade.nextPatent++}`;const p={id,name,owner:e.key,owners:[e.key],faction:e.faction,industry:e.industry,generation:e.techLevel,filed:game.day,expires:game.day+180,strategic:60,secrecy:60,royaltyRate:.03,status:'active'};game.gm.techTrade.patents[id]=p;game.gm.techTrade.patentOrder.unshift(id);e.patents.push(id);if(product)product.patentId=id;return p}
function ensureV167State(){}
function ensureV128State(){}
function rng(){return .5}
const V160_AIRCRAFT_TYPES={prototype:{manufacturer:'maker',interval:40}};
function v160CompanyKey(id){return 'aviation:'+id}
let currentAircraft=null;
function v160CreateAircraft(owner,typeId){currentAircraft={id:'ac1',owner,typeId,condition:100,nextMaintenance:game.day+40};return currentAircraft}
function v160AircraftForRoute(){return currentAircraft}
function v160ProcessRoute(){if(currentAircraft)currentAircraft.condition-=1;return true}
function gmNews(){}
function toast(){}
function escapeHtml(s){return String(s??'')}
const document={querySelector:()=>null,getElementById:()=>null};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,clamp,V12_FACTION_IDS,FACTIONS,SYSTEMS,V127_STATE_PRIORITIES,V128_STRATEGIC_INDUSTRIES,game,v127AllEnterprises,v127EnterpriseRef,v127EnterpriseName,v127GetCash,v127AddCash,v127ResearchAI,v127MarketScore,v127OperatingPerformance,v130ApplyBoardDecision,v128CreatePatent,ensureV167State,ensureV128State,rng,V160_AIRCRAFT_TYPES,v160CompanyKey,v160CreateAircraft,v160AircraftForRoute,v160ProcessRoute,gmNews,toast,escapeHtml,document,initV10:()=>true,gmAdvance:()=>{game.day++;return true},renderGM:()=>{},render:()=>{}};
ctx.global=ctx;ctx.window=ctx;vm.createContext(ctx);vm.runInContext(src,ctx,{filename:'112-v1_68-research-patent-tech-generation.js'});

vm.runInContext('ensureV168State()',ctx);
assert.equal(game.version,'1.68.0','version not upgraded');
assert(V128_STRATEGIC_INDUSTRIES.has('aerospace'),'aviation strategic technology integration missing');
const program=vm.runInContext("v168StartProgram(game.gm.enterpriseEconomy.enterprises['aviation:maker'],'propulsion',true)",ctx);
assert(program&&program.generation===2,'R&D program did not start at next generation');
const cashBefore=maker.cash;
vm.runInContext("v127ResearchAI(game.gm.enterpriseEconomy.enterprises['aviation:maker'])",ctx);
assert(maker.cash<cashBefore,'existing R&D spending was not used');
assert.equal(program.status,'completed','R&D spend did not complete domain program');
assert(program.patentId,'breakthrough was not converted to existing patent system');
const patent=game.gm.techTrade.patents[program.patentId];
assert.equal(patent.v168Domain,'propulsion','patent missing technology-domain metadata');
assert.equal(game.gm.rndInnovation.frontier.propulsion,2,'industry frontier not advanced');

// A license grants access but still requires staged modernization/adoption.
follower.licensedPatents=[patent.id];
vm.runInContext("v168PatentAccess(game.gm.enterpriseEconomy.enterprises['aviation:follower'])",ctx);
assert.equal(vm.runInContext("v168DomainGeneration(game.gm.enterpriseEconomy.enterprises['aviation:follower'],'propulsion')",ctx),2,'license did not grant technology access');
assert.equal(game.gm.rndInnovation.metrics.licensesAdopted,1,'licensed technology adoption metric was not recorded');
const followerCash=follower.cash;
game.gm.rndInnovation.enterprises[follower.key].lastAdoptionDay=game.day-10;
vm.runInContext("v168ProcessAdoption(game.gm.enterpriseEconomy.enterprises['aviation:follower'])",ctx);
assert(follower.cash<followerCash,'modernization did not consume existing enterprise cash');
assert(game.gm.rndInnovation.enterprises[follower.key].access.propulsion.adoption>12,'licensed technology adoption did not advance');
assert(follower.facilities.concat(follower.equipment).some(a=>(a.technologyGeneration||0)>=2),'asset generation transition was not applied');

// Technology advantage affects existing market/performance functions without a second enterprise economy.
for(const d of vm.runInContext("v168DomainsForIndustry('aerospace')",ctx)){game.gm.rndInnovation.enterprises[maker.key].domains[d].generation=2;game.gm.rndInnovation.enterprises[maker.key].domains[d].adoption=90;game.gm.rndInnovation.frontier[d]=2}
const makerScore=vm.runInContext("v127MarketScore(game.gm.enterpriseEconomy.enterprises['aviation:maker'])",ctx);
const lagScore=vm.runInContext("v127MarketScore(game.gm.enterpriseEconomy.enterprises['aviation:laggard'])",ctx);
assert(makerScore>lagScore,'technology leadership did not affect existing market competition');
assert(vm.runInContext("v127OperatingPerformance(game.gm.enterpriseEconomy.enterprises['aviation:maker'])",ctx)>vm.runInContext("v127OperatingPerformance(game.gm.enterpriseEconomy.enterprises['aviation:laggard'])",ctx),'technology leadership did not affect existing operating performance');

// Newly manufactured aircraft inherit manufacturer technology and gain lower wear.
const ac=vm.runInContext("v160CreateAircraft('aviation:follower','prototype',{})",ctx);
assert(ac.technologyGeneration>=2,'new aircraft did not inherit manufacturer technology generation');
const maintenance=ac.nextMaintenance;
assert(maintenance>game.day+40,'technology did not extend initial maintenance interval');
const beforeWear=ac.condition;vm.runInContext("v160ProcessRoute({})",ctx);assert(ac.condition>beforeWear-1,'technology did not reduce aircraft wear');

// Expired patents diffuse through public-domain access after the patent term.
patent.status='expired';patent.strategic=70;laggard.licensedPatents=[];game.day+=20;game.gm.rndInnovation.lastDiffusionDay=game.day-20;
vm.runInContext('v168PublicDomainDiffusion()',ctx);
assert((game.gm.rndInnovation.enterprises[laggard.key].access.propulsion?.generation||0)>=2,'expired patent did not diffuse to compatible industry');

console.log('V168_RESEARCH_PATENT_TECH_GENERATION_SMOKE_PASS',JSON.stringify({frontier:game.gm.rndInnovation.frontier.propulsion,patent:program.patentId,followerAdoption:Math.round(game.gm.rndInnovation.enterprises[follower.key].access.propulsion.adoption),makerScore:Number(makerScore.toFixed(2)),laggardScore:Number(lagScore.toFixed(2)),aircraftGeneration:ac.technologyGeneration,publicDomainGeneration:game.gm.rndInnovation.enterprises[laggard.key].access.propulsion.generation},null,2));
