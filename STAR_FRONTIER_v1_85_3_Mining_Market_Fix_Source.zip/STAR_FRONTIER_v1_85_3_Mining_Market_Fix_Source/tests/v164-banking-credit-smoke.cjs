'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..'),src=fs.readFileSync(path.join(root,'www/js/108-v1_64-banking-credit.js'),'utf8');
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const V115_BANKS={bank1:{name:'Bank 1',short:'B1',faction:'league',capital:100000,risk:.35,rate:.03},bank2:{name:'Bank 2',short:'B2',faction:'helios',capital:90000,risk:.40,rate:.035}};
const V12_FACTION_IDS=['league','helios'];
const FACTIONS={league:{short:'League'},helios:{short:'Helios'}};
const cash={'corp:good':70000,'corp:bad':3000};
const game={day:50,version:'1.63.0',war:{active:true,a:'league',b:'helios'},playerCorporation:{created:false},gm:{
 enterpriseEconomy:{enterprises:{
  'corp:good':{key:'corp:good',industry:'manufacturing',faction:'league',home:'aurora',creditScore:760,debt:12000,revenueTotal:85000,lastRevenue:5000,lastProfit:800,facilities:[{cost:30000}],equipment:[{cost:16000}],defaults:0,distress:8,status:'operating',history:[],loans:[]},
  'corp:bad':{key:'corp:bad',industry:'construction',faction:'helios',home:'forge',creditScore:510,debt:50000,revenueTotal:14000,lastRevenue:800,lastProfit:-250,facilities:[{cost:9000}],equipment:[],defaults:4,distress:78,status:'distressed',history:[],loans:[]}
 },corporateLoans:[{id:'old',bank:'bank2',borrower:'corp:bad',principal:18000,outstanding:16000,rate:.06,defaults:3,active:true,purpose:'working',guarantee:0}],},
 banking:{banks:{bank1:{capital:100000,loansIssued:0,losses:0,interestIncome:0},bank2:{capital:36000,loansIssued:18000,losses:8000,interestIncome:1000}},loans:[],history:[]},
 v130:{contracts:{c1:{id:'c1',created:48,type:'supply',parties:['corp:bad','corp:good'],status:'disputed',breachLevel:75,outstanding:9000,disputeId:'d1'}},disputes:[]},
 geoeconomicCrisis:{systems:{aurora:{severity:8},forge:{severity:90}}},insuranceReinsurance:{reinsurers:{r1:{underwriting:'restricted'}}}
}};
function v127EnterpriseRef(k){const e=game.gm.enterpriseEconomy.enterprises[k];return e?{key:k}:null}
function v127GetCash(r){return cash[r.key]||0} function v127AddCash(r,n){cash[r.key]=(cash[r.key]||0)+n}
function v129EnterpriseAssetValue(e){return [...(e.facilities||[]),...(e.equipment||[])].reduce((n,a)=>n+(a.cost||0),0)}
function v163FleetValue(){return 0} function v163ActivePolicy(k,l){return k==='corp:good'&&['property','interruption'].includes(l)?{id:k+l}:null}
function v117SanctionBetween(a,b){return a==='helios'&&b==='league'?[{type:'capital'}]:[]}
function v127EnterpriseName(k){return k}
function v127LoanRisk(e,bankId,amount,guarantee=0){return{score:e.creditScore,threshold:590,lev:e.debt/10000,margin:0}}
function v127RequestCorporateLoan(e,amount,purpose,guarantee=0){const r=v127LoanRisk(e,'bank1',amount,guarantee);if(r.score<r.threshold)return 0;const l={id:'new'+game.day,bank:'bank1',borrower:e.key,principal:amount,outstanding:amount,rate:.04,defaults:0,active:true,purpose,guarantee};game.gm.enterpriseEconomy.corporateLoans.push(l);return amount}
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,clamp,game,V115_BANKS,V12_FACTION_IDS,FACTIONS,v127EnterpriseRef,v127GetCash,v127AddCash,v129EnterpriseAssetValue,v163FleetValue,v163ActivePolicy,v117SanctionBetween,v127EnterpriseName,v127LoanRisk,v127RequestCorporateLoan,ensureV163State:()=>{},initV10:()=>{},gmAdvance:()=>{game.day++;return true},renderV117PlayerBusiness:()=>'',renderGM:()=>{},render:()=>{},gmNews:()=>{},escapeHtml:s=>String(s??''),document:{querySelector:()=>null,getElementById:()=>null}};
ctx.global=ctx;ctx.window=ctx;vm.createContext(ctx);vm.runInContext(src,ctx,{filename:'108-v1_64-banking-credit.js'});
vm.runInContext('ensureV164State()',ctx);
const good=game.gm.creditMarket.profiles['corp:good'],bad=game.gm.creditMarket.profiles['corp:bad'];
assert(good.score>bad.score,'ratings do not separate good/bad');assert(['A','AA','AAA','BBB'].includes(good.rating),'good rating too low');assert(['B','CCC','Default','BB'].includes(bad.rating),'bad rating too high');
assert(game.gm.creditMarket.banks.bank2.stress>game.gm.creditMarket.banks.bank1.stress,'stressed bank not detected');
const riskGood=vm.runInContext('v127LoanRisk(game.gm.enterpriseEconomy.enterprises["corp:good"],"bank1",5000,0)',ctx);
const riskBad=vm.runInContext('v127LoanRisk(game.gm.enterpriseEconomy.enterprises["corp:bad"],"bank2",5000,0)',ctx);
assert(riskGood.score>riskBad.score,'credit rating not affecting loan risk');assert(riskBad.threshold>riskGood.threshold,'bank stress not tightening threshold');
const before=game.gm.enterpriseEconomy.corporateLoans.length;const amt=vm.runInContext('v127RequestCorporateLoan(game.gm.enterpriseEconomy.enterprises["corp:good"],5000,"expansion",0)',ctx);assert(amt>0,'good borrower loan rejected');const nl=game.gm.enterpriseEconomy.corporateLoans[before];assert(nl.originationRating,'origination rating missing');assert(Number.isFinite(nl.riskSpread),'risk spread missing');
vm.runInContext('v164ApplyCovenants()',ctx);const old=game.gm.enterpriseEconomy.corporateLoans.find(l=>l.id==='old');assert(old.covenantBreaches>=1,'weak borrower covenant not triggered');assert(old.rate>.06,'covenant did not reprice loan');
assert.doesNotThrow(()=>JSON.parse(vm.runInContext('JSON.stringify(game.gm.creditMarket)',ctx)));assert.equal(vm.runInContext('game.version',ctx),'1.64.0');
console.log('V164_BANKING_CREDIT_SMOKE_PASS',JSON.stringify({good:good.rating,bad:bad.rating,bank1:game.gm.creditMarket.banks.bank1.stress,bank2:game.gm.creditMarket.banks.bank2.stress,covenantRate:old.rate},null,2));
