'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const miningSrc=fs.readFileSync(path.join(root,'www/js/120-v1_76-mining-ores-elements-salvage.js'),'utf8');
const fixSrc=fs.readFileSync(path.join(root,'www/js/134-v1_85_3-mining-market-integration-fix.js'),'utf8');

const SYSTEMS={aurora:{name:'オーロラ',faction:'league',security:'中',yield:{iron:55,titanium:34,crystal:12},base:{iron:62,titanium:118,crystal:245},stock:{iron:100,titanium:80,crystal:35}}};
const FACTIONS={league:{short:'連盟'}};
const HULLS={nomad:{name:'ノマド',class:'corvette',mining:1},pathfinder:{name:'パスファインダー',class:'corvette'},mole:{name:'モール採掘船',class:'corvette'}};
const V169_COMMODITIES={iron:{name:'鉄',base:62},titanium:{name:'チタン',base:118},crystal:{name:'星晶石',base:245}};
const game={day:20,version:'1.85.3',system:'aurora',fuel:100,credits:50000,cargoMax:200,cargo:{iron:0,titanium:0,crystal:0},prices:{aurora:{iron:62,titanium:118,crystal:245}},stocks:{aurora:{iron:100,titanium:80,crystal:35}},hull:'nomad',upgrades:{laser:2},loadouts:{nomad:[]},crew:{},stations:[],stationOrders:[],career:{faction:null,merit:0,activeContract:null},contracts:[],war:{active:false},freeCaptains:{heat:0},prizeShips:[],ownedHulls:['nomad'],hullState:{nomad:{condition:100}},gm:{enterpriseEconomy:{enterprises:{}},commodityMarket:{benchmarks:{}},factions:{},v130:{contracts:{},contractOrder:[]}}};
for(const [k,v] of Object.entries({aluminum:92,copper:108,nickel:146,cobalt:238,lithium:205,uranium:355,rare_earth:315,platinum:510,silicon:128,thorium:270}))game.gm.commodityMarket.benchmarks[k]={spot:v};
let rngCalls=0,rv=.12;function rng(){rngCalls++;return rv}
function miningBonus(){return 2} function crewBonus(){return 0} function combatPower(){return 100}
function cargoUsed(){return Object.values(game.cargo).reduce((a,b)=>a+b,0)} function cargoFree(){return Math.max(0,game.cargoMax-cargoUsed())}
function gmObserve(){} function gmRel(){} function gmPriceMult(){return 1} function escapeHtml(s){return String(s??'')} function addLog(){} function toast(){} function damageShip(){}
function v169State(){return game.gm.commodityMarket} function v169DemandSupply(){return{demand:100,supply:100}}
function shipyardStations(){return[]} function orderProfitBonus(){return 1}
function mineOnce(){} function mineBatch(){} function renderMine(){} function renderContracts(){} function initV10(){return true} function gmAdvance(){game.day++;return true} function travel(){return true} function executeContract(){} function directIntervene(){} function ensureV175State(){}

function node(id,hidden=false){return{id,innerHTML:'',classList:{contains:c=>c==='hidden'&&hidden},querySelector:()=>null,insertAdjacentHTML(pos,html){this.innerHTML+=html},remove(){}}}
const market=node('market',false),marketList=node('marketList',false),cargoList=node('cargoList',false),cargoStat=node('cargo',false);
const nodes={market,marketList,cargoList,cargo:cargoStat};
const document={title:'',querySelector:()=>null,querySelectorAll:()=>[],getElementById:id=>nodes[id]||null};
function renderMarket(){marketList.innerHTML='<div class="market-row" data-base="iron">BASE MARKET</div>'}
function render(){renderMarket();return true}
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Boolean,Set,Map,SYSTEMS,FACTIONS,HULLS,V169_COMMODITIES,game,rng,miningBonus,crewBonus,combatPower,cargoUsed,cargoFree,gmObserve,gmRel,gmPriceMult,escapeHtml,addLog,toast,damageShip,v169State,v169DemandSupply,shipyardStations,orderProfitBonus,mineOnce,mineBatch,renderMine,renderMarket,renderContracts,initV10,gmAdvance,travel,executeContract,directIntervene,ensureV175State,document,render};
ctx.window=ctx;ctx.global=ctx;vm.createContext(ctx);
vm.runInContext(miningSrc,ctx,{filename:'120-v1_76-mining-ores-elements-salvage.js'});
vm.runInContext(fixSrc,ctx,{filename:'134-v1_85_3-mining-market-integration-fix.js'});

vm.runInContext('ensureV176State()',ctx);
const ore=vm.runInContext("v176Survey('aurora').rows[0].k",ctx);
vm.runInContext(`v176SelectOre('${ore}');mineOnce(true)`,ctx);
const mined=vm.runInContext(`v176State().ores['${ore}']`,ctx);
assert(mined>0,'raw ore was not mined');
assert.equal(game.cargo.iron+game.cargo.titanium+game.cargo.crystal,0,'raw ore was incorrectly mirrored into legacy cargo');
const used=vm.runInContext('cargoUsed()',ctx);
assert(used>=mined,'extended cargo was not counted toward hold capacity');

const beforeMarketRng=rngCalls;
vm.runInContext('renderMarket()',ctx);
assert.equal(rngCalls,beforeMarketRng,'market integration consumed RNG');
assert(marketList.innerHTML.includes('BASE MARKET'),'legacy market rows were replaced');
assert(marketList.innerHTML.includes(`data-v1853-mining-market="ore:${ore}"`),'mined ore was not integrated into system market');
assert(marketList.innerHTML.includes('採掘船倉'),'integrated ore row lacks ship-hold labeling');

const q0=vm.runInContext(`v176State().ores['${ore}']`,ctx),c0=game.credits;
vm.runInContext(`v176SellOre('${ore}',1)`,ctx);
const q1=vm.runInContext(`v176State().ores['${ore}']`,ctx);
assert(q1<q0,'system-market raw-ore sale did not reduce mined cargo');
assert(game.credits>c0,'system-market raw-ore sale did not credit the player');

vm.runInContext('v176State().elements.uranium=2.5;renderMarket()',ctx);
assert(marketList.innerHTML.includes('data-v1853-mining-market="element:uranium"'),'refined element was not integrated into system market');
const e0=vm.runInContext('v176State().elements.uranium',ctx),c1=game.credits;
vm.runInContext("v176SellElement('uranium',1)",ctx);
assert(vm.runInContext('v176State().elements.uranium',ctx)<e0,'element sale did not reduce cargo');
assert(game.credits>c1,'element sale did not credit the player');

console.log('V1853_MINING_MARKET_INTEGRATION_SMOKE_PASS',JSON.stringify({ore,mined,used,credits:game.credits,marketHtmlBytes:Buffer.byteLength(marketList.innerHTML),rngCalls}));
