'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'www/js/104-v1_60-aviation.js'),'utf8');
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const fids=['league','helios','nyxdom','concord','imperium','orpheus','volgar'];
const sysIds=['aurora','orion','forge','nyx','elysia','verdant','umbra','bastion','drakon','cinder','meridian','halcyon','kronos'];
const factions={league:'オーロラ連盟',helios:'ヘリオス',nyxdom:'ニクス',concord:'協約',imperium:'帝国',orpheus:'オルフェウス',volgar:'ヴォルガル',unclaimed:'未領有'};
const systemFaction={aurora:'league',orion:'league',forge:'helios',nyx:'nyxdom',elysia:'concord',verdant:'concord',umbra:'orpheus',bastion:'imperium',drakon:'imperium',cinder:'unclaimed',meridian:'orpheus',halcyon:'league',kronos:'volgar'};
const SYSTEMS={};
for(let i=0;i<sysIds.length;i++){const id=sysIds[i],prev=sysIds[(i-1+sysIds.length)%sysIds.length],next=sysIds[(i+1)%sysIds.length];SYSTEMS[id]={id,name:id.toUpperCase(),faction:systemFaction[id],routes:{[prev]:1,[next]:1}}}
const FACTIONS={};for(const [id,name] of Object.entries(factions))FACTIONS[id]={short:name};
const game={day:20,version:'1.59.0',war:{active:false},system:'aurora',playerCorporation:{created:false,businessLines:[],treasury:0},gm:{factions:{},systemLogistics:{},realEstate:{regions:{},parcels:{},buildings:{},firms:{},leases:[],sales:[],listings:[]},enterpriseEconomy:{enterprises:{},supportFirms:{}},v130:{contracts:{},contractOrder:[],disputes:[]}}};
for(const fid of fids)game.gm.factions[fid]={treasury:250000};
for(const sid of sysIds){game.gm.systemLogistics[sid]={routeHealth:90,shortage:4,throughput:20,demand:70,stock:80,capacity:100};game.gm.realEstate.regions['region:'+sid]={systemId:sid,demand:72,landPriceIndex:80};game.gm.realEstate.parcels['land:'+sid+':1']={id:'land:'+sid+':1',systemId:sid,zoning:'logistics',owner:'state:'+systemFaction[sid],buildingIds:[]}}
const cash={};
const V117_PERMITS={},V117_INDUSTRIES={},V127_ASSET_NEEDS={diversified:{facility:'generic',equipment:'generic',facilityCost:1000,equipmentCost:500,days:3}},V127_LABOR_SKILL={},V127_STATE_PRIORITIES={};
for(const fid of fids)V127_STATE_PRIORITIES[fid]=[];
const V127_SUPPORT_FIRMS={baseFacility:{kind:'facility',specialties:[]},baseEquipment:{kind:'equipment',specialties:[]}};
const V130_CONTRACT_TYPES={},V156_BUILDING_META={office:{name:'office',zone:'commercial',floors:[1,4]}},V157_PROGRAMS={},V157_INDUSTRY_PROGRAM={},V157_PROGRAM_LABELS={},V159_INDUSTRY_WEIGHTS={};
const V117_BUSINESS_LAWS={};for(const fid of fids)V117_BUSINESS_LAWS[fid]={corpTax:.2};
function baseRef(key){return null}
function baseKeys(){return []}
function baseName(key){return key}
function baseGet(){return 0}
function baseSet(){}
function baseAdd(ref,n){baseSet(ref,baseGet(ref)+n)}
function baseDefault(ref){return{key:ref.key,kind:ref.kind,industry:ref.industry,faction:ref.faction,home:ref.home,strategy:'growth',status:'operating',employees:20,quality:60,productivity:1,capacity:50,creditScore:620,debt:0,facilities:[],equipment:[],capitalProjects:[],loans:[],products:[],researchPoints:0,techLevel:1,marketShare:5,lastRevenue:0,lastProfit:0,revenueTotal:0,profitTotal:0,distress:0,history:[]}}
function baseStrategic(){return 10}
function baseOperating(){return 1}
function baseOperate(e){e.lastRevenue=300;e.lastProfit=80;e.revenueTotal=(e.revenueTotal||0)+300;e.profitTotal=(e.profitTotal||0)+80}
function baseDemand(){return 1}
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Set,Map,game,SYSTEMS,FACTIONS,V12_FACTION_IDS:fids,V117_PERMITS,V117_INDUSTRIES,V117_BUSINESS_LAWS,V127_ASSET_NEEDS,V127_LABOR_SKILL,V127_STATE_PRIORITIES,V127_SUPPORT_FIRMS,V130_CONTRACT_TYPES,V156_BUILDING_META,V157_PROGRAMS,V157_INDUSTRY_PROGRAM,V157_PROGRAM_LABELS,V159_INDUSTRY_WEIGHTS,clamp,rng:()=>.5,pairTension:()=>10,v117SanctionBetween:()=>null,
 v127EnterpriseRef:baseRef,v127EnterpriseKeys:baseKeys,v127EnterpriseName:baseName,v127GetCash:baseGet,v127SetCash:baseSet,v127AddCash:baseAdd,v127DefaultEnterprise:baseDefault,v127StrategicImportance:baseStrategic,v127OperatingPerformance:baseOperating,v127OperateEnterprise:baseOperate,v117IndustryDemand:baseDemand,
 v127PickHomeSystem:fid=>sysIds.find(s=>SYSTEMS[s].faction===fid)||'aurora',v156RegionId:sid=>'region:'+sid,v156OwnerName:k=>k,
 ensureV156State:()=>game.gm.realEstate,ensureV157State:()=>{},
 v130SyncContracts:()=>{},v130UpsertContract:(id,d)=>{const old=game.gm.v130.contracts[id];game.gm.v130.contracts[id]=old?Object.assign(old,d):{id,created:game.day,breachLevel:0,...d};if(!game.gm.v130.contractOrder.includes(id))game.gm.v130.contractOrder.unshift(id);return game.gm.v130.contracts[id]},
 v130PartyFaction:k=>k.startsWith('state:')?k.slice(6):k.startsWith('aviation:')?(ctx.v127EnterpriseRef(k)?.faction||'unclaimed'):'unclaimed',
 v130PartyName:k=>k.startsWith('state:')?`${k.slice(6)} government`:ctx.v127EnterpriseName(k),
 v130PartyCash:k=>{if(k.startsWith('state:'))return game.gm.factions[k.slice(6)]?.treasury||0;const r=ctx.v127EnterpriseRef(k);return r?ctx.v127GetCash(r):(cash[k]||0)},
 v130AddPartyCash:(k,n)=>{if(k.startsWith('state:')){const f=game.gm.factions[k.slice(6)];if(f)f.treasury+=n}else{const r=ctx.v127EnterpriseRef(k);if(r)ctx.v127SetCash(r,ctx.v127GetCash(r)+n);else cash[k]=(cash[k]||0)+n}},
 initV10:()=>{},gmAdvance:()=>{game.day++;return true},renderV117PlayerBusiness:()=>'',renderGM:()=>{},renderMapDetail:()=>{},render:()=>{},toast:()=>{},escapeHtml:s=>String(s??''),document:{getElementById:()=>null,querySelector:()=>null}
};
ctx.ensureV127State=()=>{for(const key of ctx.v127EnterpriseKeys()){if(!game.gm.enterpriseEconomy.enterprises[key]){const ref=ctx.v127EnterpriseRef(key);if(ref)game.gm.enterpriseEconomy.enterprises[key]=ctx.v127DefaultEnterprise(ref)}}};
ctx.global=ctx;ctx.window=ctx;vm.createContext(ctx);vm.runInContext(src,ctx,{filename:'104-v1_60-aviation.js'});
vm.runInContext('ensureV160State()',ctx);
assert.equal(vm.runInContext('Object.keys(game.gm.aviation.companies).length',ctx),24,'aviation company count');
assert.equal(vm.runInContext('Object.keys(game.gm.aviation.airports).length',ctx),13,'airport count');
assert.equal(vm.runInContext('Object.values(game.gm.enterpriseEconomy.enterprises).filter(e=>e.key.startsWith("aviation:")).length',ctx),24,'enterprise integration');
assert.equal(vm.runInContext('Object.values(game.gm.aviation.aircraft).filter(x=>x.role==="government").length',ctx),7,'government aircraft');
assert.equal(vm.runInContext('Object.values(game.gm.aviation.aircraft).filter(x=>x.role==="vip").length',ctx),2,'VIP aircraft');
assert(vm.runInContext('Object.values(game.gm.aviation.aircraft).some(x=>x.role==="high_value")',ctx),'high value freighter missing');
assert(vm.runInContext('Object.keys(game.gm.v130.contracts).some(k=>k.startsWith("government-airlift:"))',ctx),'government airlift contracts missing');
assert(vm.runInContext('Object.values(game.gm.realEstate.buildings).filter(b=>b.type==="airport").length',ctx)>=13,'airport real estate missing');
assert.equal(vm.runInContext('V157_PROGRAMS.airport.v156Type',ctx),'airport','construction airport program');
vm.runInContext(`game.gm.realEstate.buildings['built-airport:aurora']={id:'built-airport:aurora',systemId:'aurora',parcelId:'land:aurora:1',name:'Aurora Secondary',type:'airport',zoning:'logistics',owner:'state:league',condition:91,floorArea:7000}; v160DiscoverBuiltAirports()`,ctx);
assert.equal(vm.runInContext('Object.keys(game.gm.aviation.airports).length',ctx),14,'completed construction airport not discovered');
assert(vm.runInContext('Object.values(game.gm.aviation.airports).some(x=>x.secondary&&x.buildingId==="built-airport:aurora")',ctx),'secondary airport registration missing');
assert.doesNotThrow(()=>JSON.parse(vm.runInContext('JSON.stringify(game.gm.aviation)',ctx)),'aviation state must serialize');
const before=vm.runInContext('Object.keys(game.gm.aviation.aircraft).length',ctx);
vm.runInContext(`v160CreateAircraftOrder('aviation:aurora_state_airways','aurelia_180',1)`,ctx);
assert(vm.runInContext('game.gm.aviation.orders[0].status',ctx)==='building','order not building');
vm.runInContext('game.gm.aviation.orders[0].dueDay=game.day; v160ProcessOrders(); v160SyncContracts()',ctx);
assert.equal(vm.runInContext('game.gm.aviation.orders[0].status',ctx),'completed','order did not deliver');
assert.equal(vm.runInContext('Object.keys(game.gm.aviation.aircraft).length',ctx),before+1,'delivered aircraft missing');
assert(vm.runInContext('Object.keys(game.gm.v130.contracts).some(k=>k.startsWith("aircraft:ao-"))',ctx),'aircraft purchase contract missing');
assert(vm.runInContext('Object.keys(game.gm.v130.contracts).some(k=>k.startsWith("aviation-supply:"))',ctx),'supplier contracts missing');
vm.runInContext(`{const ac=Object.values(game.gm.aviation.aircraft).find(x=>x.operator==='aviation:aurora_state_airways'&&x.role==='passenger');ac.condition=50;ac.status='maintenance_due';v160ProcessMRO();const j=game.gm.aviation.mroJobs[0];j.dueDay=game.day;v160ProcessMRO();}`,ctx);
assert.equal(vm.runInContext('game.gm.aviation.mroJobs[0].status',ctx),'completed','MRO not completed');
assert(vm.runInContext('Object.keys(game.gm.v130.contracts).some(k=>k.startsWith("mro:"))',ctx),'MRO contract missing');
const routeCount=vm.runInContext('Object.keys(game.gm.aviation.routes).length',ctx);assert(routeCount>0,'routes missing');
vm.runInContext('v160ProcessDaily()',ctx);
assert(vm.runInContext('game.gm.aviation.metrics.flights',ctx)>0,'routes did not operate');
assert.equal(vm.runInContext('game.version',ctx),'1.60.0');
console.log('V160_AVIATION_SMOKE_PASS',JSON.stringify({companies:24,airports:13,aircraft:vm.runInContext('Object.keys(game.gm.aviation.aircraft).length',ctx),routes:routeCount,government:7,vip:2,contracts:vm.runInContext('Object.keys(game.gm.v130.contracts).length',ctx),flights:vm.runInContext('game.gm.aviation.metrics.flights',ctx)},null,2));
