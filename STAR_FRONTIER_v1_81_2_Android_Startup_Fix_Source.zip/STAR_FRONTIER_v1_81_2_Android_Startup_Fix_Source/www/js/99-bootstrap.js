'use strict';
(function(){
  function start(){
    try{
      if(typeof load!=='function') throw new Error('core load() is unavailable');
      load();
      document.documentElement.dataset.sfReady='1';
    }catch(err){
      console.error('[STAR FRONTIER v1.81.2 bootstrap]',err);
      const message=String(err?.message||err||'不明なエラー');
      window.__STAR_FRONTIER_BOOT_ERROR__={message,stack:String(err?.stack||''),day:game?.day??null,version:game?.version??null};
      const t=document.getElementById('toast');
      if(t){t.textContent=`起動に失敗しました：${message.slice(0,96)}。セーブは削除しないでください。`;t.classList.add('show')}
    }
  }
  start();
})();
