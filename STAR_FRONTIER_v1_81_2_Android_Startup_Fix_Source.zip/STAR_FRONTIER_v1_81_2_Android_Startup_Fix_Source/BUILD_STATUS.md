# v1.81.2 Android startup fix

- FIXED: v1.65 `v165SystemProfile()` called `v136UrbanScore(null)` for unclaimed systems during fresh startup.
- Added full-script startup init smoke (`newGame() -> initV10()`).
- Added visible boot exception diagnostics without deleting or mutating saves.
- Android versionCode 18102 / versionName 1.81.2.

# v1.81.1 GitHub Actions Android build hotfix

- Added repository-root `.github/workflows/android-apk.yml`.
- CI explicitly configures Temurin JDK 17.
- CI installs `platforms;android-35` and `build-tools;35.0.0` with sdkmanager.
- CI writes `android/local.properties` from `ANDROID_SDK_ROOT`.
- CI restores executable permission on `android/gradlew` before build.
- Builds `assembleNubiaDebug` and `assembleUniversalDebug` and uploads both APKs as GitHub Actions artifacts.
- versionCode 18101 / versionName 1.81.1.
- Game/content code unchanged from v1.81.0.

# v1.81.0 BUILD STATUS

## Added in v1.81
- 11 v1.76 raw ores are now physical hull/equipment manufacturing inputs.
- class/role based hull BOMs; battleship BOM uses all 11 requested ores.
- slot/performance based equipment BOMs backed by real producer industrial inventory.
- ship purchase and corporate commission are blocked by raw-material shortage and consume producer-system inventory on success.
- existing v1.12 equipment-market production lots are cancelled/reduced if the manufacturer lacks ore inputs.
- player can supply mined raw ore into shipbuilding/equipment industry for payment backed by existing corporate/state cash.
- 12 ordinary mass-market corporate hulls added to common major-yard circulation.
- 9 additional ordinary corporate equipment products added to Arclight / Bulwark / Synapse physical market stock.
- 5 licensed civilian/export derivatives of heritage lineages: DEMETER, NJORD, SLEIPNIR, NIRAI-KANAI, MAMMON. Originals and signature equipment remain special-gated.
- static Web title/header and Android bridge synchronized to 1.81.0; Android versionCode 18100.

## Verification
- v1.59–v1.81 regression/dedicated smokes (18 scripts): PASS
- v1.81 dedicated industrial recipe / mass-market / heritage-derivative smoke: PASS
- all Web JavaScript syntax: PASS
- index script references missing: 0
- duplicate static HTML ids: 0
- external HTTP runtime dependencies: 0
- UI duplicate audit: PASS
- DOM integration: NOT RUN (`jsdom` module body is not bundled; MODULE_NOT_FOUND)
- legacy `tools/audit.py`: inherited v1.52 fixture mismatch (`10-v1_1-v1_17.js`, `20-v1_18-v1_31.js` baseline), not a v1.81 regression
- Android SDK / Nubia Fold physical-device build: NOT RUN in this environment
- package ZIP integrity: PASS (validated with `unzip -t`; release SHA-256 reported with artifact)

---

# v1.80.0 BUILD STATUS

## Added in v1.80
- Long-horizon strategic controller for enterprises, states, pirates and player-owned organizations.
- 45–90 day enterprise/state plans and 20–50 day pirate plans with objectives, KPIs, action cadence and review.
- Enterprise plans call existing credit, consulting, R&D, capex, commodity futures and long-term procurement systems.
- State plans call existing central-bank policy, security outsourcing, defense procurement and public-infrastructure systems.
- Pirate plans react to Heat, bounties, patrol coverage, treasury and combat power; can hide, raid, rebuild, smuggle-route shift or attempt territorial expansion.
- Player strategic AI defaults to advisor-only; limited delegation uses explicit permission toggles and never auto-authorizes M&A, war escalation or illegal raids.
- Outcome review every 30 days adjusts future objective preference without replacing underlying simulations.
- Android/Web version synchronized to 1.80.0; Android versionCode 18000.

## Verification
- v1.59–v1.69 regression smokes: PASS
- v1.75 macro/strategic integration smoke: PASS
- v1.76 mining/ore/element/salvage smoke: PASS
- v1.77 advanced mining/rights smoke: PASS
- v1.78 interstellar commerce/convoy smoke: PASS
- v1.79 resource/logistics/humanitarian smoke: PASS
- v1.80 strategic-decision-AI dedicated smoke: PASS
- all Web JavaScript syntax: PASS
- index resource references missing: 0
- duplicate static HTML ids: 0
- external HTTP runtime dependencies: 0
- UI duplicate audit: PASS
- DOM integration: NOT RUN (`jsdom` module body is not bundled; MODULE_NOT_FOUND)
- legacy `tools/audit.py`: inherited v1.52 fixture mismatch, same known baseline
- Android SDK / Nubia Fold physical-device build: NOT RUN in this environment
- package ZIP integrity: PASS (final SHA-256 reported with release artifact).

# v1.79.0 BUILD STATUS

## Added in v1.79
- resource-major mining concessions, auctions and inter-corporate concession acquisitions
- player-owned automated mining bases and fleet expansion
- physical resource-major mining fleets carrying real raw ore and using v1.76 raid/salvage rules
- mining-fleet replacement cost, cooldown, security hardening and periodic ore offload
- physical passenger liners and humanitarian/refugee evacuation traffic
- reserved-population migration with failed-evacuation rollback
- wartime blockades, checkpoints, sanctions inspections and merchant seizure/delay
- enterprise freight exchange using real origin stock and destination delivery
- freight/recovery compensation funded from existing enterprise/state finance; unpaid balances become v1.30 breaches
- tow, repair, rescue and salvage contracts based on physical damaged traffic/wrecks
- smuggling networks, trust/heat/safehouses and covert cargo jobs
- Android bridge/save version synchronized to 1.79.0; Android versionCode 17900

## Validation
- v1.59–v1.69 regression smokes: PASS
- v1.75 macro/strategic integration smoke: PASS
- v1.76 mining/ore/element/salvage smoke: PASS
- v1.77 advanced mining/rights smoke: PASS
- v1.78 interstellar commerce/convoy smoke: PASS
- v1.79 resource/logistics/humanitarian dedicated smoke: PASS
- all Web JavaScript syntax: PASS
- index resource references missing: 0
- duplicate static HTML ids: 0
- external HTTP runtime dependencies in index: 0
- UI duplicate audit: PASS
- DOM integration: NOT RUN (`jsdom` package body is not bundled; MODULE_NOT_FOUND)
- legacy `tools/audit.py`: inherited v1.52 fixture mismatch, same known baseline
- Android SDK / Nubia Fold physical-device build: NOT RUN in this environment

---

# v1.78.0 BUILD STATUS

## Added in v1.78
- physical NPC merchant traffic using existing v1.21 commercial-hull definitions
- real cargo loading from origin inventories and delivery into destination inventories
- boarding / destruction / merchant prize cargo salvage
- lawful enemy privateering vs v1.40 civilian piracy enforcement
- stolen-cargo provenance, customs seizure and underground fencing
- cargo-manifest intelligence broker
- lawful local convoy-escort work
- risk-driven 2–3 ship convoys, stronger escorts and safer-route selection
- route-danger feedback: repeated piracy reduces traffic and hardens convoys; escorting improves safety
- NPC pirate AI prefers physical merchants when available
- cargo losses/deliveries feed commodity supply and base-resource market price pressure
- cargo losses feed existing v1.63 insurance, v1.27 enterprise finance and v1.30 contract ledger
- Android bridge/save version synchronized to 1.78.0

## Validation
- v1.78 interstellar commerce / convoy smoke: PASS
- v1.59–v1.69 regression smokes: PASS
- v1.75 integrated macro/strategic smoke: PASS
- v1.76 mining smoke: PASS
- v1.77 advanced mining smoke: PASS
- all Web JavaScript syntax: PASS
- index resource references missing: 0
- duplicate static HTML ids: 0
- external HTTP runtime dependencies in index: 0
- UI duplicate audit: PASS
- DOM integration: NOT RUN (`jsdom` package body is not bundled; MODULE_NOT_FOUND)
- legacy `tools/audit.py`: inherited v1.52 fixture mismatch, same known baseline
- Android SDK / Nubia Fold physical-device build: NOT RUN in this environment

---

# v1.77.0 BUILD STATUS

## Added in v1.77
- 6 critical minerals: Ga / Ge / W / Mo / Ta / Re
- 3 new ores: scheelite / molybdenite / coltan, plus trace by-products in existing ores
- deep geological prospecting with rare lode/anomaly discoveries
- 60-day mining claims synced to the v1.30 common contract ledger
- survey-data sale as an exploration/prospecting income route
- claim/discovery yield bonuses without replacing the v1.76 mining loop
- mining/refining accidents and optional v1.63 insurance claims
- tailings generation, reprocessing and site restoration
- mining environmental load integrated into v1.73 disaster risk
- illicit ore provenance, customs seizure risk and black-market fencing
- Android bridge/save version synchronized to 1.77.0

## Validation
- all Web JavaScript syntax: PASS
- v1.59–v1.69 regression smokes: PASS
- v1.75 integrated macro/strategic smoke: PASS
- v1.76 mining/ore/element/salvage smoke: PASS
- v1.77 advanced mining smoke: PASS
- index resource references missing: 0
- duplicate static HTML ids: 0
- external HTTP runtime dependencies in index: 0
- UI duplicate audit: PASS
- DOM integration: NOT RUN (`jsdom` package body is not bundled; MODULE_NOT_FOUND)
- legacy `tools/audit.py`: inherited v1.52 fixture mismatch, same known baseline
- Android SDK / Nubia Fold physical-device build: NOT RUN in this environment

---

# v1.76.0 BUILD STATUS

## Added in v1.76
- 11 raw ores with elemental composition and system geology
- 10 refined elements integrated into v1.69 commodity benchmarks
- ore survey / grade / reserve depletion / player target selection
- shipboard concentration and industrial refining
- NPC mining-vessel traffic with real ore cargo
- lawful enemy mining-vessel seizure vs v1.40 piracy enforcement
- boarding/destroying cargo-survival tradeoff and rare prize-vessel capture
- same-day traffic respawn protection
- military paid-sortie exploit fix (operation system + one paid sortie/day)
- live mining/profit analysis UI

## Validation
- all Web JavaScript syntax: PASS
- v1.59–v1.69 regression smokes: PASS
- v1.75 integrated macro/strategic smoke: PASS
- v1.76 mining/ore/element/salvage smoke: PASS
- index resource references missing: 0
- duplicate static HTML ids: 0
- external HTTP runtime dependencies in index: 0
- UI duplicate audit: PASS
- DOM integration: NOT RUN (`jsdom` package body is not bundled; MODULE_NOT_FOUND)

## Historical baseline

## Added in cumulative v1.70–v1.75
- v1.70 monetary / FX / central-bank / inflation overlay
- v1.71 households / consumption / living standards
- v1.72 equity / corporate bonds / sovereign bonds / governance
- v1.73 environmental disasters / insured losses / resource depletion
- v1.74 abstract cyber conflict / industrial espionage / technology leakage
- v1.75 government procurement / defense-industry contracts / military-stockpile delivery

## Validation
- v1.59–v1.69 regression smoke tests: PASS
- v1.75 macro-strategic integration smoke: PASS
- all Web JavaScript syntax: PASS
- HTML local references: 0 missing
- duplicate static HTML IDs: 0
- external HTTP runtime dependencies: 0
- UI duplicate audit: PASS
- legacy `tools/audit.py` v1.52 fixture comparison remains incompatible with the inherited v1.69 baseline because `10-v1_1-v1_17.js` and `20-v1_18-v1_31.js` already differ by small inherited edits; this is not introduced by v1.70–v1.75.
- Node/jsdom DOM integration requires an installed jsdom module; package lock exists but module bytes are not bundled.
- Android SDK/device build not executed in this environment.

---

STAR FRONTIER v1.68.0 R&D, Patents & Technology Generations Source

完了:
- v1.53.0 Androidプロジェクト解析
- Nubia/Universal build flavor分離
- 保存ホットパスのデバウンス/非同期化
- SaveStore fast primary path + checkpoint分離
- バックアップ件数表示の軽量化
- Android WebView/DOM描画最適化
- 全Web JS node --check PASS
- SaveStore JVM 17項目 PASS
- >3MiB fast-save JVM benchmark: 5 writes 140ms (旧実装 1153ms、同コンテナ)
- index.html参照資源欠損 0
- v1.52基幹ゲームJS変更 0（v1.54は追加レイヤー `96-v1_54-hybrid-intervention.js` として実装）

未実施:
- Android Gradle build（この環境にAndroid SDKが無いため）
- Nubia Fold実機計測
- Universal実機計測

したがってAPK/実機PASSとは扱わない。

v1.53.3: 企業画面の契約台帳・取締役会DOM重複を修正。persistent sibling insertion監査PASS。


v1.54.0: 秘密工作・国家暗殺AI・所属不明部隊・独立工作・編入要請・傀儡/保護/勢力圏AIを追加。組織別の作戦参加判断、並列武装組織の独自行動、防諜警戒・妨害、露見時ブローバックも実装。既存v1.39独立・内戦システムへ接続。


v1.54.1: v1.54公開イベントをメディアAIへ専用カテゴリ接続。報道機関の自由度・国家統制・扇情性に応じた記事差分、帰属調査/防諜声明、国際組織のAI概要・設立需要説明を追加。内部IDは維持。


v1.55.0: UI/情報階層を再編。銀河16タブを5カテゴリへ整理し、Fold展開時サイドレール、情勢ダッシュボード、公開情報/GM解析、メディア内部タブ、国際機構詳細折りたたみ、星系図全画面、ホーム/ヘッダー再配置を追加。ゲームシステムID・セーブ構造は変更していない。

検証:
- 全Web JavaScript `node --check` PASS
- HTML静的ID重複 0 / 参照資源欠損 0
- 外部HTTP(S)ランタイムURL 0
- UI duplicate audit PASS
- Android versionCode 15500 / versionName 1.55.0
- Android Gradle/APK実ビルド・Nubia Fold実機表示確認はGitHub Actions/実機側で実施すること


v1.56.0: 土地・不動産コアを追加。星系別の地価/賃料/空室/用途区分、土地区画、建物、不動産事業者、売買・法人賃貸を実装し、既存v1.30契約台帳・商事紛争へ接続。企業財務・地方経済・建設・経営AIは再実装していない。

v1.57.0: 既存v1.27/v1.28.3建設・設備投資を拡張。18種の建物プログラム、設計/建材/重機/設備保守の下請サプライチェーン、土地への着工配置、工期リスク、制裁時の調達先変更、v1.56建物台帳への竣工実体化、所有地からのプレイヤー建設発注、竣工後保守を追加。元請支払・法人金融・契約法務は既存システムを再利用。

v1.57.0 検証:
- 全Web JavaScript `node --check` PASS
- index.html参照資源欠損 0
- 外部HTTP(S)ランタイムURL 0
- UI duplicate audit PASS
- 建設スモークテスト PASS（施設発注→下請4契約→竣工→不動産台帳登録、所有地からテーマパーク指定発注）
- Android versionCode 15700 / versionName 1.57.0
- `tools/audit.py` はv1.56.0時点から存在するv1.52 fixtureとの不一致でAssertionError（今回の変更対象外）。
- Android Gradle/APK実ビルドおよびNubia Fold実機確認は未実施。


v1.58.0: 既存の国家/地方政策・地方財政・人口・企業・物流をv1.56土地市場へ接続。立地政策プログラム、動的需要/地価/賃料/空室、投機熱、地価バブルと調整、空洞化、不動産会社投資AI、公有地供給、既存地方予算からの立地補助、既存税優遇への接続、v1.57建設許認可日数への政策反映を追加。

v1.58.0 検証:
- 全Web JavaScript `node --check` PASS
- index.html参照資源欠損 0
- 外部HTTP(S)ランタイムURL 0
- UI duplicate audit PASS
- 立地政策スモーク PASS（政策自動選択、地価・空室更新、既存税優遇への接続）
- 統合スモーク PASS（地方予算からの立地補助、開発特区による建設許認可短縮、バブル/調整分岐、空洞化分岐）
- Android versionCode 15800 / versionName 1.58.0、Android bridge build/save version 1.58.0
- `tests/dom-integration.cjs` は同梱アーカイブにjsdom実体ファイルが無く未実施。依存欠損でありテスト不合格ではない。
- `tools/audit.py` は既存v1.52 fixtureとの不一致でAssertionError。v1.56/v1.57系からの既知ベースラインで今回の変更対象外。
- Android Gradle/APK実ビルド、Nubia Fold実機確認は未実施。

v1.59.0: 不動産経営AI＋自動交渉AIを追加。既存v1.20.1経営委任、v1.27企業財務/設備投資、v1.30契約法務、v1.56不動産、v1.57建設、v1.58立地政策を再利用し、企業が現状維持・賃貸・既存建物取得・土地取得＋建設・所有地建設を比較する。上位物件の相見積もり、最大3ラウンド交渉、交渉決裂時の次善案、権限別承認、自動移転、投資30日後レビューを追加。賃貸/取得拠点はv1.27操業施設として扱い、設備AIの重複施設建設を防止。NPC企業にも同じ判断・取引を適用。

v1.59.0 検証:
- 全Web JavaScript `node --check` PASS
- index.html参照資源欠損 0
- 外部HTTP(S)ランタイムURL 0
- UI duplicate audit PASS
- 不動産経営AIスモーク PASS（候補比較、賃貸交渉、契約締結、移転、契約台帳同期、操業拠点認識、重複施設建設防止、操業効率反映、30日レビュー、NPC自動執行）
- テスト取引では賃料 900 Cr → 806 Crで交渉成立
- Android versionCode 15900 / versionName 1.59.0、Android bridge build/save version 1.59.0
- `tests/dom-integration.cjs` は同梱アーカイブのjsdom実体欠損により未実施。既知の依存欠損でテスト不合格とは扱わない。
- `tools/audit.py` は既存v1.52 fixture不一致でAssertionError。v1.56以降から継続する既知ベースライン。
- Android Gradle/APK実ビルド、Nubia Fold実機確認は未実施。



v1.60.0追加確認対象:
- 航空産業24社をv1.27企業財務へ統合
- 空港をv1.56不動産/v1.57建設へ統合
- 航空機売買・供給・MRO・空港使用・政府航空輸送をv1.30共通契約へ統合
- 既存物流・制裁・戦争リスクを航空路線/納期へ接続


v1.60.0 検証結果:
- 全 `www/**/*.js` Node構文検査 PASS
- `tests/v159-smoke.cjs` PASS（既存不動産経営AI回帰）
- `tests/v160-aviation-smoke.cjs` PASS
  - 航空企業24社の企業財務統合
  - 初期空港13 + 建設後の第2空港自動認識
  - 政府専用機7 / VIP機2 / 高価値貨物機
  - 航空機発注・エンジン/部品契約・納入
  - MRO整備契約・完了
  - 旅客/貨物路線運航・空港契約
  - 航空状態 JSON serialize PASS
- 既存 `dom-integration.cjs` はソースZIPにjsdom依存本体が同梱されていないため、この環境では未実行（構文/航空専用スモークとは別項目）


v1.61.0追加確認対象:
- コンサルティング9社をv1.27企業財務へ統合
- 戦略/経営/技術/M&A/財務/人事/SCM + 統合診断を実装
- コンサル契約をv1.30共通契約台帳へ統合
- 助言を既存取締役会・設備投資・不動産AI・調達先選定へ接続
- NPC企業の外部コンサル需要・自律採用を追加
- M&Aは既存資本市場の候補スクリーニングに限定し、並列M&Aエンジンは作成しない


v1.61.0 検証結果:
- 全 `www/**/*.js` Node構文検査 PASS
- `tests/v159-smoke.cjs` PASS（既存不動産経営AI回帰）
- `tests/v160-aviation-smoke.cjs` PASS（既存航空産業回帰）
- `tests/v161-consulting-smoke.cjs` PASS
  - コンサル会社9社 / 7専門領域 + 統合診断
  - 着手金・残額決済 / 共通契約台帳同期
  - 未払いを payment breach として既存契約へ接続、重複カウントなし
  - 財務助言を既存取締役会議案へ反映
  - SCM助言を既存調達先選定へ反映
  - 技術助言を既存設備投資エンジンへ反映
  - M&A助言は候補スクリーニングのみで、資本市場を直接変更しないことを確認
  - consulting state JSON serialize PASS
- `tools/ui-duplicate-audit.py` PASS
- index.html参照資源欠損 0 / HTML ID重複 0 / 外部HTTP(S)ランタイムURL 0
- Android versionCode 16100 / versionName 1.61.0、Android bridge build/save version 1.61.0
- `tests/dom-integration.cjs` は同梱アーカイブにjsdom本体が無いため未実施（依存欠損。今回のテスト不合格とは扱わない）
- `tools/audit.py` は既存v1.52 fixtureとの不一致で従来どおりAssertionError。v1.56以降から継続する既知ベースライン。
- Android Gradle/APK実ビルド、Nubia Fold実機確認は未実施。


v1.62.0追加確認対象:
- 既存戦争・制裁・関税・物流障害を星系別危機度へ統合
- 交戦国間の空域閉鎖・航空路線停止と再開をv1.60へ接続
- 航空機輸入関税を企業現金・国家財政・契約台帳へ接続
- 建設地/建材供給元の危機から建材不足・工期遅延・追加費用をv1.57へ接続
- 工期違約/追加費用未払いをv1.30商事係争へ接続
- 非常時用途規制変更・用地徴用・土地収用をv1.56/v1.57へ追加
- 外国不動産の制裁凍結・戦時接収・危機後解除をv1.56/v1.59へ接続
- 収用/接収補償を既存国家財政とv1.30契約法務へ接続
- 危機関連契約と企業distress/restructuring/bankruptcyの因果ログを追加

v1.62.0 検証結果:
- 全 `www/**/*.js` Node構文検査 PASS
- `tests/v159-smoke.cjs` PASS（既存不動産経営AI回帰）
- `tests/v160-aviation-smoke.cjs` PASS（既存航空産業回帰）
- `tests/v161-consulting-smoke.cjs` PASS（既存コンサル産業回帰）
- `tests/v162-geoeconomic-crisis-smoke.cjs` PASS
  - 戦争・物流危機から危機度100
  - 交戦国間航空路線リスク100 → suspended
  - 航空機輸入関税 2,000 Crの企業支払→国家財政入金を確認
  - 建材不足による危機起因工期 +3日
  - 危機時建材追加費用・未払い契約を生成
  - 建設履行違反/追加費用未払いから商事係争を生成
  - 非常時用途変更・用地徴用・土地収用を確認
  - 外国不動産の凍結→接収を確認
  - 未払公的補償請求を共通契約へ同期
  - 危機関連契約→資金繰り悪化の因果ログを確認
  - geoeconomic crisis state JSON serialize PASS
- `tools/ui-duplicate-audit.py` PASS
- index.html参照資源欠損 0 / HTML ID重複 0 / 外部HTTP(S)ランタイムURL 0
- Android versionCode 16200 / versionName 1.62.0、Android bridge build/save version 1.62.0
- `tests/dom-integration.cjs` は同梱アーカイブにjsdom本体が無く `MODULE_NOT_FOUND` のため未実施（依存欠損。v1.62テスト不合格とは扱わない）。
- `tools/audit.py` は既存v1.52 fixtureとの不一致で従来どおりAssertionError。v1.56以降から継続する既知ベースライン。
- Android Gradle/APK実ビルド、Nubia Fold実機確認はこの環境では未実施。


v1.63.0追加確認対象:
- 既存v1.29保険市場を専門保険へ拡張し、並列財務を新設しない
- 3社の再保険会社と元受4社の再保険特約を追加
- 企業財産 / 事業中断 / 貨物 / 航空 / 建設 / 政治リスクの6補償ライン
- v1.60航空・v1.57建設・v1.62地政学危機から保険事故を生成
- 保険金・再保険金・未払いをv1.30契約法務へ同期
- 再保険会社の資本不足から元受会社の引受制限へ波及

v1.63.0 検証結果:
- 全 `www/**/*.js` Node構文検査 PASS
- `tests/v159-smoke.cjs` PASS（不動産経営AI回帰）
- `tests/v160-aviation-smoke.cjs` PASS（航空産業回帰）
- `tests/v161-consulting-smoke.cjs` PASS（コンサル産業回帰）
- `tests/v162-geoeconomic-crisis-smoke.cjs` PASS（地政学・供給網危機回帰）
- `tests/v163-insurance-reinsurance-smoke.cjs` PASS
  - 再保険会社3社 / 再保険特約4本
  - 専門証券の航空・建設・政治リスク付帯
  - 建設危機 / 不動産接収 / 空域閉鎖 / 機体損傷から保険請求を生成
  - 元受保険金支払いから再保険回収を確認
  - 再保険会社資本不足 → 再保険未払い契約 → 商事係争を確認
  - insuranceReinsurance state JSON serialize PASS
- `tools/ui-duplicate-audit.py` PASS
- index.html参照資源欠損 0 / HTML ID重複 0
- Android versionCode 16300 / versionName 1.63.0、Android bridge build/save version 1.63.0
- `tests/dom-integration.cjs` は同梱アーカイブにjsdom本体が無い場合は未実施扱い。専用スモークとは別項目。
- Android Gradle/APK実ビルド、Nubia Fold実機確認はこの環境では未実施。

v1.64.0追加確認対象:
- 企業信用格付け AAA〜Default
- 既存7銀行の資本比率/NPL/融資姿勢
- 新規企業融資の格付け・銀行ストレス反映
- 既存融資コベナンツ/格下げ時再価格設定
- v1.63保険カバー・v1.62危機・v1.30契約違反を信用評価へ接続

v1.65.0追加確認対象:
- v1.38人口/純移動とv1.27技能別労働市場の接続
- 星系別労働力・高技能・サービス・操縦士・高所得層
- 人口移動から技能プールへの流入/流出
- 技能不足による企業生産性・賃金圧力
- 操縦士不足によるv1.60航空路線 crew_shortage

v1.66.0追加確認対象:
- 人口・所得・安全・観光資源・航空アクセスから星系別旅客需要を生成
- 宿泊企業8社をv1.27企業財務・信用・労働へ統合
- 既存ホテル/テーマパーク/博物館を観光供給・魅力度へ接続
- 観光需要をv1.60旅客便の搭乗/収益へ反映（別便シミュレーションは追加しない）
- ホテル稼働・観光消費・国家税収へ波及
- 客室不足時の設備投資をv1.27→v1.57ホテル建設へ接続

v1.66.0 検証結果:
- 全 `www/**/*.js` Node構文検査 PASS
- v1.59〜v1.65回帰スモーク PASS
- `tests/v166-tourism-passenger-smoke.cjs` PASS
  - 宿泊企業8社
  - 初期ホテルをv1.56不動産へ接続
  - 人口/所得/安全/航空アクセスによる需要差を確認
  - 観光需要→v1.60旅客便搭乗数・収益を確認
  - 観光消費→ホテル所有者/国家税収を確認
- Android Gradle/APK実ビルド、Nubia Fold実機確認はこの環境では未実施。

v1.67.0追加確認対象:
- 既存v1.12/v1.13エネルギー市場を星系別発電需給・送配電・備蓄へ接続
- 水・生命維持 / 通信 / 公共交通・物流の公共インフラ信頼度
- 停電/電力制限をv1.27企業操業・v1.57建設工期へ接続
- 空港電力制限をv1.60航空路線へ接続
- 航空燃料を既存v1.12燃料市場から購入し、航空会社→エネルギー企業へ決済
- 公共インフラ低下をv1.38/v1.65人口移動・v1.66観光需要へ接続
- 国家公共投資を既存国家財政・v1.30共通契約・v1.56公共設備へ接続

v1.67.0 検証結果:
- 全 `www/**/*.js` Node構文検査 PASS
- v1.59〜v1.66回帰スモーク PASS
- `tests/v167-energy-public-infrastructure-smoke.cjs` PASS
  - 星系別発電需給/電力信頼度差を確認
  - 公共インフラ低下→既存企業操業効率低下を確認
  - 深刻な停電→空港 `airport_power_restriction` を確認
  - 深刻な停電→既存建設案件 +1日を確認
  - 公共インフラ低下→観光需要低下/人口流出圧力を確認
  - 公共工事→国家財政支出→v1.30契約→v1.56 utility建物改良を確認
  - 正常航空便→既存燃料市場への航空燃料決済を確認
- Android Gradle/APK実ビルド、Nubia Fold実機確認はこの環境では未実施。
- `tools/ui-duplicate-audit.py` PASS
- index.html参照資源欠損 0 / HTML ID重複 0 / 外部HTTP(S)ランタイムURL 0
- Android versionCode 16700 / versionName 1.67.0、Android bridge build/save version 1.67.0
- `tests/dom-integration.cjs` は同梱アーカイブにjsdom本体が無く `MODULE_NOT_FOUND` のため未実施（依存欠損。v1.67専用/回帰スモーク不合格とは扱わない）。


v1.68.0追加確認対象:
- v1.27既存R&D支出を分野別研究プログラムへ接続（別研究財務なし）
- 推進/アビオニクス/材料/自動化/エネルギー/生命工学/物流/建設/金融AIの9技術分野
- 研究完了をv1.28既存特許へ登録し、輸出管理・技術禁輸・ライセンスを再利用
- ライセンス/M&A承継/特許失効後公開技術から技術アクセスを取得
- 発明と導入率を分離し、既存施設・設備を段階的に世代更新
- 技術世代と導入率をv1.27市場競争・操業効率へ接続
- 新造航空機へメーカーの推進/アビオニクス/材料技術を継承し、整備間隔・摩耗へ反映
- エネルギー/インフラ技術をv1.67発電・電力信頼度へ接続
- 国家研究力/国庫余力から戦略R&Dへ既存国家財政による研究助成

v1.68.0 検証結果:
- `tests/v168-research-patent-tech-generation-smoke.cjs` PASS
  - 既存R&D支出→G2研究完了→v1.28特許化
  - ライセンス→技術アクセス→既存設備の段階的世代更新
  - 技術優位→既存市場スコア/操業効率へ反映
  - 新造航空機へのメーカー技術継承と摩耗軽減
  - 特許失効→公開技術の後発企業拡散


v1.68.0 最終検証結果:
- 全 `www/**/*.js` Node構文検査 PASS
- v1.59 不動産経営AI 回帰 PASS
- v1.60 航空産業 回帰 PASS
- v1.61 コンサル産業 回帰 PASS
- v1.62 地政学・供給網危機 回帰 PASS
- v1.63 保険・再保険 回帰 PASS
- v1.64 銀行・企業信用 回帰 PASS
- v1.65 人口・労働市場 回帰 PASS
- v1.66 観光・旅客需要 回帰 PASS
- v1.67 エネルギー・公共インフラ 回帰 PASS
- v1.68 研究開発・特許・技術世代交代 専用スモーク PASS
- `tools/ui-duplicate-audit.py` PASS
- `www/index.html` ローカル参照 34件 / 欠損 0
- HTML ID 124件 / 重複 0
- 外部HTTP(S)ランタイム依存 0
- Android `versionCode 16800` / `versionName 1.68.0`
- Android bridge build/save version 1.68.0
- tests package metadata 1.68.0 / `test:research` 追加
- R&D案件履歴は上限220件とし、古い完了案件を削除して長期セーブ肥大化を抑制
- `tests/dom-integration.cjs` は同梱アーカイブに `jsdom` 本体が無く `MODULE_NOT_FOUND` のため未実施（依存欠損。v1.68コード不合格とは扱わない）
- Android SDKが無いためGradle/APK実ビルド、Nubia Fold実機確認は未実施

v1.69.0追加確認対象:
- 鉄/チタン/星晶石/燃料/建材/食料の銀河商品ベンチマーク
- 既存星系現物価格・v1.12燃料市場への価格接続
- 30/60/90日先物、証拠金、日次値洗い、追証、強制清算
- アンブラ中立決済銀行を先物清算へ再利用
- 固定価格/指数連動の長期調達契約、実納入、供給不足、支払不履行
- v1.30共通契約台帳への commodity_supply / commodity_future 同期
- NPC企業の自律ヘッジ/調達
- v1.68技術世代による資源効率と商品需要の低減
- 原料価格高騰による企業操業悪化とヘッジによる緩和

v1.69.0 検証結果:
- v1.59〜v1.69専用スモーク PASS
- 全 `www/**/*.js` Node構文検査 PASS
- UI duplicate audit PASS
- index.html参照資源欠損 0 / HTML ID重複 0 / 外部HTTP(S)ランタイムURL 0
- Android versionCode 16900 / versionName 1.69.0、Android bridge build/save version 1.69.0
- `tests/dom-integration.cjs` は同梱ソースにjsdom本体が無い場合は未実施扱い
- Android Gradle/APK実ビルド、Nubia Fold実機確認はこの環境では未実施
