'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'../www');
function noop(){}
function makeClassList(){const s=new Set();return {add(...xs){xs.forEach(x=>s.add(x))},remove(...xs){xs.forEach(x=>s.delete(x))},toggle(x){if(s.has(x)){s.delete(x);return false}s.add(x);return true},contains(x){return s.has(x)}}}
function makeEl(id=''){const el={id,textContent:'',innerHTML:'',value:'',checked:false,disabled:false,hidden:false,dataset:{},style:{},className:'',classList:makeClassList(),children:[],parentElement:null,firstChild:null,lastChild:null,nextSibling:null,clientWidth:1200,clientHeight:800,offsetWidth:1200,offsetHeight:800,append(...xs){for(const x of xs){if(x&&typeof x==='object'){x.parentElement=this;this.children.push(x);if(!this.firstChild)this.firstChild=x;this.lastChild=x}}},appendChild(x){this.append(x);return x},insertBefore(x){this.append(x);return x},after:noop,before:noop,remove:noop,replaceChildren(...xs){this.children=[];this.firstChild=null;this.lastChild=null;this.append(...xs)},setAttribute(k,v){this[k]=String(v)},getAttribute(k){return this[k]??null},removeAttribute(k){delete this[k]},querySelector(){return null},querySelectorAll(){return []},closest(){return null},matches(){return false},addEventListener:noop,removeEventListener:noop,insertAdjacentHTML:noop,scrollIntoView:noop,focus:noop,click:noop};return el}
const els=new Map();for(const id of ['home','ship','gal-stations','playerFactionPanel','localStationPanel','stationBuildPanel','warOrderPanel','stationEconomyPanel'])els.set(id,makeEl(id));
const document={title:'',documentElement:makeEl('html'),body:makeEl('body'),head:makeEl('head'),readyState:'complete',getElementById(id){if(!els.has(id))els.set(id,makeEl(id));return els.get(id)},querySelector(){return makeEl('q')},querySelectorAll(){return []},createElement(tag){return makeEl(tag)},createTextNode(t){return{textContent:String(t)}},addEventListener:noop,removeEventListener:noop};
const storage=new Map(),ls={getItem:k=>storage.has(k)?storage.get(k):null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k),clear:()=>storage.clear()};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Boolean,BigInt,Set,Map,WeakMap,WeakSet,RegExp,Promise,Error,TypeError,RangeError,Intl,parseInt,parseFloat,isNaN,isFinite,encodeURIComponent,decodeURIComponent,document,localStorage:ls,navigator:{userAgent:'probe'},location:{href:'https://appassets.androidplatform.net/www/index.html'},performance:{now:()=>0},requestAnimationFrame:fn=>0,cancelAnimationFrame:noop,setTimeout:fn=>0,clearTimeout:noop,setInterval:fn=>0,clearInterval:noop,AudioContext:function(){},webkitAudioContext:function(){},Blob:function(){},URL:{createObjectURL:()=>'',revokeObjectURL:noop},FileReader:function(){},alert:noop,confirm:()=>true,prompt:(m,d)=>d??'TEST',HTMLElement:function(){},Node:function(){},CSS:{escape:s=>String(s)}};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;ctx.window.localStorage=ls;ctx.window.addEventListener=noop;ctx.window.removeEventListener=noop;ctx.window.innerWidth=1200;ctx.window.innerHeight=800;ctx.window.matchMedia=()=>({matches:false,addEventListener:noop,removeEventListener:noop});
vm.createContext(ctx);
const html=fs.readFileSync(path.join(root,'index.html'),'utf8'),scripts=[...html.matchAll(/<script defer src="([^"]+)"/g)].map(m=>m[1]);
for(const rel of scripts){if(rel==='js/99-bootstrap.js')continue;vm.runInContext(fs.readFileSync(path.join(root,rel),'utf8'),ctx,{filename:rel});}
const evalx=code=>vm.runInContext(code,ctx);
evalx("game=newGame(); initV10(); game.credits=5000000; game.playerFaction.created=true; game.playerFaction.name='TEST FRONTIER'; game.claims.aurora=true; game.cargo={iron:999,titanium:999,crystal:999}; render=function(){};");
const seed0=evalx('game.marketSeed');
evalx('StarFrontierPlanetaryOps.ensure();');
if(evalx('game.marketSeed')!==seed0)throw new Error('v185 ensure consumed global RNG');
if(evalx('Object.keys(STATION_MODULES).length')<13)throw new Error('expanded station module catalog missing');
if(evalx('Object.keys(StarFrontierPlanetaryOps.stationShips).length')!==12)throw new Error('strategic station-ship catalog not 12');
if(evalx('Object.keys(StarFrontierPlanetaryOps.surfaceHulls).length')!==6)throw new Error('surface-capable hull catalog not 6');
if(evalx("Object.values(HULLS).filter(h=>h.surfaceCapable).length")<6)throw new Error('surface hulls not integrated into HULLS');
if(evalx('Object.keys(game.planetaryOps.sites).length')<Object.keys(evalx('SYSTEMS')).length*2)throw new Error('planetary sites not seeded');
// Build a player ground facility.
const beforeSites=evalx("Object.values(game.planetaryOps.sites).filter(s=>s.owner==='player').length");
evalx("StarFrontierPlanetaryOps.buildSite('mine')");
const afterSites=evalx("Object.values(game.planetaryOps.sites).filter(s=>s.owner==='player').length");
if(afterSites!==beforeSites+1)throw new Error('player surface facility build failed');
const playerSite=evalx("Object.values(game.planetaryOps.sites).find(s=>s.owner==='player')");ctx.__site=playerSite;
// Add a local player yard and start a strategic station-ship build.
evalx("game.stations.push({id:'test-yard',system:'aurora',name:'TEST YARD',owner:'player',modules:['shipyard','navalBase'],hp:100,npc:false,inventory:{iron:999,titanium:999,crystal:999},breached:false,destroyed:false});");
evalx("StarFrontierPlanetaryOps.buildStrategic('citadel','test-yard')");
const queue=evalx("game.strategicStations.queue.find(q=>q.type==='citadel')");if(!queue)throw new Error('strategic build queue failed');ctx.__ready=queue.readyDay;
evalx('game.day=__ready; StarFrontierPlanetaryOps.processBuilds();');
if(!evalx("game.strategicStations.assets.some(a=>a.type==='citadel'&&a.owner==='player')"))throw new Error('strategic asset completion failed');
// Register and assign a surface-capable defense ship without invoking legacy purchase RNG paths.
evalx("if(!game.ownedHulls.includes('warden_at'))game.ownedHulls.push('warden_at'); game.hullState.warden_at={condition:100}; game.shipRecords.warden_at={acquired:game.day,battles:0,captures:0,defenses:0,maxDamage:0,medals:[]}; StarFrontierPlanetaryOps.assignSurface('warden_at','aurora');");
const defense=evalx("StarFrontierPlanetaryOps.defenses('aurora','player')");
if(!(defense.orbit>0&&defense.atmo>0&&defense.surface>0))throw new Error('three-layer defenses not calculated');
// Force a real existing pirate band to stage a landing raid, then intercept/resolve deterministically.
const band=evalx("Object.values(game.gm.irregular.pirateBands)[0]");if(!band)throw new Error('existing pirate AI band unavailable');ctx.__band=band;
const raid=evalx('StarFrontierPlanetaryOps.createRaid(__band,__site,true)');if(!raid)throw new Error('pirate planetary raid creation failed');ctx.__raid=raid;
evalx("game.system='aurora'; if(!game.ownedHulls.includes('strider_ax'))game.ownedHulls.push('strider_ax'); game.hull='strider_ax'; game.hullState.strider_ax={condition:100}; game.shipRecords.strider_ax={acquired:game.day,battles:0,captures:0,defenses:0,maxDamage:0,medals:[]}; applyStats(); __raid.strength=38; StarFrontierPlanetaryOps.interceptRaid(__raid.id); if(__raid.status==='active'){__raid.resolveDay=game.day; StarFrontierPlanetaryOps.resolveDueRaids();}");
if(evalx("__raid.status==='active'"))throw new Error('planetary raid did not resolve');
if(evalx('game.planetaryOps.metrics.raids')<1)throw new Error('raid metrics missing');
if(evalx('game.marketSeed')!==seed0)throw new Error(`v185 consumed global RNG: ${seed0} -> ${evalx('game.marketSeed')}`);
evalx('save()');
if(evalx('game.version')!=='1.85.1')throw new Error('game version not v1.85.1');
const saved=JSON.parse(storage.get(evalx('SAVE_KEY'))||'{}');if(saved.version!=='1.85.1')throw new Error('persisted save version not v1.85.1');
console.log('V185_STRATEGIC_STATIONS_PLANETARY_OPERATIONS_SMOKE_PASS',JSON.stringify({seed:seed0,stationModules:evalx('Object.keys(STATION_MODULES).length'),strategicTypes:evalx('Object.keys(StarFrontierPlanetaryOps.stationShips).length'),surfaceHulls:evalx('Object.keys(StarFrontierPlanetaryOps.surfaceHulls).length'),sites:evalx('Object.keys(game.planetaryOps.sites).length'),raidStatus:raid.status,defense}));
