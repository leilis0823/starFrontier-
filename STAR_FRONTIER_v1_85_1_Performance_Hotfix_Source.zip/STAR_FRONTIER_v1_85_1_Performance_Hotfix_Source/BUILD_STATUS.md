# v1.85.1 BUILD STATUS — Performance Hotfix

## Scope

Feature Freeze maintenance release for the v1.85.0 Android/UI performance regression. No new gameplay systems.

## Implemented

- Final hidden-screen lazy guards re-applied after v1.82–v1.85 wrappers.
- Ship registry pagination (18 at a time).
- Ship codex pagination (12 at a time).
- Lightweight SVG thumbnails for large ship lists; full SVG retained for detail art.
- Dynamic-contract and strategic/planetary mounts remain visibility-gated.
- Audited v1.81.4 fast hit path for `ensureV112State`, `ensureV114State`, `ensureV127State`.
- Exact v1.24 discarded-RNG compensation retained on cached V127 reuse.
- Multiple legacy render-save requests coalesced to one logical commit.
- Android/native persistence bridge preserved; no localStorage-only replacement on Android.
- Web/Android version synchronized to 1.85.1 / Android versionCode 18501.

## RNG / state equivalence

Safe path (fast ensure-hit layer removed) and v1.85.1 fast path were run through the same UI sequence:

`home -> galaxy -> gm -> stations -> map -> mine -> market -> ship -> home`

- initial marketSeed: `4106848233`
- safe final marketSeed: `2005864285`
- fast final marketSeed: `2005864285`
- safe game hash: `71959db2131487833e579ef01ed6e16407764f429f075360372b349ee4f5869f`
- fast game hash: `71959db2131487833e579ef01ed6e16407764f429f075360372b349ee4f5869f`
- normalized JSON bytes: `1468137` both

v1.81.4 dedicated RNG regression:
- initial `4213774138`
- direct `3119341908`
- cached `3119341908`
- state JSON equality: PASS
- fast cache hits: 25

## Performance evidence

Controlled VM, initialized Home render, fast v1.81.4 ready-hit layer comparison:
- safety/reference path: ~661 ms
- v1.85.1 fast path: ~296–306 ms

Earlier v1.85.0 UI profiling identified multi-megabyte Ship DOM generation; staged registry/codex and mini SVG changes reduced the initial Ship HTML workload from roughly 3.76 MB to roughly 0.21 MB in the controlled UI benchmark.

These are controlled benchmark values, not Nubia Fold wall-clock measurements.

## Verification

- startup init smoke: PASS (`1.85.1`)
- v1.59–v1.85 regression/dedicated smoke scripts: PASS
- v1.81.4 RNG preservation: PASS
- v1.85.1 performance hotfix smoke: PASS
  - RNG/state equality: PASS
  - hidden Ship render guard: PASS
  - render save batching: 1 logical commit
  - persisted version: `1.85.1`
- 26 smoke scripts total: PASS
- all Web JavaScript syntax: PASS
- index script references missing: 0
- duplicate static HTML ids: 0
- DOM integration: NOT RUN (`jsdom` package body is unavailable in this execution environment)

## Android build

Android metadata is updated to versionCode `18501`, versionName `1.85.1`.
Android Gradle build was attempted with `./gradlew :app:assembleUniversalDebug --no-daemon`. Gradle Wrapper attempted to download Gradle 8.9 from `services.gradle.org` and failed with `java.net.UnknownHostException` because outbound network access is unavailable. Source metadata and asset wiring are updated; APK was not produced in this environment.

## Key files

- `www/js/132-v1_85_1-performance-hotfix.js`
- `docs/V1851_PERFORMANCE_HOTFIX.md`
- `tests/v1851-performance-hotfix-smoke.cjs`
