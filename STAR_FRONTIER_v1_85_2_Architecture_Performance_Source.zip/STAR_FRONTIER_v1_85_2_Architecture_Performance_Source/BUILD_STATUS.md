# v1.85.2 BUILD STATUS — Architecture Performance Update

## Status

**SOURCE RELEASE READY**

Feature Freezeを維持したパフォーマンス更新。新ゲーム機能は追加していない。

## Implemented

- Route-first user navigation: UIシェルを先に表示し、既存重描画を2 RAF後へ遅延。
- ゲーム内部の同期`showTab()` / `showGalaxy()`は変更せず、シミュレーション処理順を維持。
- 艦船2Dアイコン／レジストリ (`127-v1_82-ship-icons-registry.js`, 24,957 bytes) を起動時script列から除外し、艦船画面初回だけDynamic Import。
- ナビゲーション中の重複saveを750ms遅延・統合。pagehide / background移行時はflush。
- Android/native SaveStore経路を維持。
- `content-visibility:auto`による画面外DOM layout/paint省略。
- v1.85.1の非表示画面ガード、艦船ページング、軽量SVG、RNG保存キャッシュを継承。
- Web/Android version synchronized to `1.85.2` / Android `versionCode 18502`.

## Safety decisions

- v1.67〜v1.75 ensure-chainの追加短絡は連続操作でRNG差を検出したため**不採用・撤回**。
- Web Workerはグローバルstate/RNG順序分離が未完了のため**未導入**。
- 全JSの単一bundle化はAndroid local assetsでは優先度が低く、起動時parse増大を避けるため**未採用**。

## RNG / state equivalence

UI sequence:
`home -> galaxy -> gm -> stations -> map -> mine -> market -> ship -> home`

- direct final `marketSeed`: `2196336249`
- routed final `marketSeed`: `2196336249`
- normalized game JSON equality: PASS
- normalized JSON bytes: `1468136`

v1.81.4 regression:
- initial: `4213774138`
- direct: `3119341908`
- cached: `3119341908`
- PASS

## Controlled performance evidence

Not Nubia Fold wall-clock measurements.

- Market synchronous render average: ~`521 ms`
- v1.85.2 route call / visible shell return: ~`0.16 ms`
- Full routed market work when RAF is forced immediate: ~`510 ms` vs direct ~`573 ms`
- Ship route controlled VM: v1.85.1 ~`626 ms` -> v1.85.2 ~`532 ms`

The primary improvement is responsiveness: the visible scene changes before the expensive legacy render chain executes.

## Verification

- 28 unique smoke scripts: **PASS**
- startup init: **PASS (`1.85.2`)**
- v1.59–v1.85 gameplay regression scripts: **PASS**
- v1.81.4 RNG preservation: **PASS**
- v1.85.1 performance hotfix regression: **PASS**
- v1.85.2 architecture smoke: **PASS**
- v1.85.2 navigation state equivalence: **PASS**
- all Web JavaScript syntax: **PASS**
- index script references missing: **0**
- duplicate static HTML ids: **0**
- ship registry eagerly loaded: **NO**
- Dynamic Import target present: **YES**
- DOM integration: **NOT RUN** (`jsdom` package body unavailable; npm offline cache incomplete)

## Android build

Android metadata:
- `versionCode 18502`
- `versionName 1.85.2`

`./gradlew :app:assembleUniversalDebug --no-daemon` was attempted. Gradle Wrapper attempted to download Gradle 8.9 and failed with `java.net.UnknownHostException: services.gradle.org` because outbound network access is unavailable. APK was not produced in this environment.

## Key files

- `www/js/133-v1_85_2-architecture-performance.js`
- `www/js/127-v1_82-ship-icons-registry.js` (lazy module)
- `docs/V1852_ARCHITECTURE_PERFORMANCE.md`
- `tests/v1852-architecture-performance-smoke.cjs`
- `tests/v1852-navigation-equivalence-smoke.cjs`
- `test-results-v1852-final/`
