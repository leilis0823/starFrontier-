'use strict';
// ============================================================================
// v1.85.1 — Android UI performance hotfix
// Safe scope: UI laziness, zero-RNG normalization memoization, save batching.
// No simulation RNG is consumed, skipped, or jump-advanced by this layer.
// ============================================================================
(function(){
 const V1851_BUILD='1.85.2';
 let renderDepth=0,renderSavePending=false,perfEpoch=0;
 const perf={renders:0,lastRenderMs:0,saves:0,memoHits:0,memoMisses:0};
 function visible(id){const el=document.getElementById(id);return !!el&&!el.classList.contains('hidden')}
 function galaxySub(id){return visible('galaxy')&&visible('gal-'+id)}
 function guard(fn,pred){if(typeof fn!=='function')return fn;return function(...args){if(!pred())return;return fn.apply(this,args)}}

 // v1.81.4 installed its lazy guards before v1.82-v1.85 were loaded. Reapply
 // guards after every later wrapper so hidden screens cannot rebuild UI.
 if(typeof renderGalaxy==='function')renderGalaxy=guard(renderGalaxy,()=>visible('galaxy'));
 if(typeof renderMine==='function')renderMine=guard(renderMine,()=>visible('mine'));
 if(typeof renderMarket==='function')renderMarket=guard(renderMarket,()=>visible('market'));
 if(typeof renderShip==='function')renderShip=guard(renderShip,()=>visible('ship'));
 if(typeof renderRoutes==='function')renderRoutes=guard(renderRoutes,()=>visible('galaxy'));
 if(typeof renderBioEncounter==='function')renderBioEncounter=guard(renderBioEncounter,()=>visible('home'));
 if(typeof renderMilitary==='function')renderMilitary=guard(renderMilitary,()=>galaxySub('military'));
 if(typeof renderStations==='function')renderStations=guard(renderStations,()=>galaxySub('stations'));
 if(typeof renderCommand==='function')renderCommand=guard(renderCommand,()=>galaxySub('command'));
 if(typeof renderV10==='function')renderV10=guard(renderV10,()=>galaxySub('command'));
 if(typeof renderFleetMissions==='function')renderFleetMissions=guard(renderFleetMissions,()=>galaxySub('command'));
 if(typeof renderGM==='function')renderGM=guard(renderGM,()=>galaxySub('gm'));
 if(typeof renderMapDetail==='function')renderMapDetail=guard(renderMapDetail,()=>galaxySub('map'));
 if(typeof renderV115FinancePanel==='function')renderV115FinancePanel=guard(renderV115FinancePanel,()=>galaxySub('finance'));

 // These late-v1.3x normalizers were profiled thousands of times per render.
 // Repeated calls on an initialized state are state-idempotent and consume zero
 // RNG draws. Memoizing only this audited zero-RNG subset preserves marketSeed.
 function memoZeroRng(fn){
  if(typeof fn!=='function')return fn;
  let epoch=-1,result;
  return function(...args){
   if(renderDepth<=0)return fn.apply(this,args);
   if(epoch===perfEpoch){perf.memoHits++;return result}
   perf.memoMisses++;result=fn.apply(this,args);epoch=perfEpoch;return result;
  };
 }
 for(const name of ['ensureV1327State','ensureV133State','ensureV134State','ensureV135State','ensureV156State']){
  try{if(typeof window[name]==='function')window[name]=memoZeroRng(window[name])}catch(_){}
 }

 // Accelerate v1.81.4's own memo wrappers without changing their RNG semantics.
 // The original wrapper re-runs a large readiness predicate on every cache hit.
 // Here it is checked once per v1.81.4 epoch; V127 replays the exact same
 // discarded-RNG compensation on each subsequent hit. Outside that epoch we
 // delegate unchanged.
 function fastV1814Ensure(name,ready,replayRng=false){
  const fn=window[name];if(typeof fn!=='function')return;let epoch=-1,result,canFast=false;
  window[name]=function(...args){
   let depth=0,e=-1,inside=false;try{depth=v1814PerfDepth;e=v1814PerfEpoch;inside=v1814InsideV151Epoch()}catch(_){}
   if(depth<=0||inside)return fn.apply(this,args);
   if(epoch===e&&canFast){perf.memoHits++;if(replayRng)try{v1814ConsumeV124DiscardedRng()}catch(_){}return result}
   perf.memoMisses++;result=fn.apply(this,args);epoch=e;try{canFast=!!ready()}catch(_){canFast=false}return result;
  };
 }
 try{fastV1814Ensure('ensureV112State',v1814V112Ready,false)}catch(_){}
 try{fastV1814Ensure('ensureV114State',v1814V114Ready,false)}catch(_){}
 try{fastV1814Ensure('ensureV127State',v1814V127Ready,true)}catch(_){}

 // Historical render wrappers call save() repeatedly. Coalesce those calls,
 // but preserve the existing Android/native persistence bridge instead of
 // replacing it with a localStorage-only serializer.
 const v1851SaveBase=typeof save==='function'?save:null;
 function commitSave(){
  if(!v1851SaveBase)return false;
  try{
   if(game)game.version=V1851_BUILD;
   const out=v1851SaveBase.apply(this,arguments);
   if(game)game.version=V1851_BUILD;
   perf.saves++;
   return out;
  }catch(e){
   try{if(game?.v151)game.v151.lastSaveError=`v1851:${e?.name||'Error'}:${e?.message||e}`}catch(_){}
   return false;
  }
 }
 save=function(){
  if(renderDepth>0){
   if(typeof window!=='undefined'&&window.__SF_UI_NAV_RENDER__){window.__SF_UI_NAV_SAVE_PENDING__=true;return true}
   renderSavePending=true;return true
  }
  return commitSave.apply(this,arguments)
 };

 if(typeof render==='function'){
  const baseRender=render;
  render=function(){
   const outer=renderDepth===0,t0=performance?.now?.()||0;if(outer)perfEpoch++;renderDepth++;
   try{return baseRender.apply(this,arguments)}
   finally{
    renderDepth--;
    if(outer){
     if(game)game.version=V1851_BUILD;
     const badge=document.querySelector?.('header .title .badge')||document.querySelector?.('.version-badge');if(badge)badge.textContent='v'+V1851_BUILD;
     const sub=document.querySelector?.('header .sub');if(sub)sub.textContent='Architecture Performance / Lazy Ship UI / Deferred Navigation Save';
     if(typeof document!=='undefined')document.title='STAR FRONTIER v1.85.2 — Architecture Performance';
     if(renderSavePending){renderSavePending=false;commitSave()}
     perf.renders++;perf.lastRenderMs=t0?performance.now()-t0:0;
    }
   }
  };
 }
 if(typeof initV10==='function'){const b=initV10;initV10=function(){const out=b.apply(this,arguments);if(game)game.version=V1851_BUILD;return out}};
 if(typeof load==='function'){const b=load;load=function(){const out=b.apply(this,arguments);if(game)game.version=V1851_BUILD;return out}};
 window.StarFrontierPerformanceHotfix={build:V1851_BUILD,stats:()=>({...perf}),saveNow:()=>save()};
})();
