'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'../www');
function noop(){}
function makeClassList(init=[]){const s=new Set(init);return{add(...xs){xs.forEach(x=>s.add(x))},remove(...xs){xs.forEach(x=>s.delete(x))},toggle(x){if(s.has(x)){s.delete(x);return false}s.add(x);return true},contains(x){return s.has(x)}}}
function makeEl(id='',classes=[]){return{id,textContent:'',innerHTML:'',value:'',checked:false,disabled:false,hidden:false,dataset:{},style:{setProperty:noop},className:classes.join(' '),classList:makeClassList(classes),children:[],parentElement:null,firstChild:null,lastChild:null,clientWidth:1200,clientHeight:800,offsetWidth:1200,offsetHeight:800,append(...xs){for(const x of xs){if(x&&typeof x==='object'){x.parentElement=this;this.children.push(x)}}},appendChild(x){this.append(x);return x},insertBefore(x){this.append(x);return x},after:noop,before:noop,remove:noop,replaceChildren(...xs){this.children=[];this.append(...xs)},setAttribute(k,v){this[k]=String(v)},getAttribute(k){return this[k]??null},removeAttribute(k){delete this[k]},querySelector(sel){return makeEl(sel)},querySelectorAll(){return[]},closest(){return null},matches(){return false},contains(x){return this===x||this.children.includes(x)},addEventListener:noop,removeEventListener:noop,insertAdjacentHTML:noop,scrollIntoView:noop,focus:noop,blur:noop,click:noop,close:noop}}
const els=new Map();for(const id of ['home','galaxy','mine','market','ship'])els.set(id,makeEl(id,['tab',...(id==='home'?[]:['hidden'])]));for(const id of ['map','factions','species','classes','gm','corporations','military','stations','command','finance','international','media','anomalies'])els.set('gal-'+id,makeEl('gal-'+id,['gal-sub',...(id==='map'?[]:['hidden'])]));
const document={title:'',documentElement:makeEl('html'),body:makeEl('body'),head:makeEl('head'),readyState:'complete',hidden:false,getElementById(id){if(!els.has(id))els.set(id,makeEl(id));return els.get(id)},querySelector(sel){if(sel==='header .title .badge'||sel==='.version-badge')return this.getElementById('__badge');if(sel==='header .sub')return this.getElementById('__sub');return makeEl(sel)},querySelectorAll(sel){if(sel==='.tab')return ['home','galaxy','mine','market','ship'].map(id=>els.get(id));return[]},createElement:tag=>makeEl(tag),createTextNode:t=>({textContent:String(t)}),addEventListener:noop,removeEventListener:noop,getElementsByTagName(){return[]}};
const storage=new Map(),ls={getItem:k=>storage.has(k)?storage.get(k):null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k),clear:()=>storage.clear()};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Boolean,BigInt,Set,Map,WeakMap,WeakSet,RegExp,Promise,Error,TypeError,RangeError,Intl,parseInt,parseFloat,isNaN,isFinite,encodeURIComponent,decodeURIComponent,document,localStorage:ls,navigator:{userAgent:'probe'},location:{href:'https://appassets.androidplatform.net/www/index.html'},performance:{now:()=>0},requestAnimationFrame:()=>0,cancelAnimationFrame:noop,setTimeout:()=>0,clearTimeout:noop,setInterval:()=>0,clearInterval:noop,AudioContext:function(){},webkitAudioContext:function(){},Blob:function(){},URL:{createObjectURL:()=>'',revokeObjectURL:noop},FileReader:function(){},alert:noop,confirm:()=>true,prompt:()=>null,HTMLElement:function(){},Node:function(){},CSS:{escape:s=>String(s)},TextEncoder};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;ctx.window.localStorage=ls;ctx.window.addEventListener=noop;ctx.window.removeEventListener=noop;ctx.window.innerWidth=1200;ctx.window.innerHeight=800;ctx.window.matchMedia=()=>({matches:false,addEventListener:noop,removeEventListener:noop});
vm.createContext(ctx);const html=fs.readFileSync(path.join(root,'index.html'),'utf8'),scripts=[...html.matchAll(/<script defer src="([^"]+)"/g)].map(m=>m[1]);for(const rel of scripts){if(rel==='js/99-bootstrap.js')continue;vm.runInContext(fs.readFileSync(path.join(root,rel),'utf8'),ctx,{filename:rel})}
const ev=s=>vm.runInContext(s,ctx);

ev('game=newGame();initV10();refreshMarket(false);ensureMilitaryContent();ensureStationOrders();mapSelected=game.system;');
const snap=ev('JSON.stringify(game)');ctx.__snap=snap;
function setHome(){for(const id of ['home','galaxy','mine','market','ship']){const e=document.getElementById(id);if(id==='home')e.classList.remove('hidden');else e.classList.add('hidden')}for(const id of ['map','factions','species','classes','gm','corporations','military','stations','command','finance','international','media','anomalies']){const e=document.getElementById('gal-'+id);if(id==='map')e.classList.remove('hidden');else e.classList.add('hidden')}}
function normalized(){return ev(`(()=>{const x=JSON.parse(JSON.stringify(game));delete x.version;return JSON.stringify(x)})()`)}
// Direct legacy navigation.
ev('game=JSON.parse(__snap)');setHome();
ev("showTab('galaxy');showGalaxy('gm');showGalaxy('stations');showGalaxy('map');showTab('mine');showTab('market');showTab('ship');showTab('home')");
const directSeed=ev('game.marketSeed'),directState=normalized();
// v1.85.4 user-navigation path. Two RAFs execute immediately in this harness;
// deferred saves are intentionally queued, not executed, because persistence is
// outside the state-equivalence surface.
ev('game=JSON.parse(__snap)');setHome();ctx.requestAnimationFrame=fn=>{fn();return 1};ctx.requestIdleCallback=fn=>1;ctx.setTimeout=fn=>1;
ev("StarFrontierNavigator.openTab('galaxy');StarFrontierNavigator.openGalaxy('gm');StarFrontierNavigator.openGalaxy('stations');StarFrontierNavigator.openGalaxy('map');StarFrontierNavigator.openTab('mine');StarFrontierNavigator.openTab('market');StarFrontierNavigator.openTab('ship');StarFrontierNavigator.openTab('home')");
const routedSeed=ev('game.marketSeed'),routedState=normalized();
if(directSeed!==routedSeed)throw new Error(`navigator changed RNG seed: ${directSeed} != ${routedSeed}`);
if(directState!==routedState)throw new Error('navigator changed normalized game state');
console.log('V1852_NAVIGATION_STATE_EQUIVALENCE_PASS',JSON.stringify({directSeed,routedSeed,bytes:directState.length}));
