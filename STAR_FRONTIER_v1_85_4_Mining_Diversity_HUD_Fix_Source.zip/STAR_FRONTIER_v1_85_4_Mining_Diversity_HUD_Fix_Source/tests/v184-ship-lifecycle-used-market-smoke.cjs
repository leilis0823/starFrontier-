'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'../www');
function noop(){}
function makeClassList(){const s=new Set();return {add(...xs){xs.forEach(x=>s.add(x))},remove(...xs){xs.forEach(x=>s.delete(x))},toggle(x){if(s.has(x)){s.delete(x);return false}s.add(x);return true},contains(x){return s.has(x)}}}
function makeEl(id=''){const el={id,textContent:'',innerHTML:'',value:'',checked:false,disabled:false,hidden:false,dataset:{},style:{},className:'',classList:makeClassList(),children:[],parentElement:null,firstChild:null,lastChild:null,nextSibling:null,clientWidth:1200,clientHeight:800,offsetWidth:1200,offsetHeight:800,append(...xs){for(const x of xs){if(x&&typeof x==='object'){x.parentElement=this;this.children.push(x);if(!this.firstChild)this.firstChild=x;this.lastChild=x}}},appendChild(x){this.append(x);return x},insertBefore(x){this.append(x);return x},after:noop,before:noop,remove:noop,replaceChildren(...xs){this.children=[];this.firstChild=null;this.lastChild=null;this.append(...xs)},setAttribute(k,v){this[k]=String(v)},getAttribute(k){return this[k]??null},removeAttribute(k){delete this[k]},querySelector(){return null},querySelectorAll(){return []},closest(){return null},matches(){return false},addEventListener:noop,removeEventListener:noop,insertAdjacentHTML:noop,scrollIntoView:noop,focus:noop,click:noop};return el}
const els=new Map();for(const id of ['home','ship','crewPanel','sfShipRegistryPanel'])els.set(id,makeEl(id));
const document={title:'',documentElement:makeEl('html'),body:makeEl('body'),head:makeEl('head'),readyState:'complete',getElementById(id){if(!els.has(id))els.set(id,makeEl(id));return els.get(id)},querySelector(){return makeEl('q')},querySelectorAll(){return []},createElement(tag){return makeEl(tag)},createTextNode(t){return{textContent:String(t)}},addEventListener:noop,removeEventListener:noop};
const storage=new Map(),ls={getItem:k=>storage.has(k)?storage.get(k):null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k),clear:()=>storage.clear()};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Boolean,BigInt,Set,Map,WeakMap,WeakSet,RegExp,Promise,Error,TypeError,RangeError,Intl,parseInt,parseFloat,isNaN,isFinite,encodeURIComponent,decodeURIComponent,document,localStorage:ls,navigator:{userAgent:'probe'},location:{href:'https://appassets.androidplatform.net/www/index.html'},performance:{now:()=>0},requestAnimationFrame:fn=>0,cancelAnimationFrame:noop,setTimeout:fn=>0,clearTimeout:noop,setInterval:fn=>0,clearInterval:noop,AudioContext:function(){},webkitAudioContext:function(){},Blob:function(){},URL:{createObjectURL:()=>'',revokeObjectURL:noop},FileReader:function(){},alert:noop,confirm:()=>true,prompt:(m,d)=>d??'TEST',HTMLElement:function(){},Node:function(){},CSS:{escape:s=>String(s)}};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;ctx.window.localStorage=ls;ctx.window.addEventListener=noop;ctx.window.removeEventListener=noop;ctx.window.innerWidth=1200;ctx.window.innerHeight=800;ctx.window.matchMedia=()=>({matches:false,addEventListener:noop,removeEventListener:noop});
vm.createContext(ctx);
const html=fs.readFileSync(path.join(root,'index.html'),'utf8'),scripts=[...html.matchAll(/<script defer src="([^"]+)"/g)].map(m=>m[1]);
for(const rel of scripts){if(rel==='js/99-bootstrap.js')continue;vm.runInContext(fs.readFileSync(path.join(root,rel),'utf8'),ctx,{filename:rel});}
const evalx=code=>vm.runInContext(code,ctx);
evalx("game=newGame(); initV10(); game.credits=2000000; for(const f of Object.keys(game.gm.relations))game.gm.relations[f]=100; render=function(){};");
const seed0=evalx('game.marketSeed');
evalx('StarFrontierShipLifecycle.ensure();');
if(evalx('game.marketSeed')!==seed0)throw new Error('lifecycle ensure consumed global RNG');
const market=evalx('StarFrontierShipLifecycle.market(game.system,true)');
if(!market||!Array.isArray(market.listings)||market.listings.length<4)throw new Error('used market did not generate');
if(!market.listings.some(x=>x.mode==='auction')||!market.listings.some(x=>x.mode==='direct'))throw new Error('used market modes missing');
const direct=market.listings.find(x=>x.mode==='direct');ctx.__direct=direct;
evalx('StarFrontierShipLifecycle.inspectListing(__direct.id)');
if(!direct.inspected)throw new Error('listing inspection failed');
const creditsBefore=evalx('game.credits');
evalx('StarFrontierShipLifecycle.buy(__direct.id)');
const usedId=`used-${direct.id}`;ctx.__usedId=usedId;
if(!evalx('game.ownedHulls.includes(__usedId)'))throw new Error('used ship purchase failed');
if(evalx('game.shipLifecycle.records[__usedId].source')!=='used')throw new Error('used lifecycle source missing');
if(evalx('StarFrontierShipLifecycle.appraisal(__usedId)')<=0)throw new Error('used ship appraisal missing');
if(evalx('game.credits')>=creditsBefore)throw new Error('used purchase did not charge credits');
evalx('StarFrontierShipLifecycle.maintain(__usedId); StarFrontierShipLifecycle.overhaul(__usedId);');
if(evalx('game.shipLifecycle.records[__usedId].serviceHistory.length')<3)throw new Error('maintenance history not recorded');
if(evalx('Math.round(game.hullState[__usedId].condition)')!==100)throw new Error('overhaul did not restore condition');
const appraisal=evalx('StarFrontierShipLifecycle.appraisal(__usedId)');
evalx("StarFrontierShipLifecycle.sell(__usedId,'dealer')");
if(evalx('game.ownedHulls.includes(__usedId)'))throw new Error('used ship resale failed');
if(appraisal<=0)throw new Error('invalid appraisal');
const auction=market.listings.find(x=>x.mode==='auction');auction.baseId='caravan';ctx.__auction=auction;
evalx('__auction.currentBid=__auction.competitorMax; StarFrontierShipLifecycle.bid(__auction.id);');
if(!auction.playerBid||auction.playerBid<=auction.competitorMax)throw new Error('auction bid did not exceed competitor max');
evalx('game.day=__auction.expires; StarFrontierShipLifecycle.daily();');
const auctionId=`used-${auction.id}`;ctx.__auctionId=auctionId;
if(!evalx('game.ownedHulls.includes(__auctionId)'))throw new Error('auction win did not register ship');
if(evalx('game.shipLifecycle.metrics.auctionsWon')<1)throw new Error('auction metrics missing');
if(evalx('game.marketSeed')!==seed0)throw new Error(`v184 actions consumed global RNG: ${seed0} -> ${evalx('game.marketSeed')}`);
if(evalx('game.version')!=='1.85.4')throw new Error('version metadata not v1.85.4 after lifecycle actions');
console.log('V184_SHIP_LIFECYCLE_USED_MARKET_SMOKE_PASS',JSON.stringify({seed:seed0,listings:market.listings.length,direct:direct.baseId,auction:auction.baseId,appraisal,auctionsWon:evalx('game.shipLifecycle.metrics.auctionsWon')}));
