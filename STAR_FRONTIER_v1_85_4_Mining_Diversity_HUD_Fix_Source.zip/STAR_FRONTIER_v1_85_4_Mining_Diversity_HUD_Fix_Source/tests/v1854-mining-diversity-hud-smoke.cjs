'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src176=fs.readFileSync(path.join(root,'www/js/120-v1_76-mining-ores-elements-salvage.js'),'utf8');
const src177=fs.readFileSync(path.join(root,'www/js/121-v1_77-advanced-mining-rights-exploration.js'),'utf8');
const src1854=fs.readFileSync(path.join(root,'www/js/135-v1_85_4-mining-diversity-hud-fix.js'),'utf8');
const SYSTEMS={
 aurora:{name:'オーロラ',faction:'league',security:'高',yield:{iron:55,titanium:34,crystal:12},base:{iron:62,titanium:118,crystal:245},stock:{iron:100,titanium:80,crystal:35}},
 forge:{name:'フォージ',faction:'imperium',security:'軍管',yield:{iron:72,titanium:58,crystal:8},base:{iron:68,titanium:130,crystal:250},stock:{iron:110,titanium:90,crystal:30}}
};
const FACTIONS={league:{short:'連盟'},imperium:{short:'帝国'},helios:{short:'ヘリオス'}};
const HULLS={nomad:{name:'ノマド',class:'corvette',mining:1},pathfinder:{name:'パスファインダー',class:'corvette'},mole:{name:'モール採掘船',class:'corvette'},corp_nox_extractor:{name:'ノックス採掘船',class:'frigate'}};
const V169_COMMODITIES={iron:{name:'鉄',base:62},titanium:{name:'チタン',base:118},crystal:{name:'星晶石',base:245}};
const game={day:30,version:'1.85.3',system:'aurora',fuel:300,maxFuel:300,credits:100000,cargoMax:1000,cargo:{iron:0,titanium:0,crystal:0},prices:{aurora:{iron:62,titanium:118,crystal:245},forge:{iron:68,titanium:130,crystal:250}},stocks:{aurora:{iron:100,titanium:80,crystal:35},forge:{iron:110,titanium:90,crystal:30}},hull:'nomad',upgrades:{laser:2},loadouts:{nomad:['capture']},crew:{},stations:[{id:'r1',system:'aurora',owner:'player',destroyed:false,modules:['refinery','shipyard']}],stationOrders:[],career:{faction:'league',merit:0,activeContract:null},contracts:[],war:{active:false},freeCaptains:{heat:0},prizeShips:[],ownedHulls:['nomad'],hullState:{nomad:{condition:100}},playerCorporation:{created:false},gm:{enterpriseEconomy:{enterprises:{}},commodityMarket:{benchmarks:{},history:{},futures:[],supplyContracts:[],metrics:{}},factions:{league:{treasury:200000},imperium:{treasury:200000},helios:{treasury:200000}},v130:{contracts:{},contractOrder:[]},environmentalRisk:{systems:{},events:[],reserves:{},history:[],metrics:{}}}};
for(const [k,v] of Object.entries({aluminum:92,copper:108,nickel:146,cobalt:238,lithium:205,uranium:355,rare_earth:315,platinum:510,silicon:128,thorium:270}))game.gm.commodityMarket.benchmarks[k]={spot:v};
let rngCalls=0,seed=123456789;function rng(){rngCalls++;seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}
function miningBonus(){return 2} function crewBonus(){return 0} function combatPower(){return 120} function cargoUsed(){return Object.values(game.cargo).reduce((a,b)=>a+b,0)} function cargoFree(){return Math.max(0,game.cargoMax-cargoUsed())}
function gmObserve(){} function gmRel(){} function gmPriceMult(){return 1} function escapeHtml(s){return String(s??'')} function addLog(){} function toast(){} function damageShip(n){game.hullState[game.hull].condition-=n}
function v140Jurisdiction(sid){return SYSTEMS[sid]?.faction||null} function v140RecordOffense(){return{}}
function addPrizeShip(baseHull,origin,condition,source){const p={name:'Prize',baseHull,origin,condition,source};game.prizeShips.push(p);return p}
function v169State(){const x=game.gm.commodityMarket;x.benchmarks=x.benchmarks||{};x.history=x.history||{};for(const [k,m] of Object.entries(V169_COMMODITIES)){x.benchmarks[k]=x.benchmarks[k]||{spot:m.base,previous:m.base,momentum:0,volatility:m.vol||.04,demand:100,supply:100,lastDay:game.day-1};x.history[k]=x.history[k]||[]}return x} function v169DemandSupply(){return{demand:100,supply:100}}
function shipyardStations(){return game.stations.filter(s=>s.modules.includes('shipyard'))} function orderProfitBonus(){return 1.08}
function mineOnce(){} function mineBatch(){} function renderMine(){} function renderMarket(){} function renderContracts(){} function initV10(){return true} function load(){return true} function gmAdvance(){game.day++;return true} function travel(id){game.system=id;return true}
function executeContract(){} function directIntervene(){} function ensureV175State(){game.version='1.75.0'} function save(){save.calls=(save.calls||0)+1;return true}
const contracts={};function v130UpsertContract(id,data){contracts[id]={id,...data};return contracts[id]}
function v173System(sid){const old=game.gm.environmentalRisk.systems[sid]||{systemId:sid,environmentalRisk:30};game.gm.environmentalRisk.systems[sid]=old;return old}
const nodes={};for(const id of ['credits','fuel','cargo','mineFreeCargo'])nodes[id]={id,textContent:'',classList:{contains:()=>false}};nodes.mine={id:'mine',classList:{contains:()=>false}};
const document={title:'',querySelector:()=>null,getElementById:id=>nodes[id]||null};function render(){render.calls=(render.calls||0)+1;return true}
function requestAnimationFrame(fn){fn();return 1}
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Boolean,Set,Map,SYSTEMS,FACTIONS,HULLS,V169_COMMODITIES,game,rng,miningBonus,crewBonus,combatPower,cargoUsed,cargoFree,gmObserve,gmRel,gmPriceMult,escapeHtml,addLog,toast,damageShip,v140Jurisdiction,v140RecordOffense,addPrizeShip,v169State,v169DemandSupply,shipyardStations,orderProfitBonus,mineOnce,mineBatch,renderMine,renderMarket,renderContracts,initV10,load,gmAdvance,travel,executeContract,directIntervene,ensureV175State,save,v130UpsertContract,v173System,document,render,requestAnimationFrame,setTimeout,clearTimeout,performance:{now:()=>0}};ctx.window=ctx;ctx.global=ctx;vm.createContext(ctx);
vm.runInContext(src176,ctx,{filename:'120-v1_76-mining-ores-elements-salvage.js'});vm.runInContext(src177,ctx,{filename:'121-v1_77-advanced-mining-rights-exploration.js'});vm.runInContext(src1854,ctx,{filename:'135-v1_85_4-mining-diversity-hud-fix.js'});

vm.runInContext('ensureV177State(); v176State().selectionMode="auto"; v176State().selectedOre=null',ctx);
assert.equal(vm.runInContext('v176State().selectionMode',ctx),'auto');
const beforeRng=rngCalls;
const minedTypes=[];
for(let i=0;i<12;i++){
 const before=vm.runInContext('JSON.stringify(v176State().ores)',ctx);
 vm.runInContext('mineOnce()',ctx);
 const prev=JSON.parse(before),cur=vm.runInContext('JSON.parse(JSON.stringify(v176State().ores))',ctx);
 for(const k of Object.keys(cur))if((cur[k]||0)>(prev[k]||0)){minedTypes.push(k);break}
}
const unique=[...new Set(minedTypes)];
assert(unique.length>=3,'auto mining did not diversify ore output: '+JSON.stringify(minedTypes));
let maxStreak=1,streak=1;for(let i=1;i<minedTypes.length;i++){streak=minedTypes[i]===minedTypes[i-1]?streak+1:1;maxStreak=Math.max(maxStreak,streak)}
assert(maxStreak<=2,'auto mining repeated one ore more than twice: '+JSON.stringify(minedTypes));
assert.equal(vm.runInContext('v176State().selectedOre',ctx),null,'AUTO mode leaked a persistent selectedOre');
assert(nodes.fuel.textContent.includes('/ 300'),'fuel HUD was not refreshed immediately');
assert(nodes.cargo.textContent.includes('/ 1000'),'cargo HUD was not refreshed immediately');
assert(rngCalls>beforeRng,'authoritative mining RNG did not run');

// Explicit target mode must still mine only the chosen surveyed ore.
const target=vm.runInContext('v176Survey(game.system).rows[1].k',ctx);
vm.runInContext(`v176SelectOre('${target}')`,ctx);
assert.equal(vm.runInContext('v176State().selectionMode',ctx),'target');
const t0=vm.runInContext(`v176State().ores['${target}']`,ctx);
for(let i=0;i<3;i++)vm.runInContext('mineOnce()',ctx);
const t1=vm.runInContext(`v176State().ores['${target}']`,ctx);
assert(t1>t0,'target mining did not mine the selected ore');
assert.equal(vm.runInContext('v176State().selectedOre',ctx),target,'target selection was not preserved');

// AUTO selection itself must be RNG-free: asking the picker directly cannot
// advance the global RNG stream.
vm.runInContext("v176SelectOre('auto')",ctx);const r0=rngCalls;vm.runInContext('StarFrontierMiningHudFix.pickAutoOre(v176Survey(game.system))',ctx);assert.equal(rngCalls,r0,'AUTO ore picker consumed global RNG');

console.log('V1854_MINING_DIVERSITY_HUD_SMOKE_PASS',JSON.stringify({unique,minedTypes,maxStreak,rngCalls,fuel:game.fuel,cargo:nodes.cargo.textContent,selectionMode:vm.runInContext('v176State().selectionMode',ctx)}));
