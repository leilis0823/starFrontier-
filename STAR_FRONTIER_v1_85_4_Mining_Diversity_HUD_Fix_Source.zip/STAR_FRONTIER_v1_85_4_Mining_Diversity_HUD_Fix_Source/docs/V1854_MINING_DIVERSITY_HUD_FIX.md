# STAR FRONTIER v1.85.4 — Mining Diversity & HUD Responsiveness Fix

## Problem

Two playtest issues remained after v1.85.3:

1. Mining repeatedly produced hematite in systems where hematite was the highest survey result.
2. Fuel/cargo/credits could visually update one beat after mining/refuelling because the legacy full render chain blocked the main thread before the browser painted the changed HUD values.

## Root cause: ore lock

v1.76 `v176Survey()` wrote survey row #1 into `game.miningV176.selectedOre` whenever no ore was selected. `v176MineCore()` treats any valid `selectedOre` as an explicit target. Therefore the intended weighted automatic ore selector was practically unreachable during normal play. If hematite was survey rank #1, every mining action targeted hematite.

## Fix: explicit AUTO vs TARGET mining

v1.85.4 adds `game.miningV176.selectionMode`:

- `auto`: chooses from the currently surveyed deposits using survey score and remaining deposit strength.
- `target`: mines the ore explicitly selected by the player.

Old saves are migrated conservatively. A stored selection different from the current survey rank #1 is treated as likely intentional; otherwise the save starts in AUTO mode.

AUTO selection is deterministic and consumes no extra global `rng()` call. This preserves the established v1.76/v1.77 RNG consumption sequence for yield and mining-accident checks. A repeat limiter prevents AUTO from producing the same ore more than twice consecutively while other surveyed deposits remain available.

The mining panel now includes a visible `🎲 自動採掘` control. Selecting any ore switches to TARGET mode; selecting AUTO clears the persistent target.

## HUD responsiveness

Player-facing mining actions no longer require the synchronous whole-game `render()` to finish before critical values can be seen.

Immediate HUD path updates:

- Credits
- Fuel
- Cargo used / cargo capacity
- Mining-panel free cargo

The expensive legacy render call triggered by mining is intercepted only for the synchronous player action. The visible Mining panel is refreshed on the next animation frame and existing `save()` remains authoritative. `mineOnce`, `mineBatch`, ore refining, ore/element sales, and refuelling use the lightweight feedback path where applicable.

This does not change internal travel/combat/AI render semantics.

## Compatibility

- v1.77 claims, discoveries, pollution and accidents remain in the mining call chain.
- v1.84 ship lifecycle mining wear remains outside the core wrapper and continues to run.
- v1.85.2 Route-first navigation and Dynamic Import remain enabled.
- v1.85.3 system-market mining inventory integration remains enabled.
- Raw ore remains outside legacy `game.cargo`; no cargo double-counting is introduced.

## Verification

Dedicated v1.85.4 smoke test:

- 12 AUTO mining actions yielded at least 3 ore types (controlled run yielded 5 types).
- Maximum same-ore AUTO streak: 2.
- TARGET mode stayed locked to the selected ore.
- AUTO picker itself consumed zero global RNG draws.
- Fuel/cargo HUD values updated on the lightweight action path.

Release metadata:

- Web/game version: `1.85.4`
- Android `versionCode`: `18504`
- Android `versionName`: `1.85.4`
