# v1.85.4 BUILD STATUS — Mining Diversity & HUD Responsiveness Fix

## Status

**SOURCE RELEASE READY**

- User-reported hematite-only mining bug: **FIXED**
- Root cause (survey #1 silently becoming permanent target): **CONFIRMED / FIXED**
- AUTO / TARGET mining mode separation: **PASS**
- AUTO controlled run, 12 mining actions: **5 ore types observed**
- AUTO same-ore streak limit when alternatives exist: **max 2 / PASS**
- Explicit TARGET mining remains persistent: **PASS**
- AUTO ore picker additional global RNG draws: **0 / PASS**
- Critical HUD fast path (fuel / cargo / credits / mine free cargo): **PASS**
- Mining full-render interception + next-frame Mining panel refresh: **PASS**
- Refuel / mining refine / ore-element sell lightweight feedback path: **PASS**
- v1.85.3 mining-market integration retained: **PASS**
- v1.85.2 navigation state equivalence retained: **PASS**
- v1.81.4 RNG preservation retained: **PASS**
- Smoke scripts: **30 / 30 PASS**
- Web JavaScript syntax: **54 files PASS**
- index script references missing: **0**
- duplicate static HTML ids: **0**
- Web/Android version: `1.85.4` / `versionCode 18504`

### Controlled mining diversity result

`chalcopyrite, ilmenite, ilmenite, hematite, bauxite, ilmenite, bauxite, silicate, bauxite, chalcopyrite, hematite, ilmenite`

Unique ores: 5 / maximum same-ore streak: 2.

### RNG / architecture regressions

- v1.81.4 regression: initial `4213774138`, direct `3119341908`, cached `3119341908` — **PASS**
- v1.85.2 navigation equivalence: direct `2196336249`, routed `2196336249` — **PASS**
- AUTO ore selector itself does not call global `rng()`.

### Android build

Android metadata is synchronized:

- `versionCode 18504`
- `versionName 1.85.4`

`./gradlew --offline assembleNubiaDebug` was attempted. Gradle Wrapper still attempted to download Gradle 8.9 from `services.gradle.org` and failed with `java.net.UnknownHostException`, because outbound network access is unavailable. No APK is claimed for this environment.

---

# v1.85.3 BUILD STATUS — Mining Market Integration Fix

## Status

- User-reported mining cargo/system-market integration bug: **FIXED**
- Mined raw ore appears in normal System Market list: **PASS**
- Refined elements appear in normal System Market list: **PASS**
- Raw-ore sale reduces mining cargo and credits player: **PASS**
- Refined-element sale reduces cargo and credits player: **PASS**
- Legacy base-resource market rows preserved: **PASS**
- No ore mirroring into legacy `game.cargo` (no double cargo count): **PASS**
- v1.85.2 navigation state equivalence: **PASS**
- v1.81.4 RNG preservation: **PASS**
- Web JS syntax: **PASS**
- Script-reference/order audit: **PASS**
- Smoke tests: **29 / 29 PASS**
- Web/Android version: `1.85.3` / `versionCode 18503`

The Android source is synchronized. `./gradlew --offline assembleNubiaDebug` was attempted, but the wrapper still tried to download Gradle 8.9 from `services.gradle.org` and failed with `UnknownHostException`; no APK is claimed for this environment.

---

# v1.85.2 BUILD STATUS — Architecture Performance Update

## Status

**SOURCE RELEASE READY**

Feature Freezeを維持したパフォーマンス更新。新ゲーム機能は追加していない。

## Implemented

- Route-first user navigation: UIシェルを先に表示し、既存重描画を2 RAF後へ遅延。
- ゲーム内部の同期`showTab()` / `showGalaxy()`は変更せず、シミュレーション処理順を維持。
- 艦船2Dアイコン／レジストリ (`127-v1_82-ship-icons-registry.js`, 24,957 bytes) を起動時script列から除外し、艦船画面初回だけDynamic Import。
- ナビゲーション中の重複saveを750ms遅延・統合。pagehide / background移行時はflush。
- Android/native SaveStore経路を維持。
- `content-visibility:auto`による画面外DOM layout/paint省略。
- v1.85.1の非表示画面ガード、艦船ページング、軽量SVG、RNG保存キャッシュを継承。
- Web/Android version synchronized to `1.85.2` / Android `versionCode 18502`.

## Safety decisions

- v1.67〜v1.75 ensure-chainの追加短絡は連続操作でRNG差を検出したため**不採用・撤回**。
- Web Workerはグローバルstate/RNG順序分離が未完了のため**未導入**。
- 全JSの単一bundle化はAndroid local assetsでは優先度が低く、起動時parse増大を避けるため**未採用**。

## RNG / state equivalence

UI sequence:
`home -> galaxy -> gm -> stations -> map -> mine -> market -> ship -> home`

- direct final `marketSeed`: `2196336249`
- routed final `marketSeed`: `2196336249`
- normalized game JSON equality: PASS
- normalized JSON bytes: `1468136`

v1.81.4 regression:
- initial: `4213774138`
- direct: `3119341908`
- cached: `3119341908`
- PASS

## Controlled performance evidence

Not Nubia Fold wall-clock measurements.

- Market synchronous render average: ~`521 ms`
- v1.85.2 route call / visible shell return: ~`0.16 ms`
- Full routed market work when RAF is forced immediate: ~`510 ms` vs direct ~`573 ms`
- Ship route controlled VM: v1.85.1 ~`626 ms` -> v1.85.2 ~`532 ms`

The primary improvement is responsiveness: the visible scene changes before the expensive legacy render chain executes.

## Verification

- 28 unique smoke scripts: **PASS**
- startup init: **PASS (`1.85.2`)**
- v1.59–v1.85 gameplay regression scripts: **PASS**
- v1.81.4 RNG preservation: **PASS**
- v1.85.1 performance hotfix regression: **PASS**
- v1.85.2 architecture smoke: **PASS**
- v1.85.2 navigation state equivalence: **PASS**
- all Web JavaScript syntax: **PASS**
- index script references missing: **0**
- duplicate static HTML ids: **0**
- ship registry eagerly loaded: **NO**
- Dynamic Import target present: **YES**
- DOM integration: **NOT RUN** (`jsdom` package body unavailable; npm offline cache incomplete)

## Android build

Android metadata:
- `versionCode 18502`
- `versionName 1.85.2`

`./gradlew :app:assembleUniversalDebug --no-daemon` was attempted. Gradle Wrapper attempted to download Gradle 8.9 and failed with `java.net.UnknownHostException: services.gradle.org` because outbound network access is unavailable. APK was not produced in this environment.

## Key files

- `www/js/133-v1_85_2-architecture-performance.js`
- `www/js/127-v1_82-ship-icons-registry.js` (lazy module)
- `docs/V1852_ARCHITECTURE_PERFORMANCE.md`
- `tests/v1852-architecture-performance-smoke.cjs`
- `tests/v1852-navigation-equivalence-smoke.cjs`
- `test-results-v1852-final/`
