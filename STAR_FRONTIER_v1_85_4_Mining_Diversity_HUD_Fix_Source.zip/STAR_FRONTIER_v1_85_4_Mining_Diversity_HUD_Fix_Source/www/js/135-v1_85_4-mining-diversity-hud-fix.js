'use strict';
// ============================================================================
// v1.85.4 — Mining Diversity + Critical HUD Responsiveness Fix
//
// Fixes an old v1.76 selection bug where the first survey result was written
// into selectedOre automatically. That made the intended weighted auto-mining
// path practically unreachable, so a system whose top result was hematite
// could mine hematite forever unless the player manually selected another ore.
//
// This layer separates AUTO and TARGET mining modes. AUTO chooses among the
// currently surveyed deposits without consuming an additional global RNG draw;
// the existing v1.76/v1.77 mining RNG order (yield, accidents, etc.) remains
// authoritative. TARGET mode preserves explicit ore selection.
//
// It also avoids a synchronous full-game render after player mining actions.
// Fuel / cargo / credits are refreshed immediately, then only the visible
// mining panel is refreshed on the next frame. Existing save() remains the
// persistence authority.
// ============================================================================
(function(){
 const BUILD='1.85.4';
 let autoMiningDepth=0, uiRefreshQueued=false;
 const raf=fn=>typeof requestAnimationFrame==='function'?requestAnimationFrame(fn):setTimeout(fn,16);
 const round1=n=>Math.round((Number(n)||0)*10)/10;

 function state(){
  const x=v1854StateBase();
  if(x.selectionMode!=='auto'&&x.selectionMode!=='target'){
   // Migration: old builds auto-selected survey row #1. A non-top selection is
   // strong evidence of an intentional player target, so preserve that case.
   let manual=false;
   try{
    const rows=x.survey?.[game.system]?.rows||[];
    manual=!!(x.selectedOre&&rows.length&&rows[0]?.k!==x.selectedOre&&rows.some(r=>r.k===x.selectedOre));
   }catch(_){}
   x.selectionMode=manual?'target':'auto';
   if(!manual)x.selectedOre=null;
  }
  x.autoMineCount=Math.max(0,Number(x.autoMineCount)||0);
  x.autoOreStreak=Math.max(0,Number(x.autoOreStreak)||0);
  if(x.selectionMode==='auto'&&autoMiningDepth===0)x.selectedOre=null;
  return x;
 }
 const v1854StateBase=typeof v176State==='function'?v176State:function(){return game.miningV176||(game.miningV176={})};
 v176State=state;

 const v1854SurveyBase=typeof v176Survey==='function'?v176Survey:null;
 if(v1854SurveyBase)v176Survey=function(sid=game.system,force=false){
  const out=v1854SurveyBase.call(this,sid,force),x=v176State();
  if(x.selectionMode==='auto'&&autoMiningDepth===0)x.selectedOre=null;
  return out;
 };

 function pickAutoOre(survey,x){
  const rows=(survey?.rows||[]).filter(r=>V176_ORES?.[r.k]&&Number(r.reserve??v176EnsureDeposits(game.system,x)?.[r.k]??0)>0);
  if(!rows.length)return null;
  const dep=v176EnsureDeposits(game.system,x);
  const weighted=rows.map(r=>({
   k:r.k,
   w:Math.max(.01,(Number(r.score)||1)*(.30+(Number(dep?.[r.k])||0)/100))
  }));
  const total=weighted.reduce((n,r)=>n+r.w,0)||1;
  const serial=x.autoMineCount||0;
  const unit=typeof v176Hash==='function'?v176Hash(`${game.system}:${game.day}:auto:${serial}:${Math.round(game.fuel||0)}:${Math.round((typeof cargoUsed==='function'?cargoUsed():0)*10)}`):((serial*.61803398875)%1);
  let target=unit*total,chosen=weighted[weighted.length-1].k;
  for(const r of weighted){target-=r.w;if(target<=0){chosen=r.k;break}}
  // AUTO should feel like broad prospecting rather than an accidental lock.
  // Never allow more than two consecutive pulls of the same ore when another
  // surveyed deposit is available. This is deterministic and RNG-free.
  if(chosen===x.lastAutoOre&&(x.autoOreStreak||0)>=2&&weighted.length>1){
   const idx=weighted.findIndex(r=>r.k===chosen);
   chosen=weighted[(idx+1+(serial%Math.max(1,weighted.length-1)))%weighted.length].k;
  }
  if(chosen===x.lastAutoOre)x.autoOreStreak=(x.autoOreStreak||0)+1;
  else{x.lastAutoOre=chosen;x.autoOreStreak=1}
  x.autoMineCount=serial+1;
  return chosen;
 }

 // Wrap the current v1.77-enhanced mining core rather than replacing it, so
 // claims, discoveries, pollution, accidents and provenance remain intact.
 const v1854MineCoreBase=typeof v176MineCore==='function'?v176MineCore:null;
 if(v1854MineCoreBase)v176MineCore=function(silent=false,acc=null){
  const x=v176State();
  if(x.selectionMode!=='auto')return v1854MineCoreBase.call(this,silent,acc);
  const survey=v176Survey(game.system,false),chosen=pickAutoOre(survey,x);
  if(!chosen)return v1854MineCoreBase.call(this,silent,acc);
  autoMiningDepth++;
  const prev=x.selectedOre;
  x.selectedOre=chosen;
  try{return v1854MineCoreBase.call(this,silent,acc)}
  finally{
   autoMiningDepth=Math.max(0,autoMiningDepth-1);
   x.selectedOre=autoMiningDepth?prev:null;
  }
 };

 v176SelectOre=function(k){
  const x=v176State();
  if(k==null||k===''||k==='auto'){
   x.selectionMode='auto';x.selectedOre=null;x.autoOreStreak=0;
   toast?.('自動採掘：鉱床分布に応じて採掘');
  }else{
   if(!V176_ORES?.[k])return;
   x.selectionMode='target';x.selectedOre=k;
   toast?.(`${V176_ORES[k].name}を指定採掘`);
  }
  try{renderMine?.()}catch(_){try{render?.()}catch(__){}}
 };

 // Add a visible AUTO control and make the mode explicit without replacing the
 // rest of the v1.77 mining panel.
 if(typeof v176RenderMining==='function'){
  const base=v176RenderMining;
  v176RenderMining=function(){
   let html=base.apply(this,arguments),x=v176State();
   const auto=`<button class="${x.selectionMode==='auto'?'purple':'secondary'}" onclick="v176SelectOre('auto')"><b>🎲 自動採掘</b><br><small>スキャン済み鉱床から分布加重で選択</small></button>`;
   html=html.replace('<div class="grid">','<div class="grid">'+auto);
   const label=x.selectionMode==='auto'?'自動（鉱床分布）':(x.selectedOre&&V176_ORES[x.selectedOre]?V176_ORES[x.selectedOre].name:'指定なし');
   html=html.replace(/選択中：[^<]* \/ 船内選鉱/,`選択中：${label} / 船内選鉱`);
   return html;
  };
 }

 function refreshCriticalHud(){
  try{const e=document.getElementById?.('credits');if(e)e.textContent=(Number(game.credits)||0).toLocaleString()+' Cr'}catch(_){}
  try{const e=document.getElementById?.('fuel');if(e)e.textContent=`${round1(game.fuel)} / ${round1(game.maxFuel)}`}catch(_){}
  try{const used=typeof cargoUsed==='function'?round1(cargoUsed()):0,e=document.getElementById?.('cargo');if(e)e.textContent=`${used} / ${game.cargoMax}`}catch(_){}
  try{const e=document.getElementById?.('mineFreeCargo');if(e)e.textContent=round1(typeof cargoFree==='function'?cargoFree():0)}catch(_){}
 }
 function mineVisible(){const e=document.getElementById?.('mine');return !!e&&!e.classList?.contains?.('hidden')}
 function scheduleMiningUi(){
  if(uiRefreshQueued)return;uiRefreshQueued=true;
  raf(()=>{uiRefreshQueued=false;try{refreshCriticalHud()}catch(_){}try{if(mineVisible())renderMine?.()}catch(_){}try{save?.()}catch(_){}});
 }
 function withLightMiningRender(fn,args){
  const original=typeof render==='function'?render:null;
  if(!original)return fn.apply(this,args);
  let intercepted=false;
  const light=function(){intercepted=true;refreshCriticalHud();return true};
  render=light;
  let out;
  try{out=fn.apply(this,args)}finally{render=original}
  refreshCriticalHud();
  if(intercepted)scheduleMiningUi();
  return out;
 }
 // Public player mining actions are the latency-sensitive path. Internal/silent
 // mining keeps its established behavior.
 if(typeof mineOnce==='function'){
  const base=mineOnce;
  mineOnce=function(...args){if(args[0]===true)return base.apply(this,args);return withLightMiningRender.call(this,base,args)};
 }
 if(typeof mineBatch==='function'){
  const base=mineBatch;
  mineBatch=function(...args){return withLightMiningRender.call(this,base,args)};
 }
 if(typeof v176RefineOre==='function'){
  const base=v176RefineOre;
  v176RefineOre=function(...args){return withLightMiningRender.call(this,base,args)};
 }
 function marketVisible(){const e=document.getElementById?.('market');return !!e&&!e.classList?.contains?.('hidden')}
 function withLightMarketRender(fn,args){
  const original=typeof render==='function'?render:null;if(!original)return fn.apply(this,args);let intercepted=false;
  render=function(){intercepted=true;refreshCriticalHud();return true};
  let out;try{out=fn.apply(this,args)}finally{render=original}
  refreshCriticalHud();
  if(intercepted)raf(()=>{try{if(marketVisible())renderMarket?.()}catch(_){}try{save?.()}catch(_){}});
  return out;
 }
 if(typeof v176SellOre==='function'){const base=v176SellOre;v176SellOre=function(...args){return withLightMarketRender.call(this,base,args)}}
 if(typeof v176SellElement==='function'){const base=v176SellElement;v176SellElement=function(...args){return withLightMarketRender.call(this,base,args)}}

 // Refuel feedback uses the same critical HUD fast path; the authoritative
 // market calculation remains untouched.
 if(typeof buyFuel==='function'){
  const base=buyFuel;
  buyFuel=function(...args){
   const original=typeof render==='function'?render:null;let intercepted=false;
   if(original)render=function(){intercepted=true;refreshCriticalHud();return true};
   let out;try{out=base.apply(this,args)}finally{if(original)render=original}
   refreshCriticalHud();
   if(intercepted)raf(()=>{try{renderMarket?.()}catch(_){}try{save?.()}catch(_){}});
   return out;
  };
 }

 // Keep final version metadata authoritative even when old render wrappers run.
 if(typeof render==='function'){
  const base=render;
  render=function(){const out=base.apply(this,arguments);try{game.version=BUILD;const b=document.querySelector?.('header .title .badge')||document.querySelector?.('.version-badge');if(b)b.textContent='v'+BUILD;const s=document.querySelector?.('header .sub');if(s)s.textContent='Mining Diversity / Instant Fuel & Cargo HUD / Architecture Performance';document.title='STAR FRONTIER v1.85.4 — Mining Diversity & HUD Fix'}catch(_){}return out};
 }
 if(typeof initV10==='function'){const base=initV10;initV10=function(){const out=base.apply(this,arguments);if(game)game.version=BUILD;return out}};
 if(typeof load==='function'){const base=load;load=function(){const out=base.apply(this,arguments);if(game)game.version=BUILD;return out}};

 if(typeof window!=='undefined')window.StarFrontierMiningHudFix={build:BUILD,refreshHud:refreshCriticalHud,pickAutoOre:(survey)=>pickAutoOre(survey,v176State()),state:()=>({selectionMode:v176State().selectionMode,autoMineCount:v176State().autoMineCount,lastAutoOre:v176State().lastAutoOre,autoOreStreak:v176State().autoOreStreak})};
})();
