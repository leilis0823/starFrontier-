'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'../www');
function noop(){}
function makeClassList(){return {add:noop,remove:noop,toggle(){return false},contains(){return false}}}
function makeEl(id=''){
 const el={id,textContent:'',innerHTML:'',value:'',checked:false,disabled:false,hidden:false,dataset:{},style:{},className:'',classList:makeClassList(),children:[],parentElement:null,firstChild:null,lastChild:null,clientWidth:1200,clientHeight:800,offsetWidth:1200,offsetHeight:800,
  append(...xs){for(const x of xs){if(x&&typeof x==='object'){x.parentElement=this;this.children.push(x)}}},appendChild(x){this.append(x);return x},insertBefore(x){this.append(x);return x},after:noop,before:noop,remove:noop,replaceChildren(...xs){this.children=[];this.append(...xs)},
  setAttribute(k,v){this[k]=String(v)},getAttribute(k){return this[k]??null},removeAttribute(k){delete this[k]},
  querySelector(sel){return makeEl(sel)},querySelectorAll(sel){return []},closest(){return null},matches(){return false},
  addEventListener:noop,removeEventListener:noop,insertAdjacentHTML:noop,scrollIntoView:noop,focus:noop,click:noop,
 };
 return el;
}
const els=new Map();
const document={title:'',documentElement:makeEl('html'),body:makeEl('body'),head:makeEl('head'),readyState:'complete',
 getElementById(id){if(!els.has(id))els.set(id,makeEl(id));return els.get(id)},
 querySelector(sel){return makeEl(sel)},querySelectorAll(sel){return []},
 createElement(tag){return makeEl(tag)},createTextNode(t){return {textContent:String(t)}},
 addEventListener:noop,removeEventListener:noop,
};
const storage=new Map();
const ls={getItem:k=>storage.has(k)?storage.get(k):null,setItem:(k,v)=>storage.set(k,String(v)),removeItem:k=>storage.delete(k),clear:()=>storage.clear()};
const ctx={console,Math,Date,JSON,Object,Array,Number,String,Boolean,BigInt,Set,Map,WeakMap,WeakSet,RegExp,Promise,Error,TypeError,RangeError,Intl,parseInt,parseFloat,isNaN,isFinite,encodeURIComponent,decodeURIComponent,
 document,localStorage:ls,navigator:{userAgent:'probe'},location:{href:'https://appassets.androidplatform.net/www/index.html'},performance:{now:()=>0},
 requestAnimationFrame:fn=>0,cancelAnimationFrame:noop,setTimeout:(fn)=>0,clearTimeout:noop,setInterval:(fn)=>0,clearInterval:noop,
 AudioContext:function(){},webkitAudioContext:function(){},Blob:function(){},URL:{createObjectURL:()=>'',revokeObjectURL:noop},FileReader:function(){},
 alert:noop,confirm:()=>true,prompt:()=>null,HTMLElement:function(){},Node:function(){},CSS:{escape:s=>String(s)},
};
ctx.window=ctx;ctx.self=ctx;ctx.globalThis=ctx;ctx.window.localStorage=ls;ctx.window.addEventListener=noop;ctx.window.removeEventListener=noop;ctx.window.innerWidth=1200;ctx.window.innerHeight=800;ctx.window.matchMedia=()=>({matches:false,addEventListener:noop,removeEventListener:noop});
vm.createContext(ctx);
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const scripts=[...html.matchAll(/<script defer src="([^"]+)"/g)].map(m=>m[1]);
for(const rel of scripts){
 if(rel==='js/99-bootstrap.js')continue;
 const f=path.join(root,rel);
 try{vm.runInContext(fs.readFileSync(f,'utf8'),ctx,{filename:rel});}
 catch(e){console.log('TOPLEVEL_FAIL',rel,e&&e.stack||e);process.exitCode=2;break;}
}
if(process.exitCode)process.exit();
try{
 vm.runInContext('game=newGame(); initV10();',ctx,{filename:'V1814_RNG_INIT'});
 const initial=vm.runInContext('JSON.stringify(game)',ctx);
 const initialSeed=vm.runInContext('game.marketSeed',ctx);
 const directStart=Date.now();
 vm.runInContext('for(let i=0;i<25;i++)ensureV127State();',ctx,{filename:'V1814_DIRECT'});
 const directMs=Date.now()-directStart;
 const direct=vm.runInContext('JSON.stringify(game)',ctx);
 const directSeed=vm.runInContext('game.marketSeed',ctx);

 vm.runInContext('game=JSON.parse(__v1814InitialSnapshot)',Object.assign(ctx,{__v1814InitialSnapshot:initial}),{filename:'V1814_RESTORE'});
 const beforeHits=vm.runInContext('(window.StarFrontierPerformance.stats().ensure.ensureV127State||{}).hits||0',ctx);
 const cachedStart=Date.now();
 vm.runInContext('v1814WithPerfEpoch(()=>{for(let i=0;i<25;i++)ensureV127State()});',ctx,{filename:'V1814_CACHED'});
 const cachedMs=Date.now()-cachedStart;
 const cached=vm.runInContext('JSON.stringify(game)',ctx);
 const cachedSeed=vm.runInContext('game.marketSeed',ctx);
 const afterHits=vm.runInContext('(window.StarFrontierPerformance.stats().ensure.ensureV127State||{}).hits||0',ctx);
 const hitDelta=afterHits-beforeHits;

 if(directSeed!==cachedSeed)throw new Error(`RNG seed diverged: direct=${directSeed}, cached=${cachedSeed}`);
 if(direct!==cached)throw new Error('game state diverged between direct and cached ensureV127State sequence');
 if(hitDelta<24)throw new Error(`cache did not engage as expected; V127 hit delta=${hitDelta}`);
 console.log('V1814_RNG_SEED_PRESERVATION_SMOKE_PASS',JSON.stringify({initialSeed,directSeed,cachedSeed,hitDelta,directMs,cachedMs}));
}catch(e){console.error('V1814_RNG_SEED_PRESERVATION_SMOKE_FAIL',e&&e.stack||e);process.exitCode=3;}
