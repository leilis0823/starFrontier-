# v1.85.0 BUILD STATUS — Strategic Stations & Planetary Operations

## Added
- Expanded orbital-station module catalog from 5 to 13 without replacing legacy station state.
- Automatic role classification for trade hubs, grand yards, naval bases, fortresses, mining/refinery, research, sensor, medical, fuel, habitat and black-market stations.
- 12 strategic station-ship classes with strategic build queues, physical yard-material consumption, local deployment effects, repair and relocation.
- Strategic-asset scarcity: player cap 4, one per class.
- 6 dual-environment surface/space hulls integrated into the existing HULLS/ownership/lifecycle stack.
- Deterministically seeded planetary mines, fuel refineries, research outposts, logistics depots, settlements and defense garrisons.
- Player planetary-facility construction and repair.
- Existing pirate-band AI connected to planetary facility target selection and landing raids.
- Three-layer combat resolution: orbit -> atmosphere -> surface.
- Player raid interception and reserve assignment for owned surface-capable ships.
- Strategic/economic linkage to existing station income, logistics, research, intelligence, bioship and machine-contact state.
- Web/Android metadata synchronized to 1.85.0 / Android versionCode 18500.

## Verification
- startup init smoke: PASS (`1.85.0`)
- v1.59–v1.84 regression/dedicated smoke scripts: PASS
- v1.81.4 RNG cache preservation smoke: PASS
- v1.85 Strategic Stations & Planetary Operations smoke: PASS
  - station modules: 13
  - strategic station-ship types: 12
  - dual-environment hulls: 6
  - baseline deterministic planetary sites: 38
  - strategic CITADEL build queue/completion: PASS
  - surface defense assignment: PASS
  - existing pirate-band planetary raid: PASS
  - orbit/atmosphere/surface defense calculation: PASS
  - player interception + raid resolution: PASS
  - feature-only `marketSeed` remained `4213774138`
- 25 startup/regression/feature smoke scripts: PASS
- all Web JavaScript syntax: PASS
- index script references missing: 0
- duplicate static HTML ids: 0
- v1.85 script reference count: 1
- DOM integration: NOT RUN (`jsdom` package body is not installed in this execution environment)
- Android Gradle build: NOT COMPLETED. `./gradlew :app:assembleUniversalDebug --no-daemon` attempted to download Gradle 8.9 from `services.gradle.org` and failed with `UnknownHostException` because outbound network access is unavailable. Source asset sync and version metadata are updated.

## Key files
- `www/js/131-v1_85-strategic-stations-planetary-operations.js`
- `docs/V185_STRATEGIC_STATIONS_PLANETARY_OPERATIONS.md`
- `tests/v185-strategic-stations-planetary-operations-smoke.cjs`
