'use strict';
// ============================================================================
// STAR FRONTIER v1.82.0 — Fleet Identity & Discovery
// 1) Manufacturer reputation / discounts / evaluation contracts / exclusives
// 2) Player-developed derivative hull projects
// 3) Crew traits, hull compatibility and class familiarity
// 4) Discovery-based ship encyclopedia with unknown silhouettes
//
// IMPORTANT: this layer does not call rng(). All progression introduced here is
// deterministic so the v1.81.4 performance fix RNG-seed guarantees remain intact.
// ============================================================================
(function(){
 const V182_BUILD='1.82.0';
 const V182_FEATURE='Fleet Identity & Discovery';
 const V182_STATE_VERSION=1;
 const V182_REP_MAX=100;
 const V182_VARIANT_TYPES={
  mining:{name:'採掘特化型',code:'M',days:4,cost:.30,desc:'採掘装備・鉱石処理区画を増設。採掘能力と船倉を優先する。'},
  trade:{name:'交易特化型',code:'T',days:5,cost:.32,desc:'貨物区画と荷役系を拡張。交易・定期輸送を重視する。'},
  escort:{name:'護衛特化型',code:'E',days:6,cost:.38,desc:'装甲・火器・損傷制御を増強し、護衛戦闘へ寄せる。'},
  range:{name:'長距離航行型',code:'R',days:5,cost:.34,desc:'燃料搭載量・推進器効率を高め、遠征・調査航海へ寄せる。'},
  support:{name:'支援指揮型',code:'S',days:6,cost:.36,desc:'修理・救難・指揮通信区画を増設し、艦隊支援へ寄せる。'}
 };
 const V182_CREW_TRAITS={
  captain:{name:'統合作戦',classes:['cruiser','carrier','battleship','dread','dreadnought'],desc:'大型艦・指揮艦で全体判断を最適化'},
  gunnery:{name:'射撃管制',classes:['corvette','frigate','cruiser','battleship','dread','dreadnought'],desc:'戦闘艦で火器管制の反応速度が上がる'},
  navigator:{name:'航路感覚',classes:['prospect','freighter','corvette','frigate'],desc:'小中型艦・商船で航法効率を引き出す'},
  engineer:{name:'機関習熟',classes:['freighter','carrier','battleship','dread','dreadnought'],desc:'大型機関・重船体で損傷抑制能力が上がる'},
  marine:{name:'強襲配置',classes:['corvette','frigate','cruiser'],desc:'接舷しやすい戦闘艦で拿捕能力を引き出す'},
  intel:{name:'艦影識別',classes:['prospect','corvette','frigate','cruiser'],desc:'探査・偵察向け艦で未確認艦の識別能力が上がる'}
 };
 const V182_EXCLUSIVE_HULLS={
  regulus_pioneer:{name:'PIONEER-RX〈パイオニア〉',class:'prospect',cost:58600,baseCargo:112,baseFuel:228,mining:4,engine:.12,maker:'regulus',marketHull:true,makerExclusiveRep:45,combatBonus:2,desc:'レグルス造船の高信頼顧客向け遠征探査艇。量産規格を維持しながら深部探査・長期航海能力を強化した限定仕様。'},
  horizon_comet:{name:'COMET-LX〈コメット〉',class:'freighter',cost:72800,baseCargo:208,baseFuel:306,mining:-1,engine:.24,maker:'horizon',marketHull:true,makerExclusiveRep:45,desc:'ホライズンの長期契約船主向け高速商船。高価値貨物と長距離定期便を想定し、速度と燃費を両立する。'},
  nox_deepcore:{name:'DEEPCORE-NX〈ディープコア〉',class:'prospect',cost:69800,baseCargo:124,baseFuel:206,mining:5,engine:.05,maker:'nox',marketHull:true,makerExclusiveRep:50,combatBonus:3,desc:'ノクス資源の優良鉱区請負人向け重採掘艇。高出力掘削器と鉱石保持区画を拡張した限定採鉱仕様。'},
  asterion_paladin:{name:'PALADIN-AH〈パラディン〉',class:'frigate',cost:104000,baseCargo:84,baseFuel:236,mining:-2,engine:.15,maker:'asterion',marketHull:true,makerExclusiveRep:55,combatBonus:12,armorBonus:.06,desc:'アステリオンの高信用顧客向け企業護衛フリゲート。警備会社・鉱区防衛・重要船団の旗艦用途を想定する。'}
 };
 Object.assign(HULLS,V182_EXCLUSIVE_HULLS);

 function v182Clamp(n,a=0,b=100){return Math.max(a,Math.min(b,Number(n)||0))}
 function v182Hash(text){let h=2166136261>>>0;for(const ch of String(text||'')){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0}return h>>>0}
 function v182MakerName(maker){return V17_CORPORATIONS?.[maker]?.short||({regulus:'レグルス造船',horizon:'ホライズン',nox:'ノクス資源',asterion:'アステリオン',pilgrim:'ピルグリム',meridian:'メリディアン',helix:'ヘリックス',arclight:'アークライト',bulwark:'ブルワーク',synapse:'シナプス',crownforge:'クラウンフォージ'}[maker]||maker||'独立造船所')}
 function v182MakerHome(maker){return V17_CORPORATIONS?.[maker]?.home||null}
 function v182HullMaker(id){const h=HULLS?.[id];return h?.maker||null}
 function v182State(){
  game.shipIdentity=game.shipIdentity&&typeof game.shipIdentity==='object'?game.shipIdentity:{};
  const s=game.shipIdentity;
  s.version=V182_STATE_VERSION;
  s.manufacturerRep=s.manufacturerRep&&typeof s.manufacturerRep==='object'?s.manufacturerRep:{};
  s.manufacturerStats=s.manufacturerStats&&typeof s.manufacturerStats==='object'?s.manufacturerStats:{};
  s.contracts=Array.isArray(s.contracts)?s.contracts:[];
  s.variants=Array.isArray(s.variants)?s.variants:[];
  s.variantSeq=Math.max(1,Number(s.variantSeq)||1);
  s.discoveries=s.discoveries&&typeof s.discoveries==='object'?s.discoveries:{};
  s.discoveryLog=Array.isArray(s.discoveryLog)?s.discoveryLog:[];
  s.lastScanDay=Number.isFinite(Number(s.lastScanDay))?Number(s.lastScanDay):-9999;
  s.seeded=!!s.seeded;
  if(!s.seeded){
   const makers=new Set();
   for(const id of game.ownedHulls||[]){const m=v182HullMaker(id);if(m)makers.add(m)}
   for(const m of makers)s.manufacturerRep[m]=Math.max(Number(s.manufacturerRep[m])||0,6);
   s.seeded=true;
  }
  for(const [m,n] of Object.entries(s.manufacturerRep))s.manufacturerRep[m]=v182Clamp(n,0,V182_REP_MAX);
  for(const c of s.contracts){c.progress=Math.max(0,Number(c.progress)||0);c.target=Math.max(1,Number(c.target)||3);c.status=c.status||'active'}
  for(const c of Object.values(game.crew||{})){c.classFamiliarity=c.classFamiliarity&&typeof c.classFamiliarity==='object'?c.classFamiliarity:{}}
  const variantIds=new Set(s.variants.map(r=>r?.id).filter(Boolean));
  for(const [id,h] of Object.entries(HULLS||{}))if(h?.playerVariantFeature&&!variantIds.has(id))delete HULLS[id];
  v182MaterializeVariants(s.variants);
  v182SyncDiscoveries(false);
  return s;
 }
 function v182Rep(maker){const s=game?.shipIdentity||v182State();return v182Clamp(s?.manufacturerRep?.[maker]||0,0,V182_REP_MAX)}
 function v182AddRep(maker,delta,reason=''){if(!maker||!delta)return;const s=v182State(),before=v182Rep(maker);s.manufacturerRep[maker]=v182Clamp(before+delta,0,V182_REP_MAX);if(reason&&Math.floor(before/10)!==Math.floor(s.manufacturerRep[maker]/10))addLog?.(`${v182MakerName(maker)}との取引信用が ${Math.round(s.manufacturerRep[maker])} に上昇。${reason}`)}
 function v182DiscountRate(maker){return maker?Math.min(.12,Math.floor(v182Rep(maker)/10)*.015):0}
 function v182Price(id){const h=HULLS?.[id];if(!h)return 0;const rate=v182DiscountRate(h.maker);return Math.max(0,Math.round((Number(h.cost)||0)*(1-rate)/100)*100)}
 function v182MakerAccess(maker){const home=v182MakerHome(maker);if(home&&game.system===home)return true;try{if(typeof regionalYardFaction==='function'&&regionalYardFaction())return true}catch(_){}return !!localStations?.().some?.(s=>s.modules?.includes?.('shipyard'))}

 // ---- Discovery / encyclopedia ------------------------------------------------
 function v182Discover(id,source='識別',announce=false){
  if(!id||!HULLS?.[id])return false;const s=game.shipIdentity||v182State();
  if(s.discoveries[id])return false;s.discoveries[id]={day:game.day,source};s.discoveryLog.unshift({day:game.day,id,source});s.discoveryLog=s.discoveryLog.slice(0,80);
  if(announce)addLog?.(`艦船図鑑更新：${HULLS[id].name} を識別（${source}）。`);
  return true;
 }
 function v182IsDiscovered(id){if(!id)return false;if((game?.ownedHulls||[]).includes(id))return true;if((game?.prizeShips||[]).some(p=>p.uid===id||p.baseHull===id))return true;return !!(game?.shipIdentity?.discoveries?.[id])}
 function v182CurrentMarketIds(){
  const set=new Set();
  try{if(typeof V13_COMMON_YARD_HULLS!=='undefined'&&typeof regionalYardFaction==='function'&&regionalYardFaction())for(const id of V13_COMMON_YARD_HULLS)if(HULLS[id])set.add(id)}catch(_){}
  try{const fid=typeof regionalYardFaction==='function'?regionalYardFaction():null;if(fid&&typeof regionalHullIds==='function')for(const id of regionalHullIds(fid))if(HULLS[id])set.add(id)}catch(_){}
  try{if(game.career?.faction&&typeof serviceHullIds==='function')for(const id of serviceHullIds(game.career.faction))if(HULLS[id])set.add(id)}catch(_){}
  for(const [id,h] of Object.entries(HULLS||{})){if(h?.marketHull&&!h.makerExclusiveRep&&(!Array.isArray(h.marketSystems)||!h.marketSystems.length||h.marketSystems.includes(game.system)))set.add(id)}
  for(const [id,h] of Object.entries(V182_EXCLUSIVE_HULLS))if(v182Rep(h.maker)>=(h.makerExclusiveRep||100)&&v182MakerAccess(h.maker))set.add(id)
  return [...set];
 }
 function v182SyncDiscoveries(announce=false){
  if(!game?.shipIdentity)return;const ids=new Set([game.hull,...(game.ownedHulls||[]),...v182CurrentMarketIds()]);
  for(const p of game.prizeShips||[])ids.add(p.baseHull);
  for(const i of game.intel||[])if(i?.baseHull)ids.add(i.baseHull);
  try{for(const t of game.gm?.v176?.traffic||[])if(t.system===game.system&&t.hullId)ids.add(t.hullId)}catch(_){}
  try{for(const t of game.gm?.v178?.traffic||[])if(t.currentSystem===game.system&&t.prizeHull)ids.add(t.prizeHull)}catch(_){}
  try{for(const h of game.gm?.v131?.hunts||[])if(h.system===game.system&&h.baseHull)ids.add(h.baseHull)}catch(_){}
  for(const id of ids)if(HULLS[id])v182Discover(id,'遭遇・市場・保有情報',announce);
 }
 function v182ScanCandidates(){
  const set=new Set();const fid=SYSTEMS?.[game.system]?.faction;
  if(fid&&fid!=='unclaimed')for(const [id,h] of Object.entries(HULLS||{}))if(h?.regionalFaction===fid)set.add(id);
  for(const [id,h] of Object.entries(HULLS||{}))if(h?.marketSystems?.includes?.(game.system))set.add(id);
  try{for(const i of game.intel||[])if(i?.baseHull)set.add(i.baseHull)}catch(_){}
  try{for(const t of game.gm?.v176?.traffic||[])if(t.system===game.system&&t.hullId)set.add(t.hullId)}catch(_){}
  try{for(const t of game.gm?.v178?.traffic||[])if(t.currentSystem===game.system&&t.prizeHull)set.add(t.prizeHull)}catch(_){}
  return [...set].filter(id=>HULLS[id]&&!v182IsDiscovered(id));
 }
 function v182ScanRegistry(){
  const s=v182State();if(s.lastScanDay===game.day)return toast?.('本日の艦影解析は実施済み');
  const intel=typeof crewBonus==='function'?crewBonus('intel'):0,cost=Math.max(160,520-intel*12);if(game.credits<cost)return toast?.(`解析費 ${cost.toLocaleString()} Crが必要`);
  const candidates=v182ScanCandidates();if(!candidates.length)return toast?.('現在宙域に未識別の艦影情報はありません');
  game.credits-=cost;s.lastScanDay=game.day;
  candidates.sort((a,b)=>v182Hash(`${game.system}:${game.day}:${a}`)-v182Hash(`${game.system}:${game.day}:${b}`));
  const count=intel>=18?2:1,found=candidates.slice(0,count);for(const id of found)v182Discover(id,'情報士官による艦影解析',true);
  save?.();render?.();toast?.(`${found.length}件の艦級を識別`);
 }
 function v182UnknownSvgUri(seed){
  const n=v182Hash(seed)%4,paths=[
   'M24 70 L82 48 L154 53 L254 60 L296 70 L254 80 L154 87 L82 92 Z',
   'M20 70 L64 43 L146 43 L220 52 L292 70 L220 88 L146 97 L64 97 Z',
   'M28 70 L72 51 L112 51 L152 43 L214 43 L270 55 L304 70 L270 85 L214 97 L152 97 L112 89 L72 89 Z',
   'M18 70 L68 38 L140 38 L206 48 L276 55 L310 70 L276 85 L206 92 L140 102 L68 102 Z'
  ];
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 140"><rect width="320" height="140" rx="16" fill="#07131f"/><g fill="#101d29" stroke="#3a5163" stroke-width="3"><path d="${paths[n]}"/></g><g fill="#71879a" font-family="Arial,sans-serif"><text x="18" y="25" font-size="11">UNIDENTIFIED CONTACT</text><text x="18" y="126" font-size="12">SIGNATURE ${String(v182Hash(seed)%10000).padStart(4,'0')}</text></g></svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
 }

 // ---- Manufacturer reputation ------------------------------------------------
 function v182KnownMakers(){
  const set=new Set();for(const h of Object.values(HULLS||{}))if(h?.maker)set.add(h.maker);for(const m of Object.keys(v182State().manufacturerRep))set.add(m);
  return [...set].filter(Boolean).sort((a,b)=>v182Rep(b)-v182Rep(a)||v182MakerName(a).localeCompare(v182MakerName(b),'ja'));
 }
 function v182Contract(maker){return v182State().contracts.find(c=>c.maker===maker&&c.status==='active')||null}
 function v182AcceptMakerContract(maker){
  const s=v182State(),rep=v182Rep(maker);if(rep<8)return toast?.('メーカー信用 8 以上が必要');if(s.contracts.some(c=>c.status==='active'))return toast?.('同時に受けられるメーカー評価契約は1件です');
  const target=rep>=55?2:3,reward=Math.round((1900+rep*52)/100)*100,id=`maker-${maker}-${game.day}-${s.contracts.length+1}`;
  s.contracts.push({id,maker,status:'active',accepted:game.day,progress:0,target,reward});addLog?.(`${v182MakerName(maker)}と実地運用評価契約を締結。同社製艦で${target}日運用すると完了。`);save?.();render?.();
 }
 function v182ProcessMakerContracts(){
  const s=v182State();for(const c of s.contracts.filter(x=>x.status==='active')){
   const maker=v182HullMaker(game.hull);if(maker===c.maker)c.progress++;
   if(c.progress>=c.target){c.status='completed';c.completed=game.day;game.credits+=c.reward;v182AddRep(c.maker,8,'実地評価契約を完了');addLog?.(`${v182MakerName(c.maker)}の実地評価契約を完了。報酬 ${c.reward.toLocaleString()} Cr / 信用 +8。`)}
  }
  s.contracts=s.contracts.slice(-30);
 }
 function v182ExclusiveCard(id,h){
  const rep=v182Rep(h.maker),need=h.makerExclusiveRep||100,unlocked=rep>=need,access=v182MakerAccess(h.maker),own=game.ownedHulls.includes(id),active=game.hull===id,price=v182Price(id);
  let action=active?'<button disabled>搭乗中</button>':own?`<button class="good" onclick="switchHull('${id}')">乗り換え</button>`:!unlocked?`<button disabled>信用 ${need} で解放</button>`:!access?'<button disabled>主要造船所で引渡</button>':`<button onclick="buyHull('${id}')" ${game.credits<price?'disabled':''}>${price.toLocaleString()} Crで購入</button>`;
  return `<div class="shop-item ship-card"><div>${typeof sfShipImageHtml==='function'?sfShipImageHtml(id,h.name,'sf-ship-thumb'):''}<div class="shop-head"><strong>${escapeHtml(h.name)}</strong><span class="pill">限定艦</span></div><div class="statsline">${escapeHtml(v182MakerName(h.maker))} / 必要信用 ${need} / 現在 ${Math.round(rep)}</div><p>${escapeHtml(h.desc)}</p></div><div>${action}</div></div>`;
 }
 function v182ManufacturerHtml(){
  const makers=v182KnownMakers().filter(m=>Object.values(HULLS).some(h=>h?.maker===m));
  const rows=makers.slice(0,12).map(m=>{const rep=v182Rep(m),disc=Math.round(v182DiscountRate(m)*100),active=v182Contract(m),owned=game.ownedHulls.filter(id=>HULLS[id]?.maker===m).length;return `<div class="v182-maker-row"><div><b>${escapeHtml(v182MakerName(m))}</b><div class="smallnote">信用 ${Math.round(rep)}/100 / 値引 ${disc}% / 保有 ${owned}隻${v182MakerHome(m)?` / 本拠 ${escapeHtml(SYSTEMS[v182MakerHome(m)]?.name||v182MakerHome(m))}`:''}</div></div><div>${active?`<span class="pill">評価 ${active.progress}/${active.target}</span>`:`<button class="mini" onclick="StarFrontierFleetIdentity.acceptContract('${m}')" ${rep<8?'disabled':''}>評価契約</button>`}</div></div>`}).join('');
  const exclusives=Object.entries(V182_EXCLUSIVE_HULLS).map(([id,h])=>v182ExclusiveCard(id,h)).join('');
  return `<div class="section-title"><h3>🏭 艦船メーカー信用</h3><span class="pill">LOYALTY MARKET</span></div><p class="desc">同じ造船会社の艦を購入・実地評価すると信用が上がります。信用10ごとに購入価格が1.5%下がり、最大12%。一定信用で限定艦が解放されます。</p><div class="v182-maker-list">${rows}</div><div class="separator"></div><h3>限定カタログ</h3>${exclusives}`;
 }

 // ---- Derivative hull development -------------------------------------------
 function v182VariantSpec(record){
  const base=HULLS?.[record.baseId];if(!base)return null;const type=V182_VARIANT_TYPES[record.type];if(!type)return null;
  const h={...base,name:record.name||`${base.name} ${type.code}改`,cost:record.buildValue||Math.max(12000,Math.round((base.cost||24000)*.72/100)*100),variant:true,playerVariantFeature:true,variantType:record.type,baseHull:record.baseId,marketHull:false,special:false,service:false,corporate:false,makerExclusiveRep:undefined};
  if(record.type==='mining'){h.baseCargo=Math.round(base.baseCargo*1.10);h.baseFuel=Math.round(base.baseFuel*.98);h.mining=(base.mining||0)+2;h.engine=(base.engine||0)-.02;h.desc=`${base.name}を基礎に、採掘器・選鉱区画・鉱石保持能力を強化したプレイヤー開発派生型。`}
  if(record.type==='trade'){h.baseCargo=Math.round(base.baseCargo*1.24);h.baseFuel=Math.round(base.baseFuel*1.08);h.mining=(base.mining||0)-1;h.engine=(base.engine||0)+.02;h.desc=`${base.name}を基礎に、貨物区画・荷役設備・定期輸送効率を強化したプレイヤー開発派生型。`}
  if(record.type==='escort'){h.baseCargo=Math.max(20,Math.round(base.baseCargo*.90));h.baseFuel=Math.round(base.baseFuel*1.03);h.combatBonus=(base.combatBonus||0)+8;h.armorBonus=(base.armorBonus||0)+.04;h.engine=(base.engine||0)-.01;h.desc=`${base.name}を基礎に、装甲・損傷制御・火器管制を強化したプレイヤー開発護衛型。`}
  if(record.type==='range'){h.baseCargo=Math.round(base.baseCargo*.95);h.baseFuel=Math.round(base.baseFuel*1.26);h.engine=(base.engine||0)+.08;h.desc=`${base.name}を基礎に、燃料区画・推進器・航法冗長系を拡張したプレイヤー開発長距離型。`}
  if(record.type==='support'){h.baseCargo=Math.round(base.baseCargo*1.12);h.baseFuel=Math.round(base.baseFuel*1.12);h.armorBonus=(base.armorBonus||0)+.03;h.directFleetPowerBonus=Math.max(base.directFleetPowerBonus||0,.03);h.desc=`${base.name}を基礎に、修理・救難・補給・指揮通信を強化したプレイヤー開発支援型。`}
  return h;
 }
 function v182MaterializeVariants(records){for(const r of records||[]){if(r?.status!=='complete'||!r.id)continue;const h=v182VariantSpec(r);if(h)HULLS[r.id]=h}}
 const v182NormalizeBase=typeof normalize==='function'?normalize:null;
 if(v182NormalizeBase)normalize=function(g){try{v182MaterializeVariants(g?.shipIdentity?.variants||[])}catch(_){}return v182NormalizeBase(g)};
 function v182HasDevYard(){try{if(typeof regionalYardFaction==='function'&&regionalYardFaction())return true}catch(_){}try{return !!shipyardStations?.().length}catch(_){return false}}
 function v182VariantProjectCost(baseId,type){const h=HULLS[baseId],t=V182_VARIANT_TYPES[type];if(!h||!t)return 0;return Math.max(6500,Math.round(((h.cost||22000)*t.cost+5200)/100)*100)}
 function v182StartVariant(type){
  const s=v182State(),t=V182_VARIANT_TYPES[type],baseId=game.hull,base=HULLS[baseId];if(!t||!base)return;
  if(!game.ownedHulls.includes(baseId))return toast?.('保有艦のみ派生開発できます');if(!v182HasDevYard())return toast?.('主要造船所または自勢力造船所が必要');
  if(s.variants.some(r=>r.status==='developing'))return toast?.('別の派生艦開発が進行中です');if(s.variants.some(r=>r.baseId===baseId&&r.type===type))return toast?.('同系統の派生型は開発済みです');
  const cost=v182VariantProjectCost(baseId,type);if(game.credits<cost)return toast?.(`開発費 ${cost.toLocaleString()} Crが必要`);
  let name=prompt?.('派生艦級名',`${game.customNames?.[baseId]||base.name}-${t.code}`);if(name===null)return;name=(String(name||'').trim().slice(0,30)||`${base.name}-${t.code}`);
  game.credits-=cost;const seq=s.variantSeq++,id=`player_variant_${seq}_${String(baseId).replace(/[^a-zA-Z0-9_-]/g,'_')}_${type}`;const classExtra=['cruiser','carrier','battleship','dread','dreadnought'].includes(base.class)?2:0;
  s.variants.push({id,baseId,type,name,status:'developing',started:game.day,readyDay:game.day+t.days+classExtra,developmentCost:cost,buildValue:Math.max(12000,Math.round(((base.cost||24000)*.72+cost*.35)/100)*100)});
  addLog?.(`派生艦開発「${name}」を開始。${t.name} / 完成予定 Day ${game.day+t.days+classExtra}。`);save?.();render?.();
 }
 function v182ProcessVariants(){
  const s=v182State();for(const r of s.variants.filter(x=>x.status==='developing'&&x.readyDay<=game.day)){
   r.status='complete';r.completed=game.day;const h=v182VariantSpec(r);if(!h)continue;HULLS[r.id]=h;if(!game.ownedHulls.includes(r.id))game.ownedHulls.push(r.id);game.hullState[r.id]=game.hullState[r.id]||{condition:100};game.shipRecords[r.id]=game.shipRecords[r.id]||{acquired:game.day,battles:0,captures:0,defenses:0,maxDamage:0,medals:['自社開発試作艦']};v182Discover(r.id,'自社派生艦開発',false);addLog?.(`派生艦「${r.name}」が完成し、保有艦へ登録された。`)
  }
 }
 function v182VariantsHtml(){
  const s=v182State(),pending=s.variants.find(r=>r.status==='developing'),done=s.variants.filter(r=>r.status==='complete').slice(-8).reverse(),base=HULLS[game.hull];
  const buttons=Object.entries(V182_VARIANT_TYPES).map(([k,t])=>{const cost=v182VariantProjectCost(game.hull,k),exists=s.variants.some(r=>r.baseId===game.hull&&r.type===k);return `<button onclick="StarFrontierFleetIdentity.startVariant('${k}')" ${pending||exists||!v182HasDevYard()||game.credits<cost?'disabled':''}>${escapeHtml(t.name)}<br><small>${cost.toLocaleString()} Cr / ${t.days}+日</small></button>`}).join('');
  return `<div class="section-title"><h3>🧪 派生艦開発</h3><span class="pill">DERIVATIVE DESIGN</span></div><p class="desc">現在の保有艦「${escapeHtml(game.customNames?.[game.hull]||base?.name||game.hull)}」を基礎に、用途別の派生型を設計・試作します。完成艦は通常の保有艦として乗換・艦装変更・艦歴記録が可能です。</p>${pending?`<div class="news-item"><b>開発中：${escapeHtml(pending.name)}</b><br>${escapeHtml(V182_VARIANT_TYPES[pending.type]?.name||pending.type)} / Day ${pending.readyDay}完成予定 / 残り ${Math.max(0,pending.readyDay-game.day)}日</div>`:''}<div class="grid v182-variant-grid">${buttons}</div>${done.length?`<div class="separator"></div><b>完成済み派生艦</b>${done.map(r=>`<div class="fleet-chip"><div><b>${escapeHtml(r.name)}</b><div class="lore-meta">${escapeHtml(V182_VARIANT_TYPES[r.type]?.name||r.type)} / ${escapeHtml(HULLS[r.baseId]?.name||r.baseId)}派生</div></div>${game.hull===r.id?'<span class="pill">搭乗中</span>':`<button class="mini good" onclick="switchHull('${r.id}')">乗換</button>`}</div>`).join('')}`:''}`;
 }

 // ---- Crew traits / compatibility -------------------------------------------
 const V182_PERSONAL_TRAITS=[
  {id:'duelist',name:'戦闘直感',classes:['corvette','frigate','cruiser'],desc:'軽中型戦闘艦で判断が速い'},
  {id:'longhaul',name:'長距離気質',classes:['prospect','freighter','carrier'],desc:'長時間航行と遠征任務に強い'},
  {id:'heavyhand',name:'重艦適性',classes:['cruiser','carrier','battleship','dread','dreadnought'],desc:'大型艦の慣性と複雑な系統を好む'},
  {id:'scoutmind',name:'偵察眼',classes:['prospect','corvette','frigate'],desc:'探査・偵察艦の情報量を処理しやすい'},
  {id:'merchant',name:'船団感覚',classes:['freighter','frigate','carrier'],desc:'物流・護送任務で船の癖を掴みやすい'},
  {id:'adaptive',name:'適応型',classes:[],desc:'艦級習熟が進むほど能力を引き出す'}
 ];
 function v182CrewPersonalTrait(role,c){if(!c)return null;const idx=v182Hash(`${role}:${c.name||role}`)%V182_PERSONAL_TRAITS.length;return V182_PERSONAL_TRAITS[idx]}
 function v182CrewCompatibility(role,hid=game.hull){
  const c=game.crew?.[role],trait=V182_CREW_TRAITS[role],h=HULLS?.[hid]||hull?.();if(!c||!trait||!h)return {match:false,familiarity:0,bonus:0,trait:trait||null};
  const match=trait.classes.includes(h.class),fam=Math.max(0,Number(c.classFamiliarity?.[h.class])||0),xp=Math.max(0,Number(c.xp)||0),loyalty=Math.max(0,Number(c.loyalty)||0),personal=v182CrewPersonalTrait(role,c);
  const personalMatch=personal?.id==='adaptive'?fam>=8:!!personal?.classes?.includes(h.class);
  const bonus=(match?2:0)+Math.min(2,Math.floor(fam/8))+(xp>=120?1:0)+(loyalty>=80?1:0)+(personalMatch?1:0);return{match,familiarity:fam,bonus:Math.min(5,bonus),trait,personal,personalMatch};
 }
 function v182ProcessCrewFamiliarity(){
  const cls=HULLS?.[game.hull]?.class||hull?.().class;if(!cls)return;for(const [role,c] of Object.entries(game.crew||{})){if(!c)continue;c.classFamiliarity=c.classFamiliarity||{};const comp=V182_CREW_TRAITS[role];const gain=comp?.classes?.includes(cls)?2:1;c.classFamiliarity[cls]=Math.min(40,(Number(c.classFamiliarity[cls])||0)+gain)}
 }
 const v182CrewBonusBase=typeof crewBonus==='function'?crewBonus:null;
 if(v182CrewBonusBase)crewBonus=function(role){const base=v182CrewBonusBase(role);if(!base)return 0;return Math.min(23,base+v182CrewCompatibility(role,game.hull).bonus)};
 const v182DamageShipBase=typeof damageShip==='function'?damageShip:null;
 if(v182DamageShipBase)damageShip=function(amount){const engineer=v182CrewCompatibility('engineer',game.hull).bonus,reduced=Number(amount)*(1-Math.min(.05,engineer*.01));return v182DamageShipBase(reduced)};
 function v182CrewHtml(){
  const rows=Object.entries(CREW_ROLES||{}).map(([role,r])=>{const c=game.crew?.[role],comp=v182CrewCompatibility(role,game.hull),trait=V182_CREW_TRAITS[role];return `<div class="v182-crew-row"><div><b>${escapeHtml(r.name)}：${escapeHtml(c?.name||'空席')}</b><div class="smallnote">職務特性「${escapeHtml(trait?.name||'標準')}」— ${escapeHtml(trait?.desc||'')}${c&&comp.personal?`<br>個人特性「${escapeHtml(comp.personal.name)}」— ${escapeHtml(comp.personal.desc)}`:''}<br>${c?`現在艦相性 ${comp.match||comp.personalMatch?'適性':'標準'} / 習熟 ${comp.familiarity}/40 / 相性補正 +${comp.bonus}`:'乗員を雇用すると艦級相性が有効になります'}</div></div><span class="pill">${c?`+${crewBonus(role)}`:'---'}</span></div>`}).join('');
  return `<div class="separator"></div><div class="section-title"><h3>🧑‍🚀 艦級適性・習熟</h3><span class="pill">CREW SYNERGY</span></div><p class="desc">乗組員は得意な艦級を持ち、実際に乗艦して日を進めるほどその艦級へ習熟します。最大+5が既存の乗組員補正へ加算されます。</p>${rows}`;
 }
 function v182DecorateCrewPanel(){const el=document.getElementById('crewPanel');if(!el||el.querySelector?.('[data-v182="crew"]'))return;const box=document.createElement('div');box.dataset.v182='crew';box.innerHTML=v182CrewHtml();el.appendChild(box)}

 // ---- Encyclopedia UI --------------------------------------------------------
 function v182EncyclopediaIds(){return Object.keys(HULLS||{}).filter(id=>{const h=HULLS[id];return h&&!h.service&&!h.corporate}).sort((a,b)=>{const da=v182IsDiscovered(a)?1:0,db=v182IsDiscovered(b)?1:0;return db-da||(HULLS[a].class||'').localeCompare(HULLS[b].class||'')||(HULLS[a].name||a).localeCompare(HULLS[b].name||b,'ja')})}
 function v182EncyclopediaCard(id,index){
  const h=HULLS[id],known=v182IsDiscovered(id);if(!known){return `<div class="v182-codex-card unknown"><img src="${v182UnknownSvgUri(id)}" alt="未確認艦影"><div><b>未確認艦級 #${String(index+1).padStart(3,'0')}</b><div class="smallnote">星系市場・航路遭遇・軍事情報・情報士官の艦影解析で識別可能。</div></div></div>`}
  const d=game.shipIdentity.discoveries[id],c=SHIP_CLASSES[h.class]||{name:h.class};return `<div class="v182-codex-card"><div class="v182-codex-art">${typeof sfShipImageHtml==='function'?sfShipImageHtml(id,h.name,'sf-ship-thumb'):''}</div><div><b>${escapeHtml(h.name)}</b> <span class="pill">${escapeHtml(c.name)}</span><div class="smallnote">船倉 ${h.baseCargo} / 燃料 ${h.baseFuel} / 採掘 ${h.mining>=0?'+':''}${h.mining||0}${h.maker?` / ${escapeHtml(v182MakerName(h.maker))}`:''}<br>${d?`識別 Day ${d.day} — ${escapeHtml(d.source)}`:'保有・初期登録'}</div></div></div>`
 }
 function v182EncyclopediaHtml(){
  const ids=v182EncyclopediaIds(),known=ids.filter(v182IsDiscovered).length,intel=typeof crewBonus==='function'?crewBonus('intel'):0,cost=Math.max(160,520-intel*12),candidates=v182ScanCandidates().length;
  return `<div class="section-title"><h3>📖 艦船図鑑・識別記録</h3><span class="pill">${known}/${ids.length} DISCOVERED</span></div><p class="desc">未遭遇の艦級はシルエットと信号番号だけ表示されます。地域造船所を訪れる、商船・採掘船・損傷艦へ遭遇する、軍事情報を得ることで自動登録されます。</p><div class="actions"><button class="purple" onclick="StarFrontierFleetIdentity.scan()" ${game.shipIdentity.lastScanDay===game.day||!candidates||game.credits<cost?'disabled':''}>情報士官で艦影解析 ${cost.toLocaleString()} Cr</button><span class="smallnote">現在宙域の未識別候補 ${candidates} / 情報補正 +${intel}</span></div><div class="v182-codex-grid">${ids.map(v182EncyclopediaCard).join('')}</div>`;
 }

 // ---- Mount / rendering ------------------------------------------------------
 function v182Mount(id,cls='panel'){
  const tab=document.getElementById('ship');if(!tab)return null;let el=document.getElementById(id);if(el)return el;el=document.createElement('div');el.id=id;el.className=cls;const save=tab.querySelector?.('.reset-wrap');if(save&&save.parentElement===tab)tab.insertBefore(el,save);else tab.appendChild(el);return el;
 }
 function v182RenderShipFeatures(){
  const tab=document.getElementById('ship');if(!tab||tab.classList?.contains('hidden'))return;v182State();v182SyncDiscoveries(false);
  const maker=v182Mount('v182ManufacturerPanel'),variants=v182Mount('v182VariantPanel'),codex=v182Mount('v182CodexPanel');if(maker)maker.innerHTML=v182ManufacturerHtml();if(variants)variants.innerHTML=v182VariantsHtml();if(codex)codex.innerHTML=v182EncyclopediaHtml();
 }
 function v182Daily(){v182State();v182ProcessMakerContracts();v182ProcessVariants();v182ProcessCrewFamiliarity();v182SyncDiscoveries(false)}

 // ---- Integration wrappers ---------------------------------------------------
 const v182CanBuyHullBase=typeof canBuyHull==='function'?canBuyHull:null;
 if(v182CanBuyHullBase)canBuyHull=function(id){const h=HULLS?.[id];if(h?.makerExclusiveRep&&v182Rep(h.maker)<h.makerExclusiveRep)return false;return v182CanBuyHullBase(id)};
 const v182BuyHullBase=typeof buyHull==='function'?buyHull:null;
 if(v182BuyHullBase)buyHull=function(id){
  v182State();const h=HULLS?.[id],maker=h?.maker,before=game.ownedHulls.includes(id);if(!h||before)return v182BuyHullBase(id);
  const price=v182Price(id),orig=h.cost;if(game.credits<price)return;try{h.cost=price;v182BuyHullBase(id)}finally{h.cost=orig}
  if(!before&&game.ownedHulls.includes(id)){if(maker){v182AddRep(maker,Math.max(4,Math.min(12,Math.round((orig||20000)/12000))),'艦船購入実績');const st=v182State().manufacturerStats[maker]||(v182State().manufacturerStats[maker]={purchases:0,spent:0});st.purchases++;st.spent+=(price||0)}v182Discover(id,'艦船購入',false);save?.();render?.()}
 };
 const v182ShipyardCardBase=typeof shipyardCard==='function'?shipyardCard:null;
 if(v182ShipyardCardBase)shipyardCard=function(id,h){
  let html=v182ShipyardCardBase(id,h);if(!html||!h?.maker||game.ownedHulls.includes(id))return html;const rate=v182DiscountRate(h.maker),price=v182Price(id);if(rate>0){const original=(Number(h.cost)||0).toLocaleString()+' Cr';html=html.replace(original,price.toLocaleString()+' Cr');html=html.replace('</p></div><div>',`</p><div class="hint">${escapeHtml(v182MakerName(h.maker))}信用 ${Math.round(v182Rep(h.maker))} / 顧客値引 ${Math.round(rate*100)}%</div></div><div>`)}return html
 };
 const v182AdvanceBase=typeof gmAdvance==='function'?gmAdvance:null;
 if(v182AdvanceBase)gmAdvance=function(){const out=v182AdvanceBase();v182Daily();if(game)game.version=V182_BUILD;return out};
 const v182InitBase=typeof initV10==='function'?initV10:null;
 if(v182InitBase)initV10=function(){const out=v182InitBase();v182State();if(game)game.version=V182_BUILD;return out};
 const v182RenderShipBase=typeof renderShip==='function'?renderShip:null;
 if(v182RenderShipBase)renderShip=function(){const out=v182RenderShipBase();v182RenderShipFeatures();return out};
 const v182RenderV10Base=typeof renderV10==='function'?renderV10:null;
 if(v182RenderV10Base)renderV10=function(){const out=v182RenderV10Base();try{v182DecorateCrewPanel()}catch(_){}return out};
 const v182RenderBase=typeof render==='function'?render:null;
 function v182ApplyVersionUI(){if(game)game.version=V182_BUILD;const badge=document.querySelector?.('header .title .badge')||document.querySelector?.('.version-badge');if(badge)badge.textContent='v'+V182_BUILD;const sub=document.querySelector?.('header .sub');if(sub)sub.textContent='Ship Icons / Manufacturer Loyalty / Derivative Design / Crew Synergy / Discovery Codex';if(typeof document!=='undefined')document.title='STAR FRONTIER v1.82.0 — Fleet Identity & Discovery'}
 if(v182RenderBase)render=function(){const out=v182RenderBase();try{v182State();v182SyncDiscoveries(false);v182ApplyVersionUI()}catch(_){}return out};

 window.StarFrontierFleetIdentity={
  ensure:v182State,rep:v182Rep,discount:v182DiscountRate,price:v182Price,addRep:v182AddRep,
  acceptContract:v182AcceptMakerContract,startVariant:v182StartVariant,scan:v182ScanRegistry,
  isDiscovered:v182IsDiscovered,discover:v182Discover,crewCompatibility:v182CrewCompatibility,
  processDaily:v182Daily,syncDiscoveries:v182SyncDiscoveries,
  variantTypes:V182_VARIANT_TYPES,exclusiveHulls:V182_EXCLUSIVE_HULLS,feature:V182_FEATURE
 };
})();
