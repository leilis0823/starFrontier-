'use strict';
// ============================================================================
// STAR FRONTIER v1.83.0 — Dynamic Contracts & Exploration
// - World-state driven mission board (logistics / war / disaster / rescue / survey)
// - Deterministic anomaly discovery and multi-step investigation
// - Mission outcomes feed back into logistics, route safety, disaster recovery,
//   faction relations and v1.82 ship discovery where appropriate.
//
// IMPORTANT: this layer intentionally never calls the global rng(). New content
// uses a private deterministic hash so existing marketSeed / simulation RNG order
// remains unchanged.
// ============================================================================
(function(){
 const V183_BUILD='1.83.0';
 const V183_FEATURE='Dynamic Contracts & Exploration';
 const V183_STATE_VERSION=1;
 const V183_MAX_ACTIVE=3;
 const V183_MISSION_TYPES={
  supply:{name:'緊急補給',icon:'📦',baseReward:1900,desc:'物流不足星系へ契約貨物を輸送する。',color:'good'},
  relief:{name:'災害救援',icon:'🚑',baseReward:2600,desc:'被災星系へ救援班・復旧資材を輸送する。',color:'warn'},
  courier:{name:'緊急連絡',icon:'📡',baseReward:1600,desc:'機密通信・行政文書を指定星系へ届ける。',color:'purple'},
  escort:{name:'船団護衛',icon:'🛡',baseReward:3000,desc:'危険航路を横断する船団に随伴する。',color:'good'},
  rescue:{name:'救難対応',icon:'🧰',baseReward:2800,desc:'遭難船・損傷船の救難と応急復旧を行う。',color:'warn'},
  survey:{name:'未知信号調査',icon:'🛰',baseReward:2300,desc:'未確認信号を追跡し、現地アノマリーを調査する。',color:'purple'}
 };
 const V183_ANOMALIES={
  derelict:{name:'漂流船群',icon:'⚓',risk:42,desc:'識別信号を失った複数の廃船が弱い電力反応を残している。'},
  precursor:{name:'古代航路リレー',icon:'◈',risk:34,desc:'現行規格以前の航法ビーコンらしき構造物。断続的な同期信号を発している。'},
  orefield:{name:'未登録高密度鉱化帯',icon:'⬣',risk:28,desc:'通常航路から外れた小惑星群に高密度の鉱物反応がある。'},
  bioship:{name:'星海生体艦回遊域',icon:'🜚',risk:38,desc:'人工機関とは異なる熱・電磁反応が群れを成して移動している。'},
  axiom:{name:'アクシオム残響ノード',icon:'⬡',risk:64,desc:'機械文明由来と推定される暗号化信号。近傍空間の航法データを書き換えている。'},
  abandoned:{name:'放棄軌道施設',icon:'🏚',risk:46,desc:'登録抹消済みの小型ステーション。ドック区画の一部だけが稼働している。'}
 };
 const V183_ANOMALY_REWARDS={
  derelict:{credits:1900,exploration:10},precursor:{credits:1500,exploration:14},orefield:{credits:1200,exploration:12},
  bioship:{credits:1100,exploration:16},axiom:{credits:2300,exploration:20},abandoned:{credits:2100,exploration:13}
 };
 function v183Clamp(n,a=0,b=100){return Math.max(a,Math.min(b,Number(n)||0))}
 function v183HashInt(text){let h=2166136261>>>0;for(const ch of String(text||'')){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)>>>0}return h>>>0}
 function v183Unit(text){return v183HashInt(text)/4294967295}
 function v183Round100(n){return Math.max(100,Math.round((Number(n)||0)/100)*100)}
 function v183SystemName(sid){return SYSTEMS?.[sid]?.name||sid||'不明星系'}
 function v183News(text){
  try{game.gm=game.gm||{};game.gm.news=Array.isArray(game.gm.news)?game.gm.news:[];game.gm.news.unshift(`Day ${game.day}: ${text}`);game.gm.news=game.gm.news.slice(0,30)}catch(_){}
 }

 function v183FactionName(fid){return FACTIONS?.[fid]?.short||fid||'独立組織'}
 function v183Neighbors(sid){return Object.keys(SYSTEMS?.[sid]?.routes||{}).filter(x=>SYSTEMS?.[x])}
 function v183Distance(from,to){
  if(from===to)return 0;if(!SYSTEMS?.[from]||!SYSTEMS?.[to])return 99;
  const q=[[from,0]],seen=new Set([from]);while(q.length){const [cur,d]=q.shift();for(const n of v183Neighbors(cur)){if(seen.has(n))continue;if(n===to)return d+1;seen.add(n);q.push([n,d+1])}}
  return 99;
 }
 function v183Path(from,to){
  if(from===to)return[from];const q=[from],seen=new Set([from]),prev={};while(q.length){const cur=q.shift();for(const n of v183Neighbors(cur)){if(seen.has(n))continue;seen.add(n);prev[n]=cur;if(n===to){const out=[to];let p=to;while(p!==from){p=prev[p];if(!p)return[];out.unshift(p)}return out}q.push(n)}}return[];
 }
 function v183CurrentHull(){try{return typeof hull==='function'?hull():HULLS?.[game.hull]}catch(_){return HULLS?.[game?.hull]}}
 function v183CombatScore(){try{return Math.max(1,Number(combatPower?.())||0)}catch(_){const h=v183CurrentHull();return Math.max(1,(COMBAT_POWER?.[h?.class]||10)+(h?.combatBonus||0))}}
 function v183SupportScore(){const h=v183CurrentHull()||{},eng=(()=>{try{return crewBonus?.('engineer')||0}catch(_){return 0}})(),cap=Number(h.baseCargo)||0,armor=(Number(h.armorBonus)||0)*100;return Math.round(v183Clamp(25+cap*.13+eng*2.2+armor+(h.class==='carrier'?16:0)+(h.class==='freighter'?9:0),5,100))}
 function v183SurveyScore(){const h=v183CurrentHull()||{},intel=(()=>{try{return crewBonus?.('intel')||0}catch(_){return 0}})();return Math.round(v183Clamp(24+intel*2.4+(h.class==='prospect'?28:0)+(h.class==='corvette'?10:0)+(h.class==='frigate'?8:0)+(Number(h.mining)||0)*3,5,100))}
 function v183State(){
  game.dynamicOps=game.dynamicOps&&typeof game.dynamicOps==='object'?game.dynamicOps:{};const s=game.dynamicOps;s.version=V183_STATE_VERSION;
  s.offers=Array.isArray(s.offers)?s.offers:[];s.active=Array.isArray(s.active)?s.active:[];s.history=Array.isArray(s.history)?s.history:[];
  s.anomalies=s.anomalies&&typeof s.anomalies==='object'?s.anomalies:{};s.discoveryLog=Array.isArray(s.discoveryLog)?s.discoveryLog:[];
  s.boardStamp=s.boardStamp&&typeof s.boardStamp==='object'?s.boardStamp:{};s.scanStamp=s.scanStamp&&typeof s.scanStamp==='object'?s.scanStamp:{};
  s.nextId=Math.max(1,Number(s.nextId)||1);s.explorationXP=Math.max(0,Number(s.explorationXP)||0);s.reputation=Math.max(0,Number(s.reputation)||0);
  s.metrics={generated:0,accepted:0,completed:0,failed:0,credits:0,scans:0,anomalies:0,resolved:0,...(s.metrics||{})};
  for(const m of s.active){m.status=m.status||'active';m.stage=m.stage||'travel';m.accepted=Number.isFinite(Number(m.accepted))?Number(m.accepted):game.day;m.expires=Math.max(m.accepted+1,Number(m.expires)||game.day+6)}
  return s;
 }
 function v183ExplorationRank(){const xp=v183State().explorationXP;if(xp>=180)return{name:'深宇宙航路開拓者',tier:5};if(xp>=105)return{name:'上級探査官',tier:4};if(xp>=55)return{name:'探査官',tier:3};if(xp>=20)return{name:'航路測量士',tier:2};return{name:'候補探査員',tier:1}}
 function v183Logistics(sid){return game.gm?.systemLogistics?.[sid]||{shortage:0,routeHealth:70,stock:50,capacity:100}}
 function v183Disaster(sid){return (game.gm?.environmentalRisk?.events||[]).filter(e=>e.systemId===sid&&e.status!=='closed'&&(e.until==null||e.until>=game.day-1)).sort((a,b)=>(b.severity||0)-(a.severity||0))[0]||null}
 function v183RescueCase(sid){return game.gm?.v179?.rescue?.cases?.find?.(c=>!c.completed&&c.system===sid&&c.expires>=game.day)||game.gm?.resourceNetworks?.rescue?.cases?.find?.(c=>!c.completed&&c.system===sid&&c.expires>=game.day)||null}
 function v183WarSystem(sid){const fid=SYSTEMS?.[sid]?.faction;return !!(game.war?.active&&fid&&[game.war.a,game.war.b].includes(fid))}
 function v183RouteDanger(sid){return Number(game.gm?.interstellarCommerce?.routeDanger?.[sid])||0}
 function v183RiskScore(sid){const sec=SYSTEMS?.[sid]?.security||'',base=sec==='無法'?75:sec==='低'?55:sec==='軍管'?45:sec==='条約監視'?38:sec==='最高'?12:sec==='高'?20:35;return v183Clamp(base+v183RouteDanger(sid)*.35+(v183WarSystem(sid)?18:0),5,100)}
 function v183MissionPressure(type,target,source){
  const d=Math.max(1,v183Distance(source,target)),log=v183Logistics(target),dis=v183Disaster(target),risk=v183RiskScore(target),res=v183RescueCase(target);
  if(type==='supply')return (log.shortage||0)*1.35+(100-(log.routeHealth||70))*.35-d*7;
  if(type==='relief')return (dis?.severity||0)*1.65+(log.shortage||0)*.28-d*6;
  if(type==='rescue')return (res?78:0)+risk*.28-d*7;
  if(type==='escort')return risk*.72+(v183WarSystem(target)?28:0)+(100-(log.routeHealth||70))*.25-d*4;
  if(type==='survey')return (SYSTEMS?.[target]?.faction==='unclaimed'?68:20)+risk*.32+(v183State().scanStamp[target]? -14:12)-d*4;
  if(type==='courier')return 28+(v183WarSystem(target)?24:0)+(log.shortage||0)*.18-d*3;
  return 0;
 }
 function v183IssuerFor(type,target){const fid=SYSTEMS?.[target]?.faction;if(type==='relief')return fid&&fid!=='unclaimed'?`${v183FactionName(fid)}復旧局`:'独立救難ネットワーク';if(type==='supply')return fid&&fid!=='unclaimed'?`${v183FactionName(fid)}物流調整局`:'辺境交易組合';if(type==='escort')return '星間船団保安組合';if(type==='rescue')return '銀河救難ビーコン網';if(type==='survey')return '航路測量・探査局';return fid&&fid!=='unclaimed'?`${v183FactionName(fid)}連絡局`:'中立航路管理局'}
 function v183MissionTitle(type,target){const n=v183SystemName(target);if(type==='supply')return `${n} 緊急補給便`;if(type==='relief')return `${n} 災害救援輸送`;if(type==='escort')return `${n} 航路護衛`;if(type==='rescue')return `${n} 救難信号対応`;if(type==='survey')return `${n} 未知信号追跡`;return `${n} 緊急連絡便`}
 function v183OfferId(source,type,target){return `v183-${game.day}-${source}-${type}-${target}-${v183HashInt(`${game.day}:${source}:${type}:${target}`)%10000}`}
 function v183MakeOffer(source,type,target,pressure){
  const dist=Math.max(1,v183Distance(source,target)),meta=V183_MISSION_TYPES[type],risk=v183RiskScore(target),volume=type==='supply'?18+Math.round(Math.max(0,pressure)/8):type==='relief'?24+Math.round(Math.max(0,pressure)/10):0;
  const reward=v183Round100(meta.baseReward*(1+dist*.22+Math.max(0,pressure)*.006+risk*.0025));
  const duration=Math.max(4,3+dist*2+(type==='survey'?3:0));
  return{id:v183OfferId(source,type,target),type,source,target,issuer:v183IssuerFor(type,target),title:v183MissionTitle(type,target),created:game.day,expires:game.day+duration,reward,pressure:Math.round(pressure),risk:Math.round(risk),distance:dist,volume,stage:'offer',status:'offered'};
 }
 function v183GenerateBoard(source=game.system,force=false){
  const s=v183State();if(!SYSTEMS?.[source])return[];const stamp=`${game.day}:${source}`;if(!force&&s.boardStamp[source]===stamp)return s.offers.filter(o=>o.source===source&&o.status==='offered'&&o.expires>=game.day);
  s.offers=s.offers.filter(o=>o.status==='offered'&&o.expires>=game.day&&o.source!==source);const candidates=[];
  for(const target of Object.keys(SYSTEMS||{})){if(target===source)continue;const d=v183Distance(source,target);if(d>4)continue;for(const type of Object.keys(V183_MISSION_TYPES)){const p=v183MissionPressure(type,target,source);let threshold=type==='relief'?35:type==='rescue'?38:type==='supply'?30:type==='escort'?34:type==='survey'?34:24;if(p>=threshold)candidates.push({type,target,p,rank:p-d*2+v183Unit(`${stamp}:${type}:${target}`)*3})}}
  // Always keep at least one exploration/courier option so a quiet galaxy is still playable.
  if(!candidates.some(x=>x.type==='survey')){const targets=Object.keys(SYSTEMS).filter(x=>x!==source&&v183Distance(source,x)<=3).sort((a,b)=>v183MissionPressure('survey',b,source)-v183MissionPressure('survey',a,source));if(targets[0])candidates.push({type:'survey',target:targets[0],p:v183MissionPressure('survey',targets[0],source),rank:30})}
  if(!candidates.some(x=>x.type==='courier')){const nb=v183Neighbors(source).sort((a,b)=>v183Unit(`${stamp}:${a}`)-v183Unit(`${stamp}:${b}`))[0];if(nb)candidates.push({type:'courier',target:nb,p:v183MissionPressure('courier',nb,source),rank:26})}
  candidates.sort((a,b)=>b.rank-a.rank||v183HashInt(`${stamp}:${a.type}:${a.target}`)-v183HashInt(`${stamp}:${b.type}:${b.target}`));
  const picked=[],usedTypes=new Set(),usedTargets=new Set();for(const c of candidates){if(picked.length>=5)break;if(usedTypes.has(c.type)&&picked.length<3)continue;if(usedTargets.has(c.target)&&picked.length<3)continue;picked.push(v183MakeOffer(source,c.type,c.target,c.p));usedTypes.add(c.type);usedTargets.add(c.target)}
  s.offers.push(...picked);s.boardStamp[source]=stamp;s.metrics.generated+=picked.length;return picked;
 }
 function v183Accept(id){
  const s=v183State(),o=s.offers.find(x=>x.id===id&&x.status==='offered');if(!o||o.expires<game.day)return toast?.('この案件は失効しています');if(s.active.filter(x=>x.status==='active').length>=V183_MAX_ACTIVE)return toast?.(`同時受注は${V183_MAX_ACTIVE}件までです`);
  if(o.volume>0&&(game.cargoMax||0)<o.volume)return toast?.(`契約貨物 ${o.volume}u を積める船倉が必要です`);
  o.status='accepted';const m={...o,status:'active',stage:'travel',accepted:game.day,deadline:o.expires};s.active.push(m);s.metrics.accepted++;addLog?.(`動的依頼を受注：${o.title} / ${v183SystemName(o.target)} / 報酬 ${o.reward.toLocaleString()} Cr。`);save?.();render?.();if(game)game.version=V183_BUILD;
 }
 function v183Abandon(id){const s=v183State(),m=s.active.find(x=>x.id===id&&x.status==='active');if(!m)return;m.status='abandoned';m.completed=game.day;s.reputation=Math.max(0,s.reputation-1);s.history.unshift({day:game.day,type:'abandon',text:`${m.title}を放棄`});addLog?.(`依頼「${m.title}」を放棄した。`);save?.();render?.();if(game)game.version=V183_BUILD}
 function v183ApplyMissionWorldEffect(m){
  const log=v183Logistics(m.target);if(m.type==='supply'){log.stock=v183Clamp((log.stock||0)+10,0,log.capacity||120);log.shortage=v183Clamp((log.shortage||0)-10,0,100);log.routeHealth=v183Clamp((log.routeHealth||70)+2,0,100)}
  if(m.type==='relief'){const ev=v183Disaster(m.target);if(ev)ev.severity=v183Clamp((ev.severity||0)-7,0,100);log.shortage=v183Clamp((log.shortage||0)-5,0,100);const inf=game.gm?.publicInfrastructure?.systems?.[m.target];if(inf&&Number.isFinite(inf.overall))inf.overall=v183Clamp(inf.overall+1.5,0,100)}
  if(m.type==='escort'){const x=game.gm?.interstellarCommerce;if(x?.routeDanger)x.routeDanger[m.target]=v183Clamp((x.routeDanger[m.target]||0)-8,0,100);log.routeHealth=v183Clamp((log.routeHealth||70)+3,0,100)}
  if(m.type==='courier'){const fid=SYSTEMS?.[m.target]?.faction;if(fid&&fid!=='unclaimed'&&game.gm?.relations?.[fid]!=null)game.gm.relations[fid]=v183Clamp(game.gm.relations[fid]+1,-100,100)}
  if(m.type==='rescue'){log.routeHealth=v183Clamp((log.routeHealth||70)+1.5,0,100)}
 }
 function v183FinishMission(m,mult=1,note=''){
  const s=v183State();m.status='completed';m.completed=game.day;m.stage='complete';const pay=v183Round100(m.reward*mult);game.credits+=pay;s.reputation+=2+(m.type==='survey'?1:0);s.metrics.completed++;s.metrics.credits+=pay;v183ApplyMissionWorldEffect(m);s.history.unshift({day:game.day,type:'complete',mission:m.type,text:`${m.title} / +${pay.toLocaleString()} Cr${note?` / ${note}`:''}`});s.history=s.history.slice(0,80);addLog?.(`依頼完了：${m.title}。報酬 ${pay.toLocaleString()} Cr${note?`（${note}）`:''}。`);v183News(`【民間航宙活動】${m.issuer}の「${m.title}」が完了。${v183SystemName(m.target)}の現地状況が改善した。`);save?.();render?.();if(game)game.version=V183_BUILD;return pay;
 }
 function v183ResolveMission(id){
  const s=v183State(),m=s.active.find(x=>x.id===id&&x.status==='active');if(!m)return;if(game.system!==m.target)return toast?.(`${v183SystemName(m.target)}へ移動してください`);if(game.day>m.deadline)return v183FailExpired(m);
  if(m.type==='survey'){
   if(m.stage==='travel'){const a=v183RevealAnomaly(m.target,`mission:${m.id}`,true);if(!a)return toast?.('信号源を再取得できません');m.stage='investigate';m.anomalyId=a.id;addLog?.(`未知信号の発信源「${a.name}」を特定。現地調査へ移行した。`);save?.();render?.();if(game)game.version=V183_BUILD;return}
   const a=s.anomalies[m.anomalyId];if(!a||a.status!=='resolved')return toast?.('先にアノマリーを調査してください');return v183FinishMission(m,1,'探査データ提出')
  }
  if(m.type==='escort'){
   const req=34+m.risk*.55,score=v183CombatScore()+(()=>{try{return crewBonus?.('captain')||0}catch(_){return 0}})();if(score<req){const deficit=req-score,dmg=Math.min(13,Math.max(3,Math.round(deficit/6)));try{damageShip?.(dmg)}catch(_){}return v183FinishMission(m,.76,`護衛中に船体 ${dmg}%相当損傷`)}return v183FinishMission(m,1.08,'損害なく護送完了')
  }
  if(m.type==='rescue'){
   const score=v183SupportScore();if(game.fuel<2)return toast?.('救難作業用に燃料2が必要');game.fuel-=2;return v183FinishMission(m,score>=62?1.12:score>=42?1:.82,score>=62?'高度救難に成功':score>=42?'救難完了':'応急救難のみ完了')
  }
  if(m.type==='relief'){if(game.fuel<1)return toast?.('救援降下用に燃料1が必要');game.fuel-=1;return v183FinishMission(m,1,'救援物資引渡')}
  if(m.type==='supply')return v183FinishMission(m,1,'契約貨物納入');
  return v183FinishMission(m,1,'通信確認済み');
 }
 function v183FailExpired(m){if(!m||m.status!=='active')return;const s=v183State();m.status='failed';m.completed=game.day;s.metrics.failed++;s.reputation=Math.max(0,s.reputation-1);s.history.unshift({day:game.day,type:'failed',text:`${m.title} / 期限超過`});addLog?.(`依頼失敗：${m.title}（期限超過）。`);return false}
 function v183Daily(){const s=v183State();for(const m of s.active.filter(x=>x.status==='active'&&game.day>x.deadline))v183FailExpired(m);s.active=s.active.filter(m=>m.status==='active'||(m.completed||0)>=game.day-20).slice(-30);s.offers=s.offers.filter(o=>o.status==='offered'&&o.expires>=game.day-1).slice(-45);v183GenerateBoard(game.system,false)}

 // ---- Exploration ------------------------------------------------------------
 function v183AnomalySeed(sid,bucket,slot){return `${sid}:${bucket}:${slot}:v183-anomaly`}
 function v183AnomalyType(sid,bucket,slot){const keys=Object.keys(V183_ANOMALIES),u=v183Unit(v183AnomalySeed(sid,bucket,slot));let idx=Math.floor(u*keys.length);if(SYSTEMS?.[sid]?.faction==='unclaimed'&&u>.55)idx=(idx+2)%keys.length;if(sid==='halcyon'&&u>.35)idx=keys.indexOf('bioship');if(sid==='umbra'&&u>.65)idx=keys.indexOf('axiom');return keys[Math.max(0,idx)]}
 function v183ExistingAnomalies(sid){return Object.values(v183State().anomalies).filter(a=>a.system===sid&&a.status!=='expired')}
 function v183RevealAnomaly(sid=game.system,source='scan',force=false){
  const s=v183State(),bucket=Math.floor(game.day/6),existing=v183ExistingAnomalies(sid).find(a=>a.bucket===bucket&&a.status!=='resolved');if(existing)return existing;
  const slot=existing?1:v183ExistingAnomalies(sid).filter(a=>a.bucket===bucket).length,type=v183AnomalyType(sid,bucket,slot),meta=V183_ANOMALIES[type],id=`anomaly-${sid}-${bucket}-${slot}-${v183HashInt(v183AnomalySeed(sid,bucket,slot))%100000}`;
  if(!force&&v183Unit(`${id}:presence`)<.20)return null;
  const a={id,type,name:meta.name,system:sid,bucket,discovered:game.day,status:'discovered',source,risk:Math.round(v183Clamp(meta.risk+(v183Unit(`${id}:risk`)-.5)*18,8,92)),signature:String(v183HashInt(id)%100000).padStart(5,'0')};s.anomalies[id]=a;s.discoveryLog.unshift({day:game.day,id,system:sid,type});s.discoveryLog=s.discoveryLog.slice(0,80);s.metrics.anomalies++;addLog?.(`探査反応：${v183SystemName(sid)}で「${a.name}」を発見。信号 ${a.signature}。`);return a;
 }
 function v183Scan(sid=game.system){
  const s=v183State();if(s.scanStamp[sid]===game.day)return toast?.('この星系は本日すでに長距離走査済みです');const cost=Math.max(1,4-Math.floor(v183SurveyScore()/35));if(game.fuel<cost)return toast?.(`長距離走査には燃料${cost}が必要`);game.fuel-=cost;s.scanStamp[sid]=game.day;s.metrics.scans++;
  const score=v183SurveyScore(),threshold=.54-Math.min(.24,score/420),u=v183Unit(`${sid}:${game.day}:scan:${score}`);let a=null;if(u>=threshold)a=v183RevealAnomaly(sid,'long_range_scan',true);
  if(!a){s.explorationXP+=2;addLog?.(`${v183SystemName(sid)}の長距離走査を完了。重要反応なし。航路測量データを蓄積した。`);toast?.('重要な未知信号は検出されませんでした')}else{s.explorationXP+=4;toast?.(`${a.name}を発見`)}save?.();render?.();if(game)game.version=V183_BUILD;return a;
 }
 function v183AnomalyOutcome(a,mode){
  const survey=v183SurveyScore(),support=v183SupportScore(),combat=v183CombatScore(),base=mode==='secure'?survey+support*.35:mode==='salvage'?support+combat*.22:survey+combat*.18;
  const target=a.risk+28,margin=base-target,grade=margin>=24?'excellent':margin>=4?'good':margin>=-16?'mixed':'poor';return{grade,margin,base,target};
 }
 function v183DiscoverShipFromAnomaly(a){
  try{if(!window.StarFrontierFleetIdentity?.discover)return null;const ids=Object.keys(HULLS||{}).filter(id=>!window.StarFrontierFleetIdentity.isDiscovered(id)&&!HULLS[id]?.service);if(!ids.length)return null;ids.sort((x,y)=>v183HashInt(`${a.id}:${x}`)-v183HashInt(`${a.id}:${y}`));const id=ids[0];window.StarFrontierFleetIdentity.discover(id,`${a.name}の記録`,true);return id}catch(_){return null}
 }
 function v183ResolveAnomaly(id,mode='secure'){
  const s=v183State(),a=s.anomalies[id];if(!a||a.status!=='discovered')return;if(a.system!==game.system)return toast?.(`${v183SystemName(a.system)}で調査してください`);const meta=V183_ANOMALIES[a.type],out=v183AnomalyOutcome(a,mode),rw=V183_ANOMALY_REWARDS[a.type]||{credits:1200,exploration:8};let mult=out.grade==='excellent'?1.35:out.grade==='good'?1.12:out.grade==='mixed'?.88:.62,credits=v183Round100(rw.credits*mult),xp=Math.max(4,Math.round(rw.exploration*(out.grade==='excellent'?1.35:out.grade==='good'?1.1:out.grade==='mixed'?.85:.65))),note='';
  if(mode==='salvage'){credits=v183Round100(credits*1.35);xp=Math.max(3,Math.round(xp*.8));note='回収優先'}else if(mode==='observe'){credits=v183Round100(credits*.75);xp=Math.round(xp*1.25);note='保全観測'}else note='安全調査';
  if(out.grade==='poor'){const dmg=Math.max(2,Math.min(10,Math.round((a.risk-out.base+20)/7)));try{damageShip?.(dmg)}catch(_){}note+=` / 船体損傷 ${dmg}%`}
  if(a.type==='orefield'){
   try{const dep=typeof v176EnsureDeposits==='function'?v176EnsureDeposits(a.system):null;if(dep){const keys=Object.keys(dep);if(keys.length){const k=keys[v183HashInt(a.id)%keys.length];dep[k]=Math.min(240,(Number(dep[k])||0)+(mode==='salvage'?8:14));note+=` / ${V176_ORES?.[k]?.name||k}鉱脈登録`}}}catch(_){}
  }
  if(a.type==='bioship'){game.bio=game.bio||{};if(mode==='observe'){game.bio.affinity=(game.bio.affinity||0)+3;game.bio.protected=(game.bio.protected||0)+1;note+=' / 生体艦保護記録'}else if(mode==='salvage'){game.bio.exploited=(game.bio.exploited||0)+1;note+=' / 生体サンプル回収'}}
  if(a.type==='axiom'){game.machineContact=game.machineContact||{met:false,resonance:0};game.machineContact.met=true;game.machineContact.resonance=(game.machineContact.resonance||0)+(out.grade==='poor'?1:3);note+=' / 機械文明残響'}
  if(a.type==='derelict'||a.type==='abandoned'){const shipId=v183DiscoverShipFromAnomaly(a);if(shipId)note+=` / 艦級記録 ${HULLS[shipId]?.name||shipId}`}
  if(a.type==='precursor'){const fid=SYSTEMS?.[a.system]?.faction;if(fid&&fid!=='unclaimed'&&game.gm?.factions?.[fid])game.gm.factions[fid].research=v183Clamp((game.gm.factions[fid].research||50)+.35,0,100);note+=' / 航法研究データ'}
  game.credits+=credits;s.explorationXP+=xp;s.reputation+=1;s.metrics.resolved++;s.metrics.credits+=credits;a.status='resolved';a.resolved=game.day;a.mode=mode;a.grade=out.grade;a.reward=credits;a.xp=xp;s.history.unshift({day:game.day,type:'anomaly',text:`${a.name} / ${note} / +${credits.toLocaleString()} Cr`});addLog?.(`アノマリー調査完了：${a.name}。${note}。報酬 ${credits.toLocaleString()} Cr / 探査XP +${xp}。`);v183News(`【探査報告】${v183SystemName(a.system)}の${a.name}が民間探査船により調査された。`);save?.();render?.();if(game)game.version=V183_BUILD;return a;
 }

 // ---- UI ---------------------------------------------------------------------
 function v183MissionActionHtml(m){if(game.system!==m.target)return `<button disabled>${escapeHtml(v183SystemName(m.target))}へ移動</button>`;if(m.type==='survey'&&m.stage==='investigate'){const a=v183State().anomalies[m.anomalyId];if(a?.status==='resolved')return `<button class="good" onclick="StarFrontierDynamicOps.resolveMission('${m.id}')">探査データを提出</button>`;return '<button disabled>アノマリー調査が必要</button>'}return `<button class="good" onclick="StarFrontierDynamicOps.resolveMission('${m.id}')">現地任務を実行</button>`}
 function v183OfferHtml(o){const m=V183_MISSION_TYPES[o.type];return `<div class="v183-mission-card"><div class="v183-mission-head"><div><b>${m.icon} ${escapeHtml(o.title)}</b><div class="smallnote">${escapeHtml(o.issuer)} / ${escapeHtml(v183SystemName(o.source))} → ${escapeHtml(v183SystemName(o.target))}</div></div><span class="pill">${o.reward.toLocaleString()} Cr</span></div><div class="v183-mission-meta"><span>距離 ${o.distance}</span><span>危険 ${o.risk}</span><span>期限 Day ${o.expires}</span>${o.volume?`<span>契約貨物 ${o.volume}u</span>`:''}</div><p>${escapeHtml(m.desc)} 世界圧力 ${o.pressure}。</p><button class="${m.color||''}" onclick="StarFrontierDynamicOps.accept('${o.id}')">受注</button></div>`}
 function v183ActiveHtml(m){const meta=V183_MISSION_TYPES[m.type],left=m.deadline-game.day;return `<div class="v183-mission-card active"><div class="v183-mission-head"><div><b>${meta.icon} ${escapeHtml(m.title)}</b><div class="smallnote">${escapeHtml(m.issuer)} / ${m.stage==='investigate'?'現地調査中':'移動・遂行中'}</div></div><span class="pill ${left<=1?'badtext':''}">残 ${Math.max(0,left)}日</span></div><div class="v183-mission-meta"><span>目標 ${escapeHtml(v183SystemName(m.target))}</span><span>報酬 ${m.reward.toLocaleString()} Cr</span><span>危険 ${m.risk}</span></div><div class="actions">${v183MissionActionHtml(m)}<button class="secondary" onclick="StarFrontierDynamicOps.abandon('${m.id}')">放棄</button></div></div>`}
 function v183OpsHtml(){const s=v183State(),offers=v183GenerateBoard(game.system,false),active=s.active.filter(x=>x.status==='active'),rank=v183ExplorationRank();return `<div class="section-title"><h2>🧭 動的依頼・航宙オペレーション</h2><span class="pill">v1.83 / ${escapeHtml(rank.name)}</span></div><p class="desc">物流不足、戦争、災害、危険航路、救難信号を銀河シミュレーションから読み取り、現在の世界状況に応じて依頼が発生します。完了結果は物流・航路安全・復旧・外交へ戻ります。</p><div class="v183-summary"><div>受注中<b>${active.length}/${V183_MAX_ACTIVE}</b></div><div>完了<b>${s.metrics.completed}</b></div><div>信頼<b>${Math.round(s.reputation)}</b></div><div>探査XP<b>${Math.round(s.explorationXP)}</b></div></div>${active.length?`<h3>進行中</h3><div class="v183-mission-grid">${active.map(v183ActiveHtml).join('')}</div><div class="separator"></div>`:''}<div class="section-title"><h3>現在地の依頼掲示板</h3><span class="pill">${escapeHtml(v183SystemName(game.system))}</span></div><div class="v183-mission-grid">${offers.length?offers.map(v183OfferHtml).join(''):'<div class="hint">現在、条件に合う新規依頼はありません。</div>'}</div>`}
 function v183AnomalyCard(a){const meta=V183_ANOMALIES[a.type],resolved=a.status==='resolved';return `<div class="v183-anomaly-card ${resolved?'resolved':''}"><div class="v183-mission-head"><div><b>${meta.icon} ${escapeHtml(a.name)}</b><div class="smallnote">信号 ${a.signature} / ${escapeHtml(v183SystemName(a.system))}</div></div><span class="pill">危険 ${a.risk}</span></div><p>${escapeHtml(meta.desc)}</p>${resolved?`<div class="goodtext">調査済み Day ${a.resolved} / ${escapeHtml(a.grade||'complete')} / ${Number(a.reward||0).toLocaleString()} Cr</div>`:game.system!==a.system?`<button disabled>${escapeHtml(v183SystemName(a.system))}へ移動</button>`:`<div class="v183-anomaly-actions"><button class="good" onclick="StarFrontierDynamicOps.resolveAnomaly('${a.id}','secure')">安全調査</button><button class="purple" onclick="StarFrontierDynamicOps.resolveAnomaly('${a.id}','observe')">保全観測</button><button class="warn" onclick="StarFrontierDynamicOps.resolveAnomaly('${a.id}','salvage')">回収優先</button></div>`}</div>`}
 function v183ExplorationHtml(){const s=v183State(),rank=v183ExplorationRank(),local=v183ExistingAnomalies(game.system).sort((a,b)=>(a.status==='resolved')-(b.status==='resolved')||b.discovered-a.discovered),scanCost=Math.max(1,4-Math.floor(v183SurveyScore()/35));return `<div class="section-title"><h2>🌌 未知宙域・アノマリー探査</h2><span class="pill">${escapeHtml(rank.name)} Lv.${rank.tier}</span></div><p class="desc">長距離センサーと情報士官で既知航路の外側を走査します。発見物は世界へ残り、鉱床・生体艦・古代航路・機械文明・艦級図鑑へ接続します。</p><div class="v183-summary"><div>走査性能<b>${v183SurveyScore()}</b></div><div>救難性能<b>${v183SupportScore()}</b></div><div>戦闘性能<b>${v183CombatScore()}</b></div><div>発見<b>${s.metrics.anomalies}</b></div></div><button class="purple" onclick="StarFrontierDynamicOps.scan()" ${s.scanStamp[game.system]===game.day||game.fuel<scanCost?'disabled':''}>長距離走査　燃料 ${scanCost}</button><div class="smallnote">同一星系は1日1回。探鉱艇・情報士官・艦級習熟で発見効率が向上します。</div><div class="separator"></div><h3>現在星系の探査記録</h3><div class="v183-anomaly-grid">${local.length?local.slice(0,8).map(v183AnomalyCard).join(''):'<div class="hint">まだ登録されたアノマリーはありません。</div>'}</div>`}
 function v183Mount(){
  const home=document.getElementById('home');if(!home)return;let ops=document.getElementById('v183DynamicOpsPanel'),exp=document.getElementById('v183ExplorationPanel');if(!ops){ops=document.createElement('div');ops.id='v183DynamicOpsPanel';ops.className='panel';const log=home.querySelector?.('#log')?.closest?.('.panel');if(log&&log.parentElement===home)home.insertBefore(ops,log);else home.appendChild(ops)}if(!exp){exp=document.createElement('div');exp.id='v183ExplorationPanel';exp.className='panel';if(ops.nextSibling)home.insertBefore(exp,ops.nextSibling);else home.appendChild(exp)}ops.innerHTML=v183OpsHtml();exp.innerHTML=v183ExplorationHtml();
 }
 function v183ApplyVersionUI(){if(game)game.version=V183_BUILD;const badge=document.querySelector?.('header .title .badge')||document.querySelector?.('.version-badge');if(badge)badge.textContent='v'+V183_BUILD;const sub=document.querySelector?.('header .sub');if(sub)sub.textContent='Dynamic Contracts / Exploration / World-State Mission Chains / Fleet Identity';if(typeof document!=='undefined')document.title='STAR FRONTIER v1.83.0 — Dynamic Contracts & Exploration'}

 // ---- Integration ------------------------------------------------------------
 const v183AdvanceBase=typeof gmAdvance==='function'?gmAdvance:null;if(v183AdvanceBase)gmAdvance=function(){const out=v183AdvanceBase();v183Daily();if(game)game.version=V183_BUILD;return out};
 const v183InitBase=typeof initV10==='function'?initV10:null;if(v183InitBase)initV10=function(){const out=v183InitBase();v183State();v183GenerateBoard(game.system,false);if(game)game.version=V183_BUILD;return out};
 const v183RenderBase=typeof render==='function'?render:null;if(v183RenderBase)render=function(){const out=v183RenderBase();try{v183State();v183GenerateBoard(game.system,false);v183Mount();v183ApplyVersionUI()}catch(_){}return out};
 window.StarFrontierDynamicOps={ensure:v183State,generate:v183GenerateBoard,accept:v183Accept,abandon:v183Abandon,resolveMission:v183ResolveMission,scan:v183Scan,revealAnomaly:v183RevealAnomaly,resolveAnomaly:v183ResolveAnomaly,distance:v183Distance,path:v183Path,rank:v183ExplorationRank,feature:V183_FEATURE,missionTypes:V183_MISSION_TYPES,anomalyTypes:V183_ANOMALIES};
})();
