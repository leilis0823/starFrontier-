STAR FRONTIER v1.54.0 Hybrid Intervention Source

完了:
- v1.53.0 Androidプロジェクト解析
- Nubia/Universal build flavor分離
- 保存ホットパスのデバウンス/非同期化
- SaveStore fast primary path + checkpoint分離
- バックアップ件数表示の軽量化
- Android WebView/DOM描画最適化
- 全Web JS node --check PASS
- SaveStore JVM 17項目 PASS
- >3MiB fast-save JVM benchmark: 5 writes 140ms (旧実装 1153ms、同コンテナ)
- index.html参照資源欠損 0
- v1.52基幹ゲームJS変更 0（v1.54は追加レイヤー `96-v1_54-hybrid-intervention.js` として実装）

未実施:
- Android Gradle build（この環境にAndroid SDKが無いため）
- Nubia Fold実機計測
- Universal実機計測

したがってAPK/実機PASSとは扱わない。

v1.53.3: 企業画面の契約台帳・取締役会DOM重複を修正。persistent sibling insertion監査PASS。


v1.54.0: 秘密工作・国家暗殺AI・所属不明部隊・独立工作・編入要請・傀儡/保護/勢力圏AIを追加。組織別の作戦参加判断、並列武装組織の独自行動、防諜警戒・妨害、露見時ブローバックも実装。既存v1.39独立・内戦システムへ接続。
