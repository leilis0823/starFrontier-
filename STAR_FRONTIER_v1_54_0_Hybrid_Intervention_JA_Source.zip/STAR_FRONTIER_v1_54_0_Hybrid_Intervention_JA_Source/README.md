# STAR FRONTIER v1.54.0 Hybrid Intervention Source

v1.53.3 UI修正版を基準に、Nubia/Universal性能最適化を維持したまま、v1.54.0 Hybrid Interventionを追加したAndroidソースです。

## 2つの版

- **Nubia版**: Nubia Fold / Snapdragon 8 Elite / RAM 12GB専用調整。Gradle flavor `nubia`。
- **Universal版**: 他端末向け。Gradle flavor `universal`。

同じapplicationIdとDebug鍵を維持するため、v1.53.0から上書き更新して内部セーブを維持する設計です。両版の同時インストールはできません。

## 最重要変更

旧v1.53.0は画面レンダーのたびに数MBのセーブを同期処理し、バックアップ検証まで繰り返していました。v1.54.0はv1.53.3の保存最適化を継承し、保存をデバウンス・非同期化し、世代バックアップを通常主保存から分離しました。詳細は`docs/PERFORMANCE_OPTIMIZATION_V1531.md`。

## ビルド

```bash
cd android
./gradlew assembleNubiaDebug assembleUniversalDebug
```

この作業環境ではv1.54.0 APKを同梱していません。GitHub ActionsまたはAndroid SDK環境で上記2 variantを生成してください。

既存v1.53.0 APKを「最適化済み」として再利用してはいけません。

## v1.53.3 UI hotfix
企業画面で `契約台帳・取締役会` が再描画のたびに重複するDOM累積を修正。表示入口のみ整理し、契約・取締役会データ、セーブ互換、AIロジックは変更していません。詳細は `docs/V1533_UI_DEDUP.md`。

## v1.54.0 Hybrid Intervention

- 政府・正規軍・国境警備隊・並列武装組織による秘密工作AIを追加。
- 国家暗殺は手段を抽象化し、承認・成功・発覚・帰属立証を別判定。
- 独立運動への秘密政治支援・代理勢力支援と、所属不明部隊の介入を実装。
- 独立成立後の編入要請、保護国・安全保障従属国・傀儡国家・勢力圏形成を実装。
- 防諜捜査により、当初は不明だった実行主体が後日露見する仕組みを追加。
- 発覚後の防諜警戒・秘密支援網の妨害・警戒減衰を追加。
- 並列武装組織は条件次第で政府未承認の独自行動を起こし、露見時には政治的ブローバックが発生。
- 既存v1.39独立・内戦システムへ接続し、既存セーブ形式との互換を維持。

詳細は `docs/V154_HYBRID_INTERVENTION.md`。
