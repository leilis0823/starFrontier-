'use strict';
// Application integration layer; the v1.52 game files and wrapper chain remain intact.
(()=>{
 const p=SF153Persistence,native=p.state.native;
 const profile=native&&typeof AndroidNative.getPerformanceProfile==='function'?AndroidNative.getPerformanceProfile():'universal';
 const nubia=profile==='nubia_8elite_12gb';
 const perf=nubia?{saveDelay:180,checkpointDays:5,historyLimit:48}:{saveDelay:650,checkpointDays:7,historyLimit:28};
 let ready=false,loading=false,rendering=false,active=!document.hidden,audioFocus=true;
 let resizeFrame=0,audioTimer=null,audioEpoch=0,liveNodes=0,maxNodes=0,saveCount=0;
 let saveTimer=null,saveDirty=false,lastCheckpointDay=0,cachedBackupCount=null,lastSerializeMs=0,maxSerializeMs=0,navigationDepth=0;
 const history=[];let navigating=false,normalizationFailure=null;
 const oldLoad=load,oldSave=save,oldRender=render,oldNormalize=normalize;
 normalize=function(...args){try{return oldNormalize(...args);}catch(e){normalizationFailure=e;throw e;}};
 const oldShowTab=showTab,oldShowGalaxy=showGalaxy;
 // v1.6 unconditionally disabled BGM on every normalization, even during saves.
 // Preserve the memoized normalizer and retain only the user's audio preference.
 const oldAudioEnsure=ensureV16State;
 ensureV16State=function(...args){const enabled=game?.audio?.enabled;const out=oldAudioEnsure(...args);if(enabled!==undefined)game.audio.enabled=enabled;return out;};
 const oldClockStart=StarFrontierRealtime.start;
 StarFrontierRealtime.start=function(){if(ready)oldClockStart();else StarFrontierRealtime.pauseFromNative();};
 const audioPrefsKey='starFrontierAudioSettingsV153';let prefs={seEnabled:true,seVolume:.25};
 try{Object.assign(prefs,JSON.parse(localStorage.getItem(audioPrefsKey)||'{}'));}catch(_){}
 function notify(text){if(typeof toast==='function')toast(text);}
 function validate(raw){
  if(typeof raw!=='string'||new TextEncoder().encode(raw).length>32*1024*1024)throw new Error('32 MiBを超えるセーブです');
  const o=JSON.parse(raw);
  if(!o||Array.isArray(o)||!Number.isInteger(Number(o.day))||Number(o.day)<1||typeof o.system!=='string'||!SYSTEMS[o.system]||!Number.isFinite(Number(o.credits))||o.gm!=null&&(typeof o.gm!=='object'||Array.isArray(o.gm)))throw new Error('有効なSTAR FRONTIERセーブではありません');
  return o;
 }
 function serializeGame(forceCompact=false){
  const t=performance?.now?.()??Date.now();v151CompactState(!!forceCompact);game.version='1.54.0';if(game.v151)game.v151.lastSaveError=null;
  const raw=JSON.stringify(game);validate(raw);const e=performance?.now?.()??Date.now();lastSerializeMs=Math.round((e-t)*10)/10;maxSerializeMs=Math.max(maxSerializeMs,lastSerializeMs);return raw;
 }
 function refreshBackupCount(){if(!native)return 0;try{cachedBackupCount=typeof AndroidNative.backupCountFast==='function'?AndroidNative.backupCountFast():AndroidNative.backupCount();}catch(_){cachedBackupCount=cachedBackupCount??0;}return cachedBackupCount;}
 function writePrimary(raw,checkpoint=false){
  if(native&&typeof AndroidNative.queueSave==='function'){
   if(!AndroidNative.queueSave(raw,!!checkpoint))throw new Error('ネイティブ保存キューを開始できません');p.state.raw=raw;saveCount++;
   if(checkpoint){lastCheckpointDay=game.day;cachedBackupCount=Math.min(5,(cachedBackupCount??0)+1);}return true;
  }
  localStorage.setItem(SAVE_KEY,raw);saveCount++;return true;
 }
 function flushAutosave(){
  saveTimer=null;if(!saveDirty||!ready||loading)return true;saveDirty=false;
  try{const raw=serializeGame(false),checkpoint=native&&game.day-lastCheckpointDay>=perf.checkpointDays;writePrimary(raw,checkpoint);if(game.v151){game.v151.lastSaveChars=raw.length;game.v151.lastSaveDay=game.day;}sfWriteBackupStatus();return true;}
  catch(e){if(game?.v151)game.v151.lastSaveError=String(e.message||e);notify('自動保存に失敗しました。前の正常セーブは保持されています。');return false;}
 }
 function scheduleSave(){
  if(!ready||loading)return false;if(!native)return oldSave();saveDirty=true;if(saveTimer!==null)return true;
  saveTimer=setTimeout(flushAutosave,perf.saveDelay);return true;
 }
 function saveNow(){
  if(!ready||loading)return false;if(!native)return oldSave();
  if(saveTimer!==null){clearTimeout(saveTimer);saveTimer=null;}saveDirty=false;
  try{const raw=serializeGame(false);p.unwrap(AndroidNative.writeSave(raw));p.state.raw=raw;saveCount++;lastCheckpointDay=game.day;refreshBackupCount();if(game.v151){game.v151.lastSaveChars=raw.length;game.v151.lastSaveDay=game.day;}sfWriteBackupStatus();return true;}
  catch(e){if(game?.v151)game.v151.lastSaveError=String(e.message||e);notify('保存に失敗しました。前の正常セーブは保持されています。');return false;}
 }
 save=function(){return loading||rendering?true:scheduleSave();};
 if(native)sfRotateBackup=function(raw,force=false){if(!ready||loading||!force)return false;try{p.unwrap(AndroidNative.backupSave(raw));refreshBackupCount();sfWriteBackupStatus();return true;}catch(e){notify('バックアップ保存に失敗しました');return false;}};
 if(native)sfBestRecoveryRaw=function(){return p.unwrap(AndroidNative.readBackup(1));};
 if(native)sfWriteBackupStatus=function(){const e=document.getElementById('sfBackupStatus');if(e)e.textContent=game?.v151?.lastSaveError?'保存に失敗：前の正常セーブを保持中':`端末ファイル保存 / バックアップ ${cachedBackupCount??'?'}世代（最大5） / ${nubia?'Nubia高速':'Universal'}プロファイル`;};
 function title(){document.title=`STAR FRONTIER v1.54.0 ${nubia?'Nubia Performance':'Universal'}`;const b=document.querySelector('header .title .badge');if(b)b.textContent='v1.54.0';const s=document.querySelector('header .sub');if(s)s.textContent=nubia?'Nubia Fold / Snapdragon 8 Elite・12GB 最適化':'Universal Performance Build / ハイブリッド介入 v1.54.0';document.documentElement.dataset.sfPerformanceProfile=profile;}
 render=function(){const outer=!rendering;let complete=false;rendering=true;try{const r=oldRender();title();complete=true;return r;}finally{rendering=!outer;if(complete&&outer&&ready&&!loading&&navigationDepth===0)scheduleSave();}};
 load=function(){
  loading=true;ready=false;p.state.ready=false;normalizationFailure=null;let expected=null;
  try{if(p.state.error)throw new Error(p.state.error);const raw=native?(p.state.staged!==undefined?p.state.staged:p.state.raw):localStorage.getItem(SAVE_KEY);expected=raw?validate(raw):null;
   oldLoad();if(normalizationFailure)throw normalizationFailure;
   if(expected&&game.day!==Number(expected.day))throw new Error('旧ロード処理で日付が変化しました。元データは保持されています');ready=true;p.state.ready=true;lastCheckpointDay=game.day;refreshBackupCount();title();
  }catch(e){StarFrontierRealtime.pauseFromNative();throw e;}finally{loading=false;}
  if(!expected||p.state.migrated){if(!saveNow())notify('起動しましたが保存できていません');}else scheduleSave();setActive(native?AndroidNative.isActive():!document.hidden);
 };
 function route(){return {tab:document.querySelector('main > .tab:not(.hidden)')?.id||'home',sub:document.querySelector('.gal-sub:not(.hidden)')?.id?.replace(/^gal-/,'')||'map',scroll:window.scrollY};}
 function remember(before){if(navigating)return;const after=route();if(before.tab!==after.tab||before.sub!==after.sub){history.push(before);if(history.length>perf.historyLimit)history.shift();}}
 showTab=function(id){const before=route();navigationDepth++;try{const r=oldShowTab(id);remember(before);return r;}finally{navigationDepth--;}};
 showGalaxy=function(id){const before=route();navigationDepth++;try{const r=oldShowGalaxy(id);remember(before);return r;}finally{navigationDepth--;}};
 function back(){
  if(document.getElementById('v138MajorEventRoot')?.classList.contains('show')){v138CloseMajorEvent();return true;}
  const dialog=document.querySelector('dialog[open]');if(dialog){dialog.close();return true;}
  const focused=document.activeElement;if(focused?.matches('input,textarea,select')){focused.blur();return true;}
  const previous=history.pop();navigating=true;
  try{if(previous){oldShowTab(previous.tab);if(previous.tab==='galaxy')oldShowGalaxy(previous.sub);window.scrollTo(0,previous.scroll);return true;}
   const current=route();if(current.tab==='galaxy'&&current.sub!=='map'){oldShowGalaxy('map');return true;}if(current.tab!=='home'){oldShowTab('home');return true;}return false;
  }finally{navigating=false;}
 }
 function resize(){if(resizeFrame)return;resizeFrame=requestAnimationFrame(()=>{resizeFrame=0;document.documentElement.style.setProperty('--sf-viewport-height',`${window.visualViewport?.height||innerHeight}px`);});}
 window.addEventListener('resize',resize,{passive:true});window.visualViewport?.addEventListener('resize',resize,{passive:true});resize();
 function stopScheduler(){if(audioTimer!==null){clearInterval(audioTimer);audioTimer=null;}if(v16AudioTimer!==null){clearInterval(v16AudioTimer);v16AudioTimer=null;}}
 function audioAllowed(){return ready&&active&&!document.hidden&&audioFocus;}
 async function syncAudio(){
  const epoch=++audioEpoch;stopScheduler();if(!v16AudioCtx)return;if(!audioAllowed()){await v16AudioCtx.suspend().catch(()=>{});return;}
  if(v16AudioCtx.state==='suspended')await v16AudioCtx.resume().catch(()=>{});if(epoch!==audioEpoch||!audioAllowed())return;
  v16AudioNext=v16AudioCtx.currentTime+.06;v16AudioMaster.gain.cancelScheduledValues(v16AudioCtx.currentTime);v16AudioMaster.gain.setTargetAtTime(game.audio?.enabled?Number(game.audio.volume??.32):0,v16AudioCtx.currentTime,.08);
  if(game.audio?.enabled){scheduleBgm();audioTimer=setInterval(()=>{if(audioAllowed())scheduleBgm();},120);}
 }
 initAudio=function(){if(v16AudioCtx)return true;const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return false;if(native&&!AndroidNative.requestAudioFocus()){audioFocus=false;return false;}audioFocus=true;v16AudioCtx=new AC();v16AudioMaster=v16AudioCtx.createGain();v16AudioMaster.gain.value=0;v16AudioMaster.connect(v16AudioCtx.destination);v16AudioNext=v16AudioCtx.currentTime+.08;v16AudioStep=0;return true;};
 synthNote=function(freq,start,dur,type,gain,cut=1800){if(!v16AudioCtx||!v16AudioMaster||!audioAllowed())return;
  const o=v16AudioCtx.createOscillator(),g=v16AudioCtx.createGain(),f=v16AudioCtx.createBiquadFilter();o.type=type;o.frequency.setValueAtTime(freq,start);f.type='lowpass';f.frequency.setValueAtTime(cut,start);g.gain.setValueAtTime(.0001,start);g.gain.exponentialRampToValueAtTime(Math.max(.0002,gain),start+.025);g.gain.exponentialRampToValueAtTime(.0001,start+dur);o.connect(f);f.connect(g);g.connect(v16AudioMaster);liveNodes+=3;maxNodes=Math.max(maxNodes,liveNodes);o.onended=()=>{o.disconnect();f.disconnect();g.disconnect();o.onended=null;liveNodes-=3;};o.start(start);o.stop(start+dur+.04);
 };
 toggleBGM=async function(){ensureV16State();if(!initAudio())return;game.audio.enabled=!game.audio.enabled;await syncAudio();updateBgmButton();renderBgmControl();saveNow();};
 setBgmVolume=function(v){ensureV16State();game.audio.volume=clamp(Number(v),0,.65);if(v16AudioCtx)v16AudioMaster.gain.setTargetAtTime(game.audio.enabled?game.audio.volume:0,v16AudioCtx.currentTime,.05);scheduleSave();};
 const oldBgmControl=renderBgmControl;
 renderBgmControl=function(){oldBgmControl();const el=document.getElementById('bgmControl');if(!el)return;const div=document.createElement('div');div.className='gm-row';div.innerHTML=`<label><input id="sf-se-enabled" type="checkbox" ${prefs.seEnabled?'checked':''}> SEを再生</label><label>SE音量 <input id="sf-se-volume" type="range" min="0" max="1" step="0.05" value="${clamp(Number(prefs.seVolume)||0,0,1)}"></label>`;el.appendChild(div);div.querySelector('#sf-se-enabled').onchange=e=>setSE(e.target.checked,prefs.seVolume);div.querySelector('#sf-se-volume').oninput=e=>setSE(prefs.seEnabled,Number(e.target.value));};
 function setSE(enabled,volume){prefs={seEnabled:!!enabled,seVolume:clamp(Number(volume)||0,0,1)};try{localStorage.setItem(audioPrefsKey,JSON.stringify(prefs));}catch(_){notify('音声設定の保存に失敗');}}
 function playSE(){if(!prefs.seEnabled||!audioAllowed()||!initAudio())return;if(v16AudioCtx.state!=='running'){syncAudio();return;}
  const o=v16AudioCtx.createOscillator(),g=v16AudioCtx.createGain(),t=v16AudioCtx.currentTime;o.type='sine';o.frequency.setValueAtTime(660,t);o.frequency.exponentialRampToValueAtTime(440,t+.05);g.gain.setValueAtTime(Math.max(.0001,prefs.seVolume*.08),t);g.gain.exponentialRampToValueAtTime(.0001,t+.065);o.connect(g);g.connect(v16AudioCtx.destination);liveNodes+=2;maxNodes=Math.max(maxNodes,liveNodes);o.onended=()=>{o.disconnect();g.disconnect();o.onended=null;liveNodes-=2;};o.start(t);o.stop(t+.07);
 }
 document.addEventListener('click',e=>{if(e.target.closest('button'))playSE();},{passive:true});
 function setActive(value){const next=!!value&&!document.hidden&&(!native||AndroidNative.isActive());const changed=next!==active;active=next;
  if(!next){StarFrontierRealtime.pauseFromNative();if(changed&&ready)saveNow();}else if(ready){StarFrontierRealtime.resumeFromNative();if(v16AudioCtx&&native)audioFocus=AndroidNative.requestAudioFocus();}syncAudio();
 }
 document.addEventListener('visibilitychange',()=>setActive(!document.hidden));window.addEventListener('pagehide',()=>setActive(false));window.addEventListener('pageshow',()=>setActive(!document.hidden));
 function importRaw(raw){
  if(!ready)return false;let input;try{input=validate(raw);}catch(e){notify(`読み込みを中止しました：${e.message}`);return false;}
  const previous=game,priorRaw=p.state.raw;let succeeded=false;StarFrontierRealtime.pauseFromNative();loading=true;
  try{p.state.staged=raw;p.state.ready=false;normalizationFailure=null;
   if(native){oldLoad();if(normalizationFailure)throw normalizationFailure;if(game.day!==Number(input.day))throw new Error('セーブ移行に失敗');}
   else{game=normalize(migrate(input));initV10();refreshMarket(false);ensureMilitaryContent();ensureStationOrders();mapSelected=game.system;render();}
   if(v151Validate().length)throw new Error('状態の整合性を確認できませんでした');loading=false;p.state.ready=true;if(!saveNow())throw new Error('保存に失敗');
   history.length=0;navigating=true;oldShowTab('home');navigating=false;notify('セーブを読み込みました');succeeded=true;
  }catch(e){game=previous;p.state.raw=priorRaw;notify(`読み込みを中止しました：${e.message}`);}
  finally{p.state.ready=true;p.state.staged=undefined;navigating=false;loading=!succeeded;try{render();}finally{loading=false;}setActive(active);}return succeeded;
 }
 StarFrontierSaveTools.makeBackup=function(){if(!saveNow())return false;const ok=sfRotateBackup(p.state.raw||JSON.stringify(game),true);notify(ok?'バックアップを作成しました':'バックアップを作成できませんでした');return ok;};
 StarFrontierSaveTools.exportSave=function(){if(!ready)return;if(!saveNow())return;const raw=native&&p.state.raw?p.state.raw:JSON.stringify(game);if(native){AndroidNative.exportSave(raw);return;}const url=URL.createObjectURL(new Blob([raw],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=`STAR_FRONTIER_Day_${game.day}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
 StarFrontierSaveTools.receiveImport=importRaw;
 StarFrontierSaveTools.restoreBackup=function(slot=1){try{const raw=native?p.unwrap(AndroidNative.readBackup(slot)):localStorage.getItem(SF_BACKUP_KEYS[slot-1]);if(!raw)return notify('復元可能なバックアップがありません');if(confirm(`Day ${validate(raw).day}のバックアップに戻しますか？`))return importRaw(raw);}catch(e){notify('バックアップを読み込めません');}return false;};
 const originalReset=resetGame;
 resetGame=function(){if(!native)return originalReset();if(!confirm('新しい航海を開始しますか？現在のセーブは世代バックアップに保持されます。'))return;const previous=game;loading=true;try{game=newGame();initV10();refreshMarket(true);ensureStationOrders();mapSelected='aurora';}finally{loading=false;}if(!saveNow())game=previous;history.length=0;showTab('home');render();};
 function trimHiddenDom(level){
  const aggressive=!nubia||level>=80,targets=['shipyard','classList','speciesList','factionList','gmFactionList','corporationList','corporateOffers','corporateContracts'];if(!aggressive)return 0;let cleared=0;
  for(const id of targets){const e=document.getElementById(id);if(!e||!e.children.length)continue;const tab=e.closest('main > .tab'),sub=e.closest('.gal-sub');if(tab?.classList.contains('hidden')||sub?.classList.contains('hidden')){e.replaceChildren();cleared++;}}
  return cleared;
 }
 function memoryPressure(level){trimHiddenDom(Number(level)||0);if(history.length>8)history.splice(0,history.length-8);}
 function nativeSaveError(){try{const st=native&&typeof AndroidNative.saveStatus==='function'?JSON.parse(AndroidNative.saveStatus()):null;if(st?.error){if(game?.v151)game.v151.lastSaveError=st.error;sfWriteBackupStatus();}}catch(_){}}
 window.StarFrontierAndroid={build:'1.54.0',profile,saveNow,back,resize,setActive,setSE,playSE,memoryPressure,nativeSaveError,

  audioFocus(value){audioFocus=!!value;syncAudio();},
  receiveNativeImport(){if(!ready)return;try{const raw=p.unwrap(AndroidNative.consumeImport());if(raw&&confirm(`Day ${validate(raw).day}のセーブを読み込みますか？現在の状態はバックアップに保持されます。`))importRaw(raw);}catch(e){notify('セーブファイルを読み込めません');}},
  diagnostics(){let nativeSave=null;try{nativeSave=native&&typeof AndroidNative.saveStatus==='function'?JSON.parse(AndroidNative.saveStatus()):null;}catch(_){}return {build:'1.54.0',profile,ready,native,active,history:history.length,saveCount,day:game?.day,nodes:document.getElementsByTagName('*').length,save:{dirty:saveDirty,timer:saveTimer!==null,lastSerializeMs,maxSerializeMs,checkpointEveryDays:perf.checkpointDays,native:nativeSave},audio:{state:v16AudioCtx?.state||'uninitialized',timer:audioTimer!==null,liveNodes,maxNodes,se:prefs},realtime:StarFrontierRealtime.status()};}
 };
})();
