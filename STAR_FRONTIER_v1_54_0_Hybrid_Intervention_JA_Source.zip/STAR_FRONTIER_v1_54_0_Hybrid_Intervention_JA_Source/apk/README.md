v1.54.0 APKはこのソースZIPには同梱していません。GitHub ActionsまたはAndroid SDK環境で `assembleNubiaDebug` / `assembleUniversalDebug` を実行してください。
