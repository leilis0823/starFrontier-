'use strict';
// ============================================================================
// v1.76.0 — Mining, ore bodies, elemental refining and mining-vessel salvage
// Extends the existing mining loop without creating a parallel finance/logistics
// economy.  Refined elements feed the v1.69 commodity benchmark layer; piracy
// uses the v1.40 legal system and existing combat/cargo mechanics.
// ============================================================================
const V176_BUILD='1.76.0';

const V176_ELEMENTS={
 aluminum:{name:'アルミニウム',symbol:'Al',icon:'▱',base:92,unit:'t',consumers:['aerospace','aero_parts','infrastructure','airport_operator']},
 copper:{name:'銅',symbol:'Cu',icon:'◫',base:108,unit:'t',consumers:['energy','data','infrastructure','aero_parts']},
 nickel:{name:'ニッケル',symbol:'Ni',icon:'⬟',base:146,unit:'t',consumers:['aero_engine','shipbuilding','energy','arms']},
 cobalt:{name:'コバルト',symbol:'Co',icon:'⬢',base:238,unit:'t',consumers:['aero_engine','energy','research','data']},
 lithium:{name:'リチウム',symbol:'Li',icon:'◇',base:205,unit:'t',consumers:['energy','data','aerospace','research']},
 uranium:{name:'ウラン',symbol:'U',icon:'☢',base:355,unit:'t',consumers:['energy','shipbuilding','research']},
 rare_earth:{name:'希土類元素',symbol:'REE',icon:'✦',base:315,unit:'t',consumers:['data','research','aerospace','aero_engine','aero_parts']},
 platinum:{name:'白金族元素',symbol:'PGM',icon:'♢',base:510,unit:'t',consumers:['aero_engine','research','biotech','energy']},
 silicon:{name:'高純度シリコン',symbol:'Si',icon:'⬡',base:128,unit:'t',consumers:['data','research','aero_parts','energy']},
 thorium:{name:'トリウム',symbol:'Th',icon:'☼',base:270,unit:'t',consumers:['energy','research']}
};

// Fractions are recoverable material mass per raw-ore cargo unit before recovery loss.
const V176_ORES={
 hematite:{name:'赤鉄鉱',icon:'⬛',rarity:'普通',base:42,composition:{iron:.78},tags:['Fe','鉄鋼']},
 ilmenite:{name:'チタン鉄鉱',icon:'◈',rarity:'普通',base:72,composition:{titanium:.32,iron:.34},tags:['Ti','Fe']},
 bauxite:{name:'ボーキサイト',icon:'▰',rarity:'普通',base:66,composition:{aluminum:.48},tags:['Al']},
 chalcopyrite:{name:'黄銅鉱',icon:'◆',rarity:'普通',base:82,composition:{copper:.34,iron:.25},tags:['Cu','Fe']},
 pentlandite:{name:'ペントランド鉱',icon:'⬟',rarity:'やや希少',base:118,composition:{nickel:.30,cobalt:.05,iron:.20},tags:['Ni','Co','Fe']},
 spodumene:{name:'スポジュメン',icon:'◇',rarity:'やや希少',base:136,composition:{lithium:.08,aluminum:.14,silicon:.20},tags:['Li','Al','Si']},
 uraninite:{name:'閃ウラン鉱',icon:'☢',rarity:'希少',base:205,composition:{uranium:.68},tags:['U']},
 monazite:{name:'モナズ石',icon:'✦',rarity:'希少',base:225,composition:{rare_earth:.38,thorium:.06},tags:['REE','Th']},
 pgm_ore:{name:'白金族鉱石',icon:'♢',rarity:'極希少',base:330,composition:{platinum:.09,nickel:.14},tags:['Pt/Pd','Ni']},
 silicate:{name:'高品位珪酸塩鉱',icon:'⬡',rarity:'普通',base:74,composition:{silicon:.46,aluminum:.08},tags:['Si','Al']},
 star_matrix:{name:'星晶母岩',icon:'✧',rarity:'希少',base:260,composition:{crystal:.30,rare_earth:.10},tags:['星晶','REE']}
};

const V176_ORE_BIAS={
 aurora:{bauxite:1.25,chalcopyrite:1.25,silicate:1.15},
 orion:{spodumene:1.45,silicate:1.35,chalcopyrite:1.15},
 forge:{hematite:1.45,ilmenite:1.25,bauxite:1.20},
 nyx:{star_matrix:1.55,uraninite:1.38,pgm_ore:1.34,monazite:1.26},
 elysia:{spodumene:1.25,monazite:1.30,silicate:1.15},
 verdant:{spodumene:1.50,monazite:1.42,star_matrix:1.18},
 umbra:{silicate:1.20,chalcopyrite:1.10,pgm_ore:1.08},
 bastion:{ilmenite:1.45,hematite:1.30,pentlandite:1.32},
 drakon:{ilmenite:1.52,pentlandite:1.48,uraninite:1.18},
 cinder:{hematite:1.52,pentlandite:1.42,chalcopyrite:1.28,pgm_ore:1.18},
 meridian:{chalcopyrite:1.38,bauxite:1.22,silicate:1.22},
 halcyon:{star_matrix:1.75,monazite:1.44,spodumene:1.18},
 kronos:{uraninite:1.62,pentlandite:1.40,monazite:1.20,ilmenite:1.18}
};

function v176Clamp(n,a=0,b=100){return Math.max(a,Math.min(b,n))}
function v176Round(n,p=1){const m=10**p;return Math.round((Number(n)||0)*m)/m}
function v176State(){
 const x=game.miningV176=game.miningV176||{version:1,ores:{},elements:{},survey:{},selectedOre:null,deposits:{},traffic:[],trafficEnsured:{},wrecks:[],history:[],metrics:{mined:0,refined:0,elementOutput:0,minerAttacks:0,legalRaids:0,piracy:0,lootValue:0},marketSupply:{},lastTrafficDay:game.day-1,lastDepletionDay:game.day-1,lastPaidCombatDay:null};
 x.ores=x.ores||{};x.elements=x.elements||{};x.survey=x.survey||{};x.deposits=x.deposits||{};x.traffic=Array.isArray(x.traffic)?x.traffic:[];x.trafficEnsured=x.trafficEnsured||{};x.wrecks=Array.isArray(x.wrecks)?x.wrecks:[];x.history=Array.isArray(x.history)?x.history:[];x.metrics=x.metrics||{};x.marketSupply=x.marketSupply||{};
 for(const k of Object.keys(V176_ORES))x.ores[k]=Math.max(0,Number(x.ores[k])||0);
 for(const k of Object.keys(V176_ELEMENTS)){x.elements[k]=Math.max(0,Number(x.elements[k])||0);x.marketSupply[k]=Math.max(0,Number(x.marketSupply[k])||0)}
 for(const k of ['mined','refined','elementOutput','minerAttacks','legalRaids','piracy','lootValue'])x.metrics[k]=Number(x.metrics[k])||0;
 for(const sid of Object.keys(SYSTEMS||{}))v176EnsureDeposits(sid,x);
 return x
}
function v176Hash(s){let h=2166136261;for(const c of String(s)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return((h>>>0)%10000)/10000}
function v176OreWeight(sid,k){
 const s=SYSTEMS[sid]||{},y=s.yield||{},bias=V176_ORE_BIAS[sid]?.[k]||1;
 let w=12;
 if(k==='hematite')w=18+(y.iron||40)*.85;
 else if(k==='ilmenite')w=15+(y.titanium||30)*.88+(y.iron||40)*.12;
 else if(k==='star_matrix')w=7+(y.crystal||10)*1.6;
 else if(k==='bauxite')w=22+(y.iron||40)*.18;
 else if(k==='chalcopyrite')w=20+(y.iron||40)*.15;
 else if(k==='pentlandite')w=13+(y.titanium||30)*.22;
 else if(k==='spodumene')w=11+(y.crystal||10)*.25;
 else if(k==='uraninite')w=6+(y.crystal||10)*.15;
 else if(k==='monazite')w=7+(y.crystal||10)*.35;
 else if(k==='pgm_ore')w=4+(y.titanium||30)*.12;
 else if(k==='silicate')w=24;
 return Math.max(1,w*bias)
}
function v176EnsureDeposits(sid,x=v176State()){
 if(x.deposits[sid])return x.deposits[sid];
 const d={};
 for(const k of Object.keys(V176_ORES)){
  const w=v176OreWeight(sid,k),seed=v176Hash(`${sid}:${k}:reserve`);
  d[k]=v176Clamp(28+w*.72+seed*26,18,100);
 }
 x.deposits[sid]=d;return d
}
function v176WeightedOre(sid=game.system){
 const x=v176State(),d=v176EnsureDeposits(sid,x),rows=Object.keys(V176_ORES).map(k=>({k,w:v176OreWeight(sid,k)*(.25+d[k]/100)}));
 const total=rows.reduce((n,o)=>n+o.w,0),r=rng()*total;let a=0;for(const o of rows){a+=o.w;if(r<=a)return o.k}return rows[0].k
}
function v176Survey(sid=game.system,force=false){
 const x=v176State(),old=x.survey[sid];if(old&&!force&&old.day===game.day)return old;
 const dep=v176EnsureDeposits(sid,x),rows=Object.keys(V176_ORES).map(k=>{const noise=.82+rng()*.38,score=v176OreWeight(sid,k)*noise*(.35+dep[k]/100);return{k,score,grade:v176Clamp(72+rng()*47+(dep[k]-50)*.14,58,135),reserve:dep[k]}}).sort((a,b)=>b.score-a.score).slice(0,5);
 const out={day:game.day,rows};x.survey[sid]=out;if(!x.selectedOre||!rows.some(r=>r.k===x.selectedOre))x.selectedOre=rows[0]?.k||null;
 x.history.unshift({day:game.day,type:'survey',system:sid,text:`${SYSTEMS[sid]?.name||sid}で鉱床スペクトルを更新`});x.history=x.history.slice(0,100);return out
}
function v176SelectOre(k){if(!V176_ORES[k])return;v176State().selectedOre=k;toast?.(`${V176_ORES[k].name}を採掘対象に設定`);render?.()}
function v176RawOreUnits(){return Object.values(v176State().ores).reduce((a,b)=>a+(Number(b)||0),0)}
function v176ElementVolume(){return Object.values(v176State().elements).reduce((a,b)=>a+(Number(b)||0)*.5,0)}
const v176CargoUsedBase=typeof cargoUsed==='function'?cargoUsed:null;
if(v176CargoUsedBase)cargoUsed=function(){return v176Round(v176CargoUsedBase()+v176RawOreUnits()+v176ElementVolume(),1)};

function v176MineCore(silent=false,acc=null){
 const x=v176State();if(game.fuel<2){if(!silent){addLog('燃料不足で採掘できない。');toast('燃料不足');render()}return false}if(cargoFree()<1){if(!silent){addLog('船倉が満杯だ。');toast('船倉が満杯');render()}return false}
 const survey=v176Survey(game.system),available=survey.rows.map(r=>r.k),k=available.includes(x.selectedOre)?x.selectedOre:v176WeightedOre(game.system),row=survey.rows.find(r=>r.k===k),grade=(row?.grade||90)/100,dep=v176EnsureDeposits(game.system,x),bonus=miningBonus();
 game.fuel-=2;let n=Math.max(1,1+Math.floor(rng()*3)+bonus);n=Math.max(1,Math.round(n*grade));n=Math.min(n,Math.max(1,Math.floor(cargoFree())));x.ores[k]=v176Round((x.ores[k]||0)+n,1);x.metrics.mined+=n;dep[k]=Math.max(0,dep[k]-n*.045);if(acc)acc[k]=(acc[k]||0)+n;
 const primary=Object.keys(V176_ORES[k].composition).find(e=>['iron','titanium','crystal'].includes(e))||'iron';try{gmObserve({type:'mine',faction:SYSTEMS[game.system].faction,resource:primary,amount:n})}catch(_){}
 if(!silent){addLog(`${V176_ORES[k].name}を ${n} units 採掘した（品位指数 ${Math.round((row?.grade||90))}）。`);toast(`${V176_ORES[k].name} +${n}`);render()}return true
}
const v176MineOnceLegacy=typeof mineOnce==='function'?mineOnce:null;
if(v176MineOnceLegacy)mineOnce=function(silent=false,acc=null){return v176MineCore(silent,acc)};
if(typeof mineBatch==='function')mineBatch=function(){const a={};let runs=0;for(let i=0;i<5;i++){if(!v176MineCore(true,a))break;runs++}const text=Object.entries(a).map(([k,n])=>`${V176_ORES[k]?.name||k} ${n}`).join('、');addLog(text?`連続採掘${runs}回：${text}`:'連続採掘できなかった。');toast(runs?`${runs}回採掘完了`:'採掘できません');render()};

function v176HasRefinery(sid=game.system){return (game.stations||[]).some(s=>s.system===sid&&!s.destroyed&&(s.modules||[]).includes('refinery'))}
function v176AddProduct(k,n){n=v176Round(n,1);if(n<=0)return;if(['iron','titanium','crystal'].includes(k)){game.cargo[k]=v176Round((game.cargo[k]||0)+n,1)}else if(V176_ELEMENTS[k]){const x=v176State();x.elements[k]=v176Round((x.elements[k]||0)+n,1)}}
function v176RefineOre(k,qty=null,industrial=true){
 const x=v176State(),ore=V176_ORES[k];if(!ore)return false;const have=x.ores[k]||0;qty=Math.min(have,qty==null?have:Math.max(0,Number(qty)||0));if(qty<=0)return false;
 if(industrial&&!v176HasRefinery()){toast?.('この星系に利用可能な精錬所がない');return false}
 const recovery=industrial?.94:.62,fee=industrial?Math.ceil(qty*12):0;if(fee>game.credits){toast?.('精錬手数料が不足');return false}
 if(fee)game.credits-=fee;x.ores[k]=v176Round(have-qty,1);let out=0;for(const [e,f] of Object.entries(ore.composition)){const n=qty*f*recovery;v176AddProduct(e,n);out+=n}x.metrics.refined+=qty;x.metrics.elementOutput+=out;x.history.unshift({day:game.day,type:'refine',ore:k,qty,industrial,output:v176Round(out,1)});addLog(`${ore.name} ${v176Round(qty,1)}を${industrial?'工業精錬':'船内簡易選鉱'}。回収 ${v176Round(out,1)} units${fee?` / 手数料 ${fee.toLocaleString()} Cr`:''}。`);toast?.('精錬完了');render?.();return true
}
function v176RefineAll(industrial=true){const x=v176State();let n=0;for(const k of Object.keys(V176_ORES))if((x.ores[k]||0)>0){if(industrial&&!v176HasRefinery())break;const before=x.ores[k];if(v176RefineOre(k,before,industrial))n+=before}if(!n)toast?.(industrial?'精錬可能な鉱石または精錬所がありません':'選鉱可能な鉱石がありません')}

function v176ElementPrice(k){const m=V176_ELEMENTS[k];if(!m)return 0;try{const b=v169State?.().benchmarks?.[k];if(b?.spot)return Math.max(5,b.spot*(typeof gmPriceMult==='function'?gmPriceMult(game.system,null):1))}catch(_){}return m.base}
function v176OrePrice(k){const ore=V176_ORES[k];if(!ore)return 0;let v=0;for(const [e,f] of Object.entries(ore.composition)){let p;if(e==='iron'||e==='titanium'||e==='crystal')p=game.prices?.[game.system]?.[e]||SYSTEMS[game.system]?.base?.[e]||80;else p=v176ElementPrice(e);v+=p*f}return Math.max(8,Math.round(v*.62))}
function v176SellOre(k,qty=1){const x=v176State(),n=Math.min(x.ores[k]||0,Math.max(0,Number(qty)||0));if(n<=0)return;const rev=Math.round(v176OrePrice(k)*n);x.ores[k]=v176Round(x.ores[k]-n,1);game.credits+=rev;addLog(`${V176_ORES[k].name} ${v176Round(n,1)}を未精錬鉱として ${rev.toLocaleString()} Crで売却。`);toast?.(`+${rev.toLocaleString()} Cr`);render?.()}
function v176SellElement(k,qty=1){const x=v176State(),n=Math.min(x.elements[k]||0,Math.max(0,Number(qty)||0));if(n<=0)return;const rev=Math.round(v176ElementPrice(k)*n*.94);x.elements[k]=v176Round(x.elements[k]-n,1);x.marketSupply[k]=v176Round((x.marketSupply[k]||0)+n,1);game.credits+=rev;addLog(`${V176_ELEMENTS[k].name} ${v176Round(n,1)}を ${rev.toLocaleString()} Crで売却。`);toast?.(`+${rev.toLocaleString()} Cr`);render?.()}

// Integrate new refined elements into the existing v1.69 benchmark/futures layer.
if(typeof V169_COMMODITIES!=='undefined'){
 for(const [k,m] of Object.entries(V176_ELEMENTS))if(!V169_COMMODITIES[k])V169_COMMODITIES[k]={name:`${m.name} (${m.symbol})`,icon:m.icon,unit:m.unit,base:m.base,vol:(k==='platinum'||k==='uranium')?.055:.038,carry:.038,producerIndustries:['mining'],consumerIndustries:m.consumers};
}
function v176ElementReserveFactor(element){const ores=Object.entries(V176_ORES).filter(([,o])=>Object.prototype.hasOwnProperty.call(o.composition,element));if(!ores.length)return 1;const x=v176State();let n=0,c=0;for(const sid of Object.keys(SYSTEMS)){const d=v176EnsureDeposits(sid,x);for(const [k] of ores){n+=d[k]||0;c++}}const avg=c?n/c:60;return v176Clamp(.62+avg/150,.55,1.18)}
if(typeof v169DemandSupply==='function'){const v176DSBase=v169DemandSupply;v169DemandSupply=function(k){const o=v176DSBase(k);if(V176_ELEMENTS[k]){const flow=v176State().marketSupply[k]||0;o.supply=v176Clamp(o.supply*v176ElementReserveFactor(k)+Math.min(32,flow*1.25),25,175)}return o}}

function v176MiningFaction(sid){const f=SYSTEMS[sid]?.faction;if(f&&f!=='unclaimed')return f;const r=rng();return r<.48?'nyxdom':r<.78?'league':'imperium'}
function v176TrafficName(owner,hullId){const p=owner==='league'?'自由採鉱':owner==='nyxdom'?'辺境採鉱':owner==='imperium'?'帝政鉱業':owner==='helios'?'統合資源':owner==='volgar'?'復興資源':owner==='concord'?'協約採集':'民間鉱業';return `${p}船 ${HULLS[hullId]?.name||'採掘船'}`}
function v176SpawnMiner(sid=game.system,forced=false){
 const x=v176State();if(!SYSTEMS[sid])return null;const active=x.traffic.filter(t=>t.system===sid&&t.status==='active'&&t.expires>=game.day);if(!forced&&active.length>=2)return null;
 const owner=v176MiningFaction(sid),roll=rng(),hullId=roll<.48?'pathfinder':roll<.84?'mole':(HULLS.corp_nox_extractor?'corp_nox_extractor':'mole'),ore=v176WeightedOre(sid),reserve=v176EnsureDeposits(sid,x)[ore],qty=Math.max(5,Math.round((6+rng()*22)*(.55+reserve/120))),escort=Math.round(8+rng()*25+(SYSTEMS[sid].security==='軍管'?8:0)),t={id:`miner-${game.day}-${Math.floor(rng()*1e8)}`,system:sid,owner,hullId,name:v176TrafficName(owner,hullId),cargo:{[ore]:qty},escort,status:'active',spawned:game.day,expires:game.day+3,value:Math.round(v176OrePrice(ore)*qty),integrity:100};x.traffic.unshift(t);x.traffic=x.traffic.slice(0,36);return t
}
function v176EnsureTraffic(sid=game.system,force=false){const x=v176State();x.traffic=x.traffic.filter(t=>t.expires>=game.day&&t.status!=='expired');x.wrecks=x.wrecks.filter(w=>w.expires>=game.day&&!w.empty);if(!force&&x.trafficEnsured[sid]===game.day)return;x.trafficEnsured[sid]=game.day;while(x.traffic.filter(t=>t.system===sid&&t.status==='active'&&t.expires>=game.day).length<2){const t=v176SpawnMiner(sid,true);if(!t)break}}
function v176IsLegalRaid(owner){
 // Mining-vessel seizure is lawful only against the actual opposing belligerent,
 // or the explicit enemy named in a currently accepted military contract.
 // This is deliberately stricter than the legacy legalCapture() helper, which
 // treats any non-own faction as capturable while the player's faction is at war.
 try{
  const cf=game.career?.faction;
  if(cf&&game.war?.active&&(cf===game.war.a||cf===game.war.b)){
   const enemy=cf===game.war.a?game.war.b:game.war.a;
   return owner===enemy;
  }
  const c=game.career?.activeContract&&game.contracts?.find(q=>q.id===game.career.activeContract);
  return !!(c&&c.enemy===owner);
 }catch(_){return false}
}
function v176RecordRaidCrime(owner,value){const x=v176State(),jur=typeof v140Jurisdiction==='function'?v140Jurisdiction(game.system):null;x.metrics.piracy++;try{gmRel(owner,-7,'民間採掘船への襲撃')}catch(_){}if(game.freeCaptains)game.freeCaptains.heat=v176Clamp((game.freeCaptains.heat||0)+7,0,100);if(jur&&typeof v140RecordOffense==='function')v140RecordOffense(jur,'piracy',value,game.system)}
function v176AttackMiner(id,mode='board'){
 const x=v176State(),t=x.traffic.find(q=>q.id===id&&q.status==='active');if(!t||t.system!==game.system)return;if(game.career?.faction===t.owner){toast?.('所属国の採掘船は攻撃できない');return}
 const legal=v176IsLegalRaid(t.owner),power=combatPower(),capture=(game.loadouts?.[game.hull]||[]).includes('capture')?9:0,marine=typeof crewBonus==='function'?crewBonus('marine'):0,base=mode==='board'?.32:.50,ch=v176Clamp(base+(power-t.escort)/170+capture/100+marine/260,.08,.94),ok=rng()<ch;x.metrics.minerAttacks++;
 if(ok){const survival=mode==='board'?(.78+rng()*.20):(.34+rng()*.36),cargo={};for(const [k,n] of Object.entries(t.cargo||{}))cargo[k]=Math.max(0,Math.round(n*survival));t.status=mode==='board'?'boarded':'destroyed';t.integrity=mode==='board'?Math.round(45+rng()*35):Math.round(5+rng()*20);const w={id:`mw-${game.day}-${Math.floor(rng()*1e8)}`,system:t.system,owner:t.owner,hullId:t.hullId,cargo,integrity:t.integrity,mode,expires:game.day+4,empty:false};x.wrecks.unshift(w);if(legal){x.metrics.legalRaids++;if(game.career?.faction)game.career.merit=(game.career.merit||0)+4}else v176RecordRaidCrime(t.owner,t.value||0);if(mode==='board'&&t.integrity>=50&&(game.loadouts?.[game.hull]||[]).includes('capture')&&rng()<.12&&typeof addPrizeShip==='function'){const p=addPrizeShip(t.hullId,t.owner,t.integrity,'mining_capture');addLog(`${t.name}を無力化。積荷を確保し、さらに${p.name}を鹵獲船として登録した。`)}else addLog(`${t.name}を${mode==='board'?'無力化・接舷':'撃沈'}。残存鉱石貨物を回収可能。`);toast?.('採掘船襲撃成功')
 }else{t.status='escaped';const dmg=Math.round((mode==='board'?8:5)+rng()*(mode==='board'?18:13));damageShip(dmg);if(!legal)v176RecordRaidCrime(t.owner,Math.round((t.value||0)*.35));addLog(`${t.name}への襲撃に失敗。対象は離脱し、自艦が${dmg}%相当損傷。`);toast?.('襲撃失敗')}
 render?.()
}
function v176LootMiningWreck(id){const x=v176State(),w=x.wrecks.find(q=>q.id===id&&!q.empty);if(!w||w.system!==game.system)return;let got=[],value=0;for(const [k,n0] of Object.entries(w.cargo||{})){const n=Math.min(n0,Math.max(0,Math.floor(cargoFree())));if(n>0){x.ores[k]=v176Round((x.ores[k]||0)+n,1);w.cargo[k]-=n;got.push(`${V176_ORES[k]?.name||k} ${n}`);value+=v176OrePrice(k)*n}}w.empty=Object.values(w.cargo||{}).every(n=>n<=0);x.metrics.lootValue+=Math.round(value);addLog(`${HULLS[w.hullId]?.name||'採掘船'}残骸から${got.length?got.join('、'):'船倉に空きがなく回収不能'}。`);toast?.(got.length?'鉱石貨物を鹵獲':'回収できません');render?.()}

function v176ProcessDepletion(){const x=v176State();if(x.lastDepletionDay===game.day)return;x.lastDepletionDay=game.day;for(const sid of Object.keys(SYSTEMS)){const d=v176EnsureDeposits(sid,x),miners=Object.values(game.gm.enterpriseEconomy?.enterprises||{}).filter(e=>(e.home===sid||e.locationSystem===sid)&&e.industry==='mining'&&e.status==='operating').length;if(!miners)continue;for(const k of Object.keys(d))d[k]=Math.max(0,d[k]-miners*.0025*(.65+v176OreWeight(sid,k)/70))}}
function v176ProcessDaily(){const x=v176State();v176ProcessDepletion();for(const k of Object.keys(V176_ELEMENTS))x.marketSupply[k]=v176Round((x.marketSupply[k]||0)*.35,1);for(const t of x.traffic)if(t.status==='active'&&t.expires<game.day)t.status='expired';for(const sid of Object.keys(SYSTEMS))if(rng()<.12)v176SpawnMiner(sid,false);x.traffic=x.traffic.slice(0,36);x.wrecks=x.wrecks.slice(0,24);x.history=x.history.slice(0,100);game.version=V176_BUILD}

function v176BestOreRows(){const survey=v176Survey(game.system),avgYield=Math.max(1,2+miningBonus()),rows=survey.rows.map(r=>({k:r.k,grade:r.grade,perRun:v176OrePrice(r.k)*avgYield*(r.grade/100)}));return rows.sort((a,b)=>b.perRun-a.perRun)}
function v176MoneyGuide(){
 const x=v176State(),best=v176BestOreRows()[0],order=(game.stationOrders||[]).filter(o=>!o.done&&o.expires>=game.day).map(o=>{const yard=shipyardStations?.()[0];return{pay:yard?Math.round(o.pay*orderProfitBonus(yard)):o.pay,type:o.type}}).sort((a,b)=>b.pay-a.pay)[0],contract=(game.contracts||[]).filter(c=>c.expires>=game.day).sort((a,b)=>b.reward-a.reward)[0],loot=x.traffic.filter(t=>t.system===game.system&&t.status==='active').sort((a,b)=>(b.value||0)-(a.value||0))[0];
 return{bestOre:best?{name:V176_ORES[best.k].name,expected:Math.round(best.perRun),price:v176OrePrice(best.k)}:null,shipyard:order||null,military:contract?{name:contract.name,reward:contract.reward,system:contract.system}:null,miner:loot?{name:loot.name,value:loot.value,legal:v176IsLegalRaid(loot.owner)}:null}
}

function v176OreCargoHtml(){const x=v176State(),rows=Object.entries(V176_ORES).filter(([k])=>(x.ores[k]||0)>0).sort((a,b)=>v176OrePrice(b[0])-v176OrePrice(a[0]));if(!rows.length)return'<div class="hint">未精錬鉱石はありません。</div>';return rows.map(([k,o])=>`<div class="market-row"><div><b>${o.icon} ${escapeHtml(o.name)}</b><div class="own">保有 ${v176Round(x.ores[k],1)} / 原鉱売価 ${v176OrePrice(k).toLocaleString()} Cr/u<br>${o.tags.join('・')}</div></div><div class="mini-stack"><button class="mini" onclick="v176RefineOre('${k}',${x.ores[k]},false)">船内選鉱</button><button class="mini good" onclick="v176RefineOre('${k}',${x.ores[k]},true)" ${v176HasRefinery()?'':'disabled'}>精錬所</button><button class="mini secondary" onclick="v176SellOre('${k}',${x.ores[k]})">原鉱売却</button></div></div>`).join('')}
function v176ElementsHtml(){const x=v176State(),rows=Object.entries(V176_ELEMENTS).filter(([k])=>(x.elements[k]||0)>.04).sort((a,b)=>v176ElementPrice(b[0])-v176ElementPrice(a[0]));if(!rows.length)return'<div class="hint">精錬済み元素はありません。</div>';return rows.map(([k,m])=>`<div class="market-row"><div><b>${m.icon} ${escapeHtml(m.name)} <span class="pill">${m.symbol}</span></b><div class="own">保有 ${v176Round(x.elements[k],1)} / ${Math.round(v176ElementPrice(k)).toLocaleString()} Cr/${m.unit}</div></div><div class="mini-stack"><button class="mini good" onclick="v176SellElement('${k}',1)" ${(x.elements[k]||0)<1?'disabled':''}>1売る</button><button class="mini good" onclick="v176SellElement('${k}',${x.elements[k]})">全売却</button></div></div>`).join('')}
function v176TrafficHtml(){const x=v176State(),rows=x.traffic.filter(t=>t.system===game.system&&t.status==='active'&&t.expires>=game.day),wrecks=x.wrecks.filter(w=>w.system===game.system&&!w.empty&&w.expires>=game.day);return `${rows.length?rows.map(t=>{const legal=v176IsLegalRaid(t.owner),cargo=Object.entries(t.cargo).map(([k,n])=>`${V176_ORES[k]?.name||k} ${n}`).join(' / ');return `<div class="contract ${legal?'battlefield':'hot'}"><div class="contract-head"><strong>${escapeHtml(t.name)}</strong><span class="pill">${legal?'合法交戦対象':'民間船・違法襲撃'}</span></div><p>${escapeHtml(FACTIONS[t.owner]?.short||t.owner)} / 護衛戦力 ${t.escort}<br>推定貨物：${escapeHtml(cargo)} / 推定原鉱価値 ${Math.round(t.value).toLocaleString()} Cr / Day ${t.expires}まで</p><div class="actions"><button class="warn" onclick="v176AttackMiner('${t.id}','board')" ${game.career?.faction===t.owner?'disabled':''}>無力化・接舷</button><button class="dangerBtn" onclick="v176AttackMiner('${t.id}','destroy')" ${game.career?.faction===t.owner?'disabled':''}>撃沈して回収</button></div></div>`}).join(''):'<div class="hint">現在地で追跡可能な採掘船はありません。</div>'}${wrecks.map(w=>`<div class="wreck battlefield"><b>${escapeHtml(HULLS[w.hullId]?.name||'採掘船')} 鉱石貨物残骸</b><p>船体 ${w.integrity}% / ${Object.entries(w.cargo).filter(([,n])=>n>0).map(([k,n])=>`${V176_ORES[k]?.name||k} ${n}`).join(' / ')}</p><button class="good" onclick="v176LootMiningWreck('${w.id}')">鉱石貨物を鹵獲</button></div>`).join('')}`}
function v176RenderMining(){
 const x=v176State(),sv=v176Survey(game.system),best=v176MoneyGuide(),dep=v176EnsureDeposits(game.system,x),rows=sv.rows.map(r=>`<button class="${x.selectedOre===r.k?'purple':'secondary'}" onclick="v176SelectOre('${r.k}')"><b>${V176_ORES[r.k].icon} ${escapeHtml(V176_ORES[r.k].name)}</b><br><small>品位 ${Math.round(r.grade)} / 埋蔵 ${Math.round(dep[r.k])} / 原鉱 ${v176OrePrice(r.k)} Cr</small></button>`).join('');
 return `<div data-v176="mining"><div class="panel"><div class="section-title"><h2>🧪 鉱床・元素採掘</h2><span class="pill">v1.76</span></div><p class="desc">スペクトル分析で鉱石を選び、採掘後に船内選鉱または精錬所処理します。鉱石ごとに複数元素を含み、希少元素価格は商品市場・産業需要と連動します。</p><div class="actions"><button onclick="v176Survey(game.system,true);render()">鉱床を再スキャン</button></div><div class="grid">${rows}</div><div class="hint">選択中：${x.selectedOre?escapeHtml(V176_ORES[x.selectedOre].name):'自動'} / 船内選鉱 回収率62% / 精錬所 回収率94%（12 Cr/原鉱u）</div></div><div class="wide-grid"><div class="panel"><h2>未精錬鉱石</h2>${v176OreCargoHtml()}</div><div class="panel"><h2>精錬済み元素</h2>${v176ElementsHtml()}</div></div><div class="panel"><div class="section-title"><h2>☠ 採掘船・鉱石貨物</h2><span class="pill">拿捕 / 海賊行為</span></div><p class="desc">交戦国の採掘船なら合法な通商破壊対象になり得ます。中立・友好国の民間採掘船を襲うと、v1.40の海賊罪・指名手配・関係悪化が発生します。接舷は難しい代わりに貨物残存率が高く、撃沈は成功しやすい代わりに鉱石を失います。</p>${v176TrafficHtml()}</div><div class="panel"><h2>💰 現在の収益分析</h2>${best.bestOre?`<div class="news-item"><b>採掘：</b>${escapeHtml(best.bestOre.name)} 推定 ${best.bestOre.expected.toLocaleString()} Cr/採掘（原鉱換算、現在地）</div>`:''}${best.shipyard?`<div class="news-item"><b>軍需造船：</b>有効オーダー最大 ${best.shipyard.pay.toLocaleString()} Cr（資材原価別）</div>`:'<div class="hint">自勢力造船所があれば戦時軍需オーダーが高収益候補になります。</div>'}${best.miner?`<div class="news-item"><b>採掘船貨物：</b>${escapeHtml(best.miner.name)} 推定 ${best.miner.value.toLocaleString()} Cr ${best.miner.legal?'（合法交戦対象）':'（違法襲撃リスク）'}</div>`:''}<div class="hint">v1.76では軍事契約の同日無限連打を是正。作戦宙域へ移動し、有償戦闘出撃は1日1件です。</div></div></div>`
}
function v176RenderMarketPanel(){return `<div data-v176="market" class="panel"><div class="section-title"><h2>⛏ 鉱石・元素スポット市場</h2><span class="pill">ORE / ELEMENT</span></div><p class="desc">原鉱はすぐ売れます。精錬は回収率・手数料・元素相場次第ですが、希少鉱では高い付加価値を狙えます。精錬済み元素はv1.69の商品ベンチマーク価格へ連動します。</p><div class="wide-grid"><div><h3>原鉱</h3>${v176OreCargoHtml()}</div><div><h3>元素</h3>${v176ElementsHtml()}</div></div></div>`}

// Balance fix: paid military operations must occur in their advertised system and
// cannot be regenerated/harvested infinitely in the same game day.
const v176ExecuteContractBase=typeof executeContract==='function'?executeContract:null;
if(v176ExecuteContractBase)executeContract=function(id){const c=game.contracts?.find(x=>x.id===id);if(!c)return;if(c.system!==game.system){toast?.(`作戦宙域 ${SYSTEMS[c.system]?.name||c.system} へ移動してください`);return}const x=v176State();if(x.lastPaidCombatDay===game.day){toast?.('本日の有償戦闘出撃は完了済み');return}x.lastPaidCombatDay=game.day;return v176ExecuteContractBase(id)};
const v176DirectBase=typeof directIntervene==='function'?directIntervene:null;
if(v176DirectBase)directIntervene=function(side){const x=v176State();if(x.lastPaidCombatDay===game.day){toast?.('本日の有償戦闘出撃は完了済み');return}x.lastPaidCombatDay=game.day;return v176DirectBase(side)};
if(typeof renderContracts==='function'){const b=renderContracts;renderContracts=function(){const o=b();const c=game.career?.activeContract&&game.contracts?.find(x=>x.id===game.career.activeContract),btn=document.querySelector?.('#contractPanel button.dangerBtn');if(btn&&c){if(c.system!==game.system){btn.disabled=true;btn.textContent=`${SYSTEMS[c.system]?.name||c.system}へ移動が必要`}else if(v176State().lastPaidCombatDay===game.day){btn.disabled=true;btn.textContent='本日の有償出撃済み'}}return o}}

function ensureV176State(){if(typeof ensureV175State==='function')ensureV175State();const x=v176State();v176Survey(game.system);v176EnsureTraffic();game.version=V176_BUILD;return x}
const v176InitBase=initV10;initV10=function(){const o=v176InitBase();ensureV176State();game.version=V176_BUILD;return o};
const v176AdvanceBase=gmAdvance;gmAdvance=function(){ensureV176State();const o=v176AdvanceBase();v176ProcessDaily();v176EnsureTraffic();game.version=V176_BUILD;return o};
if(typeof travel==='function'){const b=travel;travel=function(id,base){const o=b(id,base);try{ensureV176State();v176Survey(game.system);v176EnsureTraffic()}catch(_){}return o}}
if(typeof renderMine==='function'){const b=renderMine;renderMine=function(){const o=b();document.querySelector?.('[data-v176="mining"]')?.remove();document.getElementById('mine')?.insertAdjacentHTML('beforeend',v176RenderMining());return o}}
if(typeof renderMarket==='function'){const b=renderMarket;renderMarket=function(){const o=b();document.querySelector?.('[data-v176="market"]')?.remove();document.getElementById('market')?.insertAdjacentHTML('beforeend',v176RenderMarketPanel());return o}}
if(typeof render==='function'){const b=render;render=function(){const o=b();try{ensureV176State();const z=document.querySelector('header .title .badge')||document.querySelector('.version-badge');if(z)z.textContent='v1.76.0';const s=document.querySelector('header .sub');if(s)s.textContent='Ore Bodies / Element Refining / Mining Vessel Salvage';document.title='STAR FRONTIER v1.76.0 — Mining, Ores & Element Economy'}catch(_){}return o}}
if(typeof window!=='undefined')window.StarFrontierMiningV176={ensure:ensureV176State,state:v176State,ores:V176_ORES,elements:V176_ELEMENTS,survey:v176Survey,refine:v176RefineOre,attackMiner:v176AttackMiner,moneyGuide:v176MoneyGuide};
